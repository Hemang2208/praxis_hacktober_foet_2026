import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from datetime import datetime
from bson import ObjectId

# Load environment variables
load_dotenv()

async def setup_database():
    """Setup database with sample data"""
    
    client = AsyncIOMotorClient(os.getenv("MONGODB_URI"))
    db = client.get_database()
    
    print("🔧 Setting up database...")
    
    # Create collections
    projects_collection = db.projects
    users_collection = db.users
    
    # Sample user data
    sample_user = {
        "_id": ObjectId(),
        "name": "John Doe",
        "email": "john@example.com",
        "created_at": datetime.now(),
        "updated_at": datetime.now()
    }
    
    # Insert user if doesn't exist
    existing_user = await users_collection.find_one({"email": sample_user["email"]})
    if not existing_user:
        await users_collection.insert_one(sample_user)
        print(f"✅ Created sample user: {sample_user['email']}")
    else:
        sample_user = existing_user
    
    # Sample project data (matching your schema)
    sample_projects = [
        {
            "_id": ObjectId(),
            "title": "E-commerce Web Application",
            "description": "Build a full-stack e-commerce platform with React, Node.js, and MongoDB. Features include user authentication, product catalog, shopping cart, and payment integration.",
            "deadline": datetime(2024, 12, 31),
            "tags": ["react", "nodejs", "mongodb", "javascript", "fullstack", "ecommerce"],
            "document": "Project requirements and specifications document",
            "status": "in-progress",
            "tasks": [],
            "progress": 45,
            "team": [
                {"name": "Alice Johnson", "avatar": "avatar1.jpg"},
                {"name": "Bob Smith", "avatar": "avatar2.jpg"}
            ],
            "sprints": [
                {"name": "Sprint 1 - Setup", "progress": 100, "status": "completed"},
                {"name": "Sprint 2 - Frontend", "progress": 70, "status": "in-progress"}
            ],
            "timeline": [
                {
                    "title": "Project Started",
                    "description": "Initial project setup completed",
                    "type": "milestone",
                    "date": datetime(2024, 1, 15)
                }
            ],
            "resources": [
                {
                    "profile": "Full Stack Developer",
                    "skills": ["React", "Node.js", "MongoDB"],
                    "experience": "3 years",
                    "description": "Experienced in modern web development",
                    "type": "developer",
                    "avatar": "dev1.jpg",
                    "username": "fullstack_dev",
                    "name": "Development Expert",
                    "user": sample_user["_id"]
                }
            ],
            "user": sample_user["_id"],
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        },
        {
            "_id": ObjectId(),
            "title": "Machine Learning Data Analysis",
            "description": "Analyze customer behavior data using Python, pandas, and scikit-learn. Build predictive models and create data visualizations.",
            "deadline": datetime(2024, 11, 30),
            "tags": ["python", "machine-learning", "data-science", "pandas", "sklearn", "analytics"],
            "document": "Data analysis requirements and dataset description",
            "status": "planning",
            "tasks": [],
            "progress": 20,
            "team": [
                {"name": "Data Scientist", "avatar": "avatar3.jpg"}
            ],
            "sprints": [
                {"name": "Data Exploration", "progress": 30, "status": "in-progress"}
            ],
            "timeline": [],
            "resources": [],
            "user": sample_user["_id"],
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        },
        {
            "_id": ObjectId(),
            "title": "Mobile App Development",
            "description": "Create a cross-platform mobile application using React Native. Include features like user authentication, real-time messaging, and offline capability.",
            "deadline": datetime(2025, 2, 28),
            "tags": ["react-native", "mobile", "javascript", "ios", "android", "cross-platform"],
            "document": "Mobile app specification and design mockups",
            "status": "planning",
            "tasks": [],
            "progress": 5,
            "team": [],
            "sprints": [],
            "timeline": [],
            "resources": [],
            "user": sample_user["_id"],
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        }
    ]
    
    # Insert sample projects
    for project in sample_projects:
        existing = await projects_collection.find_one({"title": project["title"]})
        if not existing:
            await projects_collection.insert_one(project)
            print(f"✅ Created sample project: {project['title']}")
        else:
            print(f"⏭️  Project already exists: {project['title']}")
    
    # Create indexes for better performance
    await projects_collection.create_index("user")
    await projects_collection.create_index("status")
    await projects_collection.create_index("tags")
    
    # Create indexes for assessment collections
    await db.assessments.create_index("project_id")
    await db.submissions.create_index("user_id")
    await db.submissions.create_index("assessment_id")
    await db.results.create_index("submission_id")
    
    print("✅ Database setup completed!")
    
    # Print sample project IDs for testing
    print("\n📋 Sample Project IDs for testing:")
    cursor = projects_collection.find({}, {"_id": 1, "title": 1})
    async for project in cursor:
        print(f"  - {project['title']}: {str(project['_id'])}")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(setup_database())