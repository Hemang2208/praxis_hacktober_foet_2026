# assessment_quality_engine.py
"""
Assessment Quality Engine for generating high-quality, non-repetitive, domain-specific assessment questions.

This module ensures that:
1. Generated questions are never repeated across assessments
2. Questions are tailored to project domain (Web Dev, Mobile, Data Science, etc.)
3. Difficulty levels are validated and accurately reflected in question content
4. Questions deeply probe project-specific requirements
5. Question types are balanced and varied appropriately
"""

from enum import Enum
from typing import List, Dict, Set, Any, Optional, Tuple
import json
import hashlib
from models import DifficultyLevel, QuestionType


class ProjectDomain(str, Enum):
    """Supported project domains for specialized question generation"""
    WEB_DEVELOPMENT = "web_development"
    MOBILE_DEVELOPMENT = "mobile_development"
    DATA_SCIENCE = "data_science"
    DEVOPS = "devops"
    MACHINE_LEARNING = "machine_learning"
    API_SERVICE = "api_service"
    DATABASE = "database"
    CLOUD_INFRASTRUCTURE = "cloud_infrastructure"
    BLOCKCHAIN = "blockchain"
    IOT = "iot"
    GAME_DEVELOPMENT = "game_development"
    SAAS_PLATFORM = "saas_platform"


class QuestionDifficulty(str, Enum):
    """Question difficulty classification"""
    TRIVIAL = "trivial"  # Recall only
    BASIC = "basic"  # Comprehension
    INTERMEDIATE = "intermediate"  # Application
    ADVANCED = "advanced"  # Analysis/Synthesis
    EXPERT = "expert"  # Evaluation/Creation


class QuestionCategory(str, Enum):
    """Question categories for balanced assessment"""
    CONCEPTUAL = "conceptual"
    PRACTICAL = "practical"
    TECHNICAL = "technical"
    ARCHITECTURE = "architecture"
    SECURITY = "security"
    PERFORMANCE = "performance"
    BEST_PRACTICES = "best_practices"
    TROUBLESHOOTING = "troubleshooting"


class AssessmentQualityEngine:
    """
    Core engine for generating high-quality assessments with domain expertise.
    
    Features:
    - Automatic project domain detection from skills/tags
    - Question deduplication across assessments
    - Domain-specific question templates
    - Difficulty validation
    - Balanced category distribution
    """
    
    # Question fingerprint tracking to prevent duplication
    _asked_question_hashes: Set[str] = set()
    _question_history_cache: Dict[str, List[str]] = {}
    
    # Domain detection patterns
    DOMAIN_PATTERNS = {
        ProjectDomain.WEB_DEVELOPMENT: {
            "keywords": ["react", "vue", "angular", "html", "css", "javascript", "typescript", "frontend", "backend", "fullstack", "http", "rest", "express", "nextjs", "flask", "django"],
            "skills": ["web", "frontend", "backend", "fullstack"]
        },
        ProjectDomain.MOBILE_DEVELOPMENT: {
            "keywords": ["ios", "android", "react-native", "flutter", "swift", "kotlin", "mobile", "app", "native"],
            "skills": ["mobile", "ios", "android", "react-native", "flutter"]
        },
        ProjectDomain.DATA_SCIENCE: {
            "keywords": ["machine learning", "data", "analytics", "python", "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch", "jupyter", "analysis", "visualization"],
            "skills": ["data science", "machine learning", "analytics", "python", "data analysis"]
        },
        ProjectDomain.DEVOPS: {
            "keywords": ["docker", "kubernetes", "ci/cd", "jenkins", "gitlab", "github actions", "terraform", "ansible", "aws", "azure", "gcp", "deployment", "infrastructure"],
            "skills": ["devops", "docker", "kubernetes", "ci/cd", "infrastructure"]
        },
        ProjectDomain.MACHINE_LEARNING: {
            "keywords": ["deep learning", "neural network", "nlp", "computer vision", "model", "training", "tensorflow", "pytorch", "sklearn", "ml"],
            "skills": ["machine learning", "deep learning", "ai", "neural networks"]
        },
        ProjectDomain.API_SERVICE: {
            "keywords": ["api", "rest", "graphql", "soap", "microservice", "service", "endpoint", "integration"],
            "skills": ["api", "rest", "graphql", "microservice"]
        },
        ProjectDomain.DATABASE: {
            "keywords": ["database", "sql", "mongodb", "postgres", "mysql", "redis", "cassandra", "schema", "query", "orm"],
            "skills": ["database", "sql", "mongodb", "postgres", "redis"]
        },
        ProjectDomain.CLOUD_INFRASTRUCTURE: {
            "keywords": ["aws", "azure", "gcp", "cloud", "cloudformation", "bicep", "terraform", "vpc", "security group"],
            "skills": ["aws", "azure", "gcp", "cloud", "infrastructure"]
        },
        ProjectDomain.BLOCKCHAIN: {
            "keywords": ["blockchain", "ethereum", "bitcoin", "solidity", "web3", "smart contract", "crypto", "ledger"],
            "skills": ["blockchain", "solidity", "web3", "crypto"]
        },
        ProjectDomain.IOT: {
            "keywords": ["iot", "embedded", "arduino", "rasberry pi", "sensor", "mqtt", "iot gateway"],
            "skills": ["iot", "embedded", "arduino", "electronics"]
        },
        ProjectDomain.GAME_DEVELOPMENT: {
            "keywords": ["game", "unity", "unreal", "godot", "graphics", "3d", "2d", "gaming", "physics engine"],
            "skills": ["game development", "unity", "unreal", "godot"]
        },
        ProjectDomain.SAAS_PLATFORM: {
            "keywords": ["saas", "multi-tenant", "subscription", "billing", "user management", "tenant isolation"],
            "skills": ["saas", "multi-tenant", "subscription"]
        }
    }
    
    @staticmethod
    def detect_project_domain(
        title: str,
        description: str,
        tags: List[str],
        srs_document: str = ""
    ) -> ProjectDomain:
        """
        Detect project domain from title, description, tags, and SRS.
        
        Returns:
            ProjectDomain enum value
        """
        text = f"{title} {description} {' '.join(tags)} {srs_document}".lower()
        
        # Count matches per domain
        domain_scores = {}
        for domain, patterns in AssessmentQualityEngine.DOMAIN_PATTERNS.items():
            score = 0
            for keyword in patterns["keywords"]:
                score += text.count(keyword.lower())
            domain_scores[domain] = score
        
        # Return domain with highest score, default to WEB_DEVELOPMENT
        best_domain = max(domain_scores, key=domain_scores.get)
        return best_domain if domain_scores[best_domain] > 0 else ProjectDomain.WEB_DEVELOPMENT
    
    @staticmethod
    def estimate_question_difficulty(
        question: str,
        question_type: str,
        domain: ProjectDomain
    ) -> QuestionDifficulty:
        """
        Estimate difficulty level of a question based on content analysis.
        
        Factors:
        - Question length and complexity
        - Keywords indicating difficulty level
        - Question type (MC easier than short answer)
        """
        q_lower = question.lower()
        
        # Expert indicators
        expert_keywords = ["compare", "evaluate", "design", "architect", "optimize", "vulnerability", "edge cases", "refactor", "complex scenarios"]
        expert_score = sum(1 for k in expert_keywords if k in q_lower)
        
        # Advanced indicators
        advanced_keywords = ["analyze", "troubleshoot", "implement", "debug", "explain", "performance", "scalability", "security implications"]
        advanced_score = sum(1 for k in advanced_keywords if k in q_lower)
        
        # Intermediate indicators
        intermediate_keywords = ["use", "apply", "configure", "deploy", "integrate", "modify"]
        intermediate_score = sum(1 for k in intermediate_keywords if k in q_lower)
        
        # Basic indicators
        basic_keywords = ["what", "which", "define", "describe", "list"]
        basic_score = sum(1 for k in basic_keywords if k in q_lower)
        
        # Calculate total score
        total_score = (expert_score * 5) + (advanced_score * 4) + (intermediate_score * 2) + basic_score
        
        # Adjust for question type
        if question_type == "short_answer":
            total_score *= 1.2  # Short answers typically harder
        
        # Map score to difficulty
        if total_score >= 8:
            return QuestionDifficulty.EXPERT
        elif total_score >= 5:
            return QuestionDifficulty.ADVANCED
        elif total_score >= 3:
            return QuestionDifficulty.INTERMEDIATE
        elif total_score >= 1:
            return QuestionDifficulty.BASIC
        else:
            return QuestionDifficulty.TRIVIAL
    
    @staticmethod
    def validate_question_quality(
        question: str,
        correct_answer: str,
        explanation: str,
        options: Optional[List[str]] = None,
        question_type: str = "multiple_choice"
    ) -> Tuple[bool, List[str]]:
        """
        Validate question quality and provide feedback.
        
        Checks:
        - Question not too generic ("What is X?" pattern)
        - Answer is actually in options (for MC)
        - Explanation is substantive
        - No spelling/grammar issues
        """
        issues = []
        
        # Check for generic questions
        generic_patterns = [
            "what is", "what are", "define", "which of the following"
        ]
        if any(q in question.lower()[:20] for q in generic_patterns):
            if len(question) < 40:
                issues.append("Question is too generic or too short")
        
        # Check explanation length
        if len(explanation) < 20:
            issues.append("Explanation is too brief; should provide context")
        
        # Check for multiple choice specific issues
        if question_type == "multiple_choice" and options:
            if correct_answer not in options:
                issues.append("Correct answer not in options list")
            if len(options) < 3:
                issues.append("Multiple choice should have at least 3 options")
            if len(options) > 5:
                issues.append("Multiple choice should have at most 5 options")
        
        # Check for true/false specific issues
        if question_type == "true_false":
            if correct_answer not in ["True", "False", "true", "false"]:
                issues.append("True/False answer should be 'True' or 'False'")
        
        # Check for duplicate or very similar questions in history
        is_quality = len(issues) == 0
        return is_quality, issues
    
    @staticmethod
    def add_to_question_history(project_id: str, question: str) -> None:
        """Track asked question to prevent duplication in future assessments"""
        if project_id not in AssessmentQualityEngine._question_history_cache:
            AssessmentQualityEngine._question_history_cache[project_id] = []
        
        # Create question fingerprint (hash of question text for fast comparison)
        question_hash = hashlib.md5(question.lower().strip().encode()).hexdigest()
        AssessmentQualityEngine._asked_question_hashes.add(question_hash)
        AssessmentQualityEngine._question_history_cache[project_id].append(question)
    
    @staticmethod
    def has_duplicate_question(question: str, project_id: Optional[str] = None) -> bool:
        """Check if question is similar to previously asked questions"""
        question_hash = hashlib.md5(question.lower().strip().encode()).hexdigest()
        
        if question_hash in AssessmentQualityEngine._asked_question_hashes:
            return True
        
        if project_id and project_id in AssessmentQualityEngine._question_history_cache:
            # Check for semantic similarity (simple substring matching)
            q_words = set(question.lower().split())
            for prev_q in AssessmentQualityEngine._question_history_cache[project_id]:
                prev_words = set(prev_q.lower().split())
                # If >70% word overlap, consider it duplicate
                overlap = len(q_words & prev_words) / len(q_words | prev_words)
                if overlap > 0.7:
                    return True

        return False

    @staticmethod
    def generate_simplified_prompt_for_free_models(
        domain: ProjectDomain,
        num_questions: int,
        difficulty: DifficultyLevel,
        project_context: Dict[str, Any]
    ) -> Tuple[str, str]:
        """
        Generate optimized prompts for free models - with rich context but clear JSON formatting.
        Balances detail with simplicity for better JSON generation reliability.

        Returns:
            Tuple of (system_prompt, user_prompt)
        """

        # Domain-specific tips to guide free models better
        domain_hints = {
            ProjectDomain.WEB_DEVELOPMENT: "APIs, databases, frontend/backend, security, deployment",
            ProjectDomain.MOBILE_DEVELOPMENT: "iOS, Android, performance, UI, networking",
            ProjectDomain.DATA_SCIENCE: "data preprocessing, ML models, evaluation, visualization",
            ProjectDomain.DEVOPS: "containers, CI/CD, infrastructure, monitoring, security",
            ProjectDomain.MACHINE_LEARNING: "training, testing, optimization, deployment, data",
            ProjectDomain.API_SERVICE: "REST, endpoints, errors, authentication, documentation",
            ProjectDomain.DATABASE: "schema, queries, indexes, transactions, scaling",
            ProjectDomain.BLOCKCHAIN: "smart contracts, consensus, security, gas, wallets",
            ProjectDomain.SAAS_PLATFORM: "multi-tenancy, billing, compliance, scalability",
            ProjectDomain.CLOUD_INFRASTRUCTURE: "cloud services, networking, scaling, security",
        }
        
        domain_hint = domain_hints.get(domain, "implementation, design, testing, deployment")
        points_per_q = "1" if difficulty == DifficultyLevel.BEGINNER else "2" if difficulty == DifficultyLevel.INTERMEDIATE else "3"

        system_prompt = f"""You are PRAXIS, the official AI Support Agent, and an expert assessment generator for {domain.value.replace('_', ' ')}.

YOUR TASK: Generate exactly {num_questions} quality assessment questions.

CRITICAL RULES:
1. Output ONLY valid JSON - no markdown, no explanations, no comments
2. All keys and string values must use double quotes
3. Each question MUST have all 7 fields: question, type, options, correct_answer, explanation, points, domain
4. Use proper JSON formatting - no trailing commas

QUESTION TYPES:
- multiple_choice: Must have exactly 4 options. One must be correct_answer.
- true_false: Options MUST be ["True", "False"]. correct_answer is "True" or "False".
- short_answer: Options is empty list []. correct_answer is 1-2 sentence answer.

POINTS PER QUESTION: {points_per_q}

DIFFICULTY LEVEL: {difficulty.value}
{{
    "Beginner": "Basic concepts, definitions, simple scenarios",
    "Intermediate": "Apply knowledge, solve problems, combine concepts",  
    "Advanced": "System design, optimization, edge cases, analysis"
}}

DOMAIN FOCUS: {domain_hint}

JSON EXAMPLE (exactly this format):
{{
    "title": "Title here",
    "description": "Description here",
    "questions": [
        {{
            "question": "Question text here?",
            "type": "multiple_choice",
            "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
            "correct_answer": "Correct option text",
            "explanation": "Explanation (50+ words) why this is correct",
            "points": {points_per_q},
            "domain": "{domain.value}"
        }}
    ]
}}"""

        title = project_context.get('title', 'Project Assessment').replace('"', '')[:40]
        description = project_context.get('description', '').replace('"', '')[:200]
        tags = ', '.join(project_context.get('tags', ['General'])[:5])
        
        user_prompt = f"""Generate {num_questions} {difficulty.value.lower()} level assessment questions.

PROJECT INFORMATION:
- Title: {title}
- Description: {description}
- Tags/Skills: {tags}
- Domain: {domain.value}

CONTENT FOCUS:
Focus on {domain_hint}. Make questions specific to {title} project requirements.

REQUIREMENTS:
- Generate EXACTLY {num_questions} questions (not more, not less)
- Mix question types: ~40% multiple choice, ~40% short answer, ~20% true/false
- Questions must be {difficulty.value.lower()} level ({"conceptual, definitions, recall" if difficulty == DifficultyLevel.BEGINNER else "practical application, problem-solving" if difficulty == DifficultyLevel.INTERMEDIATE else "system design, deep analysis, optimization"})
- Each explanation must be 50+ words
- No duplicate or similar questions
- All questions should be relevant to {domain.value.lower()}

OUTPUT: Return ONLY the JSON object. Start with {{ and end with }}.
No markdown code blocks. No text before or after the JSON.
Valid JSON with proper quotes and formatting."""

        return system_prompt, user_prompt

    @staticmethod
    def generate_prompt_for_domain(
        domain: ProjectDomain,
        num_questions: int,
        difficulty: DifficultyLevel,
        project_context: Dict[str, Any],
        existing_questions: List[str] = None
    ) -> Tuple[str, str]:
        """
        Generate domain-specific system and user prompts.
        
        Returns:
            Tuple of (system_prompt, user_prompt)
        """
        
        # Domain-specific focus areas
        domain_focus = {
            ProjectDomain.WEB_DEVELOPMENT: [
                "frontend frameworks and state management",
                "backend API design and REST principles",
                "database schema design",
                "authentication and authorization",
                "responsive design and UX principles",
                "deployment and DevOps practices"
            ],
            ProjectDomain.MOBILE_DEVELOPMENT: [
                "platform-specific UI guidelines (iOS/Android)",
                "mobile performance optimization",
                "battery and memory management",
                "offline-first architecture",
                "push notifications and background processes",
                "native API integration"
            ],
            ProjectDomain.DATA_SCIENCE: [
                "data preprocessing and cleaning",
                "statistical analysis and hypothesis testing",
                "feature engineering and selection",
                "model evaluation metrics",
                "data visualization best practices",
                "handling imbalanced datasets"
            ],
            ProjectDomain.DEVOPS: [
                "containerization and orchestration",
                "CI/CD pipeline design",
                "infrastructure as code",
                "monitoring and logging strategies",
                "security and compliance",
                "disaster recovery and high availability"
            ],
            ProjectDomain.MACHINE_LEARNING: [
                "model selection and training",
                "hyperparameter tuning",
                "overfitting and regularization",
                "transfer learning",
                "neural network architectures",
                "production deployment of models"
            ],
            ProjectDomain.API_SERVICE: [
                "API design principles (REST/GraphQL)",
                "rate limiting and throttling",
                "API versioning strategies",
                "error handling and status codes",
                "API documentation",
                "security and authentication"
            ],
            ProjectDomain.DATABASE: [
                "normalization and schema design",
                "indexing strategies",
                "query optimization",
                "transactions and ACID properties",
                "replication and backup",
                "scaling strategies (vertical/horizontal)"
            ],
            ProjectDomain.CLOUD_INFRASTRUCTURE: [
                "cloud service models (IaaS/PaaS/SaaS)",
                "networking and VPC design",
                "security groups and firewalls",
                "load balancing",
                "auto-scaling policies",
                "cost optimization"
            ],
            ProjectDomain.BLOCKCHAIN: [
                "consensus mechanisms",
                "smart contract security",
                "gas optimization",
                "wallet management",
                "DeFi protocols",
                "cryptographic primitives"
            ],
            ProjectDomain.IOT: [
                "sensor integration and calibration",
                "wireless protocols (WiFi, BLE, Zigbee)",
                "power management",
                "real-time processing",
                "edge computing",
                "data aggregation"
            ],
            ProjectDomain.GAME_DEVELOPMENT: [
                "game loop architecture",
                "physics engine integration",
                "collision detection",
                "animation and sprite management",
                "input handling",
                "performance optimization for gaming"
            ],
            ProjectDomain.SAAS_PLATFORM: [
                "multi-tenant architecture",
                "subscription and billing systems",
                "feature flags and A/B testing",
                "data isolation",
                "compliance and data privacy",
                "scalability for multi-tenant systems"
            ]
        }
        
        focus_areas = domain_focus.get(domain, ["general concepts", "implementation", "best practices"])
        
        # Difficulty-specific expectations
        difficulty_expectations = {
            DifficultyLevel.BEGINNER: "test fundamental understanding, basic definitions, simple scenarios, recall of key concepts",
            DifficultyLevel.INTERMEDIATE: "test practical application, problem-solving, design decisions, integration of multiple concepts",
            DifficultyLevel.ADVANCED: "test deep analysis, system design, optimization, edge cases, architectural decisions, security implications"
        }
        
        system_prompt = f"""
You are PRAXIS, the official AI Support Agent, and an expert assessment designer specializing in {domain.value.replace('_', ' ')} projects.

Your task is to create a comprehensive, non-repetitive assessment that accurately measures deep understanding of this project domain.

CRITICAL REQUIREMENTS:
1. Generate exactly {num_questions} UNIQUE questions - NO REPETITION
2. Ensure questions are appropriately challenging for {difficulty.value} level
3. Focus on: {', '.join(focus_areas[:3])}
4. Each question must:
   - Be SPECIFIC to project requirements (not generic)
   - Have SUBSTANTIVE explanation (minimum 50 words)
   - Test actual understanding, not memorization
   - Include technical depth appropriate for {difficulty.value} level

DIFFICULTY CALIBRATION FOR {difficulty.value}:
{difficulty_expectations.get(difficulty, "test comprehensive understanding")}

QUESTION TYPES (distribute evenly):
- Multiple Choice: 40-50% (3-4 options, one clearly correct)
- True/False: 20-30% (require explanation)
- Short Answer: 20-40% (require 2-3 sentence answers minimum)

POINTS ALLOCATION:
- Beginner: 1-2 points per question
- Intermediate: 2-3 points per question
- Advanced: 3-5 points per question

OUTPUT FORMAT:
Return ONLY valid JSON with this structure:
{{
    "title": "Assessment Title",
    "description": "Description explaining assessment scope",
    "questions": [
        {{
            "question": "Specific, detailed question text",
            "type": "multiple_choice|true_false|short_answer",
            "options": ["A", "B", "C"] if multiple choice,
            "correct_answer": "Correct answer",
            "explanation": "50+ word detailed explanation",
            "points": 1-5
        }}
    ]
}}

JSON FORMAT REQUIREMENTS:
- ALL keys must be in double quotes
- ALL string values must be in double quotes
- Do NOT include markdown code blocks
- Do NOT include any text before or after the JSON
- Do NOT use single quotes anywhere - use double quotes ONLY
- Each question object must have all required fields
- Points must be a NUMBER, not a string

ANTI-PATTERNS TO AVOID:
- Generic questions like "What is X?"
- Vague phrases: "discuss", "tell me about"
- Questions without clear correct answers
- Duplicate or near-duplicate questions
- Questions unrelated to project domain
- Simple recall questions for Advanced level

ENSURE:
- Questions probe ACTUAL project requirements
- No yes/no questions in multiple choice
- Explanations reference project-specific terminology
- Difficulty progression across questions
"""
        
        existing_q_context = ""
        if existing_questions:
            existing_q_context = f"\n\nPREVIOUSLY ASKED QUESTIONS (DO NOT REPEAT):\n" + "\n".join(f"- {q}" for q in existing_questions[:10])
        
        user_prompt = f"""
Generate {num_questions} assessment questions for this {domain.value.replace('_', ' ')} project.

PROJECT DETAILS:
Title: {project_context.get('title', 'Untitled Project')}
Description: {project_context.get('description', 'No description provided')}
Key Skills/Tags: {', '.join(project_context.get('tags', ['general']))}

PROJECT REQUIREMENTS:
{project_context.get('srs_document', 'No SRS document provided')[:1000] or 'Not provided'}

PROJECT PLAN:
{project_context.get('plan', 'No plan provided')[:1000] or 'Not provided'}

DIFFICULTY LEVEL: {difficulty.value}
TARGET DOMAIN: {domain.value}{existing_q_context}

IMPORTANT:
1. Make questions SPECIFIC to this project's requirements
2. Avoid questions that could apply to any project
3. Test understanding of actual technical decisions needed for this project
4. Include {num_questions} UNIQUE questions only
5. Return ONLY the JSON object, no markdown or extra text
"""
        
        return system_prompt, user_prompt
    
    @staticmethod
    def get_category_distribution(num_questions: int) -> Dict[QuestionCategory, int]:
        """
        Calculate balanced distribution of question categories.
        
        Returns:
            Dict mapping category to number of questions
        """
        categories = [
            QuestionCategory.CONCEPTUAL,
            QuestionCategory.PRACTICAL,
            QuestionCategory.TECHNICAL,
            QuestionCategory.ARCHITECTURE,
            QuestionCategory.BEST_PRACTICES
        ]
        
        dist = {}
        base_count = num_questions // len(categories)
        remainder = num_questions % len(categories)
        
        for i, cat in enumerate(categories):
            dist[cat] = base_count + (1 if i < remainder else 0)
        
        return dist
    
    @staticmethod
    def generate_validation_criteria(
        domain: ProjectDomain,
        difficulty: DifficultyLevel
    ) -> Dict[str, Any]:
        """
        Generate domain-specific validation criteria for assessment quality.
        
        Returns:
            Dict with validation rules and thresholds
        """
        return {
            "domain": domain.value,
            "difficulty": difficulty.value,
            "min_explanation_length": 50 if difficulty == DifficultyLevel.BEGINNER else 75,
            "min_options": 3,
            "max_options": 5,
            "min_points": 1 if difficulty == DifficultyLevel.BEGINNER else 2,
            "max_points": 3 if difficulty == DifficultyLevel.BEGINNER else 5,
            "max_generic_questions": 2,  # Max 2 generic questions allowed
            "require_domain_keywords": 3,  # Must reference domain at least 3 times
            "min_unique_questions": 0.95,  # 95% of questions must be unique
        }


class AssessmentQuestionValidator:
    """Validates and improves generated assessment questions"""
    
    @staticmethod
    def validate_assessment_questions(
        questions: List[Dict[str, Any]],
        domain: ProjectDomain,
        difficulty: DifficultyLevel,
        project_id: str
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Validate and report on assessment quality.
        
        Returns:
            Tuple of (validated_questions, validation_report)
        """
        validation_report = {
            "total_questions": len(questions),
            "duplicates_found": 0,
            "quality_issues": [],
            "difficulty_mismatches": [],
            "passing_validation": True
        }
        
        valid_questions = []
        seen_hashes = set()
        
        for idx, q in enumerate(questions):
            question_text = q.get("question", "")
            
            # Check for duplicates
            q_hash = hashlib.md5(question_text.lower().strip().encode()).hexdigest()
            if q_hash in seen_hashes:
                validation_report["duplicates_found"] += 1
                validation_report["passing_validation"] = False
                continue
            seen_hashes.add(q_hash)
            
            # Check for global duplicates
            if AssessmentQualityEngine.has_duplicate_question(question_text, project_id):
                validation_report["duplicates_found"] += 1
                validation_report["passing_validation"] = False
                continue
            
            # Validate quality
            is_quality, issues = AssessmentQualityEngine.validate_question_quality(
                question=question_text,
                correct_answer=q.get("correct_answer", ""),
                explanation=q.get("explanation", ""),
                options=q.get("options"),
                question_type=q.get("type", "multiple_choice")
            )
            
            if not is_quality:
                validation_report["quality_issues"].append({
                    "questionIndex": idx,
                    "issues": issues
                })
            
            # Validate difficulty
            est_difficulty = AssessmentQualityEngine.estimate_question_difficulty(
                question=question_text,
                question_type=q.get("type", "multiple_choice"),
                domain=domain
            )
            
            # Allow 1 level variance
            expected_level = {
                DifficultyLevel.BEGINNER: QuestionDifficulty.BASIC,
                DifficultyLevel.INTERMEDIATE: QuestionDifficulty.INTERMEDIATE,
                DifficultyLevel.ADVANCED: QuestionDifficulty.ADVANCED
            }
            
            if est_difficulty not in [expected_level.get(difficulty), 
                                       QuestionDifficulty(list(QuestionDifficulty)[list(QuestionDifficulty).index(expected_level.get(difficulty, QuestionDifficulty.INTERMEDIATE)) - 1] if list(QuestionDifficulty).index(expected_level.get(difficulty, QuestionDifficulty.INTERMEDIATE)) > 0 else QuestionDifficulty.TRIVIAL),
                                       QuestionDifficulty(list(QuestionDifficulty)[list(QuestionDifficulty).index(expected_level.get(difficulty, QuestionDifficulty.INTERMEDIATE)) + 1] if list(QuestionDifficulty).index(expected_level.get(difficulty, QuestionDifficulty.INTERMEDIATE)) < len(QuestionDifficulty) - 1 else QuestionDifficulty.EXPERT)]:
                validation_report["difficulty_mismatches"].append({
                    "questionIndex": idx,
                    "expected": difficulty.value,
                    "estimated": est_difficulty.value,
                    "question": question_text[:50] + "..."
                })
            
            # Add question history
            AssessmentQualityEngine.add_to_question_history(project_id, question_text)
            valid_questions.append(q)
        
        return valid_questions, validation_report


# Export for use in llm_service.py
__all__ = [
    "AssessmentQualityEngine",
    "AssessmentQuestionValidator",
    "ProjectDomain",
    "QuestionDifficulty",
    "QuestionCategory"
]
