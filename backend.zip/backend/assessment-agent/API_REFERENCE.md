# Assessment Agent - API Reference

## Base URL

```
http://localhost:8001
```

## Health Check

### GET /health

Check if the service is running.

**Response:**

```json
{
  "status": "healthy",
  "timestamp": "2025-01-01T00:00:00Z"
}
```

---

## Assessment Generation

### POST /assessments/generate

Generate a new assessment based on project specifications.

**Request Body:**

```json
{
  "project_id": "string",
  "num_questions": "integer (1-50)",
  "difficulty_level": "beginner|intermediate|advanced",
  "project_title": "string",
  "project_description": "string",
  "project_srs_document": "string (optional)",
  "project_plan": "string (optional)",
  "project_tags": ["string"] (optional)
}
```

**Response (200 OK):**

```json
{
  "id": "string",
  "project_id": "string",
  "title": "string",
  "description": "string",
  "difficulty": "beginner|intermediate|advanced",
  "questions": [
    {
      "question": "string",
      "type": "multiple_choice|true_false|short_answer",
      "options": ["string"] | null,
      "correct_answer": "string",
      "explanation": "string",
      "points": "integer"
    }
  ],
  "total_points": "integer",
  "time_limit": "integer",
  "created_at": "string (ISO 8601)",
  "created_by": "string (optional)"
}
```

**Error Responses:**

- 400: Invalid input (num_questions out of range)
- 404: Project not found
- 500: LLM or database error

**Example:**

```bash
curl -X POST "http://localhost:8001/assessments/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": "507f1f77bcf86cd799439011",
    "num_questions": 10,
    "difficulty_level": "intermediate",
    "project_title": "Web App",
    "project_description": "Build a web app",
    "project_tags": ["React", "Node.js"]
  }'
```

---

## Assessment Submission & Evaluation

### POST /assessments/{assessment_id}/submit

Submit student answers and get evaluation results.

**Path Parameters:**

- `assessment_id` (string): ID of the assessment

**Request Body:**

```json
{
  "student_id": "string",
  "answers": [
    {
      "question_index": "integer",
      "answer": "string"
    }
  ]
}
```

**Response (200 OK):**

```json
{
  "id": "string",
  "submission_id": "string",
  "assessment_id": "string",
  "student_id": "string",
  "score": {
    "total_score": "integer",
    "max_score": "integer",
    "percentage": "number",
    "correct_answers": "integer",
    "total_questions": "integer"
  },
  "feedback": {
    "overall_feedback": "string",
    "strengths": ["string"],
    "improvements": ["string"],
    "recommendations": ["string"]
  },
  "question_feedback": [
    {
      "question_index": "integer",
      "question": "string",
      "student_answer": "string",
      "correct_answer": "string",
      "is_correct": "boolean",
      "points_earned": "integer",
      "max_points": "integer",
      "feedback": "string"
    }
  ],
  "completed_at": "string (ISO 8601)",
  "status": "string"
}
```

**Error Responses:**

- 400: Invalid answer format
- 404: Assessment not found
- 500: Evaluation error

**Example:**

```bash
curl -X POST "http://localhost:8001/assessments/507f1f77bcf86cd799439012/submit" \
  -H "Content-Type: application/json" \
  -d '{
    "student_id": "student123",
    "answers": [
      {"question_index": 0, "answer": "Option A"},
      {"question_index": 1, "answer": "true"}
    ]
  }'
```

---

## Assessment Retrieval

### GET /assessments/{assessment_id}

Get a complete assessment with answers (for admin/review purposes).

**Path Parameters:**

- `assessment_id` (string): ID of the assessment

**Response (200 OK):**
Returns full Assessment object (see POST /assessments/generate response)

**Error Responses:**

- 404: Assessment not found

**Example:**

```bash
curl "http://localhost:8001/assessments/507f1f77bcf86cd799439012"
```

---

### GET /assessments/{assessment_id}/take

Get assessment questions for student (without correct answers).

**Path Parameters:**

- `assessment_id` (string): ID of the assessment

**Response (200 OK):**

```json
{
  "id": "string",
  "title": "string",
  "description": "string",
  "difficulty": "string",
  "questions": [
    {
      "question": "string",
      "type": "string",
      "options": ["string"] | null,
      "points": "integer"
    }
  ],
  "total_points": "integer",
  "time_limit": "integer"
}
```

**Error Responses:**

- 404: Assessment not found

**Example:**

```bash
curl "http://localhost:8001/assessments/507f1f77bcf86cd799439012/take"
```

---

## Results Management

### GET /results/{submission_id}

Get evaluation result for a specific submission.

**Path Parameters:**

- `submission_id` (string): ID of the submission

**Response (200 OK):**
Returns full AssessmentResult object (see POST /assessments/{assessment_id}/submit response)

**Error Responses:**

- 404: Result not found

**Example:**

```bash
curl "http://localhost:8001/results/507f1f77bcf86cd799439014"
```

---

### GET /students/{student_id}/results

Get all assessment results for a student.

**Path Parameters:**

- `student_id` (string): ID of the student

**Query Parameters:**

- `project_id` (string, optional): Filter by project ID

**Response (200 OK):**

```json
{
  "results": [
    {
      "submission_id": "string",
      "assessment_id": "string",
      "assessment_title": "string",
      "project_id": "string",
      "score": {
        "total_score": "integer",
        "max_score": "integer",
        "percentage": "number",
        "correct_answers": "integer",
        "total_questions": "integer"
      },
      "feedback": {
        "overall_feedback": "string",
        "strengths": ["string"],
        "improvements": ["string"],
        "recommendations": ["string"]
      },
      "status": "string",
      "submitted_at": "string (ISO 8601)",
      "completed_at": "string (ISO 8601)"
    }
  ],
  "total": "integer"
}
```

**Error Responses:**

- 404: Student not found

**Examples:**

```bash
# Get all results for student
curl "http://localhost:8001/students/student123/results"

# Get results for specific project
curl "http://localhost:8001/students/student123/results?project_id=507f1f77bcf86cd799439011"
```

---

## Project Assessments

### GET /projects/{project_id}/assessments

Get all assessments created for a project.

**Path Parameters:**

- `project_id` (string): ID of the project

**Response (200 OK):**

```json
[
  {
    "id": "string",
    "project_id": "string",
    "title": "string",
    "description": "string",
    "difficulty": "string",
    "questions": [...],
    "total_points": "integer",
    "time_limit": "integer",
    "created_at": "string (ISO 8601)",
    "created_by": "string (optional)"
  }
]
```

**Error Responses:**

- 404: Project not found

**Example:**

```bash
curl "http://localhost:8001/projects/507f1f77bcf86cd799439011/assessments"
```

---

## Status Codes

| Code | Meaning                               |
| ---- | ------------------------------------- |
| 200  | Success                               |
| 400  | Bad Request (validation error)        |
| 404  | Not Found (resource doesn't exist)    |
| 408  | Request Timeout (LLM service timeout) |
| 500  | Internal Server Error                 |

---

## Request Headers

All requests should include:

```
Content-Type: application/json
```

---

## Response Format

All successful responses return JSON with:

- `200 OK`: Resource object or array
- `4xx/5xx`: Error object with "detail" field

---

## Pagination

Currently, the API does not support pagination. Use client-side filtering for large result sets.

---

## Rate Limiting

No built-in rate limiting is implemented. Recommended for production:

- Implement rate limiting middleware
- Configure by API key or user
- Set reasonable limits (e.g., 100 requests/minute)

---

## Authentication

Currently, the API does not require authentication. Recommended for production:

- Implement JWT or OAuth2
- Validate API keys
- Track API usage per user

---

## Data Types

### DifficultyLevel (enum)

- `"beginner"`
- `"intermediate"`
- `"advanced"`

### QuestionType (enum)

- `"multiple_choice"`
- `"true_false"`
- `"short_answer"`

### ISO 8601 Timestamp

Example: `"2026-02-06T10:30:45.123456"`

---

## Common Error Messages

| Error                                            | Cause                     | Solution                          |
| ------------------------------------------------ | ------------------------- | --------------------------------- |
| "Number of questions must be between 1 and 50"   | Invalid num_questions     | Use value between 1 and 50        |
| "Assessment not found"                           | Invalid assessment_id     | Verify assessment_id is correct   |
| "Project not found"                              | Invalid project_id        | Verify project_id exists          |
| "LLM request timed out"                          | LLM service slow          | Reduce num_questions or try again |
| "Failed to parse assessment generation response" | LLM returned invalid JSON | Try again with simpler prompts    |

---

## Examples by Language

### Python (requests)

```python
import requests

# Generate assessment
response = requests.post(
    "http://localhost:8001/assessments/generate",
    json={"project_id": "123", "num_questions": 5, ...}
)
assessment = response.json()

# Submit answers
response = requests.post(
    f"http://localhost:8001/assessments/{assessment['id']}/submit",
    json={"student_id": "s123", "answers": [...]}
)
result = response.json()
```

### JavaScript (fetch)

```javascript
// Generate assessment
const response = await fetch(
  "http://localhost:8001/assessments/generate",
  {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      project_id: "123",
      num_questions: 5,
      // ... other params
    })
  }
);
const assessment = await response.json();

// Submit answers
const result_response = await fetch(
  `http://localhost:8001/assessments/${assessment.id}/submit`,
  {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      student_id: "s123",
      answers: [...]
    })
  }
);
const result = await result_response.json();
```

### cURL

```bash
# Generate assessment
curl -X POST "http://localhost:8001/assessments/generate" \
  -H "Content-Type: application/json" \
  -d '{"project_id":"123","num_questions":5,...}'

# Submit answers
curl -X POST "http://localhost:8001/assessments/ASSESSMENT_ID/submit" \
  -H "Content-Type: application/json" \
  -d '{"student_id":"s123","answers":[...]}'
```

---

## Versioning

Current API Version: **1.0.0**

No versioning prefix in URLs. Breaking changes will bump major version.

---

## Support

For detailed specification and implementation guide, see:

- [ASSESSMENT_SPEC.md](./ASSESSMENT_SPEC.md) - Complete specification
- [QUICK_START.md](./QUICK_START.md) - Getting started guide
- [IMPLEMENTATION_SUMMARY.md](./IMPLEMENTATION_SUMMARY.md) - Implementation details
