# assessment.py

from motor.motor_asyncio import AsyncIOMotorDatabase
from models import (
    Assessment, AssessmentSubmission, AssessmentResult, Project, DifficultyLevel,
    AssessmentGenerationRequest, ScoreResult, AssessmentFeedback, QuestionFeedbackItem,
    AssessmentComparisonStats, TopPerformer
)
from llm_service import llm_service
from database import get_database
from bson import ObjectId
from typing import List, Dict, Any, Optional
import json
import logging
from datetime import datetime
import statistics

class AssessmentService:
    def __init__(self, db: AsyncIOMotorDatabase):
        self.db = db
        self.assessments_collection = db.assessments
        self.submissions_collection = db.submissions
        self.results_collection = db.results
        self.projects_collection = db.projects
    
    # ============================================================================
    # 1.1 ASSESSMENT GENERATION
    # ============================================================================
    
    async def generate_assessment(self, request: AssessmentGenerationRequest) -> Assessment:
        """
        Generate assessment based on specifications.
        
        Input:
            - project_id: ID of project (all other info fetched from database)
            - num_questions: Number of questions (1-50)
            - difficulty_level: Difficulty level
        
        Process:
            1. Fetches project data from database
            2. Analyzes project requirements and SRS documentation
            3. Evaluates skills required from the project plan
            4. Considers difficulty level and project complexity
            5. Generates questions based on project tags and technical requirements
            6. Creates diverse mix of question types
            7. Assigns appropriate points and explanations
        
        Returns:
            Assessment object with structured JSON following the output schema
        """
        
        # Fetch project data from database
        try:
            project_data = await self.projects_collection.find_one({"_id": ObjectId(request.project_id)})
            if not project_data:
                raise ValueError(f"Project not found with ID: {request.project_id}")
        except Exception as e:
            if "not a valid ObjectId" in str(e):
                raise ValueError(f"Invalid project ID format: {request.project_id}")
            raise ValueError(f"Failed to fetch project: {str(e)}")
        
        # Extract project information
        project_title = project_data.get("title", "")
        project_description = project_data.get("description", "")
        project_srs_document = project_data.get("srs_document") or project_data.get("document") or ""
        project_plan = project_data.get("plan", "")
        project_tags = project_data.get("tags", [])
        
        # Generate assessment using LLM with fetched project context
        assessment = await llm_service.generate_assessment(
            num_questions=request.num_questions,
            difficulty_level=request.difficulty_level,
            project_title=project_title,
            project_description=project_description,
            project_srs_document=project_srs_document,
            project_plan=project_plan,
            project_tags=project_tags,
            project_data={}
        )
        
        # Add project_id and save to database
        assessment.project_id = request.project_id
        assessment_dict = assessment.dict(exclude={"id"})
        assessment_dict["_id"] = ObjectId()
        assessment_dict["created_at"] = datetime.utcnow()
        
        await self.assessments_collection.insert_one(assessment_dict)
        assessment.id = str(assessment_dict["_id"])
        
        return assessment
    
    async def create_assessment(self, project_id: str, difficulty: DifficultyLevel, num_questions: int = 10) -> Assessment:
        """Create a new assessment for a project (legacy method)"""
        
        # Build assessment generation request with only project_id
        # All project data will be fetched from database
        request = AssessmentGenerationRequest(
            project_id=project_id,
            num_questions=num_questions,
            difficulty_level=difficulty
        )
        
        return await self.generate_assessment(request)
    
    # ============================================================================
    # Assessment Retrieval
    # ============================================================================
    
    async def get_assessment(self, assessment_id: str, include_deleted: bool = False) -> Optional[Assessment]:
        """Get assessment by ID"""
        try:
            # Validate and convert assessment_id to ObjectId
            try:
                obj_id = ObjectId(assessment_id)
                logging.info(f"Converted assessment_id to ObjectId: {assessment_id} -> {obj_id}")
            except Exception as e:
                logging.error(f"Invalid assessment ID format '{assessment_id}': {e}")
                raise ValueError(f"Invalid ObjectId format: {assessment_id}")
            
            logging.info(f"Querying database for assessment with _id={obj_id}")
            assessment_data = await self.assessments_collection.find_one({"_id": obj_id})
            
            if not assessment_data:
                logging.warning(f"No assessment document found for _id={obj_id}")
                return None
            
            if not include_deleted and assessment_data.get("status") == "deleted":
                logging.info(f"Assessment {obj_id} is marked as deleted, skipping")
                return None
            
            # Try to construct Assessment object
            try:
                assessment_data["id"] = str(assessment_data["_id"])
                assessment = Assessment(**assessment_data)
                logging.info(f"Successfully constructed Assessment object from DB for {obj_id}")
                return assessment
            except Exception as e:
                logging.error(f"Failed to construct Assessment model from data: {e}")
                logging.error(f"Assessment data keys: {assessment_data.keys()}")
                raise ValueError(f"Assessment data validation failed: {str(e)}")
                
        except ValueError as e:
            logging.error(f"ValueError getting assessment {assessment_id}: {e}")
            return None
        except Exception as e:
            logging.error(f"Unexpected error fetching assessment {assessment_id}: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    async def get_assessments_by_project(self, project_id: str, include_deleted: bool = False) -> List[Assessment]:
        """Get all assessments for a project"""
        query: Dict[str, Any] = {"project_id": project_id}
        if not include_deleted:
            query["status"] = {"$ne": "deleted"}
        cursor = self.assessments_collection.find(query)
        assessments = []
        
        async for assessment_data in cursor:
            assessment_data["id"] = str(assessment_data["_id"])
            assessments.append(Assessment(**assessment_data))
        
        return assessments
    
    async def update_assessment(self, assessment_id: str, update_data: Dict[str, Any]) -> Optional[Assessment]:
        """Update assessment details (excluding questions logic for simplicity)"""
        try:
            # Prevent updating critical fields
            for field in ["_id", "id", "project_id", "created_at"]:
                if field in update_data:
                    del update_data[field]
                    
            result = await self.assessments_collection.update_one(
                {"_id": ObjectId(assessment_id)},
                {"$set": update_data}
            )
            if result.matched_count > 0:
                return await self.get_assessment(assessment_id)
            return None
        except Exception as e:
            print(f"Error updating assessment: {e}")
            return None

    async def soft_delete_assessment(self, assessment_id: str) -> bool:
        """Soft delete an assessment and clear its question cache"""
        try:
            # Get the assessment to find project_id
            assessment_data = await self.assessments_collection.find_one({"_id": ObjectId(assessment_id)})
            if assessment_data:
                project_id = assessment_data.get("project_id")
                # Clear question deduplication cache for this project
                if project_id:
                    from assessment_quality_engine import AssessmentQualityEngine
                    if project_id in AssessmentQualityEngine._question_history_cache:
                        logging.info(f"Clearing question cache for project {project_id}")
                        del AssessmentQualityEngine._question_history_cache[project_id]
            
            # Soft delete the assessment
            result = await self.assessments_collection.update_one(
                {"_id": ObjectId(assessment_id)},
                {"$set": {"status": "deleted"}}
            )
            return result.matched_count > 0
        except Exception as e:
            logging.error(f"Error soft deleting assessment: {e}")
            return False
    
    # ============================================================================
    # 1.2 ASSESSMENT EVALUATION
    # ============================================================================
    
    async def evaluate_assessment(self, submission: AssessmentSubmission) -> AssessmentResult:
        """
        Evaluate assessment submission.
        
        Input:
            - Questions with student answers
            - Correct answers from assessment
            - Assessment metadata
        
        Process:
            1. Receives assessment submission with user's answers
            2. Automatically checks True/False and Multiple Choice Questions
            3. Uses AI evaluation for short answers and subjective responses
            4. Calculates percentage of correctness for each answer
            5. Aggregates total score and provides detailed feedback
            6. Generates question-wise feedback for learning purposes
        
        Returns:
            AssessmentResult following the output schema
        """
        
        # Get assessment
        assessment = await self.get_assessment(submission.assessmentId)
        if not assessment:
            raise ValueError("Assessment not found")
        
        # Evaluate each question
        question_feedback_list = []
        total_points_earned = 0
        correct_count = 0
        
        for answer in submission.answers:
            if answer.questionIndex >= len(assessment.questions):
                raise ValueError(f"Invalid question index: {answer.questionIndex}")
            
            question = assessment.questions[answer.questionIndex]
            
            # Evaluate based on question type
            if question.type.value in ["multiple_choice", "true_false"]:
                # Direct evaluation for objective questions
                is_correct = answer.answer.strip().lower() == question.correct_answer.strip().lower()
                points_earned = question.points if is_correct else 0
                feedback_text = "Correct!" if is_correct else f"Incorrect. The correct answer is: {question.correct_answer}"
            else:
                # Use AI for short answer evaluation
                is_correct, points_earned, feedback_text = await llm_service.evaluate_short_answer(
                    question=question.question,
                    correct_answer=question.correct_answer,
                    student_answer=answer.answer,
                    max_points=question.points
                )
            
            if is_correct:
                correct_count += 1
            
            total_points_earned += points_earned
            
            # Create feedback for this question
            q_feedback = QuestionFeedbackItem(
                questionIndex=answer.questionIndex,
                question=question.question,
                studentAnswer=answer.answer,
                correctAnswer=question.correct_answer,
                isCorrect=is_correct,
                pointsEarned=points_earned,
                maxPoints=question.points,
                feedback=feedback_text
            )
            question_feedback_list.append(q_feedback)
        
        # Calculate score
        percentage = (total_points_earned / assessment.total_points * 100) if assessment.total_points > 0 else 0
        
        score = ScoreResult(
            totalScore=total_points_earned,
            maxScore=assessment.total_points,
            percentage=round(percentage, 2),
            correctAnswers=correct_count,
            totalQuestions=len(assessment.questions)
        )
        
        # Generate overall feedback using AI
        overall_feedback = await llm_service.generate_overall_feedback(
            assessment=assessment,
            score=score,
            question_feedback=question_feedback_list
        )
        
        feedback = AssessmentFeedback(
            overallFeedback=overall_feedback.get("overallFeedback") or overall_feedback.get("overall_feedback", ""),
            strengths=overall_feedback.get("strengths", []),
            improvements=overall_feedback.get("improvements", []),
            recommendations=overall_feedback.get("recommendations", [])
        )
        
        # Save submission and result to database
        submission_dict = submission.dict(exclude={"id"})
        submission_dict["_id"] = ObjectId()
        submission_dict["submitted_at"] = datetime.utcnow()
        await self.submissions_collection.insert_one(submission_dict)
        submission_id = str(submission_dict["_id"])
        
        # Create assessment result
        result = AssessmentResult(
            submissionId=submission_id,
            assessmentId=submission.assessmentId,
            user_id=submission.user_id,
            score=score,
            feedback=feedback,
            questionFeedback=question_feedback_list,
            completed_at=datetime.utcnow(),
            status="completed"
        )
        
        # Save result to database
        result_dict = result.dict(exclude={"id"})
        result_dict["_id"] = ObjectId()
        result_dict["completed_at"] = datetime.utcnow()
        await self.results_collection.insert_one(result_dict)
        result.id = str(result_dict["_id"])
        
        return result
    
    async def submit_assessment(self, submission: AssessmentSubmission) -> AssessmentResult:
        """Submit assessment (calls evaluate_assessment)"""
        return await self.evaluate_assessment(submission)
    
    # ============================================================================
    # Results Retrieval
    # ============================================================================
    
    async def get_assessment_result(self, submission_id: str) -> Optional[AssessmentResult]:
        """Get assessment result by submission ID"""
        try:
            result_data = await self.results_collection.find_one({"submission_id": submission_id})
            if not result_data:
                return None
            
            result_data["id"] = str(result_data["_id"])
            return AssessmentResult(**result_data)
        except:
            return None
    
    async def get_user_results(self, user_id: str, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all results for a user, optionally filtered by project"""
        
        # Build query for submissions
        submission_query = {"user_id": user_id}
        submissions_cursor = self.submissions_collection.find(submission_query)
        results = []
        
        async for submission in submissions_cursor:
            submission_id = str(submission["_id"])
            
            # Get corresponding result
            result_data = await self.results_collection.find_one({"submission_id": submission_id})
            if not result_data:
                continue
            
            # Get assessment info
            assessment = await self.get_assessment(submission["assessment_id"])
            if not assessment:
                continue
            
            # Filter by project if specified
            if project_id and assessment.project_id != project_id:
                continue
            
            results.append({
                "submission_id": submission_id,
                "assessment_id": submission["assessment_id"],
                "assessment_title": assessment.title,
                "project_id": assessment.project_id,
                "score": result_data["score"],
                "feedback": result_data["feedback"],
                "status": result_data["status"],
                "submitted_at": submission["submitted_at"],
                "completed_at": result_data["completed_at"]
            })
        
        return sorted(results, key=lambda x: x["completed_at"], reverse=True)

    # ============================================================================
    # Anonymous Performance Comparison
    # ============================================================================
    
    async def get_assessment_comparison(self, submission_id: str) -> Optional[AssessmentComparisonStats]:
        """
        Get anonymous performance comparison statistics for a student's submission.
        
        This method compares a student's performance against all other students
        who completed the same assessment, providing:
        - Rank among all participants
        - Percentile score
        - How many scored higher/lower/same
        - Top 3 performers (anonymous)
        - Average, median, highest, lowest scores
        
        Returns:
            AssessmentComparisonStats with anonymous comparison data
        """
        # Get the student's result
        student_result = await self.get_assessment_result(submission_id)
        if not student_result:
            return None
        
        from typing import Dict, Any
        
        # Get the assessment
        assessment = await self.get_assessment(student_result.assessmentId)
        if not assessment:
            return None
        
        # Get all results for this assessment
        all_results_cursor = self.results_collection.find({
            "assessmentId": student_result.assessmentId,
            "status": "completed"
        })
        
        all_scores = []
        async for result in all_results_cursor:
            score_data = result.get("score", {})
            total_score = score_data.get("total_score", 0)
            percentage = score_data.get("percentage", 0.0)
            all_scores.append({
                "score": total_score,
                "percentage": percentage
            })
        
        if not all_scores:
            return None
        
        total_participants = len(all_scores)
        student_score = student_result.score.totalScore
        student_percentage = student_result.score.percentage
        
        # Sort scores in descending order for ranking
        sorted_scores = sorted(all_scores, key=lambda x: x["score"], reverse=True)
        
        # Calculate rank (1-based)
        student_rank = 1
        for i, s in enumerate(sorted_scores):
            if s["score"] > student_score:
                student_rank = i + 2
            elif s["score"] == student_score:
                student_rank = i + 1
                break
        
        # Count students who scored higher, lower, same
        students_scored_higher = sum(1 for s in all_scores if s["score"] > student_score)
        students_scored_lower = sum(1 for s in all_scores if s["score"] < student_score)
        # Exclude the current student from 'scored same' count
        students_scored_same = max(0, sum(1 for s in all_scores if s["score"] == student_score) - 1)

        # Calculate percentile (standard definition)
        if total_participants > 1:
            percentile = round(((students_scored_lower + 0.5 * students_scored_same) / total_participants) * 100, 1)
        else:
            percentile = 100.0  # Only participant
        
        # Calculate statistics
        score_values = [s["score"] for s in all_scores]
        percentage_values = [s["percentage"] for s in all_scores]
        
        average_score = round(statistics.mean(score_values), 2)
        average_percentage = round(statistics.mean(percentage_values), 2)
        highest_score = max(score_values)
        lowest_score = min(score_values)
        median_score = round(statistics.median(score_values), 2)
        
        # Get top 3 performers (anonymous)
        top_performers = []
        seen_scores = set()
        rank = 0
        for s in sorted_scores[:3]:
            rank += 1
            top_performers.append(TopPerformer(
                rank=rank,
                score=s["score"],
                percentage=s["percentage"]
            ))
        
        # Generate performance summary
        if percentile >= 90:
            performance_summary = f"Excellent! You're in the top {100 - percentile:.0f}% of students. You outperformed {students_scored_lower} out of {total_participants} participants."
        elif percentile >= 75:
            performance_summary = f"Great job! You scored better than {percentile:.0f}% of students. You're ranked #{student_rank} out of {total_participants} participants."
        elif percentile >= 50:
            performance_summary = f"Good effort! You scored better than {percentile:.0f}% of students. {students_scored_higher} students scored higher than you."
        elif percentile >= 25:
            performance_summary = f"You scored better than {percentile:.0f}% of students. Consider reviewing the material to improve your ranking."
        else:
            performance_summary = f"You're ranked #{student_rank} out of {total_participants}. Keep practicing - there's room for improvement!"
        
        return AssessmentComparisonStats(
            assessment_id=student_result.assessmentId,
            assessment_title=assessment.title,
            total_participants=total_participants,
            your_score=student_score,
            your_percentage=student_percentage,
            your_rank=student_rank,
            students_scored_lower=students_scored_lower,
            students_scored_higher=students_scored_higher,
            students_scored_same=students_scored_same,
            percentile=percentile,
            average_score=average_score,
            average_percentage=average_percentage,
            highest_score=highest_score,
            lowest_score=lowest_score,
            median_score=median_score,
            max_possible_score=assessment.total_points,
            top_performers=top_performers,
            performance_summary=performance_summary
        )

# Function to get service instance
def get_assessment_service() -> AssessmentService:
    db = get_database()
    if db is None:
        raise RuntimeError("Database connection not initialized")
    return AssessmentService(db)