from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import os
from dotenv import load_dotenv
from typing import List, Optional, Any
from datetime import datetime
from bson import ObjectId

# Import our modules
from database import connect_to_mongo, close_mongo_connection, get_database
from models import (
    Assessment, AssessmentSubmission, AssessmentResult, 
    DifficultyLevel, StudentAnswer, AssessmentGenerationRequest,
    AssessmentResultView, AssessmentComparisonStats
)
from assessment import AssessmentService, get_assessment_service

# Load environment variables
load_dotenv()

def convert_objectid_to_str(obj: Any) -> Any:
    """Recursively convert ObjectId instances to strings in dictionaries and lists"""
    if isinstance(obj, dict):
        return {key: convert_objectid_to_str(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_objectid_to_str(item) for item in obj]
    elif isinstance(obj, ObjectId):
        return str(obj)
    else:
        return obj

def normalize_id(id_value: Any) -> Optional[str]:
    """Convert various ID formats to string for comparison"""
    if id_value is None:
        return None
    if isinstance(id_value, str):
        return id_value
    if isinstance(id_value, ObjectId):
        return str(id_value)
    if isinstance(id_value, dict) and '$oid' in id_value:
        return id_value['$oid']
    return str(id_value)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    await connect_to_mongo()
    yield
    # Shutdown
    await close_mongo_connection()

# Create FastAPI app
app = FastAPI(
    title="AI Assessment Generator",
    description="AI-powered assessment generator for project-based learning",
    version="1.0.0",
    lifespan=lifespan,
    json_encoders={datetime: str, ObjectId: str}  # Handle datetime and ObjectId serialization
)

# Add CORS middleware
def _get_allowed_origins():
    """Read CORS origins from the environment and always allow local development."""
    configured = os.getenv("ALLOWED_ORIGINS", "")
    origins = [origin.strip() for origin in configured.split(",") if origin.strip()]
    for local in ("http://localhost:3000", "http://localhost:8000", "http://localhost"):
        if local not in origins:
            origins.append(local)
    return origins


app.add_middleware(
    CORSMiddleware,
    allow_origins=_get_allowed_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Root endpoint
@app.get("/")
async def root():
    return {"message": "AI Assessment Generator API", "status": "running"}

@app.get("/api/v1/debug/db-status")
async def debug_db_status():
    """Debug endpoint to check database status and projects"""
    try:
        db = get_database()
        
        if db is None:
            return {
                "status": "FAILED",
                "message": "Database object is None",
                "db": str(db)
            }
        
        # Try to get database info
        db_name = db.name if hasattr(db, 'name') else "unknown"
        
        # Count projects
        project_count = await db.projects.count_documents({})
        
        # Get all collections
        collections = await db.list_collection_names()
        
        # Get sample project if exists
        sample_project = await db.projects.find_one({})
        
        return {
            "status": "OK",
            "database_name": db_name,
            "collections": collections,
            "project_count": project_count,
            "sample_project": {
                "_id": str(sample_project["_id"]) if sample_project and "_id" in sample_project else None,
                "title": sample_project.get("title") if sample_project else None
            } if sample_project else None
        }
    except Exception as e:
        import traceback
        return {
            "status": "ERROR",
            "error": str(e),
            "traceback": traceback.format_exc()
        }

# Health check
@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": "2025-01-01T00:00:00Z"}

# Admin endpoint to initialize sample projects
@app.post("/api/v1/admin/init-projects")
async def init_projects():
    """Initialize database with sample projects (admin endpoint)"""
    try:
        db = get_database()
        if db is None:
            raise HTTPException(status_code=500, detail="Database not initialized")
        
        # Check if projects exist
        existing_count = await db.projects.count_documents({})
        if existing_count > 0:
            return {"message": f"Database already has {existing_count} projects", "projects_added": 0}
        
        # Sample projects data
        sample_projects = [
            {
                "title": "AI Chatbot Development",
                "description": "Create an AI-powered chatbot using Python, FastAPI, and Google's Generative AI API",
                "tags": ["python", "fastapi", "ai", "nlp", "chatbots"],
                "status": "active",
                "srs_document": "Build a conversational AI chatbot that can understand user intent and provide relevant responses.",
                "plan": "1. Design architecture\n2. Setup API endpoints\n3. Integrate Generative AI\n4. Build frontend\n5. Deploy to production",
            },
            {
                "title": "E-Commerce Platform",
                "description": "Build a full-stack e-commerce platform with product catalog, shopping cart, and payment integration",
                "tags": ["nodejs", "react", "mongodb", "ecommerce", "payment-integration"],
                "status": "active",
                "srs_document": "Platform for selling products online with user authentication, product management, and secure payment processing.",
                "plan": "1. Database design\n2. API development\n3. Frontend development\n4. Payment gateway setup\n5. Testing and deployment",
            },
            {
                "title": "Data Analytics Dashboard",
                "description": "Create a real-time analytics dashboard for business intelligence",
                "tags": ["python", "data-visualization", "mongodb", "pandas", "streamlit"],
                "status": "active",
                "srs_document": "Real-time dashboard displaying KPIs, sales metrics, and customer analytics.",
                "plan": "1. Data pipeline setup\n2. Database optimization\n3. Dashboard design\n4. Data visualization\n5. Performance tuning",
            },
            {
                "title": "Mobile Weather App",
                "description": "Build a cross-platform weather application with real-time updates and forecasts",
                "tags": ["react-native", "api-integration", "mobile", "weather-api"],
                "status": "active",
                "srs_document": "Mobile app that provides weather information, forecasts, and alerts.",
                "plan": "1. Design UI/UX\n2. API integration\n3. Data caching\n4. Testing on devices\n5. App store deployment",
            },
            {
                "title": "Project Management System",
                "description": "Develop a project management tool with task tracking, team collaboration, and reporting",
                "tags": ["fullstack", "project-management", "collaboration", "nodejs", "react"],
                "status": "active",
                "srs_document": "System for teams to plan, track, and manage projects with real-time collaboration.",
                "plan": "1. Requirements analysis\n2. Database schema\n3. API development\n4. UI implementation\n5. Integration testing",
            }
        ]
        
        result = await db.projects.insert_many(sample_projects)
        return {
            "message": "Sample projects initialized successfully",
            "projects_added": len(result.inserted_ids)
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"ERROR in /admin/init-projects: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to initialize projects: {str(e)}")

# ============================================================================
# Projects Endpoints
# ============================================================================

@app.get("/api/v1/projects")
async def get_projects():
    """Get list of all projects for assessment generation"""
    try:
        db = get_database()
        if db is None:
            print("ERROR: Database not initialized")
            raise HTTPException(status_code=500, detail="Database not initialized")
        
        projects = await db.projects.find({}).to_list(None)
        print(f"Found {len(projects)} projects in database")
        
        # Convert ObjectId to string and ensure all fields exist
        formatted_projects = []
        for project in projects:
            # Convert all ObjectId fields to strings recursively
            project = convert_objectid_to_str(project)
            
            # Ensure required fields exist
            if "title" not in project or not project["title"]:
                continue  # Skip projects without title
            
            # Add default values for missing fields
            if "description" not in project:
                project["description"] = ""
            if "tags" not in project:
                project["tags"] = []
            if "status" not in project:
                project["status"] = "active"
            
            formatted_projects.append(project)
        
        print(f"Returning {len(formatted_projects)} formatted projects")
        for p in formatted_projects:
            print(f"  - {p.get('title')}: {p.get('description', 'N/A')[:50]}")
        
        return formatted_projects
    except HTTPException:
        raise
    except Exception as e:
        print(f"ERROR in /projects endpoint: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to fetch projects: {str(e)}")

# ============================================================================
# 1.1 ASSESSMENT GENERATION ENDPOINTS
# ============================================================================

@app.post("/api/v1/assessments/generate")
async def generate_assessment(
    request: AssessmentGenerationRequest,
    service: AssessmentService = Depends(get_assessment_service)
):
    """
    Generate a new assessment based on project.
    
    1.1 Assessment Generation
    
    Input:
    - project_id: ID of the project (all other info fetched from database)
    - num_questions: Number of questions (1-50, default: 10)
    - difficulty_level: Level of difficulty (beginner, intermediate, advanced, default: intermediate)
    
    Process:
    1. Fetches project data from database
    2. Analyzes project requirements and SRS documentation
    3. Evaluates skills required from the project plan
    4. Considers difficulty level and project complexity
    5. Generates questions based on project tags and technical requirements
    6. Creates diverse mix of question types (multiple choice, true/false, short answer)
    7. Assigns appropriate points and provides explanations for each question
    
    Returns:
    Assessment in structured JSON format with complete question set
    """
    try:
        if request.num_questions < 1 or request.num_questions > 50:
            raise HTTPException(status_code=400, detail="Number of questions must be between 1 and 50")
        
        assessment = await service.generate_assessment(request)
        return assessment.dict()
    
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to generate assessment: {str(e)}")

@app.post("/api/v1/assessments")
async def create_assessment(
    project_id: str,
    difficulty: DifficultyLevel,
    num_questions: int = 10,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Create a new assessment for a project (legacy endpoint)"""
    try:
        if num_questions < 1 or num_questions > 50:
            raise HTTPException(status_code=400, detail="Number of questions must be between 1 and 50")
        
        assessment = await service.create_assessment(project_id, difficulty, num_questions)
        return assessment.dict()
    
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create assessment: {str(e)}")

# ============================================================================
# Assessment Retrieval Endpoints
# ============================================================================

@app.get("/api/v1/assessments/{assessment_id}")
async def get_assessment(
    assessment_id: str,
    include_deleted: bool = False,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Get assessment by ID"""
    try:
        # Validate assessment_id
        if not assessment_id or assessment_id.strip() == "":
            raise HTTPException(status_code=400, detail="Invalid assessment ID: empty value")
        
        # Log the request for debugging
        print(f"[INFO] Fetching assessment: {assessment_id}")
        
        assessment = await service.get_assessment(assessment_id, include_deleted)
        if not assessment:
            print(f"[ERROR] Assessment not found: {assessment_id}")
            raise HTTPException(status_code=404, detail="Assessment not found")
        
        print(f"[INFO] Successfully retrieved assessment: {assessment_id}")
        return assessment.dict()
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] Error fetching assessment: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# Fallback route for base assessment endpoint without /api/v1 prefix
@app.get("/assessments/{assessment_id}")
async def get_assessment_fallback(
    assessment_id: str,
    include_deleted: bool = False,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Fallback route: Get assessment by ID (for requests without /api/v1 prefix)"""
    print(f"[WARNING] Using fallback route /assessments/{assessment_id} - redirecting from missing /api/v1 prefix")
    try:
        if not assessment_id or assessment_id.strip() == "":
            raise HTTPException(status_code=400, detail="Invalid assessment ID: empty value")
        
        print(f"[INFO] Fallback: Fetching assessment: {assessment_id}")
        
        assessment = await service.get_assessment(assessment_id, include_deleted)
        if not assessment:
            print(f"[ERROR] Assessment not found (fallback): {assessment_id}")
            raise HTTPException(status_code=404, detail="Assessment not found")
        
        print(f"[INFO] Successfully retrieved assessment via fallback: {assessment_id}")
        return assessment.dict()
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] Error fetching assessment (fallback): {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/api/v1/debug/projects/{project_id}/assessments-debug")
async def debug_project_assessments(
    project_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Debug endpoint to list all assessments for a project and their IDs"""
    try:
        db = get_database()
        if db is None:
            raise HTTPException(status_code=500, detail="Database not initialized")
        
        # Get all assessments for the project (including deleted)
        assessments_cursor = db.assessments.find({"project_id": project_id})
        assessments = await assessments_cursor.to_list(None)
        
        result = {
            "project_id": project_id,
            "total_count": len(assessments),
            "assessments": [
                {
                    "_id": str(a.get("_id")),
                    "title": a.get("title"),
                    "project_id": a.get("project_id"),
                    "status": a.get("status"),
                    "created_at": str(a.get("created_at")),
                    "question_count": len(a.get("questions", [])),
                }
                for a in assessments
            ]
        }
        
        print(f"[DEBUG] Project {project_id} assessments: {result}")
        return result
    except Exception as e:
        print(f"[ERROR] Debug endpoint error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/projects/{project_id}/assessments")
async def get_project_assessments(
    project_id: str,
    include_deleted: bool = False,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Get all assessments for a project"""
    try:
        print(f"[INFO] Fetching assessments for project: {project_id}")
        assessments = await service.get_assessments_by_project(project_id, include_deleted)
        print(f"[INFO] Found {len(assessments)} assessments for project {project_id}")
        for a in assessments:
            print(f"[INFO]   - Assessment: id={a.id}, title={a.title}, status={a.status}")
        return [a.dict() for a in assessments]
    except Exception as e:
        print(f"[ERROR] Failed to fetch assessments for project {project_id}: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to fetch assessments: {str(e)}")

@app.get("/api/v1/assessments/{assessment_id}/take")
async def get_assessment_for_taking(
    assessment_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Get assessment questions without correct answers (for students taking the test or admins viewing)"""
    try:
        # Validate assessment_id is not empty
        if not assessment_id or assessment_id.strip() == "":
            print(f"[ERROR] Empty assessment ID provided")
            raise HTTPException(status_code=400, detail="Invalid assessment ID: empty value")
        
        print(f"[INFO] Fetching assessment for taking: {assessment_id}")
        
        assessment = await service.get_assessment(assessment_id)
        if not assessment:
            print(f"[WARNING] Assessment not found for ID: {assessment_id}")
            raise HTTPException(status_code=404, detail=f"Assessment not found: {assessment_id}")
        
        # Remove correct answers and explanations
        safe_questions = []
        for question in assessment.questions:
            safe_question = {
                "question": question.question,
                "type": question.type,
                "options": question.options if question.options else None,
                "points": question.points
            }
            safe_questions.append(safe_question)
        
        print(f"[INFO] Successfully returned assessment {assessment_id} for taking ({len(safe_questions)} questions)")
        return {
            "id": assessment.id,
            "title": assessment.title,
            "description": assessment.description,
            "difficulty": assessment.difficulty,
            "questions": safe_questions,
            "total_points": assessment.total_points,
            "time_limit": assessment.time_limit
        }
    except HTTPException:
        raise
    except ValueError as e:
        print(f"[ERROR] ValueError in get_assessment_for_taking: {e}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        print(f"[ERROR] Unexpected error in get_assessment_for_taking: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# Fallback route for requests without /api/v1 prefix (backward compatibility)
@app.get("/assessments/{assessment_id}/take")
async def get_assessment_for_taking_fallback(
    assessment_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Fallback route: Get assessment questions without correct answers (for requests without /api/v1 prefix)"""
    print(f"[WARNING] Using fallback route /assessments/{assessment_id}/take - redirecting to /api/v1/assessments/{{assessment_id}}/take")
    try:
        if not assessment_id or assessment_id.strip() == "":
            print(f"[ERROR] Empty assessment ID provided")
            raise HTTPException(status_code=400, detail="Invalid assessment ID: empty value")
        
        print(f"[INFO] Fallback: Fetching assessment for taking: {assessment_id}")
        
        assessment = await service.get_assessment(assessment_id)
        if not assessment:
            print(f"[WARNING] Assessment not found for ID: {assessment_id}")
            raise HTTPException(status_code=404, detail=f"Assessment not found: {assessment_id}")
        
        # Remove correct answers and explanations
        safe_questions = []
        for question in assessment.questions:
            safe_question = {
                "question": question.question,
                "type": question.type,
                "options": question.options if question.options else None,
                "points": question.points
            }
            safe_questions.append(safe_question)
        
        print(f"[INFO] Successfully returned assessment {assessment_id} for taking via fallback ({len(safe_questions)} questions)")
        return {
            "id": assessment.id,
            "title": assessment.title,
            "description": assessment.description,
            "difficulty": assessment.difficulty,
            "questions": safe_questions,
            "total_points": assessment.total_points,
            "time_limit": assessment.time_limit
        }
    except HTTPException:
        raise
    except ValueError as e:
        print(f"[ERROR] ValueError in fallback get_assessment_for_taking: {e}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        print(f"[ERROR] Unexpected error in fallback get_assessment_for_taking: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.patch("/api/v1/assessments/{assessment_id}")
async def update_assessment(
    assessment_id: str,
    update_data: dict,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Update assessment details mapping"""
    updated_assessment = await service.update_assessment(assessment_id, update_data)
    if not updated_assessment:
        raise HTTPException(status_code=404, detail="Assessment not found or could not be updated")
    return updated_assessment.dict()

@app.delete("/api/v1/assessments/{assessment_id}")
async def delete_assessment(
    assessment_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Soft delete an assessment mapping"""
    success = await service.soft_delete_assessment(assessment_id)
    if not success:
        raise HTTPException(status_code=404, detail="Assessment not found or already deleted")
    return {"message": "Assessment soft deleted successfully"}

# ============================================================================
# 1.2 ASSESSMENT EVALUATION ENDPOINTS
# ============================================================================

@app.post("/api/v1/assessments/{assessment_id}/submit")
async def submit_assessment(
    assessment_id: str,
    submission: AssessmentSubmission,
    service: AssessmentService = Depends(get_assessment_service)
):
    """
    Submit an assessment and get evaluation results.
    
    1.2 Assessment Evaluation
    
    Input:
    - assessment_id: ID of the assessment being submitted
    - user_id: ID of the user submitting
    - answers: List of user answers (question_index and answer)
    
    Process:
    1. Receives the assessment submission with user's answers
    2. Automatically checks True/False and Multiple Choice Questions against correct answers
    3. Uses AI evaluation for short answers and subjective responses
    4. Calculates percentage of correctness for each answer
    5. Aggregates total score and provides detailed feedback
    6. Generates question-wise feedback for learning purposes
    
    Returns:
    AssessmentResult with:
    - score: Total score, max score, percentage, correct answers count
    - feedback: Overall assessment feedback with strengths, improvements, recommendations
    - question_feedback: Detailed feedback for each question
    """
    try:
        # Set the assessmentId from the path parameter
        submission.assessmentId = assessment_id
        result = await service.submit_assessment(submission)
        return result.dict()
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to submit assessment: {str(e)}")

# ============================================================================

# Assessment Results Endpoints
# ============================================================================
# Get all results for a project (all students)
@app.get("/api/v1/projects/{project_id}/results")
async def get_project_results(
    project_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Return all students' result objects for a project (for email/filtering)."""
    # Use service's collections to avoid NoneType errors
    assessments = await service.assessments_collection.find({"project_id": project_id}).to_list(None)
    assessment_ids = [str(a["_id"]) for a in assessments]
    if not assessment_ids:
        return []
    submissions = await service.submissions_collection.find({"assessment_id": {"$in": assessment_ids}}).to_list(None)
    submission_id_to_student = {str(s["_id"]): s for s in submissions}
    submission_ids = list(submission_id_to_student.keys())
    if not submission_ids:
        return []
    results = await service.results_collection.find({"submission_id": {"$in": submission_ids}}).to_list(None)
    output = []
    for result in results:
        submission = submission_id_to_student.get(result["submission_id"])
        if not submission:
            continue
        user_email = submission.get("user_email") or submission.get("email")
        user_name = submission.get("user_name") or submission.get("name")
        score = result.get("score", {})
        percentage = score.get("percentage")
        output.append({
            "user_id": submission.get("user_id"),
            "user_email": user_email,
            "user_name": user_name,
            "score": score,
            "percentage": percentage,
            "isSelected": result.get("isSelected", False),
            "feedback": result.get("feedback", {}).get("overall_feedback") if isinstance(result.get("feedback"), dict) else result.get("feedback"),
            "status": result.get("status")
        })
    return output

@app.get("/api/v1/results/{submission_id}")
async def get_assessment_result(
    submission_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Get assessment result by submission ID"""
    result = await service.get_assessment_result(submission_id)
    if not result:
        raise HTTPException(status_code=404, detail="Result not found")
    return result.dict()

@app.get("/api/v1/results/{submission_id}/view")
async def view_assessment_result(
    submission_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """
    View complete assessment result with all details and feedback.
    
    This endpoint provides a comprehensive view combining:
    - Assessment details and questions
    - User submission information
    - Score breakdown (total, percentage, correct answers)
    - Overall feedback with strengths and recommendations
    - Question-by-question feedback
    
    Perfect for displaying assessment results to users with full context.
    
    Returns: AssessmentResultView with all assessment context and feedback
    """
    try:
        result = await service.get_assessment_result(submission_id)
        if not result:
            raise HTTPException(status_code=404, detail="Result not found")
        
        # Get the assessment details
        assessment = await service.get_assessment(result.assessmentId)
        if not assessment:
            raise HTTPException(status_code=404, detail="Associated assessment not found")
        
        # Build the comprehensive view
        result_view = AssessmentResultView(
            assessment=assessment.dict(),
            assessment_id=result.assessmentId,
            assessment_title=assessment.title,
            assessment_difficulty=assessment.difficulty,
            submission_id=result.submissionId,
            user_id=result.user_id,
            submitted_at=result.completed_at,
            score=result.score,
            feedback=result.feedback,
            question_feedback=result.questionFeedback,
            status=result.status,
            result_id=result.id
        )
        
        return result_view.dict()
    
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to retrieve assessment result view: {str(e)}")

@app.get("/api/v1/results/{submission_id}/compare", response_model=AssessmentComparisonStats)
async def compare_assessment_result(
    submission_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """
    Compare student's assessment performance anonymously against other students.
    
    This endpoint provides anonymous comparison statistics including:
    - Your rank among all participants
    - Percentile score (e.g., "You scored better than 75% of students")
    - Number of students who scored higher/lower/same
    - Top 3 performers (anonymous - no student IDs)
    - Average, median, highest, and lowest scores
    - Performance summary message
    
    Perfect for showing students how they compare to peers without revealing identities.
    
    **Example Response:**
    ```json
    {
        "assessment_title": "JavaScript Fundamentals",
        "total_participants": 45,
        "your_score": 85,
        "your_rank": 5,
        "percentile": 88.9,
        "students_scored_higher": 4,
        "students_scored_lower": 40,
        "average_score": 72.5,
        "top_performers": [
            {"rank": 1, "score": 98, "percentage": 98.0},
            {"rank": 2, "score": 95, "percentage": 95.0},
            {"rank": 3, "score": 92, "percentage": 92.0}
        ],
        "performance_summary": "Excellent! You're in the top 12% of students."
    }
    ```
    
    Returns: AssessmentComparisonStats with anonymous comparison data
    """
    try:
        comparison = await service.get_assessment_comparison(submission_id)
        if not comparison:
            raise HTTPException(status_code=404, detail="Submission not found or no comparison data available")
        
        return comparison
    
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to retrieve comparison data: {str(e)}")

@app.get("/api/v1/submissions/{submission_id}")
async def view_submission_details(
    submission_id: str,
    service: AssessmentService = Depends(get_assessment_service)
):
    """
    View detailed submission with assessment context and feedback.
    Alternative endpoint that provides same data as /results/{submission_id}/view
    but emphasizes submission focus.
    
    Returns: Complete submission details with assessment and feedback
    """
    try:
        result = await service.get_assessment_result(submission_id)
        if not result:
            raise HTTPException(status_code=404, detail="Submission not found")
        
        # Get the assessment details
        assessment = await service.get_assessment(result.assessmentId)
        if not assessment:
            raise HTTPException(status_code=404, detail="Associated assessment not found")
        
        # Build the comprehensive view
        result_view = AssessmentResultView(
            assessment=assessment.dict(),
            assessment_id=result.assessmentId,
            assessment_title=assessment.title,
            assessment_difficulty=assessment.difficulty,
            submission_id=result.submissionId,
            user_id=result.user_id,
            submitted_at=result.completed_at,
            score=result.score,
            feedback=result.feedback,
            question_feedback=result.questionFeedback,
            status=result.status,
            result_id=result.id
        )
        
        return result_view.dict()
    
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to retrieve submission details: {str(e)}")

@app.get("/api/v1/users/{user_id}/results")
async def get_user_results(
    user_id: str,
    project_id: Optional[str] = None,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Get all results for a user, optionally filtered by project"""
    results = await service.get_user_results(user_id, project_id)
    return {"results": results, "total": len(results)}

# Backward compatibility endpoint
@app.get("/api/v1/students/{student_id}/results")
async def get_student_results_legacy(
    student_id: str,
    project_id: Optional[str] = None,
    service: AssessmentService = Depends(get_assessment_service)
):
    """(DEPRECATED) Get all results for a student - Use /api/v1/users/{user_id}/results instead"""
    results = await service.get_user_results(student_id, project_id)
    return {"results": results, "total": len(results)}

@app.get("/api/v1/assessments/user/{user_id}/results")
async def get_user_assessment_results(
    user_id: str,
    project_id: Optional[str] = None,
    service: AssessmentService = Depends(get_assessment_service)
):
    """Get all assessment results for a user (alternate endpoint for frontend compatibility)"""
    results = await service.get_user_results(user_id, project_id)
    return results

# Backward compatibility endpoint
@app.get("/api/v1/assessments/student/{student_id}/results")
async def get_student_assessment_results_legacy(
    student_id: str,
    project_id: Optional[str] = None,
    service: AssessmentService = Depends(get_assessment_service)
):
    """(DEPRECATED) Get all assessment results for a student - Use /api/v1/assessments/user/{user_id}/results instead"""
    results = await service.get_user_results(student_id, project_id)
    return results

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8001)),
        reload=True
    )