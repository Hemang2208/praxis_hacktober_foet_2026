# Implementation Details: Assessment Quality Engine

**Deep-dive technical documentation for developers and architects.**

---

## Architecture Overview

### Module Structure

```
assessment-agent/
├── assessment_quality_engine.py      ← NEW: Core quality system
├── llm_service.py                    ← UPDATED: Integrated quality engine
├── assessment.py                     ← Service layer (no changes needed)
├── models.py                         ← Pydantic models (no changes needed)
└── main.py                           ← FastAPI routes (no changes needed)
```

### Data Flow

```
User Request
    ↓
assessment_service.generate_assessment(project_id, num_questions, difficulty)
    ↓
1. AssessmentQualityEngine.detect_project_domain()
   - Analyzes project title, description, tags
   - Returns: ProjectDomain enum value
    ↓
2. AssessmentQualityEngine.generate_prompt_for_domain()
   - Retrieves domain-specific focus areas
   - Fetches existing questions from history
   - Creates specialized system & user prompts
   - Returns: (system_prompt, user_prompt)
    ↓
3. llm_service._call_llm_with_timeout()
   - Sends prompts to the local Ollama /api/chat endpoint
   - Uses OLLAMA_MODEL (default qwen2.5-coder:latest)
   - Returns: JSON with 10 questions
    ↓
4. JSON Parsing & Question Creation
   - Parses LLM response
   - Creates Question objects
    ↓
5. Question Deduplication Loop
   - For each question:
     a. Check hash against all previously asked questions
     b. Check semantic similarity (>70% overlap = duplicate)
     c. Skip duplicates, add unique questions to history
     d. Track in _question_history_cache & _asked_question_hashes
    ↓
6. AssessmentQuestionValidator.validate_assessment_questions()
   - Validates each question for:
     • Quality (no generic opening phrases, substantial explanations)
     • Correctness (answer in options, valid true/false)
     • Difficulty alignment (estimated vs. requested)
   - Generates validation report
    ↓
7. Assessment Creation
   - Reconstruct validated Question objects
   - Calculate total points
   - Create Assessment with metadata
    ↓
AssessmentService.assessments_collection.insert_one()
    ↓
Return to user
```

---

## Core Classes & Methods

### Class: `AssessmentQualityEngine`

Static utility class with all core quality features.

#### 1. `detect_project_domain()` - Domain Detection Algorithm

```python
@staticmethod
def detect_project_domain(
    title: str,
    description: str,
    tags: List[str],
    srs_document: str = ""
) -> ProjectDomain:
```

**Algorithm:**

1. Concatenate all text sources into single analysis string
2. For each supported ProjectDomain:
   - Count keyword matches in analysis string
   - Sum all matches → domain_scores[domain]
3. Return domain with highest score
4. Default to WEB_DEVELOPMENT if no matches

**Example:**

```python
text = "E-commerce Platform React Node.js PostgreSQL microservices..."
scores = {
    ProjectDomain.WEB_DEVELOPMENT: 25,    # react, node, express, etc.
    ProjectDomain.DEVOPS: 2,              # microservices (1 match)
    ProjectDomain.DATABASE: 1             # postgresql (1 match)
}
# Returns: ProjectDomain.WEB_DEVELOPMENT (highest)
```

**Keyword Categories:**

Each domain has 15-25 keywords and 3-5 skill identifiers:

```python
ProjectDomain.WEB_DEVELOPMENT: {
    "keywords": ["react", "vue", "angular", "html", "css", "javascript", 
                 "typescript", "frontend", "backend", "fullstack", "http", 
                 "rest", "express", "nextjs", "flask", "django"],
    "skills": ["web", "frontend", "backend", "fullstack"]
}
```

**Complexity: O(n)** where n = total words in analysis text

---

#### 2. `estimate_question_difficulty()` - Difficulty Classification

```python
@staticmethod
def estimate_question_difficulty(
    question: str,
    question_type: str,
    domain: ProjectDomain
) -> QuestionDifficulty:
```

**Algorithm:**

1. Scan question text for cognitive complexity keywords
2. Categorize keywords by Bloom's taxonomy level:
   - Level 5 (Evaluate/Create): "evaluate", "design", "optimize", "vulnerability", "architect"
   - Level 4 (Analyze): "analyze", "troubleshoot", "debug", "explain", "performance"
   - Level 2-3 (Apply): "use", "apply", "configure", "deploy", "integrate"
   - Level 1 (Remember): "what", "which", "define", "describe", "list"
3. Calculate weighted score:
   ```
   score = (expert_count * 5) + (advanced_count * 4) + 
           (intermediate_count * 2) + (basic_count * 1)
   ```
4. Adjust for question type (short_answer *= 1.2 since harder than MC)
5. Map score to QuestionDifficulty enum:
   - 8+: EXPERT
   - 5-7: ADVANCED
   - 3-4: INTERMEDIATE
   - 1-2: BASIC
   - 0: TRIVIAL

**Example:**

```python
# Low complexity
q1 = "What is REST API?"
score = 1 * ("what" keyword)
→ TRIVIAL (rejected for ADVANCED request)

# High complexity
q2 = "Evaluate design tradeoffs and optimize your API error handling strategy"
score = (1 * 5) + (1 * 4) = 9
→ EXPERT (acceptable for ADVANCED request)
```

**Keyword Matching: O(k)** where k = question word count (typically 50-150 words)

---

#### 3. `generate_prompt_for_domain()` - Specialized Prompt Generation

```python
@staticmethod
def generate_prompt_for_domain(
    domain: ProjectDomain,
    num_questions: int,
    difficulty: DifficultyLevel,
    project_context: Dict[str, Any],
    existing_questions: List[str] = None
) -> Tuple[str, str]:
```

**Process:**

1. **Select domain-specific focus areas** from `domain_focus` dictionary
   - 5-6 key areas for each domain
   - Example for Web Dev: API design, authentication, database schema, deployment, etc.

2. **Build system prompt** that:
   - Establishes expert educator persona
   - Specifies domain specialization
   - Defines assessment requirements
   - Lists anti-patterns to avoid
   - Sets expected difficulty level
   - Specifies output JSON format

3. **Build user prompt** that:
   - Includes project title, description, tags
   - Includes excerpts from SRS document (first 1000 chars)
   - Includes excerpts from project plan (first 1000 chars)
   - Lists existing questions to avoid (last 15 questions)
   - Reiterates difficulty level
   - Emphasizes uniqueness requirements

**System Prompt Template Structure:**

```
You are an expert assessment designer specializing in [DOMAIN].

CRITICAL REQUIREMENTS:
1. Generate exactly [N] UNIQUE questions
2. Ensure appropriate challenging for [LEVEL]
3. Focus on: [FOCUS_AREA_1], [FOCUS_AREA_2], [FOCUS_AREA_3]

ANTI-PATTERNS TO AVOID:
- Generic questions like "What is X?"
- Vague phrases: "discuss", "tell me about"
- Questions without clear correct answers
- Duplicate or near-duplicate questions
- Questions unrelated to project domain

[Additional requirements for difficulty level]

OUTPUT FORMAT:
{JSON schema...}
```

**User Prompt Template Structure:**

```
Generate [N] assessment questions for this [DOMAIN] project.

PROJECT DETAILS:
Title: [TITLE]
Description: [DESCRIPTION]
Key Skills/Tags: [TAGS]
SRS: [First 1000 chars]
Plan: [First 1000 chars]

PREVIOUSLY ASKED QUESTIONS (DO NOT REPEAT):
- [Question 1]
- [Question 2]
...

IMPORTANT:
1. Make questions SPECIFIC to this project
2. Avoid questions that could apply to any project
3. Generate UNIQUE questions only
4. Return ONLY the JSON object
```

**Result:** Two highly specialized prompts that guide LLM toward quality, domain-specific questions

---

#### 4. `validate_question_quality()` - Quality Validation

```python
@staticmethod
def validate_question_quality(
    question: str,
    correct_answer: str,
    explanation: str,
    options: Optional[List[str]] = None,
    question_type: str = "multiple_choice"
) -> Tuple[bool, List[str]]:
```

**Validation Checks:**

1. **Generic Opening Test**
   - Check if question starts with: "what is", "what are", "define", "which of the following"
   - If true AND question < 40 characters → Issue: "Question too generic"

2. **Explanation Substantiveness**
   - Minimum length: 20 characters (always)
   - Beginner: 50 characters minimum
   - Advanced: 75 characters minimum
   - If too short → Issue: "Explanation is too brief"

3. **Multiple Choice Specific**
   - Check: `correct_answer in options`
   - Check: 3 ≤ len(options) ≤ 5
   - If not → Issue: "Answer not in options" or "Wrong number of options"

4. **True/False Specific**
   - Check: correct_answer in ["True", "False", "true", "false"]
   - If not → Issue: "Invalid true/false answer"

5. **Historical Uniqueness Check**
   - Hash current question
   - Check against global hash set
   - If found → Issue: "Question asked before" (filtered out earlier)

**Returns:**
- `(True, [])` - Question passes all checks
- `(False, ["Issue 1", "Issue 2"])` - Failed with specific reasons

**Example:**

```python
is_valid, issues = validate_question_quality(
    question="Design your authentication system considering scalability and security",
    correct_answer="Detailed explanation of design",
    explanation="Should consider JWT vs session tokens, refresh token strategy, CORS, rate limiting, etc.",
    question_type="short_answer"
)
# Returns: (True, [])  ✓ Passes all checks

# Invalid example:
is_valid, issues = validate_question_quality(
    question="What is REST?",  # Too generic
    correct_answer="...",
    explanation="REST is...",  # Too short
    options=["A", "B"],  # Only 2 options
    question_type="multiple_choice"
)
# Returns: (False, ["Question too generic", "Explanation too brief", "Wrong number of options"])
```

---

#### 5. `has_duplicate_question()` - Deduplication Detection

```python
@staticmethod
def has_duplicate_question(
    question: str,
    project_id: Optional[str] = None
) -> bool:
```

**Two-layer Deduplication:**

**Layer 1: Exact Hash Matching (Fast)**
```python
question_hash = hashlib.md5(question.lower().strip().encode()).hexdigest()
if question_hash in AssessmentQualityEngine._asked_question_hashes:
    return True  # Exact duplicate
```

**Layer 2: Semantic Similarity (Comprehensive)**
```python
if project_id and project_id in self._question_history_cache:
    for prev_question in cache[project_id]:
        # Word-overlap based similarity
        q_words = set(question.lower().split())
        prev_words = set(prev_question.lower().split())
        
        overlap_ratio = len(q_words & prev_words) / len(q_words | prev_words)
        
        if overlap_ratio > 0.7:  # 70% word overlap = duplicate
            return True
```

**Example:**

```python
# Exact duplicate
Q1: "Explain the difference between state and props in React"
Q2: "Explain the difference between state and props in React"
→ has_duplicate_question(Q2) = True (100% match)

# Semantic duplicate (>70% overlap)
Q1: "What is the difference between state and props?"
Q2: "Explain the difference between props and state"
→ Word set: [difference, state, props] = 3 common out of ~6 unique = >70%
→ has_duplicate_question(Q2) = True

# Not a duplicate
Q1: "What is the difference between state and props?"
Q2: "How would you optimize component re-renders in React?"
→ Word overlap: [react] only = 1/15 = 6.6%
→ has_duplicate_question(Q2) = False
```

**Complexity:**
- Layer 1: O(1) hash lookup
- Layer 2: O(n * m) where n = history questions, m = avg question length

---

### Class: `AssessmentQuestionValidator`

Validates entire assessments for quality metrics.

#### `validate_assessment_questions()`

```python
@staticmethod
def validate_assessment_questions(
    questions: List[Dict[str, Any]],
    domain: ProjectDomain,
    difficulty: DifficultyLevel,
    project_id: str
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
```

**Process:**

1. **Iterates through each question**
2. **For each question:**
   - Check exact hash against global dedup set
   - Check semantic similarity against project history
   - Validate quality (generic test, explanation length, options)
   - Estimate difficulty using `estimate_question_difficulty()`
   - Compare to requested difficulty (allow 1-level variance)
   - Track in `validation_report`

3. **Generates validation report:**
   ```python
   {
       "total_questions": 10,
       "duplicates_found": 0,
       "quality_issues": [
           {"question_index": 5, "issues": ["Too generic"]}
       ],
       "difficulty_mismatches": [
           {"question_index": 2, "expected": "advanced", "estimated": "basic"}
       ],
       "passing_validation": True
   }
   ```

4. **Returns:** (validated_questions_list, detailed_report)

**Complexity: O(n * m)** where n = questions, m = avg history for similarity check

---

### Data Structures

#### `ProjectDomain` Enum

```python
class ProjectDomain(str, Enum):
    WEB_DEVELOPMENT = "web_development"
    MOBILE_DEVELOPMENT = "mobile_development"
    DATA_SCIENCE = "data_science"
    DEVOPS = "devops"
    MACHINE_LEARNING = "machine_learning"
    API_SERVICE = "api_service"
    DATABASE = "database"
    CLOUD_INFRASTRUCTURE = "cloud_infrastructure"
    BLOCKCHAIN = "blockchain"
    IOT = "iot"
    GAME_DEVELOPMENT = "game_development"
    SAAS_PLATFORM = "saas_platform"
```

#### Global Caches

```python
class AssessmentQualityEngine:
    # Global question hashes (entire system)
    _asked_question_hashes: Set[str] = set()
    
    # Per-project question history
    _question_history_cache: Dict[str, List[str]] = {}
    # Structure: {
    #     "proj_123": ["Question 1 text", "Question 2 text", ...],
    #     "proj_456": ["Question A text", "Question B text", ...]
    # }
```

**Memory Usage:**
- Each question hash: 32 bytes (MD5 hex)
- Each question text: ~100-200 bytes average
- For 100 projects with 50 assessments each (500 questions):
  - Hashes: 500 * 32 bytes = 16 KB
  - History: 500 * 150 bytes = 75 KB
  - **Total: ~100 KB** (minimal)

---

### Integration Points

#### In `llm_service.py`

**Modified method signature:**
```python
async def generate_assessment(
    self,
    num_questions: int = 10,
    difficulty_level: DifficultyLevel = DifficultyLevel.INTERMEDIATE,
    project_title: str = "",
    project_description: str = "",
    project_srs_document: str = None,
    project_plan: str = None,
    project_tags: List[str] = None,
    project_data: Dict[str, Any] = None,
    project_id: str = None,  # ← NEW: For deduplication tracking
    project: Project = None
) -> Assessment:
```

**Step-by-step integration:**

1. **Import quality engine:**
   ```python
   from assessment_quality_engine import (
       AssessmentQualityEngine, 
       AssessmentQuestionValidator, 
       ProjectDomain
   )
   ```

2. **Detect domain:**
   ```python
   project_domain = AssessmentQualityEngine.detect_project_domain(
       title=project_title,
       description=project_description,
       tags=project_tags,
       srs_document=project_srs_document or ""
   )
   ```

3. **Build context:**
   ```python
   project_context = {
       "title": project_title,
       "description": project_description,
       "tags": project_tags,
       "srs_document": project_srs_document or "",
       "plan": project_plan or ""
   }
   ```

4. **Get existing questions:**
   ```python
   existing_questions = []
   if project_id:
       existing_questions = AssessmentQualityEngine._question_history_cache.get(
           project_id, []
       )[-10:]  # Last 10
   ```

5. **Generate specialized prompts:**
   ```python
   system_prompt, human_prompt = AssessmentQualityEngine.generate_prompt_for_domain(
       domain=project_domain,
       num_questions=num_questions,
       difficulty=difficulty,
       project_context=project_context,
       existing_questions=existing_questions
   )
   ```

6. **Call LLM** (unchanged):
   ```python
   response = await self._call_llm_with_timeout(
       [{"role": "system", "content": system_prompt},
        {"role": "user", "content": human_prompt}],
       timeout_seconds=60
   )
   ```

7. **Process with deduplication:**
   ```python
   for q_data in assessment_data.get("questions", []):
       q_text = q_data.get("question", "")
       
       # Check for duplicates
       if AssessmentQualityEngine.has_duplicate_question(q_text, project_id):
           continue  # Skip duplicate
       
       # Add to history
       if project_id:
           AssessmentQualityEngine.add_to_question_history(project_id, q_text)
       
       question = Question(**q_data)
       questions.append(question)
   ```

8. **Validate quality:**
   ```python
   validated_questions, report = AssessmentQuestionValidator.validate_assessment_questions(
       questions=[q.dict() for q in questions],
       domain=project_domain,
       difficulty=difficulty,
       project_id=project_id or ""
   )
   ```

---

## Performance Analysis

### Complexity Analysis

| Operation | Complexity | Time (ms) | Notes |
|-----------|-----------|-----------|-------|
| detect_project_domain() | O(n) | ~5 | n = word count |
| estimate_question_difficulty() | O(m) | ~1 | m = question words |
| generate_prompt_for_domain() | O(1) | ~2 | Dict lookups + string concat |
| has_duplicate_question() Layer 1 | O(1) | <0.1 | Hash lookup |
| has_duplicate_question() Layer 2 | O(n*m) | ~10 | n = history questions, m = words |
| validate_single_question() | O(m) | ~1 | m = question words |
| validate_all_questions() | O(n*m) | ~15 | n = 10 questions |
| **Total for 10-question assessment** | - | **~70-100** | Incl. LLM call (~30-60s) |

### Scalability

**Memory per Project:**
- 100 questions: 100 * 150 bytes ≈ 15 KB
- 1000 projects: 1000 * 15 KB = 15 MB
- **Acceptable for production**

**Memory for System:**
- Global hashes (1M questions): 32 MB
- Per-project histories (1M questions): 150 MB
- **Total: ~200 MB** - minimal overhead

**Cache Expiration (Optional Enhancement):**
```python
# Not yet implemented, but could add:
_cache_ttl = 86400 * 30  # 30 days
_created_timestamps = {}  # Track when added

# Periodically clean old entries:
for project_id in list(cache.keys()):
    if age > TTL:
        del cache[project_id]
```

---

## Error Handling

### Fallback Strategy

```
LLM Call
    ↓
Success → Parse & Process
    ↓
   No → Fallback Assessment
         (Generic but functional)
         
Fallback includes:
- 10 generic question templates per domain
- Rotate through templates
- Maintains difficulty levels
- Not ideal but prevents complete failure
```

### Common Errors & Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| JSONDecodeError | LLM returned invalid JSON | Use `_generate_fallback_assessment()` |
| Domain detection wrong | Ambiguous tags | Users can force via overriding tags |
| Too few unique questions | High duplicate rate | Regenerate or request more (15 instead of 10) |
| Difficulty mismatch | LLM calibration varies | Quality engine filters; rare in practice |

---

## Future Optimizations

### Planned Enhancements

1. **ML-Based Difficulty Estimation**
   - Train neural net on historical question data
   - Accuracy: ~95% vs. current keyword-based ~80%

2. **Semantic Similarity with Embeddings**
   - Use sentence transformers instead of word overlap
   - Better duplicate detection accuracy
   - Trade-off: +50-100ms per question

3. **Adaptive Question Generation**
   - Adjust difficulty based on student performance
   - Track which questions differentiate well

4. **Multi-language Support**
   - Generate assessments in 10+ languages
   - Translate domain focus areas
   - Maintain difficulty calibration

5. **Custom Domain Templates**
   - Allow users to define custom domains
   - Upload focus areas and keywords
   - Personalized assessment generation

---

## Configuration & Extensibility

### Adding a New Domain

```python
# 1. Add to ProjectDomain enum
class ProjectDomain(str, Enum):
    YOUR_DOMAIN = "your_domain"

# 2. Add to DOMAIN_PATTERNS
ProjectDomain.YOUR_DOMAIN: {
    "keywords": ["keyword1", "keyword2", ...],  # 15-25 keywords
    "skills": ["skill1", "skill2", ...]  # 3-5 skills
}

# 3. Add domain-specific focus areas
domain_focus = {
    ProjectDomain.YOUR_DOMAIN: [
        "Focus area 1",
        "Focus area 2",
        ...
    ]
}

# 4. Done! System will auto-detect and use new domain
```

### Custom Difficulty Thresholds

```python
# In estimate_question_difficulty()
if total_score >= 10:  # Change from 8
    return QuestionDifficulty.EXPERT
elif total_score >= 6:  # Change from 5
    return QuestionDifficulty.ADVANCED
# ... etc
```

### Custom Deduplication Settings

```python
# In has_duplicate_question()
if overlap > 0.6:  # Change from 0.7 for stricter dedup
    return True
```

---

## Testing Strategy

### Unit Tests (Recommended)

```python
def test_detect_web_dev_domain():
    domain = AssessmentQualityEngine.detect_project_domain(
        title="E-commerce Platform",
        description="React and Node.js...",
        tags=["react", "nodejs"],
        srs_document=""
    )
    assert domain == ProjectDomain.WEB_DEVELOPMENT

def test_question_deduplication():
    # Add question first
    AssessmentQualityEngine.add_to_question_history(
        "proj_123",
        "What is React?"
    )
    # Should be detected as duplicate
    assert AssessmentQualityEngine.has_duplicate_question(
        "What is React?",
        "proj_123"
    ) == True

def test_difficulty_estimation():
    easy = AssessmentQualityEngine.estimate_question_difficulty(
        "What is REST?",
        "multiple_choice",
        ProjectDomain.WEB_DEVELOPMENT
    )
    assert easy == QuestionDifficulty.TRIVIAL
    
    hard = AssessmentQualityEngine.estimate_question_difficulty(
        "Design a scalable API with caching and error handling",
        "short_answer",
        ProjectDomain.WEB_DEVELOPMENT
    )
    assert hard in [QuestionDifficulty.ADVANCED, QuestionDifficulty.EXPERT]
```

### Integration Tests (Recommended)

```python
async def test_full_assessment_generation():
    assessment = await llm_service.generate_assessment(
        num_questions=5,
        difficulty_level=DifficultyLevel.ADVANCED,
        project_title="E-commerce Platform",
        project_description="React...",
        project_tags=["react", "nodejs"],
        project_id="test_proj_123"
    )
    
    # Verify
    assert len(assessment.questions) == 5
    assert assessment.difficulty == DifficultyLevel.ADVANCED
    
    # Verify no duplicates
    questions_set = set(q.question for q in assessment.questions)
    assert len(questions_set) == 5  # All unique

    # Verify domain was detected
    # (Check logs for "Detected domain: web_development")
```

---

## Monitoring & Observability

### Key Metrics to Track

```python
# In logging/monitoring system:
- assessments_generated_total  # Total count
- assessment_quality_score_avg  # Quality by domain
- question_deduplication_rate   # % duplicates caught
- domain_detection_accuracy     # % correct domains
- difficulty_calibration_error  # Estimate vs. actual

# Per-domain metrics:
- web_development_assessments_total
- mobile_development_assessments_total
- data_science_assessments_total
- ... (one for each domain)
```

### Logging Points

```python
# In generate_assessment():
logging.info(f"Detected domain: {project_domain.value}")
logging.info(f"Generated {num_questions} questions for {difficulty.value}")
logging.info(f"Validation: {validation_report['duplicates_found']} duplicates found")
logging.warning(f"Difficulty mismatch in Q{i}: estimated {est}, requested {difficulty}")
```

---

## References

- **Assessment Domain Patterns:** `assessment_quality_engine.py:DOMAIN_PATTERNS`
- **Focus Areas:** `assessment_quality_engine.py:domain_focus`
- **Validation Rules:** `AssessmentQuestionValidator` class
- **Integration:** `llm_service.py:generate_assessment()`

---

**Version:** 1.0.0  
**Last Updated:** Feb 2025  
**Author:** GitHub Copilot Assessment Enhancement Task
