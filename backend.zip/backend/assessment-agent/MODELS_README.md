# Assessment Agent - Models Documentation

## Overview

The Assessment Agent models handle skill assessment generation, delivery, and evaluation. All models use Pydantic for validation.

## Table of Contents

- [Enum Types](#enum-types)
- [Request Models](#request-models)
- [Assessment Models](#assessment-models)
- [Submission Models](#submission-models)
- [Result Models](#result-models)
- [Comparison Models](#comparison-models)
- [API Workflows](#api-workflows)

---

## Enum Types

### DifficultyLevel
Defines assessment difficulty levels.

```python
class DifficultyLevel(str, Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
```

### QuestionType
Defines the types of questions that can be used.

```python
class QuestionType(str, Enum):
    MULTIPLE_CHOICE = "multiple_choice"
    TRUE_FALSE = "true_false"
    SHORT_ANSWER = "short_answer"
```

---

## Request Models

### AssessmentGenerationRequest

**Purpose**: Input for generating a new assessment

**Fields**:
- `project_id` (str, required): The project for which to generate the assessment
- `num_questions` (int, default=10): Number of questions to generate (1-50)
- `difficulty_level` (DifficultyLevel, default=INTERMEDIATE): Assessment difficulty

**Example**:
```python
request = AssessmentGenerationRequest(
    project_id="proj_123",
    num_questions=20,
    difficulty_level=DifficultyLevel.ADVANCED
)
```

**Validation**:
- `num_questions` must be between 1 and 50

---

## Assessment Models

### Question

**Purpose**: Individual question within an assessment

**Fields**:
- `question` (str): The question text
- `type` (QuestionType): Type of question (multiple_choice, true_false, short_answer)
- `options` (List[str], optional): Answer options (required for MC/TF questions)
- `correct_answer` (str): The correct answer
- `explanation` (str): Explanation for the correct answer
- `points` (int): Points awarded for correct answer (minimum 1)

**Example**:
```python
question = Question(
    question="What is the capital of France?",
    type=QuestionType.MULTIPLE_CHOICE,
    options=["London", "Paris", "Berlin", "Madrid"],
    correct_answer="Paris",
    explanation="Paris has been the capital of France since the 12th century",
    points=5
)
```

### Assessment

**Purpose**: Complete assessment containing multiple questions

**Fields**:
- `id` (str, optional): Assessment ID (assigned by database)
- `project_id` (str): Associated project ID
- `title` (str): Assessment title
- `description` (str): Assessment description
- `difficulty` (DifficultyLevel): Overall difficulty level
- `questions` (List[Question]): List of questions in assessment
- `total_points` (int): Sum of all question points
- `time_limit` (int, default=60): Time limit in minutes for taking assessment
- `created_at` (datetime, default=now): Creation timestamp
- `created_by` (str, optional): User ID of assessment creator
- `status` (str, default="active"): Assessment status (active, archived, draft)

**Example**:
```python
assessment = Assessment(
    project_id="proj_456",
    title="Python Fundamentals",
    description="Test your Python knowledge",
    difficulty=DifficultyLevel.INTERMEDIATE,
    questions=[question1, question2, question3],
    total_points=15,
    time_limit=45,
    created_by="teacher_001"
)
```

**Relationships**:
- Contains multiple `Question` objects
- References a `Project` via `project_id`

---

## Submission Models

### StudentAnswer

**Purpose**: Student's response to a single question

**Fields**:
- `question_index` (int): Index of the question (0-based)
- `answer` (str): The student's answer

**Example**:
```python
answer = StudentAnswer(
    question_index=0,
    answer="Paris"
)
```

### AssessmentSubmission

**Purpose**: Complete submission of an assessment by a student

**Fields**:
- `assessment_id` (str): ID of the assessment being submitted
- `student_id` (str): ID of the student submitting
- `answers` (List[StudentAnswer]): All student's answers
- `submitted_at` (datetime, default=now): Submission timestamp

**Example**:
```python
submission = AssessmentSubmission(
    assessment_id="assess_789",
    student_id="student_001",
    answers=[
        StudentAnswer(question_index=0, answer="Paris"),
        StudentAnswer(question_index=1, answer="True"),
        StudentAnswer(question_index=2, answer="Python is a programming language")
    ]
)
```

**Validation**:
- Number of answers should match number of questions in assessment

---

## Result Models

### ScoreResult

**Purpose**: Breakdown of student's score and performance metrics

**Fields**:
- `total_score` (int): Total points earned
- `max_score` (int): Maximum possible points
- `percentage` (float): Percentage score (0-100)
- `correct_answers` (int): Number of questions answered correctly
- `total_questions` (int): Total questions in assessment

**Example**:
```python
score = ScoreResult(
    total_score=42,
    max_score=50,
    percentage=84.0,
    correct_answers=8,
    total_questions=10
)
```

### QuestionFeedbackItem

**Purpose**: Detailed feedback for a single question

**Fields**:
- `question_index` (int): Question index
- `question` (str): The question text
- `student_answer` (str): Student's answer
- `correct_answer` (str): The correct answer
- `is_correct` (bool): Whether the answer was correct
- `points_earned` (int): Points earned for this question
- `max_points` (int): Maximum points for this question
- `feedback` (str): AI-generated feedback specific to this question

**Example**:
```python
feedback = QuestionFeedbackItem(
    question_index=0,
    question="What is the capital of France?",
    student_answer="London",
    correct_answer="Paris",
    is_correct=False,
    points_earned=0,
    max_points=5,
    feedback="London is the capital of United Kingdom. Paris is the capital of France."
)
```

### AssessmentFeedback

**Purpose**: Overall assessment-level feedback and recommendations

**Fields**:
- `overall_feedback` (str): Summary of overall performance
- `strengths` (List[str]): Identified strength areas
- `improvements` (List[str]): Areas needing improvement
- `recommendations` (List[str]): Learning recommendations

**Example**:
```python
feedback = AssessmentFeedback(
    overall_feedback="Good understanding of Python basics with room for improvement in advanced topics",
    strengths=[
        "Strong grasp of variables and data types",
        "Excellent loop understanding",
        "Good comprehension of functions"
    ],
    improvements=[
        "Need more practice with decorators",
        "Object-oriented programming concepts need work",
        "Exception handling could be stronger"
    ],
    recommendations=[
        "Study Python decorators documentation",
        "Complete OOP tutorial course",
        "Practice with real-world projects"
    ]
)
```

### AssessmentResult

**Purpose**: Complete assessment evaluation combining score and feedback

**Fields**:
- `id` (str, optional): Result ID (assigned by database)
- `submission_id` (str): Associated submission ID
- `assessment_id` (str): Associated assessment ID
- `student_id` (str): Student identifier
- `score` (ScoreResult): Score breakdown
- `feedback` (AssessmentFeedback): Overall feedback
- `question_feedback` (List[QuestionFeedbackItem]): Per-question feedback
- `completed_at` (datetime, default=now): Evaluation completion time
- `status` (str, default="completed"): Result status

**Example**:
```python
result = AssessmentResult(
    submission_id="sub_001",
    assessment_id="assess_789",
    student_id="student_001",
    score=score,
    feedback=feedback,
    question_feedback=[feedback_item1, feedback_item2, ...]
)
```

### AssessmentResultView

**Purpose**: Combined view of assessment details with submission results

**Fields**:
- `assessment` (Dict, optional): Complete assessment with questions
- `assessment_id` (str): Assessment ID
- `assessment_title` (str): Assessment title
- `assessment_difficulty` (DifficultyLevel): Difficulty level
- `submission_id` (str): Submission ID
- `student_id` (str): Student ID
- `submitted_at` (datetime): Submission time
- `score` (ScoreResult): Score information
- `feedback` (AssessmentFeedback): Overall feedback
- `question_feedback` (List[QuestionFeedbackItem]): Per-question feedback
- `status` (str): Result status
- `result_id` (str, optional): Result ID in database

---

## Comparison Models

### TopPerformer

**Purpose**: Anonymous data for top performing students

**Fields**:
- `rank` (int): Rank position (1, 2, or 3)
- `score` (int): Score achieved
- `percentage` (float): Percentage score

**Example**:
```python
top_performer = TopPerformer(
    rank=1,
    score=49,
    percentage=98.0
)
```

### AssessmentComparisonStats

**Purpose**: Anonymous comparison statistics for student performance

**Fields**:
- `assessment_id` (str): Assessment ID
- `assessment_title` (str): Assessment title
- `total_participants` (int): Total number of students
- `your_score` (int): Your score
- `your_percentage` (float): Your percentage
- `your_rank` (int): Your rank among participants
- `students_scored_lower` (int): Count of lower scores
- `students_scored_higher` (int): Count of higher scores
- `students_scored_same` (int): Count of same scores
- `percentile` (float): Your percentile (0-100)
- `average_score` (float): Class average score
- `average_percentage` (float): Class average percentage
- `highest_score` (int): Highest score in class
- `lowest_score` (int): Lowest score in class
- `median_score` (float): Median score
- `max_possible_score` (int): Maximum possible score
- `top_performers` (List[TopPerformer]): Top 3 performers
- `performance_summary` (str): Human-readable summary

**Example**:
```python
stats = AssessmentComparisonStats(
    assessment_id="assess_789",
    assessment_title="Python Fundamentals",
    total_participants=45,
    your_score=42,
    your_percentage=84.0,
    your_rank=8,
    students_scored_lower=37,
    students_scored_higher=7,
    students_scored_same=0,
    percentile=82.2,
    average_score=38.5,
    highest_score=50,
    lowest_score=12,
    median_score=40.0,
    max_possible_score=50,
    top_performers=[...],
    performance_summary="You performed above average with an 84% score..."
)
```

---

## API Workflows

### Generation Workflow

1. **Request**: `AssessmentGenerationRequest`
   - Client provides project_id and assessment parameters
   
2. **Processing**: 
   - Fetch project details and context
   - Generate questions using AI
   
3. **Response**: `Assessment`
   - Complete assessment with all questions

### Submission Workflow

1. **Request**: `AssessmentSubmission`
   - Student submits answers for all questions
   
2. **Processing**:
   - Validate answers
   - Calculate scores
   - Generate feedback using AI
   
3. **Response**: `AssessmentResult`
   - Complete evaluation with feedback

### Comparison Workflow

1. **Request**: `assessment_id` and `student_id`
   
2. **Processing**:
   - Fetch all submissions for the assessment
   - Calculate statistics
   - Generate performance message
   
3. **Response**: `AssessmentComparisonStats`
   - Anonymous comparison data

---

## Database Relationships

```
Project (1) ──── (N) Assessment
          (1) ──── (N) AssessmentResult

Assessment (1) ──── (N) Question
            (1) ──── (N) AssessmentSubmission
            (1) ──── (N) AssessmentResult

AssessmentSubmission (1) ──── (N) StudentAnswer
                      (1) ──── (1) AssessmentResult

AssessmentResult (1) ──── (N) QuestionFeedbackItem
                   (1) ──── (1) AssessmentFeedback
                   (1) ──── (1) ScoreResult
```

---

## Error Handling

**Common Validation Errors**:
- `num_questions` out of 1-50 range
- Missing required fields (question, correct_answer, etc.)
- Assessment submission answers count ≠ questions count
- Invalid enum values for DifficultyLevel or QuestionType

---

## Usage Examples

### Generate Assessment

```python
# Request
request = AssessmentGenerationRequest(
    project_id="web_app_proj",
    num_questions=15,
    difficulty_level=DifficultyLevel.INTERMEDIATE
)

# Response would be Assessment object
assessment = generate_assessment(request)
```

### Submit Assessment

```python
# Student submits answers
submission = AssessmentSubmission(
    assessment_id=assessment.id,
    student_id="student_123",
    answers=[
        StudentAnswer(question_index=0, answer="Paris"),
        StudentAnswer(question_index=1, answer="True"),
        # ... more answers
    ]
)

# Evaluate submission
result = evaluate_assessment(submission)
# Returns AssessmentResult with feedback
```

### Compare Performance

```python
# Get comparison stats
stats = get_comparison_stats(
    assessment_id="assess_789",
    student_id="student_001"
)
# Provides percentile, rank, top performers, etc.
```

---

## Best Practices

1. **Always set total_points**: When creating Assessment, ensure total_points equals sum of question points
2. **Meaningful explanations**: Question explanations help students learn from mistakes
3. **Varied question types**: Use mix of MC, T/F, and short answer for comprehensive assessment
4. **Reasonable time limits**: Set appropriate time_limit for estimated completion time
5. **Clear language**: Write questions and feedback in clear, unambiguous language
6. **Feedback specificity**: Provide question-specific feedback, not just correct answers

---

## Notes

- All timestamps use UTC datetime
- Assessment performance data is anonymized for comparison features
- Question order is preserved during assessment delivery
- Short answer questions require AI evaluation for grading
