#!/usr/bin/env python3
"""
Script to populate sample projects into MongoDB
Run this to add test data for the assessment generator
"""
import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId

load_dotenv()

SAMPLE_PROJECTS = [
    {
        "title": "AI Chatbot Development",
        "description": "Create an AI-powered chatbot using Python, FastAPI, and Google's Generative AI API",
        "tags": ["python", "fastapi", "ai", "nlp", "chatbots"],
        "status": "active",
        "srs_document": "Build a conversational AI chatbot that can understand user intent and provide relevant responses. Must support multiple languages.",
        "plan": "1. Design architecture\n2. Setup API endpoints\n3. Integrate Generative AI\n4. Build frontend\n5. Deploy to production",
    },
    {
        "title": "E-Commerce Platform",
        "description": "Build a full-stack e-commerce platform with product catalog, shopping cart, and payment integration",
        "tags": ["nodejs", "react", "mongodb", "ecommerce", "payment-integration"],
        "status": "active",
        "srs_document": "Platform for selling products online with user authentication, product management, and secure payment processing.",
        "plan": "1. Database design\n2. API development\n3. Frontend development\n4. Payment gateway setup\n5. Testing and deployment",
    },
    {
        "title": "Data Analytics Dashboard",
        "description": "Create a real-time analytics dashboard for business intelligence",
        "tags": ["python", "data-visualization", "mongodb", "pandas", "streamlit"],
        "status": "active",
        "srs_document": "Real-time dashboard displaying KPIs, sales metrics, and customer analytics with interactive visualizations.",
        "plan": "1. Data pipeline setup\n2. Database optimization\n3. Dashboard design\n4. Data visualization\n5. Performance tuning",
    },
    {
        "title": "Mobile Weather App",
        "description": "Build a cross-platform weather application with real-time updates and forecasts",
        "tags": ["react-native", "api-integration", "mobile", "weather-api"],
        "status": "active",
        "srs_document": "Mobile app that provides weather information, forecasts, and alerts for multiple locations.",
        "plan": "1. Design UI/UX\n2. API integration\n3. Data caching\n4. Testing on devices\n5. App store deployment",
    },
    {
        "title": "Project Management System",
        "description": "Develop a project management tool with task tracking, team collaboration, and reporting",
        "tags": ["fullstack", "project-management", "collaboration", "nodejs", "react"],
        "status": "active",
        "srs_document": "System for teams to plan, track, and manage projects with real-time collaboration features.",
        "plan": "1. Requirements analysis\n2. Database schema\n3. API development\n4. UI implementation\n5. Integration testing",
    }
]

async def populate_projects():
    """Populate sample projects into MongoDB"""
    mongodb_uri = os.getenv("MONGODB_URI")
    database_name = os.getenv("DATABASE_NAME", "praxis-aipm")
    
    if not mongodb_uri:
        print("Error: MONGODB_URI environment variable is not set")
        return
    
    try:
        client = AsyncIOMotorClient(mongodb_uri)
        db = client[database_name]
        
        # Check if projects already exist
        count = await db.projects.count_documents({})
        if count > 0:
            print(f"Database already has {count} projects. Skipping population.")
            return
        
        # Insert sample projects
        result = await db.projects.insert_many(SAMPLE_PROJECTS)
        print(f"✅ Successfully inserted {len(result.inserted_ids)} sample projects!")
        
        # Display inserted projects
        projects = await db.projects.find({}).to_list(None)
        for project in projects:
            print(f"  - {project['title']}")
        
        client.close()
        print("\n✅ Database population complete!")
        
    except Exception as e:
        print(f"Error populating database: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(populate_projects())
