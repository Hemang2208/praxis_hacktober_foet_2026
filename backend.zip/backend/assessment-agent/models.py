from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

class DifficultyLevel(str, Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"

class QuestionType(str, Enum):
    MULTIPLE_CHOICE = "multiple_choice"
    TRUE_FALSE = "true_false"
    SHORT_ANSWER = "short_answer"

# ============================================================================
# 1.1 ASSESSMENT GENERATION - Input Models
# ============================================================================

class AssessmentGenerationRequest(BaseModel):
    """Input model for assessment generation - only project_id required, all else fetched from database"""
    project_id: str
    num_questions: int = Field(default=10, gt=0, le=50, description="Number of questions (1-50)")
    difficulty_level: DifficultyLevel = Field(default=DifficultyLevel.INTERMEDIATE)

# ============================================================================
# 1.1 ASSESSMENT GENERATION - Output Schema
# ============================================================================

class Question(BaseModel):
    """Question model following the specification output schema"""
    question: str
    type: QuestionType
    options: Optional[List[str]] = None  # For multiple choice and true/false
    correct_answer: str
    explanation: str
    points: int = Field(ge=1, description="Points awarded for correct answer")

class Assessment(BaseModel):
    """Assessment model containing all questions"""
    id: Optional[str] = None
    project_id: str
    title: str
    description: str
    difficulty: DifficultyLevel
    questions: List[Question]
    total_points: int = Field(description="Sum of all question points")
    time_limit: int = Field(default=60, description="Time limit in minutes")
    created_at: datetime = Field(default_factory=datetime.now)
    created_by: Optional[str] = None
    status: str = Field(default="active", description="Status of the assessment")

# ============================================================================
# 1.2 ASSESSMENT EVALUATION - Input Models
# ============================================================================

class StudentAnswer(BaseModel):
    """Model for student's answer to a question"""
    questionIndex: int
    answer: str

class AssessmentSubmission(BaseModel):
    """Input model for assessment submission"""
    assessmentId: str
    user_id: str
    answers: List[StudentAnswer]
    submitted_at: datetime = Field(default_factory=datetime.now)

# ============================================================================
# 1.2 ASSESSMENT EVALUATION - Output Schema
# ============================================================================

class ScoreResult(BaseModel):
    """Score breakdown following the specification output schema"""
    totalScore: int = Field(description="Score obtained by student")
    maxScore: int = Field(description="Maximum possible score")
    percentage: float = Field(description="Percentage score (0-100)")
    correctAnswers: int = Field(description="Number of correct answers")
    totalQuestions: int = Field(description="Total number of questions")

class QuestionFeedbackItem(BaseModel):
    """Feedback for individual question"""
    questionIndex: int
    question: str
    studentAnswer: str
    correctAnswer: str
    isCorrect: bool
    pointsEarned: int
    maxPoints: int
    feedback: str = Field(description="AI-generated feedback for this question")

class AssessmentFeedback(BaseModel):
    """Overall feedback following the specification output schema"""
    overallFeedback: str = Field(description="Overall assessment feedback")
    strengths: List[str] = Field(default_factory=list, description="Identified strengths")
    improvements: List[str] = Field(default_factory=list, description="Areas for improvement")
    recommendations: List[str] = Field(default_factory=list, description="Learning recommendations")

class AssessmentResult(BaseModel):
    """Complete assessment evaluation result following specification"""
    id: Optional[str] = None
    submissionId: str
    assessmentId: str
    user_id: str
    score: ScoreResult
    feedback: AssessmentFeedback
    questionFeedback: List[QuestionFeedbackItem]
    completed_at: datetime = Field(default_factory=datetime.now)
    status: str = Field(default="completed", description="Status of evaluation")

# ============================================================================
# Project-related models
# ============================================================================

class Project(BaseModel):
    """Project model for assessment context"""
    id: str
    title: str
    description: str
    tags: List[str] = Field(default_factory=list)
    status: str
    progress: int
    deadline: Optional[datetime] = None
    srs_document: Optional[str] = None
    plan: Optional[str] = None

# ============================================================================
# Assessment Result View Model - Combined view with all details
# ============================================================================

class AssessmentResultView(BaseModel):
    """Complete view combining assessment details with submission results and feedback"""
    # Assessment Details
    assessment: Optional[Dict[str, Any]] = Field(None, description="Complete assessment details with questions")
    assessment_id: str = Field(description="ID of the assessment")
    assessment_title: str = Field(description="Title of the assessment")
    assessment_difficulty: DifficultyLevel = Field(description="Difficulty level of the assessment")
    
    # Submission Details
    submission_id: str = Field(description="ID of the submission")
    user_id: str = Field(description="ID of the user who submitted")
    submitted_at: datetime = Field(description="When the assessment was submitted")
    
    # Score Information
    score: ScoreResult = Field(description="Score breakdown")
    
    # Feedback Information
    feedback: AssessmentFeedback = Field(description="Overall feedback")
    question_feedback: List[QuestionFeedbackItem] = Field(description="Feedback for each question")
    
    # Status
    status: str = Field(default="completed", description="Status of the result")
    result_id: Optional[str] = Field(None, description="ID of the result record in database")

# ============================================================================
# Assessment Comparison Models - Anonymous Performance Comparison
# ============================================================================

class TopPerformer(BaseModel):
    """Anonymous top performer data"""
    rank: int = Field(description="Rank position (1, 2, 3)")
    score: int = Field(description="Total score achieved")
    percentage: float = Field(description="Percentage score")

class AssessmentComparisonStats(BaseModel):
    """Anonymous comparison statistics for an assessment"""
    assessment_id: str = Field(description="ID of the assessment")
    assessment_title: str = Field(description="Title of the assessment")
    total_participants: int = Field(description="Total number of students who completed the assessment")
    
    # Current student's performance
    your_score: int = Field(description="Your total score")
    your_percentage: float = Field(description="Your percentage score")
    your_rank: int = Field(description="Your rank among all participants")
    
    # Comparison metrics
    students_scored_lower: int = Field(description="Number of students who scored lower than you")
    students_scored_higher: int = Field(description="Number of students who scored higher than you")
    students_scored_same: int = Field(description="Number of students who scored the same as you")
    percentile: float = Field(description="Your percentile (e.g., 75 means you scored better than 75% of students)")
    
    # Statistics
    average_score: float = Field(description="Average score of all participants")
    average_percentage: float = Field(description="Average percentage of all participants")
    highest_score: int = Field(description="Highest score achieved")
    lowest_score: int = Field(description="Lowest score achieved")
    median_score: float = Field(description="Median score")
    max_possible_score: int = Field(description="Maximum possible score for this assessment")
    
    # Top performers (anonymous)
    top_performers: List[TopPerformer] = Field(description="Top 3 performers (anonymous)")
    
    # Performance message
    performance_summary: str = Field(description="Human-readable summary of performance")
