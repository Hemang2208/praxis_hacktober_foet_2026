import os
from dotenv import load_dotenv
import aiohttp
from models import (
    Project, Assessment, DifficultyLevel, Question, QuestionType, StudentAnswer,
    ScoreResult, AssessmentFeedback, QuestionFeedbackItem
)
from assessment_quality_engine import (
    AssessmentQualityEngine, AssessmentQuestionValidator, ProjectDomain
)
from typing import List, Dict, Any
import json
import logging
from fastapi import HTTPException
import re
import asyncio
import time
from functools import wraps
from shared.ollama_service import OllamaService
import hashlib


load_dotenv()
# Configure logging for better error visibility
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Configuration from environment variables
LLM_CACHE_TTL = int(os.getenv("LLM_CACHE_TTL", "3600"))

# Simple in-memory cache for LLM responses
_llm_cache = {}
_cache_ttl = LLM_CACHE_TTL

def cache_llm_response(func):
    """Cache LLM responses to reduce API calls"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        # Create a cache key from the function arguments
        cache_key = hashlib.md5(str(args + tuple(kwargs.items())).encode()).hexdigest()
        
        now = time.time()
        if cache_key in _llm_cache:
            cached_data, timestamp = _llm_cache[cache_key]
            if now - timestamp < _cache_ttl:
                logging.info(f"Using cached LLM response for {func.__name__}")
                return cached_data
            else:
                # Remove expired cache entry
                del _llm_cache[cache_key]
        
        # Call the function and cache the result
        result = await func(*args, **kwargs)
        _llm_cache[cache_key] = (result, now)
        return result
    return wrapper

class LLMService:
    def __init__(self):
        logging.info("Initializing local Ollama LLM client for Assessment Agent.")
        self.ollama = OllamaService(agent_type="assessment")

    def _generate_fallback_assessment(self, num_questions: int, difficulty: DifficultyLevel, project_title: str, project_tags: List[str]) -> Assessment:
        """Generate fallback assessment when API quota is exceeded"""
        logging.info(f"Generating {num_questions} fallback assessment questions for '{project_title}'")

        questions = []

        tag = project_tags[0] if project_tags else 'this technology'
        tag2 = project_tags[1] if len(project_tags) > 1 else project_tags[0] if project_tags else 'modern tools'
        is_advanced = difficulty.value == "ADVANCED"

        # Advanced, comprehensive question templates with high variety
        question_templates = {
            "multiple_choice": [
                # Architectural & Design Patterns
                {"question": f"Which design pattern best handles cross-cutting concerns in {tag}?", "options": ["Singleton", "Observer", "Aspect-Oriented Programming", "Factory"], "correct_answer": "Aspect-Oriented Programming", "explanation": "AOP effectively manages cross-cutting concerns like logging, security, and transactions."},
                {"question": f"In microservices {tag}, what pattern handles distributed transactions?", "options": ["Two-phase commit", "Saga pattern", "Event sourcing", "CQRS"], "correct_answer": "Saga pattern", "explanation": "Saga orchestrates distributed transactions without global locks, ideal for microservices."},
                {"question": f"How should state consistency be maintained across {tag} services?", "options": ["Strong consistency", "Eventual consistency", "Weak consistency", "Causal consistency"], "correct_answer": "Eventual consistency", "explanation": "Eventual consistency is practical for distributed systems, trading immediate consistency for availability."},
                {"question": f"Which design pattern reduces coupling in {tag}?", "options": ["Facade", "Adapter", "Observer", "All above"], "correct_answer": "All above", "explanation": "All these patterns help reduce coupling between components in various contexts."},
                {"question": f"What architecture pattern scales {tag} horizontally?", "options": ["Monolithic", "Layered", "Microservices", "CQRS only"], "correct_answer": "Microservices", "explanation": "Microservices enable independent scaling of components."},
                # Performance & Optimization
                {"question": f"Which caching strategy minimizes cache coherency issues in {tag}?", "options": ["Write-through", "Write-back", "Cache-aside", "Write-behind"], "correct_answer": "Cache-aside", "explanation": "Cache-aside decouples cache from application logic, reducing coherency issues."},
                {"question": f"What is the primary bottleneck when scaling {tag} horizontally?", "options": ["Network latency", "Database pooling", "State synchronization", "CPU"], "correct_answer": "State synchronization", "explanation": "Shared mutable state becomes the bottleneck in horizontal scaling."},
                {"question": f"Which approach optimizes database queries for {tag}?", "options": ["More indexes", "Denormalization", "Query analysis and indexing", "Caching"], "correct_answer": "Query analysis and indexing", "explanation": "Strategic indexing based on query patterns provides optimal performance."},
                # Security & Compliance
                {"question": f"Which encryption approach protects data-in-transit for {tag}?", "options": ["TLS 1.2", "TLS 1.3 with forward secrecy", "AES-256", "RSA-2048"], "correct_answer": "TLS 1.3 with forward secrecy", "explanation": "TLS 1.3 with forward secrecy prevents retroactive decryption even if keys are compromised."},
                {"question": f"How should secrets be managed in containerized {{tag}} deployment?", "options": ["Environment variables", "Config files", "Secret management service", "Hardcoded"], "correct_answer": "Secret management service", "explanation": "Dedicated secret management provides encryption, rotation, and audit trails."},
                {"question": f"What principle underlies least-privilege access in {{tag}}?", "options": ["Defense in depth", "Fail-safe", "Complete mediation", "Open design"], "correct_answer": "Complete mediation", "explanation": "Complete mediation ensures every access is checked against permissions."},
                # Testing & Quality
                {"question": f"Which metric best indicates code quality in {{tag}}?", "options": ["Code coverage %", "Cyclomatic complexity", "Defect density", "Lines of code"], "correct_answer": "Defect density", "explanation": "Defect density (bugs per KLOC) is practical; coverage alone doesn't guarantee quality."},
                {"question": f"What testing strategy provides best ROI for {{tag}}?", "options": ["Unit only", "Integration only", "Test pyramid", "Manual"], "correct_answer": "Test pyramid", "explanation": "Test pyramid (unit/integration/e2e) balances coverage, speed, and reliability."},
                # Data & Databases
                {"question": f"When should data be denormalized in {{tag}}?", "options": ["Always", "Read-heavy, infrequent writes", "Never", "NoSQL only"], "correct_answer": "Read-heavy, infrequent writes", "explanation": "Denormalization trades consistency for read performance when writes are sparse."},
                {"question": f"What's the primary SQL vs NoSQL trade-off in {{tag}}?", "options": ["Cost vs speed", "Consistency vs availability", "Consistency vs horizontal scalability", "None"], "correct_answer": "Consistency vs horizontal scalability", "explanation": "SQL prioritizes ACID; NoSQL sacrifices consistency for linear horizontal scaling."},
                # DevOps & Infrastructure
                {"question": f"How should configuration be managed across environments in {{tag}}?", "options": ["Environment files", "Centralized config server", "Hardcoded flags", "Database-driven"], "correct_answer": "Centralized config server", "explanation": "Centralized config enables dynamic updates, versioning, and auditability."},
                {"question": f"What is the primary benefit of IaC for {{tag}}?", "options": ["Lower costs", "Reproducibility and version control", "Faster deployment", "Better security"], "correct_answer": "Reproducibility and version control", "explanation": "IaC enables consistent, auditable, reproducible infrastructure changes."},
            ],
            "true_false": [
                {"question": "Eventually consistent systems can guarantee causal consistency between related operations.", "correct_answer": "True", "explanation": "Causal consistency is achievable within eventual consistency by tracking dependencies."},
                {"question": "A circuit breaker prevents cascading failures in distributed systems.", "correct_answer": "True", "explanation": "Circuit breakers detect failed services and stop requests, preventing cascade failures."},
                {"question": "CORS restrictions are enforced by the server, not the browser.", "correct_answer": "False", "explanation": "CORS is a browser security feature; servers declare headers that browsers enforce."},
                {"question": "Horizontal scaling always provides linear performance improvements.", "correct_answer": "False", "explanation": "Scaling plateau due to network overhead, synchronization costs, and shared bottlenecks."},
                {"question": "Database indexes on all columns improve query performance universally.", "correct_answer": "False", "explanation": "Indexes improve reads but degrade writes and consume storage; selective indexing is crucial."},
                {"question": "A stateless application automatically scales horizontally without issues.", "correct_answer": "True", "explanation": "Stateless applications have no affinity requirements, allowing seamless request routing."},
                {"question": "OAuth 2.0 is primarily designed for authentication.", "correct_answer": "False", "explanation": "OAuth 2.0 is authorization; authentication requires OpenID Connect on top."},
                {"question": "API rate limiting is purely a security mechanism.", "correct_answer": "False", "explanation": "Rate limiting protects against abuse and prevents resource exhaustion from legitimate spikes."},
                {"question": "Message queues guarantee exactly-once delivery by default.", "correct_answer": "False", "explanation": "Queues typically offer at-least-once or at-most-once; exactly-once requires coordination."},
                {"question": "Docker containers eliminate the need for infrastructure monitoring.", "correct_answer": "False", "explanation": "Containers simplify deployment but increase complexity; container-aware monitoring is required."},
                {"question": "Logging levels should be configurable at runtime.", "correct_answer": "True", "explanation": "Runtime log level configuration enables dynamic troubleshooting without redeployment."},
                {"question": "Immutable infrastructure improves deployment reliability.", "correct_answer": "True", "explanation": "Immutable infrastructure eliminates configuration drift and ensures consistency."},
            ],
            "short_answer": [
                {"question": f"Explain how you would implement idempotency for payment transactions in {{tag}}.", "correct_answer": "Use idempotency keys (unique request identifiers), store processed keys in cache/database, return cached result for duplicates.", "explanation": "Idempotency keys prevent duplicate processing; storing them enables safe retry handling."},
                {"question": f"What strategies would you use to reduce latency in {{tag}}?", "correct_answer": "Caching, CDN for static content, database indexing, query optimization, connection pooling, lazy loading.", "explanation": "Multi-layered approach addresses network, compute, and storage bottlenecks."},
                {"question": f"How would you handle schema evolution in {{tag}} without downtime?", "correct_answer": "Use backward/forward compatible migrations, deploy in stages, maintain multiple field versions, use feature flags.", "explanation": "Gradual schema migration with compatibility enables zero-downtime deployments."},
                {"question": f"Describe strong vs eventual consistency in {{tag}}.", "correct_answer": "Strong: immediate consistency after write, higher latency. Eventual: consistency after propagation, lower latency.", "explanation": "Strong provides linearizability; eventual trades immediate consistency for availability."},
                {"question": f"How would you implement a circuit breaker in {{tag}}?", "correct_answer": "Monitor failures over time window, open after threshold, half-open for tests, close on success, use exponential backoff.", "explanation": "Circuit breaker prevents cascading failures by isolating failed dependencies."},
                {"question": f"What observability signals are critical for {{tag}}?", "correct_answer": "Request latency, error rates, resource utilization (CPU, memory), database connections, external API calls.", "explanation": "Key signals provide visibility into system health, performance, and dependencies."},
                {"question": f"How would you implement distributed tracing across {{tag}} services?", "correct_answer": "Pass trace IDs through request headers, log trace IDs with events, aggregate in trace collector.", "explanation": "Distributed tracing correlates events across services, enabling cross-service debugging."},
                {"question": f"How would you test resilience in {{tag}} under failure?", "correct_answer": "Use chaos engineering: simulate delays, service failures, database unavailability, verify graceful degradation.", "explanation": "Chaos engineering proactively uncovers failure modes in controlled conditions."},
                {"question": f"Explain CAP theorem and its relationship to {{tag}}.", "correct_answer": "CAP: can't have all three (Consistency, Availability, Partition tolerance); choose two based on requirements.", "explanation": "Most distributed systems choose AP (eventual consistency) over CA."},
                {"question": f"How would you implement multi-tenancy securely in {{tag}}?", "correct_answer": "Row-level security with tenant IDs, separate schemas/databases, strict authorization, audit logging per tenant.", "explanation": "Multi-tenant isolation requires multiple defense layers and comprehensive audit trails."},
            ]
        }

        # Distribute questions with variety - randomize template selection
        types = ["multiple_choice", "short_answer", "true_false"]
        points_mapping = {
            "BEGINNER": 1,
            "INTERMEDIATE": 2,
            "ADVANCED": 3
        }

        points_per_question = points_mapping.get(difficulty.value, 2)

        # Weight distribution for variety
        if num_questions <= 5:
            distribution = [2, 2, 1]
        elif num_questions <= 10:
            distribution = [4, 3, 3]
        else:
            distribution = [num_questions // 3 + 2, num_questions // 3, num_questions // 3]

        used_questions = set()
        question_count = 0
        import random

        for type_idx, q_type in enumerate(types):
            templates = question_templates.get(q_type, [])
            q_count = min(distribution[type_idx], num_questions - question_count)

            # Randomize template selection for variety
            available_indices = list(range(len(templates)))
            random.shuffle(available_indices)
            selected_indices = available_indices[:min(q_count, len(templates))]

            for idx in selected_indices:
                if question_count >= num_questions:
                    break

                template = templates[idx]
                q_text = template.get('question', '')

                # Skip if we've seen this exact question
                if q_text in used_questions:
                    continue

                used_questions.add(q_text)

                if q_type == "multiple_choice":
                    question = Question(
                        question=f"{question_count + 1}. {q_text}",
                        type=QuestionType.MULTIPLE_CHOICE,
                        options=template.get("options", []),
                        correct_answer=template["correct_answer"],
                        explanation=template["explanation"],
                        points=points_per_question
                    )
                elif q_type == "true_false":
                    question = Question(
                        question=f"{question_count + 1}. {q_text}",
                        type=QuestionType.TRUE_FALSE,
                        options=["True", "False"],
                        correct_answer=template["correct_answer"],
                        explanation=template["explanation"],
                        points=points_per_question
                    )
                else:  # short_answer
                    question = Question(
                        question=f"{question_count + 1}. {q_text}",
                        type=QuestionType.SHORT_ANSWER,
                        options=None,
                        correct_answer=template["correct_answer"],
                        explanation=template["explanation"],
                        points=points_per_question
                    )

                questions.append(question)
                question_count += 1
        
        # Calculate total points
        total_points = sum(q.points for q in questions)

        assessment = Assessment(
            project_id="",
            title=f"Assessment for {project_title}",
            description=f"Fallback assessment covering {', '.join(project_tags) if project_tags else 'general topics'} - {difficulty.value} level",
            difficulty=difficulty,
            questions=questions,
            total_points=total_points if total_points > 0 else len(questions),
            time_limit=max(len(questions) * 3, 45)
        )

        logging.info(f"Generated advanced fallback assessment with {len(questions)} questions at {difficulty.value} level")
        return assessment
    
    @cache_llm_response
    async def generate_assessment(
        self, 
        num_questions: int = 10, 
        difficulty_level: DifficultyLevel = DifficultyLevel.INTERMEDIATE,
        project_title: str = "",
        project_description: str = "",
        project_srs_document: str = None,
        project_plan: str = None,
        project_tags: List[str] = None,
        project_data: Dict[str, Any] = None,
        project_id: str = None,  # For deduplication tracking
        project: Project = None  # Legacy parameter for backward compatibility  
    ) -> Assessment:
        # Handle backward compatibility
        if project is not None:
            num_questions = num_questions
            difficulty_level = difficulty_level
            project_title = project.title
            project_description = project.description
            project_srs_document = project.srs_document if hasattr(project, 'srs_document') else project.document
            project_plan = project.plan if hasattr(project, 'plan') else None
            project_tags = project.tags
        
        if project_tags is None:
            project_tags = []
        
        difficulty = difficulty_level
        
        # ===== QUALITY ENGINE INTEGRATION ====
        project_domain = AssessmentQualityEngine.detect_project_domain(
            title=project_title,
            description=project_description,
            tags=project_tags,
            srs_document=project_srs_document or ""
        )
        logging.info(f"Detected domain: {project_domain.value}")
        
        project_context = {
            "title": project_title,
            "description": project_description,
            "tags": project_tags,
            "srs_document": project_srs_document or "",
            "plan": project_plan or ""
        }
        
        existing_questions = []
        if project_id:
            existing_questions = AssessmentQualityEngine._question_history_cache.get(project_id, [])[-10:]

        system_prompt, human_prompt = AssessmentQualityEngine.generate_prompt_for_domain(
            domain=project_domain,
            num_questions=num_questions,
            difficulty=difficulty,
            project_context=project_context,
            existing_questions=existing_questions
        )

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": human_prompt}
        ]

        try:
            logging.info(f"Generating assessment for domain {project_domain.value}...")
            assessment_data = await self.ollama.generate_json_completion(messages=messages)

            # Create Question objects
            questions = []
            for i, q_data in enumerate(assessment_data.get("questions", [])):
                q_text = q_data.get("question", "")
                if not AssessmentQualityEngine.has_duplicate_question(q_text, project_id):
                    try:
                        question = Question(**q_data)
                        questions.append(question)
                        if project_id:
                            AssessmentQualityEngine.add_to_question_history(project_id, q_text)
                    except Exception as e:
                        logging.debug(f"Failed to parse question {i}: {e}")

            if not questions:
                raise ValueError("No valid questions generated")

            # Validate questions
            validated_questions, validation_report = AssessmentQuestionValidator.validate_assessment_questions(
                questions=[q.dict() for q in questions],
                domain=project_domain,
                difficulty=difficulty,
                project_id=project_id or ""
            )

            # Build final assessment
            final_questions = []
            for q_data in validated_questions:
                try:
                    final_questions.append(Question(**q_data))
                except Exception as e:
                    logging.debug(f"Failed to reconstruct question: {e}")

            if len(final_questions) >= max(num_questions - 2, 1):
                total_points = sum(q.points for q in final_questions)
                assessment = Assessment(
                    project_id="",
                    title=assessment_data.get("title", f"{project_domain.value.replace('_', ' ').title()} Assessment"),
                    description=assessment_data.get("description", f"Assessment for {project_title}"),
                    difficulty=difficulty,
                    questions=final_questions,
                    total_points=total_points if total_points > 0 else len(final_questions),
                    time_limit=max(len(final_questions) * 2, 30)
                )

                logging.info(f"✓ Assessment generated: {len(final_questions)} questions")
                return assessment
            else:
                raise ValueError(f"After validation: {len(final_questions)} questions (required {num_questions - 2})")

        except Exception as e:
            logging.warning(f"Model failed: {str(e)[:100]}")
            logging.warning("Using hardcoded fallback.")
            return self._generate_fallback_assessment(num_questions, difficulty, project_title, project_tags)
    
    # ============================================================================
    # Evaluation Methods (Spec 1.2)
    # ============================================================================
    
    async def evaluate_short_answer(
        self, 
        question: str, 
        correct_answer: str, 
        student_answer: str,
        max_points: int = 1
    ) -> tuple[bool, int, str]:
        """
        Evaluate a short answer question using AI.
        
        Returns:
            (is_correct: bool, points_earned: int, feedback: str)
        """
        prompt = f"""
        As an expert educator, evaluate the following student response to a short-answer question.
        
        QUESTION: {question}
        EXPECTED ANSWER: {correct_answer}
        STUDENT ANSWER: {student_answer}
        MAX POINTS: {max_points}
        
        Evaluate based on:
        1. Correctness of core concepts
        2. Completeness of explanation
        3. Accuracy of technical details
        4. Clarity of understanding
        
        Return ONLY a JSON object:
        {{
            "is_correct": true|false,
            "points_earned": 0-{max_points},
            "feedback": "Specific feedback explaining the evaluation"
        }}
        
        Be fair and give partial credit for answers that demonstrate understanding even if not perfect.
        """
        
        try:
            logging.info("Evaluating short answer with LLM...")
            evaluation = await self.ollama.generate_json_completion(
                messages=[{"role": "user", "content": prompt}]
            )

            is_correct = evaluation.get("is_correct", False)
            points_earned = min(evaluation.get("points_earned", 0), max_points)
            feedback = evaluation.get("feedback", "Answer evaluated")
            
            return is_correct, points_earned, feedback
            
        except Exception as e:
            logging.error(f"Error evaluating short answer: {e}")
            # Fallback: basic string matching
            similarity = self._string_similarity(student_answer.lower(), correct_answer.lower())
            is_correct = similarity > 0.6
            points = max_points if is_correct else 0
            feedback = "Unable to fully evaluate, basic comparison used"
            return is_correct, points, feedback
    
    async def generate_overall_feedback(
        self,
        assessment: Assessment,
        score: ScoreResult,
        question_feedback: List[QuestionFeedbackItem]
    ) -> Dict[str, Any]:
        """
        Generate comprehensive overall feedback for the assessment.
        
        Follows Spec 1.2 output schema:
        - overall_feedback: String assessment of performance
        - strengths: List of demonstrated strengths
        - improvements: List of areas for improvement
        - recommendations: List of learning recommendations
        """
        
        prompt = f"""
        You are PRAXIS, the official AI Support Agent, and an expert educator providing detailed feedback on a student's assessment performance.
        
        ASSESSMENT: {assessment.title}
        Difficulty: {assessment.difficulty}
        
        STUDENT PERFORMANCE:
        - Total Score: {score.total_score}/{score.max_score}
        - Percentage: {score.percentage}%
        - Correct Answers: {score.correct_answers}/{score.total_questions}
        
        QUESTION-BY-QUESTION FEEDBACK:
        """
        
        for fb in question_feedback:
            # Support both dict and Pydantic model objects
            if hasattr(fb, 'question_index'):
                # Pydantic model - use attribute access
                q_index = fb.question_index
                q_text = fb.question
                student_ans = fb.student_answer
                correct_ans = fb.correct_answer
                is_correct = fb.is_correct
            else:
                # Dict - use .get()
                q_index = fb.get('question_index', 0)
                q_text = fb.get('question', '')
                student_ans = fb.get('student_answer', '')
                correct_ans = fb.get('correct_answer', '')
                is_correct = fb.get('is_correct')
            
            prompt += f"""
            Q{q_index + 1}: {q_text}
            - Student: {student_ans}
            - Correct: {correct_ans}
            - Result: {'✓ Correct' if is_correct else '✗ Incorrect'}
            """
        
        prompt += f"""
        Based on this assessment, provide constructive feedback that:
        1. Identifies specific strengths and competencies demonstrated
        2. Highlights areas requiring improvement
        3. Provides actionable recommendations for learning
        4. Offers encouraging but honest overall assessment
        
        Return ONLY a JSON object:
        {{
            "overall_feedback": "Paragraph summarizing overall performance",
            "strengths": ["Strength 1", "Strength 2", "Strength 3"],
            "improvements": ["Area 1", "Area 2", "Area 3"],
            "recommendations": ["Recommendation 1", "Recommendation 2"]
        }}
        """

        try:
            logging.info("Generating overall feedback with LLM...")
            feedback = await self.ollama.generate_json_completion(
                messages=[{"role": "user", "content": prompt}]
            )
            return feedback
            
        except Exception as e:
            logging.error(f"Error generating feedback: {e}")
            # Fallback feedback
            return {
                "overall_feedback": f"You scored {score.total_score}/{score.max_score} ({score.percentage}%). Keep practicing to improve!",
                "strengths": ["Engaged with the assessment"],
                "improvements": ["Review topics where answers were incorrect"],
                "recommendations": ["Focus on understanding core concepts", "Practice more questions"]
            }
    
    def _string_similarity(self, a: str, b: str) -> float:
        """Calculate simple string similarity ratio"""
        from difflib import SequenceMatcher
        return SequenceMatcher(None, a, b).ratio()


# Create global instance with lazy initialization
_llm_service_instance = None

def get_llm_service():
    """Get or create the LLM service instance (lazy initialization)"""
    global _llm_service_instance
    if _llm_service_instance is None:
        _llm_service_instance = LLMService()
    return _llm_service_instance

# For backward compatibility, create a property-like accessor
class _LLMServiceProxy:
    def __getattr__(self, name):
        return getattr(get_llm_service(), name)

llm_service = _LLMServiceProxy()