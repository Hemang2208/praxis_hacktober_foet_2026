import os
import logging
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from pymongo import MongoClient
from typing import Optional
from dotenv import load_dotenv
from pathlib import Path

logger = logging.getLogger(__name__)

# Load environment variables from .env file in the current directory
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path)
class MongoDB:
    client: Optional[AsyncIOMotorClient] = None
    database: Optional[AsyncIOMotorDatabase] = None

# MongoDB connection
mongodb_client = MongoDB()

async def connect_to_mongo():
    """Create database connection"""
    mongodb_uri = os.getenv("MONGODB_URI")
    
    if not mongodb_uri:
        raise ValueError("MONGODB_URI environment variable is not set")
    
    logger.info("Connecting to MongoDB...")
    
    mongodb_client.client = AsyncIOMotorClient(mongodb_uri)
    # Extract database name from URI or use default
    db_name_env = os.getenv("DATABASE_NAME")
    if db_name_env:
        mongodb_client.database = mongodb_client.client[db_name_env]
    elif mongodb_uri and '/' in mongodb_uri:
        db_name = mongodb_uri.split('/')[-1].split('?')[0]  # Extract db name from URI
        mongodb_client.database = mongodb_client.client[db_name]
    else:
        # Fallback to default database name
        mongodb_client.database = mongodb_client.client[os.getenv("ASSESSMENT_DATABASE_NAME", "praxis-assessment")]
    
    # Test the connection
    try:
        await mongodb_client.client.admin.command('ping')
        logger.info("Connected to MongoDB successfully")
    except Exception as e:
        logger.error("Failed to connect to MongoDB: %s", e)
        raise

async def close_mongo_connection():
    """Close database connection"""
    if mongodb_client.client:
        await mongodb_client.client.close()
        logger.info("Disconnected from MongoDB")

def get_database():
    """Get database instance"""
    return mongodb_client.database