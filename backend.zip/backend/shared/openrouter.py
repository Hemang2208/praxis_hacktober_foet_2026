"""Local Ollama LLM integration used by every PRAXIS agent.

All requests are sent to a locally running Ollama instance via ``/api/chat``.
No external/cloud LLM provider, API key, or fallback is used.

The module name is retained for compatibility with existing imports; the
implementation is Ollama-only.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import Any, AsyncIterator, Dict, List, Optional

import aiohttp
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "http://localhost:11434"
DEFAULT_MODEL = "qwen2.5-coder:latest"
DEFAULT_NUM_CTX = 16384
DEFAULT_KEEP_ALIVE = "30m"


def _clean_base_url(value: Optional[str]) -> str:
    return (value or DEFAULT_BASE_URL).strip().rstrip("/")


OLLAMA_BASE_URL = _clean_base_url(os.getenv("OLLAMA_BASE_URL"))
OLLAMA_MODEL = (os.getenv("OLLAMA_MODEL") or DEFAULT_MODEL).strip() or DEFAULT_MODEL


class OllamaServiceError(RuntimeError):
    """Base error raised for failed Ollama requests."""

    def __init__(
        self,
        message: str,
        error_type: str = "ollama_error",
        status_code: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.error_type = error_type
        self.status_code = status_code


class OllamaConnectionError(OllamaServiceError):
    def __init__(self, message: str) -> None:
        super().__init__(message, error_type="connection_error")


class OllamaTimeoutError(OllamaServiceError):
    def __init__(self, message: str) -> None:
        super().__init__(message, error_type="timeout")


class OllamaModelNotFoundError(OllamaServiceError):
    def __init__(self, message: str) -> None:
        super().__init__(message, error_type="model_not_found", status_code=404)


class OllamaInvalidRequestError(OllamaServiceError):
    def __init__(self, message: str) -> None:
        super().__init__(message, error_type="invalid_request", status_code=400)


class OllamaEmptyResponseError(OllamaServiceError):
    def __init__(self, message: str = "Ollama returned an empty response") -> None:
        super().__init__(message, error_type="empty_response")


class OllamaStreamError(OllamaServiceError):
    def __init__(self, message: str) -> None:
        super().__init__(message, error_type="stream_error")


class OllamaService:
    """Async wrapper around the local Ollama ``/api/chat`` endpoint."""

    # Per-agent generation defaults. The model itself is always OLLAMA_MODEL.
    MODELS = {
        "assessment": {"temperature": 0.3, "max_tokens": 2000},
        "planner": {"temperature": 0.3, "max_tokens": 5000},
        "support": {"temperature": 0.7, "max_tokens": 1500},
        "task-mgmt": {"temperature": 0.3, "max_tokens": 2500},
        "code-review": {"temperature": 0.5, "max_tokens": 4000},
    }

    def __init__(self, agent_type: str = "support") -> None:
        self.agent_type = agent_type
        self.ollama_base_url = OLLAMA_BASE_URL
        self.ollama_model = OLLAMA_MODEL

        # Backward-compatible attributes. No API key is required or used.
        self.base_url = self.ollama_base_url
        self.api_key = None
        self.model = self.ollama_model
        self.model_name = self.ollama_model
        self.model_list = [self.ollama_model]
        self.models = [self.ollama_model]

        config = self.MODELS.get(agent_type)
        if config is None:
            logger.warning(
                "Unknown agent_type '%s'; using default generation parameters.",
                agent_type,
            )
            config = {"temperature": 0.5, "max_tokens": 2000}

        self.default_temperature = float(config["temperature"])
        self.default_max_tokens = int(config["max_tokens"])

        self.timeout = float(os.getenv("OLLAMA_TIMEOUT", "600"))
        self.connect_timeout = float(os.getenv("OLLAMA_CONNECT_TIMEOUT", "10"))
        self.max_concurrency = max(1, int(os.getenv("OLLAMA_MAX_CONCURRENCY", "3")))
        self.num_ctx = max(512, int(os.getenv("OLLAMA_NUM_CTX", str(DEFAULT_NUM_CTX))))
        self.keep_alive = (os.getenv("OLLAMA_KEEP_ALIVE") or DEFAULT_KEEP_ALIVE).strip()
        self.max_retries = max(0, int(os.getenv("OLLAMA_MAX_RETRIES", "1")))
        self.retry_backoff = max(0.0, float(os.getenv("OLLAMA_RETRY_BACKOFF", "1.0")))
        self.ollama_semaphore = asyncio.Semaphore(self.max_concurrency)

        self._session: Optional[aiohttp.ClientSession] = None

        logger.info(
            "Ollama service initialized for %s (base_url=%s, model=%s, num_ctx=%s)",
            agent_type,
            self.ollama_base_url,
            self.ollama_model,
            self.num_ctx,
        )

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(
                    total=self.timeout,
                    sock_connect=self.connect_timeout,
                ),
                headers={"Content-Type": "application/json"},
            )
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None

    @property
    def chat_url(self) -> str:
        return f"{self.ollama_base_url}/api/chat"

    @staticmethod
    def _normalize_messages(messages: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        if not messages:
            raise OllamaInvalidRequestError("At least one message is required")

        normalized: List[Dict[str, str]] = []
        for message in messages:
            if not isinstance(message, dict):
                raise OllamaInvalidRequestError("Each message must be a dictionary")

            role = str(message.get("role", "user")).lower()
            if role == "model":
                role = "assistant"
            if role not in {"system", "user", "assistant"}:
                role = "user"

            content = message.get("content", "")
            if content is None:
                content = ""
            if not isinstance(content, str):
                content = str(content)

            normalized.append({"role": role, "content": content})

        return normalized

    def _build_payload(
        self,
        messages: List[Dict[str, Any]],
        temperature: float,
        max_tokens: int,
        *,
        stream: bool,
        json_mode: bool = False,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": self.ollama_model,
            "messages": self._normalize_messages(messages),
            "stream": stream,
            "keep_alive": self.keep_alive,
            "options": {
                "temperature": float(temperature),
                "num_predict": int(max_tokens),
                "num_ctx": int(self.num_ctx),
            },
        }
        if json_mode:
            payload["format"] = "json"
        return payload

    def _raise_for_status(self, status: int, body: str) -> None:
        body_preview = (body or "").strip()[:300]
        detail = f": {body_preview}" if body_preview else ""

        if status == 404:
            lowered = body_preview.lower()
            if "model" in lowered or "not found" in lowered:
                raise OllamaModelNotFoundError(
                    f"Ollama model '{self.ollama_model}' was not found. "
                    f"Run 'ollama pull {self.ollama_model}' and try again{detail}"
                )
            raise OllamaServiceError(
                f"Ollama endpoint not found (HTTP 404){detail}",
                error_type="not_found",
                status_code=status,
            )

        if status == 429:
            raise OllamaServiceError(
                f"Ollama is busy or rate limited (HTTP 429){detail}",
                error_type="rate_limit",
                status_code=status,
            )

        if status == 400:
            raise OllamaInvalidRequestError(
                f"Ollama rejected the request (HTTP 400){detail}"
            )

        if status in (408, 504):
            raise OllamaTimeoutError(
                f"Ollama request timed out (HTTP {status}){detail}"
            )

        if status >= 500:
            raise OllamaServiceError(
                f"Ollama server error (HTTP {status}){detail}",
                error_type="server_error",
                status_code=status,
            )

        raise OllamaServiceError(
            f"Ollama request failed (HTTP {status}){detail}",
            error_type="http_error",
            status_code=status,
        )

    async def _call_ollama(
        self,
        messages: List[Dict[str, Any]],
        temperature: float,
        max_tokens: int,
        json_mode: bool = False,
    ) -> str:
        payload = self._build_payload(
            messages,
            temperature,
            max_tokens,
            stream=False,
            json_mode=json_mode,
        )

        attempts = self.max_retries + 1
        retryable_statuses = {429, 500, 502, 503, 504}

        for attempt in range(attempts):
            try:
                async with self.ollama_semaphore:
                    session = await self._get_session()
                    async with session.post(self.chat_url, json=payload) as response:
                        if response.status != 200:
                            body = await response.text()
                            if (
                                response.status in retryable_statuses
                                and attempt < attempts - 1
                            ):
                                delay = self.retry_backoff * (2 ** attempt)
                                logger.warning(
                                    "Ollama returned HTTP %s; retrying in %.1fs (%d/%d)",
                                    response.status, delay, attempt + 1, attempts,
                                )
                                await asyncio.sleep(delay)
                                continue
                            self._raise_for_status(response.status, body)

                        try:
                            data = await response.json(content_type=None)
                        except (json.JSONDecodeError, aiohttp.ContentTypeError) as exc:
                            raise OllamaServiceError(
                                "Ollama returned a response that was not valid JSON",
                                error_type="invalid_response",
                            ) from exc

                        if data.get("error"):
                            raise OllamaServiceError(
                                f"Ollama returned an error: {data['error']}",
                                error_type="server_error",
                            )

                        message = data.get("message") or {}
                        content = message.get("content") or data.get("response") or ""

                        if not isinstance(content, str) or not content.strip():
                            if attempt < attempts - 1:
                                delay = self.retry_backoff * (2 ** attempt)
                                logger.warning(
                                    "Ollama returned an empty response; retrying in %.1fs (%d/%d)",
                                    delay, attempt + 1, attempts,
                                )
                                await asyncio.sleep(delay)
                                continue
                            raise OllamaEmptyResponseError(
                                "Ollama returned an empty model response"
                            )

                        if data.get("done_reason") == "length":
                            logger.warning(
                                "Ollama stopped at num_predict=%s; output may be truncated",
                                max_tokens,
                            )

                        return content.strip()

            except (asyncio.TimeoutError, aiohttp.ServerTimeoutError) as exc:
                raise OllamaTimeoutError(
                    f"Ollama request timed out after {self.timeout:g}s"
                ) from exc
            except aiohttp.ClientConnectorError as exc:
                if attempt < attempts - 1:
                    delay = self.retry_backoff * (2 ** attempt)
                    logger.warning(
                        "Cannot connect to Ollama; retrying in %.1fs (%d/%d)",
                        delay, attempt + 1, attempts,
                    )
                    await asyncio.sleep(delay)
                    continue
                raise OllamaConnectionError(
                    f"Cannot connect to Ollama at {self.ollama_base_url}. "
                    "Ensure Ollama is running on the host and reachable from this service."
                ) from exc
            except aiohttp.ClientError as exc:
                if attempt < attempts - 1:
                    delay = self.retry_backoff * (2 ** attempt)
                    logger.warning(
                        "Ollama communication error; retrying in %.1fs (%d/%d): %s",
                        delay, attempt + 1, attempts, exc,
                    )
                    await asyncio.sleep(delay)
                    continue
                raise OllamaConnectionError(
                    f"Error communicating with Ollama at {self.ollama_base_url}: {exc}"
                ) from exc
            except OllamaServiceError:
                raise
            except Exception as exc:
                raise OllamaServiceError(
                    f"Unexpected error while calling Ollama: {exc}"
                ) from exc

        raise OllamaServiceError("Ollama request failed after retries")

    async def generate_completion(
        self,
        messages: List[Dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
    ) -> str:
        """Generate a completion using the local Ollama chat endpoint."""
        temperature = (
            temperature if temperature is not None else self.default_temperature
        )
        max_tokens = max_tokens if max_tokens is not None else self.default_max_tokens

        return await self._call_ollama(
            messages,
            temperature,
            max_tokens,
            json_mode=json_mode,
        )

    async def generate_completion_stream(
        self,
        messages: List[Dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
    ) -> AsyncIterator[str]:
        """Stream completion tokens from the local Ollama chat endpoint."""
        temperature = (
            temperature if temperature is not None else self.default_temperature
        )
        max_tokens = max_tokens if max_tokens is not None else self.default_max_tokens
        payload = self._build_payload(
            messages,
            temperature,
            max_tokens,
            stream=True,
            json_mode=json_mode,
        )
        stream_timeout = aiohttp.ClientTimeout(
            total=None,
            sock_connect=self.connect_timeout,
            sock_read=self.timeout,
        )

        emitted = False
        completed = False

        async with self.ollama_semaphore:
            try:
                session = await self._get_session()
                async with session.post(
                    self.chat_url,
                    json=payload,
                    timeout=stream_timeout,
                ) as response:
                    if response.status != 200:
                        body = await response.text()
                        self._raise_for_status(response.status, body)

                    async for raw_line in response.content:
                        line = raw_line.decode("utf-8", errors="ignore").strip()
                        if not line:
                            continue

                        try:
                            chunk = json.loads(line)
                        except json.JSONDecodeError as exc:
                            raise OllamaStreamError(
                                f"Ollama sent an invalid streaming chunk: {line[:120]}"
                            ) from exc

                        if chunk.get("error"):
                            raise OllamaServiceError(
                                f"Ollama streaming error: {chunk['error']}",
                                error_type="stream_error",
                            )

                        message = chunk.get("message") or {}
                        token = message.get("content") or chunk.get("response") or ""
                        if token:
                            emitted = True
                            yield token

                        if chunk.get("done"):
                            completed = True
                            break

                if not completed:
                    raise OllamaStreamError(
                        "Ollama stream ended before the completion finished"
                    )
                if not emitted:
                    raise OllamaEmptyResponseError(
                        "Ollama returned an empty streaming response"
                    )

            except asyncio.TimeoutError as exc:
                raise OllamaTimeoutError(
                    f"Ollama streaming request timed out after {self.timeout:g}s"
                ) from exc
            except aiohttp.ServerTimeoutError as exc:
                raise OllamaTimeoutError(
                    f"Ollama streaming server timed out after {self.timeout:g}s"
                ) from exc
            except aiohttp.ClientConnectorError as exc:
                raise OllamaConnectionError(
                    f"Cannot connect to Ollama at {self.ollama_base_url}. "
                    "Ensure Ollama is running on the host and reachable from this service."
                ) from exc
            except aiohttp.ClientError as exc:
                raise OllamaConnectionError(
                    f"Error streaming from Ollama at {self.ollama_base_url}: {exc}"
                ) from exc
            except OllamaServiceError:
                raise
            except Exception as exc:
                raise OllamaServiceError(
                    f"Unexpected error while streaming from Ollama: {exc}"
                ) from exc

    def _repair_json_response(self, response: str) -> Dict[str, Any]:
        """Parse a JSON response, repairing common small-model formatting issues."""
        if not response or not isinstance(response, str):
            raise OllamaEmptyResponseError(
                "Cannot parse an empty JSON response from Ollama"
            )

        response = response.strip()

        if response.startswith("```json"):
            response = response[7:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()
        elif response.startswith("```"):
            response = response[3:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()

        try:
            return json.loads(response)
        except json.JSONDecodeError:
            pass

        start = -1
        end = -1
        start_brace = response.find("{")
        start_bracket = response.find("[")

        if start_brace != -1 and (start_bracket == -1 or start_brace < start_bracket):
            start = start_brace
            end = response.rfind("}")
        elif start_bracket != -1:
            start = start_bracket
            end = response.rfind("]")

        if start != -1 and end != -1 and start < end:
            response = response[start : end + 1]

        try:
            return json.loads(response)
        except json.JSONDecodeError:
            pass

        response = re.sub(r"{\s+}", "{}", response)
        response = re.sub(
            r"([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:", r'\1"\2":', response
        )
        response = re.sub(r"}\s*\[", "}, [", response)
        response = re.sub(r"}\s*{", "}, {", response)
        response = re.sub(r",\s*}(?=\s*[,\]\}])", "}", response)

        try:
            return json.loads(response)
        except json.JSONDecodeError as exc:
            logger.error("JSON repair failed: %s", exc)
            raise OllamaServiceError(
                f"Failed to parse JSON response from Ollama: {exc}",
                error_type="invalid_json",
            ) from exc

    async def generate_json_completion(
        self,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Generate and parse a JSON completion from local Ollama.

        A single deterministic retry is made when the model emits malformed or
        truncated JSON, which is the most common failure mode for small local
        models under constrained output budgets.
        """
        kwargs.pop("json_mode", None)
        response_text = await self.generate_completion(
            messages=messages,
            json_mode=True,
            **kwargs,
        )
        try:
            return self._repair_json_response(response_text)
        except OllamaServiceError as exc:
            if exc.error_type != "invalid_json":
                raise
            logger.warning("Ollama returned invalid JSON; retrying once: %s", exc)

        retry_kwargs = dict(kwargs)
        requested = retry_kwargs.get("max_tokens") or self.default_max_tokens
        retry_kwargs["max_tokens"] = max(1024, min(int(requested) * 2, 8192))
        retry_kwargs["temperature"] = 0.0
        response_text = await self.generate_completion(
            messages=messages,
            json_mode=True,
            **retry_kwargs,
        )
        return self._repair_json_response(response_text)


# Backward-compatible names. Behaviour is Ollama-only.
OpenRouterService = OllamaService
LLMService = OllamaService

__all__ = [
    "OLLAMA_BASE_URL",
    "OLLAMA_MODEL",
    "DEFAULT_BASE_URL",
    "DEFAULT_MODEL",
    "DEFAULT_NUM_CTX",
    "DEFAULT_KEEP_ALIVE",
    "OllamaService",
    "OllamaServiceError",
    "OllamaConnectionError",
    "OllamaTimeoutError",
    "OllamaModelNotFoundError",
    "OllamaInvalidRequestError",
    "OllamaEmptyResponseError",
    "OllamaStreamError",
    "OpenRouterService",
    "LLMService",
]
