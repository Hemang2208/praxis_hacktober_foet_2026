import time
import uuid
import logging
from typing import Optional
import redis.asyncio as aioredis

logger = logging.getLogger(__name__)

# Basic SETNX lock implementation since aioredis.lock has some caveats in older versions
# and redlock-py is mostly sync. We will implement a simple async lock.

class DistributedLock:
    def __init__(self, redis: aioredis.Redis, name: str, timeout: int = 10000):
        """
        timeout: Lock duration in milliseconds (default 10s)
        """
        self.redis = redis
        self.name = f"lock:{name}"
        self.timeout = timeout
        self.identifier = str(uuid.uuid4())
        self.is_locked = False

    async def acquire(self) -> bool:
        """
        Attempts to acquire the lock. Returns True if successful.
        Uses SET key value NX PX timeout.
        """
        if not self.redis:
            return False

        try:
            result = await self.redis.set(
                self.name, 
                self.identifier, 
                nx=True, 
                px=self.timeout
            )
            self.is_locked = bool(result)
            return self.is_locked
        except Exception as e:
            logger.error(f"Error acquiring lock {self.name}: {e}")
            return False

    async def release(self):
        """
        Releases the lock. Uses Lua script to ensure we only release our own lock.
        """
        if not self.redis or not self.is_locked:
            return

        lua_script = """
        if redis.call("get", KEYS[1]) == ARGV[1] then
            return redis.call("del", KEYS[1])
        else
            return 0
        end
        """
        try:
            await self.redis.eval(lua_script, 1, self.name, self.identifier)
            self.is_locked = False
        except Exception as e:
            logger.error(f"Error releasing lock {self.name}: {e}")

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.release()

async def acquire_lock(redis_client: Optional[aioredis.Redis], lock_name: str, timeout_ms: int = 5000) -> DistributedLock:
    """
    Helper function to get an un-acquired lock object. 
    You must call .acquire() on it.
    """
    return DistributedLock(redis_client, lock_name, timeout_ms)
