"""Backward-compatible import path for the local Ollama integration.

All AI requests are handled locally by :mod:`shared.openrouter`, which talks to
Ollama at ``OLLAMA_BASE_URL`` (default ``http://localhost:11434``) using
``OLLAMA_MODEL`` (default ``qwen2.5-coder:latest``).
"""

try:
    from shared.openrouter import *  # noqa: F401,F403
    from shared.openrouter import __all__  # noqa: F401
except ImportError:  # when running from inside the shared/ directory
    from openrouter import *  # type: ignore  # noqa: F401,F403
    from openrouter import __all__  # type: ignore  # noqa: F401
