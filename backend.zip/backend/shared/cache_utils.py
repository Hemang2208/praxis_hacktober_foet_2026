import os
import json
import time
import random
import logging
from typing import Any, Optional
import redis.asyncio as aioredis
from redis.exceptions import ResponseError

logger = logging.getLogger(__name__)

# Constants
HOT_KEY_REPLICAS = 10
NULL_SENTINEL = "__NULL__"

class CacheManager:
    def __init__(self, redis_url: str = None):
        self.redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379")
        self.redis: Optional[aioredis.Redis] = None
        self.bloom_enabled = str(os.getenv("ENABLE_BLOOM_FILTER", "false")).lower() in ("true", "1", "yes")

    async def connect(self):
        if not self.redis:
            self.redis = await aioredis.from_url(
                self.redis_url, 
                encoding="utf-8", 
                decode_responses=True
            )
            try:
                await self.redis.ping()
                safe_url = self.redis_url.split("@")[-1] if "@" in self.redis_url else self.redis_url
                logger.info(f"✅ REDIS CACHE CONNECTED | url={safe_url}")
                # Optional: Ensure bloom filter exists if enabled
                if self.bloom_enabled:
                    try:
                        # CF.RESERVE is a Cuckoo filter, BF.RESERVE is Bloom. We use BF.
                        # We just check if module is loaded. We won't reserve here to avoid overwriting.
                        pass
                    except Exception as e:
                        logger.warning(f"⚠️ Bloom filter check failed: {e}")
            except Exception as e:
                safe_url = self.redis_url.split("@")[-1] if "@" in self.redis_url else self.redis_url
                logger.error(f"❌ REDIS CONNECTION FAILED | url={safe_url} | error={str(e)}")
                self.redis = None

    async def disconnect(self):
        if self.redis:
            await self.redis.close()

    # --- Standard Caching with Soft Expiry and Null Sentinel ---
    
    async def get_cached(self, key: str) -> tuple[Optional[Any], bool]:
        """
        Get value from cache. 
        Returns (data, is_stale).
        If data is NULL_SENTINEL, returns (NULL_SENTINEL, False) which callers should treat as DB miss.
        """
        if not self.redis:
            return None, False

        raw_data = await self.redis.get(key)
        if raw_data is None:
            return None, False
        
        if raw_data == NULL_SENTINEL:
            return NULL_SENTINEL, False

        try:
            payload = json.loads(raw_data)
            # Check soft expiry format
            if isinstance(payload, dict) and "logical_expire_at" in payload and "value" in payload:
                now = time.time()
                is_stale = now >= payload.get("logical_expire_at", 0)
                return payload["value"], is_stale
            else:
                # Standard raw JSON format (legacy/without soft expiry)
                return payload, False
        except json.JSONDecodeError:
            # If not JSON, return as string
            return raw_data, False

    async def set_cached(self, key: str, value: Any, ttl: int, soft_ttl: Optional[int] = None):
        """
        Set value in cache.
        If soft_ttl is provided, it stores a logical expiry timestamp inside.
        """
        if not self.redis:
            return

        if value == NULL_SENTINEL:
            await self.redis.setex(key, ttl, NULL_SENTINEL)
            return

        payload = value
        if soft_ttl is not None:
            payload = {
                "value": value,
                "logical_expire_at": time.time() + soft_ttl
            }
        
        if not isinstance(payload, str):
            payload = json.dumps(payload)
            
        await self.redis.setex(key, ttl, payload)

    # --- Bloom Filter (Cache Penetration) ---

    async def check_bloom(self, key: str, filter_name: str = "global_bloom") -> bool:
        """
        Returns True if the key *might* exist, False if it *definitely does not* exist.
        """
        if not self.redis or not self.bloom_enabled:
            return True # Fail open if disabled

        try:
            # Using BF.EXISTS command
            result = await self.redis.execute_command("BF.EXISTS", filter_name, key)
            return bool(result)
        except ResponseError as e:
            if "ERR unknown command" in str(e):
                logger.error("RedisBloom module not loaded on server. Disabling bloom checks.")
                self.bloom_enabled = False
                return True
            logger.error(f"Bloom filter check error: {e}")
            return True

    async def bloom_add(self, key: str, filter_name: str = "global_bloom"):
        """
        Adds a key to the bloom filter after a confirmed DB write.
        """
        if not self.redis or not self.bloom_enabled:
            return

        try:
            await self.redis.execute_command("BF.ADD", filter_name, key)
        except ResponseError as e:
            logger.error(f"Bloom filter add error: {e}")

    # --- Key Salting (Hot Key Overload) ---

    async def set_hot_key(self, key: str, value: Any, ttl: int):
        if not self.redis:
            return
            
        payload = value
        if not isinstance(payload, str):
            payload = json.dumps(payload)

        pipeline = self.redis.pipeline()
        for i in range(HOT_KEY_REPLICAS):
            pipeline.setex(f"{key}_{i}", ttl, payload)
        await pipeline.execute()

    async def get_hot_key(self, key: str) -> Optional[Any]:
        if not self.redis:
            return None
            
        suffix = random.randint(0, HOT_KEY_REPLICAS - 1)
        raw_data = await self.redis.get(f"{key}_{suffix}")
        
        if raw_data is None:
            return None
            
        try:
            return json.loads(raw_data)
        except json.JSONDecodeError:
            return raw_data

# Singleton instance
cache_manager = CacheManager()
