"""Backward-compatible import path for the local Ollama integration.

The PRAXIS backend no longer uses OpenRouter. Existing imports keep working,
but every call is handled locally by :mod:`shared.openrouter`.
"""

try:
    from shared.openrouter import *  # noqa: F401,F403
    from shared.openrouter import __all__  # noqa: F401
except ImportError:  # when running from inside the shared/ directory
    from openrouter import *  # type: ignore  # noqa: F401,F403
    from openrouter import __all__  # type: ignore  # noqa: F401
