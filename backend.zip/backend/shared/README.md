# Shared Authentication Module

This directory contains shared JWT authentication utilities used across all PRAXIS Backend microservices.

## Files

- `auth_utils.py` - Core JWT authentication functions
- `__init__.py` - Module exports
- `requirements.txt` - Dependencies

## Usage

From any microservice:

```python
import sys
from pathlib import Path

# Add shared module to path
shared_path = Path(__file__).parent.parent / "shared"
sys.path.insert(0, str(shared_path))

from auth_utils import get_current_user, create_token_pair

# Use in FastAPI routes
@app.get("/protected")
async def protected_route(current_user: dict = Depends(get_current_user)):
    return {"user_id": current_user["user_id"]}
```

## Functions

- `create_access_token()` - Generate short-lived access token (15 min)
- `create_refresh_token()` - Generate long-lived refresh token (7 days)
- `create_token_pair()` - Generate both tokens at once
- `verify_access_token()` - Verify and decode access token
- `verify_refresh_token()` - Verify and decode refresh token
- `hash_password()` - Hash password with bcrypt
- `verify_password()` - Verify password against hash
- `get_current_user()` - FastAPI dependency for protected routes
- `get_current_user_optional()` - FastAPI dependency for optional auth
