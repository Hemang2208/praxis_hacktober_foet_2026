import os
import bcrypt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import JWTError, jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

# Configuration - should be loaded from environment in production
# Use lazy initialization so the module can be imported without the env var set.
# A clear ValueError is raised on first use if JWT_SECRET_KEY is missing.
_SECRET_KEY: Optional[str] = None

def _get_secret_key() -> str:
    global _SECRET_KEY
    if _SECRET_KEY is None:
        key = os.getenv("JWT_SECRET_KEY")
        if not key:
            raise ValueError(
                "JWT_SECRET_KEY environment variable is not set. "
                "Set it in your .env file or export it before starting the service."
            )
        _SECRET_KEY = key
    return _SECRET_KEY

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

# Security setup
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login", auto_error=False)

# --- Password Utilities ---

def hash_password(password: str) -> str:
    """Hash a plain text password using bcrypt"""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain text password against a bcrypt hash"""
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

# --- Token Creation Utilities ---

def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """Generate a short-lived access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire, "type": "access"})
    encoded_jwt = jwt.encode(to_encode, _get_secret_key(), algorithm=ALGORITHM)
    return encoded_jwt

def create_refresh_token(data: Dict[str, Any]) -> str:
    """Generate a long-lived refresh token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, _get_secret_key(), algorithm=ALGORITHM)
    return encoded_jwt

def create_token_pair(data: Dict[str, Any]) -> Dict[str, str]:
    """Generate both access and refresh tokens"""
    return {
        "access_token": create_access_token(data),
        "refresh_token": create_refresh_token(data),
        "token_type": "bearer"
    }

# --- Token Verification Utilities ---

def verify_access_token(token: str) -> Optional[Dict[str, Any]]:
    """Verify and decode an access token"""
    try:
        payload = jwt.decode(token, _get_secret_key(), algorithms=[ALGORITHM])
        if payload.get("type") != "access":
            return None
        return payload
    except JWTError:
        return None

def verify_refresh_token(token: str) -> Optional[Dict[str, Any]]:
    """Verify and decode a refresh token"""
    try:
        payload = jwt.decode(token, _get_secret_key(), algorithms=[ALGORITHM])
        if payload.get("type") != "refresh":
            return None
        return payload
    except JWTError:
        return None

# --- FastAPI Dependencies ---

async def get_current_user(token: str = Depends(oauth2_scheme)) -> Dict[str, Any]:
    """FastAPI dependency to get the current authenticated user"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    if not token:
        raise credentials_exception
        
    payload = verify_access_token(token)
    if payload is None:
        raise credentials_exception
        
    # In a real app, you might fetch the user from a database here
    # For now, we'll return the payload which contains user information
    user_id = payload.get("sub") or payload.get("user_id")
    if user_id is None:
        raise credentials_exception
        
    return payload

async def get_current_user_optional(token: str = Depends(oauth2_scheme)) -> Optional[Dict[str, Any]]:
    """FastAPI dependency that returns user if authenticated, else None"""
    if not token:
        return None
        
    payload = verify_access_token(token)
    return payload
