"""Provider-neutral prompt formatting helpers."""

from typing import Dict, List


def format_ollama_prompt(messages: List[Dict[str, str]]) -> str:
    """Preserve chat-style roles for instruct models using Ollama generate.

    Wraps each message in explicit role markers so small instruct models
    (qwen2.5-coder, etc.) can distinguish system instructions from user
    messages and don't conflate the user profile data with their own identity.

    Output format:
        [SYSTEM INSTRUCTIONS]
        <content>
        [END SYSTEM INSTRUCTIONS]

        [USER]
        <content>
        [END USER]

        [ASSISTANT]          <- open marker, model fills from here
    """
    role_labels = {
        "system":    "SYSTEM INSTRUCTIONS",
        "user":      "USER",
        "assistant": "ASSISTANT",
    }
    sections = []
    for message in messages:
        content = str(message.get("content", "")).strip()
        if not content:
            continue
        role = role_labels.get(message.get("role", "user"), "USER")
        sections.append(f"[{role}]\n{content}\n[END {role}]")
    sections.append("[ASSISTANT]\n")
    return "\n\n".join(sections)
