"""
Shared Utilities for PRAXIS Backend
"""

__version__ = "1.0.0"
