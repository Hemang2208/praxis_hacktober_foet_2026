"""
Shared logging configuration for all PRAXIS backend services.
Provides consistent log formatting, levels, and structured output.
"""
import logging
import sys
import os


def configure_logging(service_name: str = "praxis") -> logging.Logger:
    """
    Configure logging with consistent formatting.
    
    - DEVELOPMENT: human-readable format with timestamps
    - PRODUCTION: JSON format for log aggregation (when JSON_LOGS=true)
    
    Returns the root logger for the service.
    """
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    json_logs = os.getenv("JSON_LOGS", "").lower() in ("1", "true", "yes")
    
    logger = logging.getLogger(service_name)
    logger.setLevel(log_level)
    
    # Avoid duplicate handlers
    if logger.handlers:
        return logger
    
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(log_level)
    
    if json_logs:
        import json
        
        class JSONFormatter(logging.Formatter):
            def format(self, record: logging.LogRecord) -> str:
                log_entry = {
                    "timestamp": self.formatTime(record),
                    "level": record.levelname,
                    "logger": record.name,
                    "message": record.getMessage(),
                }
                if record.exc_info and record.exc_info[0]:
                    log_entry["exception"] = self.formatException(record.exc_info)
                return json.dumps(log_entry)
        
        handler.setFormatter(JSONFormatter())
    else:
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
    
    logger.addHandler(handler)
    return logger
