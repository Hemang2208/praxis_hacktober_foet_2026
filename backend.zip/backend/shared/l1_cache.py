from cachetools import TTLCache
import threading
from typing import Any, Optional

# L1 Cache is an in-memory, process-local cache.
# It uses a global lock to ensure thread safety (even though asyncio is cooperative, 
# if multiple threads are involved in the web server worker, lock is safer).

_cache = TTLCache(maxsize=1024, ttl=5)
_lock = threading.Lock()

def l1_get(key: str) -> Optional[Any]:
    """
    Get value from local in-memory cache.
    """
    with _lock:
        return _cache.get(key)

def l1_set(key: str, value: Any):
    """
    Set value in local in-memory cache.
    Max 1024 entries, TTL 5 seconds.
    """
    with _lock:
        _cache[key] = value

def l1_delete(key: str):
    """
    Remove key from L1 cache.
    """
    with _lock:
        _cache.pop(key, None)
