import os
from dotenv import load_dotenv

load_dotenv()

# MongoDB Configuration
MONGODB_URI = os.getenv("MONGODB_URI")
if not MONGODB_URI:
    raise ValueError("MONGODB_URI is not set in environment variables. Please configure it in .env file.")
DATABASE_NAME = os.getenv("DATABASE_NAME", "praxis-aipm")

# Local Ollama Configuration
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:latest")

# Site Configuration
SITE_URL = os.getenv("SITE_URL", "http://localhost:8005")
SITE_NAME = os.getenv("SITE_NAME", "PRAXIS Support Agent")

# GitHub Configuration (if needed for integration)
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

# App Configuration
API_VERSION = "1.0.0"
DEBUG = os.getenv("DEBUG", "False").lower() == "true"

# Support Agent Specific Configuration
DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100
TASK_ANALYSIS_MAX_TOKENS = 2000
TASK_ANALYSIS_TEMPERATURE = 0.7

# AI Configuration
AI_ANALYSIS_ENABLED = os.getenv("AI_ANALYSIS_ENABLED", "True").lower() == "true"
AI_RECOMMENDATIONS_ENABLED = os.getenv("AI_RECOMMENDATIONS_ENABLED", "True").lower() == "true"
AI_RISK_ASSESSMENT_ENABLED = os.getenv("AI_RISK_ASSESSMENT_ENABLED", "True").lower() == "true"

# Cache Configuration
REDIS_URL = os.getenv("REDIS_URL", None)
CACHE_TTL = int(os.getenv("CACHE_TTL", "3600"))  # 1 hour default

# Rate Limiting
RATE_LIMIT_REQUESTS = int(os.getenv("RATE_LIMIT_REQUESTS", "100"))
RATE_LIMIT_WINDOW = int(os.getenv("RATE_LIMIT_WINDOW", "60"))  # per minute

# JWT Configuration
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-super-secret-jwt-key-change-this-in-production")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
JWT_ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "30"))