"""Test script to verify the local Ollama integration."""
import asyncio
import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), "..", ".."))

from shared.ollama_service import OllamaService


async def test_ollama():
    ollama = OllamaService(agent_type="support")
    try:
        print("=" * 60)
        print("Testing local Ollama integration")
        print("=" * 60)
        print(f"Base URL: {ollama.ollama_base_url}")
        print(f"Model: {ollama.ollama_model}")

        response = await ollama.generate_completion(
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful AI assistant for task management.",
                },
                {
                    "role": "user",
                    "content": "Say hello and confirm you can help with task management. Keep it brief.",
                },
            ],
            temperature=0.7,
            max_tokens=100,
        )

        print("\nSUCCESS: Ollama responded.")
        print("-" * 60)
        print(response)
        print("-" * 60)
        return True
    except Exception as e:
        print(f"\nERROR: {e}")
        return False
    finally:
        await ollama.close()


if __name__ == "__main__":
    success = asyncio.run(test_ollama())
    raise SystemExit(0 if success else 1)
