"""Regression tests for PRAXIS support context retrieval."""
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch

from bson import ObjectId

from comprehensive_ai_service import ComprehensiveAIService
from comprehensive_data_service import ComprehensiveDataService
from comprehensive_models import (
    ProjectData,
    ProjectPlan,
    TaskData,
    UserComprehensiveContext,
    UserProfile,
)
from context_retrieval_service import ContextRetrievalService


class FakeDataService:
    def __init__(self, context):
        self.context = context

    async def get_comprehensive_user_context(self, user_id):
        return self.context

    async def get_project_member_directory(self, viewer_user_id, projects=None):
        members = {}
        for project in projects if projects is not None else self.context.projects:
            for member in [*project.team_members, *project.team]:
                if member.user:
                    members[str(member.user)] = {
                        "id": str(member.user),
                        "name": member.name,
                        "email": member.email or "",
                        "project_ids": [str(project.id)],
                    }
        return list(members.values())

    async def get_tasks_for_assignee(self, viewer_user_id, target_user_id, limit=100):
        return [
            task
            for task in self.context.tasks
            if str(task.assigned_to or "") == str(target_user_id)
        ][:limit]


class FakeRedis:
    def __init__(self):
        self.store = {}

    async def get(self, key):
        return self.store.get(key)

    async def setex(self, key, ttl, value):
        self.store[key] = value


class FakeOllama:
    def __init__(self):
        self.messages = None

    async def generate_completion(self, messages, temperature=0.7, max_tokens=1000):
        self.messages = messages
        return "Grounded answer"


def make_context():
    now = datetime.now()
    project = ProjectData(
        _id=str(ObjectId()),
        title="Apollo Platform",
        description="Internal analytics platform for Apollo launch planning.",
        status="in-progress",
        progress=42,
        deadline=now + timedelta(days=10),
        tags=["analytics", "react"],
        tasks=[],
        team_members=[
            {"name": "Ada Lovelace", "role": "Project Lead", "user": "u1"}
        ],
    )
    other_project = ProjectData(
        _id=str(ObjectId()),
        title="Zephyr Mobile",
        description="Unrelated mobile application.",
        status="planning",
        progress=5,
        tags=["mobile"],
    )
    task = TaskData(
        _id=str(ObjectId()),
        title="Implement Apollo metrics API",
        description="Build the endpoint that serves Apollo dashboard metrics.",
        status="in-progress",
        priority="high",
        project_id=project.id,
        assigned_to="user-1",
        due_date=now + timedelta(days=2),
        tags=["fastapi", "metrics"],
        sub_tasks=[
            {"title": "Define response schema", "completed": True},
            {"title": "Add aggregation query", "completed": False},
        ],
    )
    other_task = TaskData(
        _id=str(ObjectId()),
        title="Fix Zephyr onboarding",
        description="Unrelated mobile onboarding issue.",
        status="todo",
        priority="medium",
        project_id=other_project.id,
        assigned_to="u1",
    )
    plan = ProjectPlan(
        _id=str(ObjectId()),
        project_id=project.id,
        summary="Apollo analytics plan",
        tech_stack=["FastAPI", "React"],
        key_features_deliverables=["Metrics API", "Executive dashboard"],
        major_milestones=[{"name": "Metrics beta", "timeline": "2026-11-15"}],
        high_level_tasks=[{"name": "Ship metrics API", "duration": "1 week"}],
        updated_at="2026-10-30",
        created_at="2026-10-01",
    )
    profile = UserProfile(
        _id="user-1",
        full_name="Test User",
        email="test@example.com",
        role="student",
        skills=["Python", "React"],
    )
    return UserComprehensiveContext(
        user_profile=profile,
        tasks=[task, other_task],
        projects=[project, other_project],
        project_plans=[plan],
        total_tasks=2,
        completed_tasks=0,
        active_projects=2,
    )


class ContextRetrievalTests(unittest.IsolatedAsyncioTestCase):
    async def test_named_project_retrieves_details_not_just_titles(self):
        service = ContextRetrievalService(FakeDataService(make_context()))
        result = await service.retrieve("user-1", "Tell me everything about Apollo Platform")
        prompt = service.format_context_for_prompt(result)

        self.assertFalse(result["is_broad"])
        self.assertEqual([project.title for project in result["projects"]], ["Apollo Platform"])
        self.assertIn("Implement Apollo metrics API", [task.title for task in result["tasks"]])
        self.assertNotIn("Zephyr Mobile", [project.title for project in result["projects"]])

        self.assertIn("Internal analytics platform for Apollo launch planning.", prompt)
        self.assertIn("Build the endpoint that serves Apollo dashboard metrics.", prompt)
        self.assertIn("Define response schema", prompt)
        self.assertIn("Metrics beta", prompt)
        self.assertIn("Apollo analytics plan", prompt)
        self.assertLessEqual(len(prompt), service.MAX_CONTEXT_CHARS)

    async def test_broad_query_selects_all_accessible_records(self):
        service = ContextRetrievalService(FakeDataService(make_context()))
        result = await service.retrieve("user-1", "Give me an overview of all my work")

        self.assertTrue(result["is_broad"])
        self.assertEqual({project.title for project in result["projects"]}, {
            "Apollo Platform",
            "Zephyr Mobile",
        })
        self.assertEqual({task.title for task in result["tasks"]}, {
            "Implement Apollo metrics API",
            "Fix Zephyr onboarding",
        })

    async def test_followup_reuses_redis_entities(self):
        redis = FakeRedis()
        service = ContextRetrievalService(FakeDataService(make_context()))

        with patch.object(ContextRetrievalService, "_get_redis", return_value=redis):
            first = await service.retrieve(
                "user-1", "Tell me about Apollo Platform", session_id="session-1"
            )
            second = await service.retrieve(
                "user-1", "What about its tasks?", session_id="session-1"
            )

        self.assertEqual([project.title for project in first["projects"]], ["Apollo Platform"])
        self.assertTrue(second["sources"]["redis_session"])
        self.assertEqual([project.title for project in second["projects"]], ["Apollo Platform"])
        self.assertIn(
            "Implement Apollo metrics API",
            [task.title for task in second["tasks"]],
        )

    async def test_my_tasks_filters_to_authenticated_user_assignments(self):
        service = ContextRetrievalService(FakeDataService(make_context()))
        result = await service.retrieve("user-1", "Show me my tasks")

        self.assertEqual(result["assignment_filter"]["user_id"], "user-1")
        self.assertTrue(result["assignment_filter"]["resolved"])
        self.assertEqual(
            [task.title for task in result["tasks"]],
            ["Implement Apollo metrics API"],
        )

    async def test_named_user_tasks_filter_to_that_user_only(self):
        service = ContextRetrievalService(FakeDataService(make_context()))
        result = await service.retrieve(
            "user-1", "Show tasks assigned to Ada Lovelace"
        )

        self.assertEqual(result["assignment_filter"]["user_id"], "u1")
        self.assertEqual(
            [task.title for task in result["tasks"]],
            ["Fix Zephyr onboarding"],
        )
        prompt = service.format_context_for_prompt(result)
        self.assertIn("filtered to assignments for Ada Lovelace", prompt)
        self.assertNotIn("Implement Apollo metrics API", prompt)

    async def test_unresolved_assignee_does_not_fall_back_to_all_tasks(self):
        service = ContextRetrievalService(FakeDataService(make_context()))
        result = await service.retrieve(
            "user-1", "Show tasks assigned to Unknown Person"
        )

        self.assertFalse(result["assignment_filter"]["resolved"])
        self.assertEqual(result["tasks"], [])
        prompt = service.format_context_for_prompt(result)
        self.assertIn("could not be resolved", prompt)

    async def test_project_task_query_still_returns_all_project_tasks(self):
        service = ContextRetrievalService(FakeDataService(make_context()))
        result = await service.retrieve(
            "user-1", "What tasks are in the Apollo Platform project?"
        )

        self.assertIsNone(result["assignment_filter"])
        self.assertEqual(
            {task.title for task in result["tasks"]},
            {"Implement Apollo metrics API"},
        )

    async def test_ai_service_uses_retrieved_details_and_fresh_context_metadata(self):
        context = make_context()
        ai_service = ComprehensiveAIService()
        ai_service.data_service = FakeDataService(context)
        ai_service.context_retrieval = ContextRetrievalService(ai_service.data_service)
        ai_service.ollama = FakeOllama()

        result = await ai_service.answer_comprehensive_query(
            "user-1", "What is the status of the Apollo metrics API task?"
        )

        self.assertEqual(result["answer"], "Grounded answer")
        system_prompt = ai_service.ollama.messages[0]["content"]
        self.assertIn("Implement Apollo metrics API", system_prompt)
        self.assertIn("Build the endpoint that serves Apollo dashboard metrics.", system_prompt)
        self.assertEqual(result["context_used"]["retrieval_source"], "mongodb")
        self.assertEqual(result["context_used"]["selected_projects"], 1)
        self.assertGreaterEqual(result["context_used"]["selected_tasks"], 1)


class WebSocketControlTests(unittest.TestCase):
    def test_ping_is_control_message_not_invalid_query(self):
        from fastapi.testclient import TestClient
        from main import app
        from comprehensive_ai_service import get_comprehensive_ai_service

        class FakeAI:
            def __init__(self):
                self.queries = []

            async def stream_comprehensive_query(self, user_id, query, session_id, mgr):
                self.queries.append(query)
                await mgr.send_event(
                    session_id, "message_complete", {"answer": "ok"}
                )

        fake_ai = FakeAI()
        app.dependency_overrides[get_comprehensive_ai_service] = lambda: fake_ai
        client = TestClient(app)
        try:
            with patch("comprehensive_routes.verify_token", return_value="user-1"):
                with client.websocket_connect(
                    "/api/v1/assistant/ws/chat/session-test?token=test"
                ) as websocket:
                    websocket.send_json({"type": "ping"})
                    self.assertEqual(websocket.receive_json()["type"], "pong")

                    websocket.send_json({"query": "Show my tasks"})
                    self.assertEqual(
                        websocket.receive_json()["type"], "message_complete"
                    )
            self.assertEqual(fake_ai.queries, ["Show my tasks"])
        finally:
            app.dependency_overrides.pop(get_comprehensive_ai_service, None)


class DataServiceRegressionTests(unittest.TestCase):
    def test_task_access_filter_uses_student_id_and_project_link(self):
        conditions = ComprehensiveDataService._task_access_conditions(
            ["user-1", ObjectId()], ["project-1", ObjectId()]
        )
        fields = {next(iter(condition.keys())) for condition in conditions}
        self.assertIn("student_id", fields)
        self.assertIn("project_id", fields)
        self.assertIn("assigned_to", fields)

    def test_assignment_filter_excludes_creator_fields(self):
        conditions = ComprehensiveDataService._task_assignment_conditions(
            ["user-1", ObjectId()]
        )
        fields = {next(iter(condition.keys())) for condition in conditions}
        self.assertIn("student_id", fields)
        self.assertIn("assigned_to", fields)
        self.assertIn("assignedTo", fields)
        self.assertIn("assignee", fields)
        self.assertNotIn("createdBy", fields)
        self.assertNotIn("created_by", fields)

    def test_project_access_filter_uses_owner_and_membership_fields(self):
        conditions = ComprehensiveDataService._project_access_conditions(["user-1"])
        fields = {next(iter(condition.keys())) for condition in conditions}
        self.assertIn("created_by", fields)
        self.assertIn("createdBy", fields)
        self.assertIn("team.user", fields)
        self.assertIn("team_members.user", fields)

    def test_task_parser_handles_object_ids_and_null_subtask_flags(self):
        task = ComprehensiveDataService._task_from_document(
            {
                "_id": ObjectId(),
                "title": "Parser test",
                "status": "todo",
                "priority": "high",
                "project_id": ObjectId(),
                "ai_feedback": ObjectId(),
                "sub_tasks": [
                    {"_id": ObjectId(), "title": "Child", "completed": None}
                ],
            }
        )
        self.assertIsInstance(task.project_id, str)
        self.assertIsInstance(task.ai_feedback, str)
        self.assertFalse(task.sub_tasks[0].completed)
        self.assertIsInstance(task.sub_tasks[0].id, str)


if __name__ == "__main__":
    unittest.main()
