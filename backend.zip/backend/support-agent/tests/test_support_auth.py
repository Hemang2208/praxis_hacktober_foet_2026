import requests
import time

BASE_URL = "http://localhost:8005/api/v1"

def test_auth_flow():
    print("Testing Support Agent Authentication Flow...")
    
    # 1. Register a test user
    test_user = {
        "email": f"test_user_{int(time.time())}@example.com",
        "password": "testpassword123",
        "full_name": "Test User",
        "role": "student"
    }
    
    print("\n1. Testing Registration...")
    try:
        reg_response = requests.post(f"{BASE_URL}/auth/register", json=test_user)
        print(f"Status: {reg_response.status_code}")
        if reg_response.status_code != 200:
            print(f"Registration failed: {reg_response.text}")
            return
        print(f"Response: {reg_response.json()}")
    except Exception as e:
        print(f"Error during registration: {e}")
        return

    # 2. Login
    print("\n2. Testing Login...")
    login_data = {
        "email": test_user["email"],
        "password": test_user["password"]
    }
    try:
        login_response = requests.post(f"{BASE_URL}/auth/login", json=login_data)
        print(f"Status: {login_response.status_code}")
        if login_response.status_code == 200:
            tokens = login_response.json()
            access_token = tokens["access_token"]
            refresh_token = tokens["refresh_token"]
            print("Login success. Tokens received.")
        else:
            print(f"Login failed: {login_response.text}")
            return
    except Exception as e:
        print(f"Error during login: {e}")
        return

    # 3. Access protected endpoint
    print("\n3. Testing Protected Endpoint Access...")
    headers = {"Authorization": f"Bearer {access_token}"}
    try:
        profile_response = requests.get(f"{BASE_URL}/my-tasks/", headers=headers)
        print(f"Status: {profile_response.status_code}")
        if profile_response.status_code == 200:
            print("Success: Accessed protected /my-tasks/ endpoint.")
        else:
            print(f"Failure: Could not access protected endpoint. Status: {profile_response.status_code}")
            print(f"Detail: {profile_response.text}")
    except Exception as e:
        print(f"Error accessing protected endpoint: {e}")

    # 4. Test Token Refresh
    print("\n4. Testing Token Refresh...")
    refresh_data = {"refresh_token": refresh_token}
    try:
        refresh_response = requests.post(f"{BASE_URL}/auth/refresh", json=refresh_data)
        print(f"Status: {refresh_response.status_code}")
        if refresh_response.status_code == 200:
            new_tokens = refresh_response.json()
            new_access_token = new_tokens["access_token"]
            print("Token refresh success. New access token received.")
            
            # Verify new access token works
            headers = {"Authorization": f"Bearer {new_access_token}"}
            new_profile_response = requests.get(f"{BASE_URL}/my-tasks/", headers=headers)
            if new_profile_response.status_code == 200:
                print("Success: New access token works.")
            else:
                print(f"Failure: New access token does not work. Status: {new_profile_response.status_code}")
        else:
            print(f"Token refresh failed: {refresh_response.text}")
    except Exception as e:
        print(f"Error during refresh test: {e}")

    # 5. Testing Unauthorized Access...
    print("\n5. Testing Unauthorized Access...")
    try:
        unauth_response = requests.get(f"{BASE_URL}/my-tasks/")
        print(f"Status: {unauth_response.status_code}")
        if unauth_response.status_code == 401:
            print("Success: Unauthorized access correctly rejected (401).")
        else:
            print(f"Failure: Unauthorized access should return 401, but returned {unauth_response.status_code}.")
    except Exception as e:
        print(f"Error during unauth test: {e}")

if __name__ == "__main__":
    print("NOTE: Ensure the Support Agent API is running on port 8005 before running this test.")
    test_auth_flow()
