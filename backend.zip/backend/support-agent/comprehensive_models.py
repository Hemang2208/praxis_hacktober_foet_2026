"""
Comprehensive data models for all MongoDB collections
Maps to the Mongoose schemas in the frontend
"""
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

# ==================== USER MODELS ====================
class SocialLinks(BaseModel):
    github: Optional[str] = ""
    linkedin: Optional[str] = ""
    twitter: Optional[str] = ""
    website: Optional[str] = ""

class Education(BaseModel):
    degree: Optional[str] = None
    fieldOfStudy: Optional[str] = None
    institution: Optional[str] = None
    graduationYear: Optional[str] = None
    gpa: Optional[str] = None

class PreviousInternship(BaseModel):
    id: str
    companyName: str
    position: str
    duration: str
    description: Optional[str] = None
    skills: List[str] = []
    addedDate: datetime

class ProjectExperience(BaseModel):
    id: str
    title: str
    description: str
    technologies: List[str]
    link: Optional[str] = None
    githubLink: Optional[str] = None
    status: str  # completed, in-progress, planned
    addedDate: datetime

class Experience(BaseModel):
    level: Optional[str] = None  # fresher, 1-2 years, 2-5 years, 5+ years
    previousInternships: List[PreviousInternship] = []
    projects: List[ProjectExperience] = []

class CareerGoals(BaseModel):
    preferredRole: Optional[str] = None
    industries: List[str] = []
    workMode: Optional[str] = None  # remote, hybrid, onsite, flexible
    careerObjective: Optional[str] = None

class Preferences(BaseModel):
    internshipDuration: Optional[str] = None
    availability: Optional[str] = None
    willingToRelocate: Optional[bool] = None

class UserProfile(BaseModel):
    """Complete user profile with all data"""
    id: Optional[str] = Field(None, alias="_id")
    externaluser_id: Optional[str] = None
    full_name: str
    email: str
    username: Optional[str] = None
    image_url: Optional[str] = None
    headline: Optional[str] = ""
    bio: Optional[str] = ""
    skills: List[str] = []
    socialLinks: SocialLinks = Field(default_factory=SocialLinks)
    phoneNumber: Optional[str] = ""
    address: Optional[str] = ""
    profile_picture: Optional[str] = ""
    resume: Optional[str] = ""
    education: Optional[Education] = None
    experience: Optional[Experience] = None
    careerGoals: Optional[CareerGoals] = None
    preferences: Optional[Preferences] = None
    role: str = "student"  # student, admin, org
    profileCompleteness: Optional[float] = 0
    githubToken: Optional[str] = ""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== SUPPORT AGENT CHAT MODELS ====================
class SupportMessage(BaseModel):
    """Individual message in support chat"""
    id: Optional[str] = Field(None, alias="_id")
    role: str  # "user" or "assistant"
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)

class SupportMessageExtended(SupportMessage):
    """Extended message with optional type and data fields"""
    type: Optional[str] = None
    data: Optional[Dict[str, Any]] = None

class SupportAgentChat(BaseModel):
    """Support agent chat conversation"""
    id: Optional[str] = Field(None, alias="_id")
    user_id: Optional[str] = None  # reference to User (optional)
    title: Optional[str] = "Support Chat"
    messages: List[SupportMessageExtended] = []
    lastActivity: datetime = Field(default_factory=datetime.now)
    is_deleted: bool = False
    deleted_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== FEEDBACK CHAT MODELS ====================
class ChatMessage(BaseModel):
    """Individual message in feedback chat"""
    role: str  # "student" or "ai"
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)
    messageId: Optional[str] = None

class FeedbackChat(BaseModel):
    """Feedback chat conversation between user and AI"""
    id: Optional[str] = Field(None, alias="_id")
    feedbackId: str  # reference to AIFeedback
    task_id: str  # reference to Task
    user_id: str  # reference to User
    messages: List[ChatMessage] = []
    lastActivity: datetime = Field(default_factory=datetime.now)
    isActive: bool = True
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== TASK MODELS ====================
class SubTask(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    title: str
    completed: bool = False
    description: Optional[str] = None

class Comment(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    user_id: str
    message: str
    created_at: datetime = Field(default_factory=datetime.now)

class Attachment(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    name: str
    url: str
    type: str
    size: int

class TimeTracking(BaseModel):
    estimated: float = 0  # hours
    logged: float = 0  # hours
    remaining: float = 0  # hours

class TaskData(BaseModel):
    """Complete task data from tasks collection"""
    id: Optional[str] = Field(None, alias="_id")
    title: str
    description: Optional[str] = ""
    status: str  # todo, in-progress, completed, blocked
    priority: str  # low, medium, high, critical
    due_date: Optional[datetime] = None
    assigned_to: Optional[str] = None  # user_id
    student_id: Optional[str] = None  # legacy/primary assignment field
    created_by: Optional[str] = None
    project_id: Optional[str] = None
    tags: List[str] = []
    sub_tasks: List[SubTask] = []
    comments: List[Comment] = []
    attachments: List[Attachment] = []
    time_tracking: Optional[TimeTracking] = None
    dependencies: List[str] = []
    completed_at: Optional[datetime] = None
    linked_pr_id: Optional[str] = None
    linked_pull_request: Optional[str] = None
    ai_feedback: Optional[str] = None
    has_feedback: bool = False
    feedback_status: Optional[str] = None  # pending, ready, reviewed
    feedback_notification_sent: bool = False
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== PROJECT MODELS ====================
class TeamMember(BaseModel):
    name: str
    avatar: Optional[str] = ""
    email: Optional[str] = None
    role: Optional[str] = None
    user: Optional[str] = None  # user_id reference

class Sprint(BaseModel):
    name: str
    progress: float
    status: str

class TimelineEvent(BaseModel):
    title: str
    description: str
    type: str
    date: datetime

class Resource(BaseModel):
    profile: str
    skills: List[str]
    experience: str
    description: str
    type: str
    avatar: Optional[str] = ""
    username: Optional[str] = ""
    name: Optional[str] = ""
    user: Optional[str] = None

class GitHubCommit(BaseModel):
    """GitHub commit information"""
    id: str
    message: str
    author: str
    authorEmail: str
    timestamp: str
    repository: str
    branch: str
    url: str
    additions: int = 0
    deletions: int = 0
    avatarUrl: Optional[str] = None

class ProjectData(BaseModel):
    """Complete project data"""
    id: Optional[str] = Field(None, alias="_id")
    title: str
    description: str
    deadline: Optional[datetime] = None
    tags: List[str] = []
    document: Optional[str] = ""
    status: str
    tasks: List[str] = []  # task IDs
    progress: float = 0
    team: List[TeamMember] = []
    team_members: List[TeamMember] = []
    sprints: List[Sprint] = []
    timeline: List[TimelineEvent] = []
    resources: List[Resource] = []
    user: Optional[str] = None  # owner user_id
    created_by: Optional[str] = None
    ai_generated_tags: List[str] = []
    githubCommits: List[GitHubCommit] = []
    github_repository: Optional[str] = None
    lastCommitSync: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== PROJECT PLAN MODELS ====================
class Milestone(BaseModel):
    name: Optional[str] = ""
    timeline: Optional[str] = ""

class HighLevelTask(BaseModel):
    task_name: Optional[str] = Field(default="", alias="name")
    description: Optional[str] = ""
    dependencies: List[str] = []
    estimated_duration: Optional[str] = Field(default="", alias="duration")

    class Config:
        populate_by_name = True

class ProjectPlan(BaseModel):
    """Project planning data"""
    id: Optional[str] = Field(None, alias="_id")
    project_id: str
    summary: str = ""
    project_summary: Optional[str] = None
    tech_stack: List[str] = []
    key_features_deliverables: List[str] = []
    major_milestones: List[Milestone] = []
    high_level_tasks: List[HighLevelTask] = []
    updated_at: str
    created_at: str

    class Config:
        populate_by_name = True

# ==================== PULL REQUEST MODELS ====================
class pull_requestInfo(BaseModel):
    url: str
    branch: Optional[str] = ""
    status: Optional[str] = ""
    title: Optional[str] = None
    description: Optional[str] = None

class pull_requestData(BaseModel):
    """Pull request submission data"""
    id: Optional[str] = Field(None, alias="_id")
    user_id: str  # user_id
    task_id: Optional[str] = None
    pull_request: pull_requestInfo
    submitted_at: datetime
    status: str
    githubId: Optional[str] = None

    class Config:
        populate_by_name = True

# ==================== AI FEEDBACK MODELS ====================
class CodeComment(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    line: int
    column: Optional[int] = None
    fileName: str
    message: str
    severity: str  # info, warning, error, suggestion
    category: str  # code-quality, performance, security, best-practices, documentation
    suggestion: Optional[str] = None
    example: Optional[str] = None

class Assessment(BaseModel):
    codeQuality: float = 0  # 0-100
    documentation: float = 0
    testCoverage: float = 0
    performance: float = 0
    security: float = 0
    bestPractices: float = 0
    overall: float = 0

class AIFeedbackData(BaseModel):
    """AI-generated code feedback"""
    id: Optional[str] = Field(None, alias="_id")
    task_id: Optional[str] = Field(None)
    user_id: str  # user_id
    pull_request_url: str
    repository_url: Optional[str] = None
    branch_name: Optional[str] = None
    commitHash: Optional[str] = None
    comments: List[CodeComment] = []
    assessment: Assessment = Field(default_factory=Assessment)
    summary: str = ""
    strengths: List[str] = []
    improvements: List[str] = []
    recommendations: List[str] = []
    ai_model: Optional[str] = "gpt-4"
    processing_time: Optional[float] = 0
    analysisDate: Optional[datetime] = None
    status: str = "pending"  # pending, completed, failed, reviewing
    error: Optional[str] = None
    totalIssues: int = 0
    criticalIssues: int = 0
    warningIssues: int = 0
    infoIssues: int = 0
    isRead: bool = False
    readAt: Optional[datetime] = None
    studentRating: Optional[int] = None
    studentFeedback: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== NOTIFICATION MODELS ====================
class NotificationData(BaseModel):
    task_id: Optional[str] = None
    taskTitle: Optional[str] = None
    feedbackId: Optional[str] = None
    pull_request_url: Optional[str] = None
    project_id: Optional[str] = None
    projectTitle: Optional[str] = None

class NotificationChannels(BaseModel):
    inApp: bool = True
    email: bool = False
    push: bool = False

class DeliveryStatus(BaseModel):
    status: bool = False
    deliveredAt: Optional[datetime] = None
    error: Optional[str] = None

class DeliveryInfo(BaseModel):
    inApp: DeliveryStatus = Field(default_factory=DeliveryStatus)
    email: DeliveryStatus = Field(default_factory=DeliveryStatus)
    push: DeliveryStatus = Field(default_factory=DeliveryStatus)

class NotificationItem(BaseModel):
    """User notifications"""
    id: Optional[str] = Field(None, alias="_id")
    user_id: str
    type: str  # ai_feedback_ready, task_assigned, task_deadline, project_update, etc
    title: str
    message: str
    data: Optional[NotificationData] = None
    isRead: bool = False
    readAt: Optional[datetime] = None
    channels: NotificationChannels = Field(default_factory=NotificationChannels)
    delivered: DeliveryInfo = Field(default_factory=DeliveryInfo)
    priority: str = "medium"  # low, medium, high, urgent
    scheduledFor: Optional[datetime] = None
    expiresAt: Optional[datetime] = None
    createdBy: Optional[str] = None
    category: str = "system"  # feedback, tasks, projects, system, achievements
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== APPLICATION MODELS ====================
class ContactInfo(BaseModel):
    email: str
    phone: str

class JobInfo(BaseModel):
    position: str
    experienceLevel: str
    yearsOfExperience: str
    expectedPackage: str
    currentEmploymentStatus: Optional[str] = None
    noticePeriod: Optional[str] = None

class Links(BaseModel):
    resumeURL: str
    linkedinURL: str
    githubURL: Optional[str] = None
    portfolioURL: Optional[str] = None
    showcaseURL: Optional[str] = None

class JobDetails(BaseModel):
    skills: List[str] = []
    coverLetter: str
    achievements: Optional[str] = None
    message: Optional[str] = None

class ApplicationData(BaseModel):
    """Job/internship applications"""
    id: Optional[str] = Field(None, alias="_id")
    full_name: str
    position: str
    expectedPackage: str
    area: str
    contactInfo: ContactInfo
    information: JobInfo
    links: Links
    job: JobDetails
    privacyConsent: bool
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True

# ==================== COMPREHENSIVE USER CONTEXT ====================
class UserComprehensiveContext(BaseModel):
    """Aggregated view of all user data for AI processing"""
    user_profile: Optional[UserProfile] = None
    tasks: List[TaskData] = []
    projects: List[ProjectData] = []
    project_plans: List[ProjectPlan] = []
    pull_requests: List[pull_requestData] = []
    ai_feedback: List[AIFeedbackData] = []
    notifications: List[NotificationItem] = []
    applications: List[ApplicationData] = []
    
    # Computed statistics
    total_tasks: int = 0
    completed_tasks: int = 0
    active_projects: int = 0
    total_feedback_received: int = 0
    average_code_quality: Optional[float] = None
    skills_from_projects: List[str] = []
    recent_achievements: List[str] = []
    
    class Config:
        populate_by_name = True
