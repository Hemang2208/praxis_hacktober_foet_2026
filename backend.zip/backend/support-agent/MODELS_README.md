# Support Agent - Models Documentation

## Overview

The Support Agent models handle user-specific tasks, profiles, recommendations, and authentication. The agent provides personalized task management and AI-powered task analysis.

## Table of Contents

- [Enum Types](#enum-types)
- [User Models](#user-models)
- [Task Models](#task-models)
- [Authentication Models](#authentication-models)
- [Analysis & Recommendations](#analysis--recommendations)
- [Query & Response Models](#query--response-models)
- [API Workflows](#api-workflows)

---

## Enum Types

### TaskStatus

Represents the current state of a task.

```python
class TaskStatus(str, Enum):
    TODO = "todo"              # Not started
    IN_PROGRESS = "in_progress"  # Currently being worked on
    DONE = "done"              # Completed
    CANCELLED = "cancelled"    # Cancelled/abandoned
```

### TaskPriority

Represents the priority level of a task.

```python
class TaskPriority(str, Enum):
    LOW = "low"           # Low priority, can wait
    MEDIUM = "medium"     # Normal priority
    HIGH = "high"         # High priority, should be done soon
    URGENT = "urgent"     # Critical, needs immediate attention
```

### TaskType

Represents the type/category of a task.

```python
class TaskType(str, Enum):
    BUG = "bug"                      # Bug fix
    FEATURE = "feature"              # Feature development
    REFACTOR = "refactor"            # Code refactoring
    DOCUMENTATION = "documentation"  # Documentation work
    CHORE = "chore"                  # Maintenance/routine task
```

### TaskComplexity

Represents the estimated complexity of a task.

```python
class TaskComplexity(str, Enum):
    SIMPLE = "simple"              # Simple, straightforward task
    MODERATE = "moderate"          # Medium complexity
    COMPLEX = "complex"            # Complex, requires planning
    VERY_COMPLEX = "very_complex"  # Very complex, high risk
```

---

## User Models

### UserProfile

**Purpose**: User profile information and preferences

**Fields**:
- `user_id` (str): Unique user identifier
- `name` (str): User's full name
- `email` (str): Email address
- `skills` (List[str]): List of user skills
  - Examples: ["Python", "JavaScript", "React", "Docker"]
- `preferences` (Dict[str, Any]): User preferences
  - Customizable user-defined preferences
  - Examples: {"theme": "dark", "notifications": true}
- `current_workload` (str): Current workload level (default: "medium")
  - "light" - Low workload, can take more tasks
  - "medium" - Regular workload
  - "heavy" - High workload, should limit new tasks

**Example**:
```python
profile = UserProfile(
    user_id="user_123",
    name="Alice Johnson",
    email="alice@example.com",
    skills=["Python", "Django", "PostgreSQL", "Docker"],
    preferences={
        "theme": "dark",
        "notifications": True,
        "digest_frequency": "daily",
        "preferred_task_types": ["backend", "infrastructure"]
    },
    current_workload="medium"
)
```

---

## Task Models

### Task

**Purpose**: User's individual task with full details

**Fields**:
- `id` (str, optional): Task ID (assigned by database)
- `user_id` (str): Associated user ID
- `title` (str): Task title
- `description` (str, optional): Detailed task description
- `status` (TaskStatus): Current status (default: TODO)
- `priority` (TaskPriority): Priority level (default: MEDIUM)
- `assignee` (str, optional): Person assigned to task (can differ from creator)
- `estimated_hours` (float, optional): Estimated effort in hours
- `actual_hours` (float, optional): Actual hours spent
- `due_date` (datetime, optional): Task deadline
- `created_at` (datetime): Creation timestamp
- `updated_at` (datetime): Last update timestamp
- `completed_at` (datetime, optional): Completion timestamp
- `tags` (List[str]): Task tags for organization
- `ai_suggestions` (List[str]): AI-generated suggestions (default: [])
- `ai_analysis` (str, optional): Detailed AI analysis

**Example**:
```python
task = Task(
    user_id="user_123",
    title="Fix authentication bug",
    description="Fix JWT token validation in login endpoint",
    status=TaskStatus.IN_PROGRESS,
    priority=TaskPriority.HIGH,
    assignee="user_456",
    estimated_hours=4.0,
    actual_hours=2.5,
    due_date=datetime(2024, 1, 20),
    tags=["bug", "security", "auth"],
    ai_suggestions=[
        "Add rate limiting to login endpoint",
        "Implement token refresh mechanism",
        "Add comprehensive error logging"
    ],
    ai_analysis="This is a critical security issue that should be fixed immediately..."
)
```

**Special Features**:
- Tracks both estimated and actual effort
- Includes AI-generated suggestions
- Supports task assignment to multiple users
- Records all timestamps

### TaskCreate

**Purpose**: Request model for creating a new task

**Fields**:
- `title` (str): Task title
- `description` (str, optional): Task description
- `priority` (TaskPriority): Priority (default: MEDIUM)
- `estimated_hours` (float, optional): Estimated hours
- `due_date` (datetime, optional): Due date
- `tags` (List[str]): Tags for organization

**Example**:
```python
create_request = TaskCreate(
    title="Review code for PR #42",
    description="Review the authentication refactor PR",
    priority=TaskPriority.HIGH,
    estimated_hours=1.5,
    due_date=datetime(2024, 1, 18),
    tags=["code-review", "auth"]
)
```

### TaskUpdate

**Purpose**: Partial update model for modifying existing tasks

**Fields**: All Task fields are optional (for partial updates)

**Special Use**:
- Used for PATCH endpoints
- Only provided fields are updated
- Omitted fields remain unchanged

**Example**:
```python
update = TaskUpdate(
    status=TaskStatus.IN_PROGRESS,
    actual_hours=2.0,
    ai_analysis="Task successfully analyzed and started"
)
```

### SubTask

**Purpose**: Smaller subtask that breaks down a larger task

**Fields**:
- `id` (str, optional, alias: "_id"): Subtask ID
- `title` (str): Subtask title
- `completed` (bool): Completion status (default: False)
- `description` (str, optional): Subtask description

**Example**:
```python
subtasks = [
    SubTask(title="Identify root cause", completed=True),
    SubTask(title="Write fix", completed=True),
    SubTask(title="Add unit tests", completed=False),
    SubTask(title="Update documentation", completed=False)
]
```

### TaskComment

**Purpose**: Comment on a task for collaboration

**Fields**:
- `id` (str): Comment ID
- `content` (str): Comment text
- `author` (str): User ID of comment author
- `created_at` (datetime): Comment timestamp

**Example**:
```python
comment = TaskComment(
    id="comment_001",
    content="Started working on this. Need clarification on requirements.",
    author="user_456",
    created_at=datetime.now()
)
```

---

## Authentication Models

### UserRegister

**Purpose**: Request model for user registration

**Fields**:
- `email` (str): Email address
- `password` (str): Password (should be validated for strength)
- `full_name` (str): User's full name
- `role` (str): User role (default: "student")
  - "student" - Regular student user
  - "teacher" - Teacher/instructor
  - "admin" - Administrator
  - "assistant" - Teaching assistant

**Example**:
```python
register = UserRegister(
    email="newuser@example.com",
    password="Secure@Pass123",
    full_name="Bob Smith",
    role="student"
)
```

**Security Notes**:
- Passwords should be validated for strength
- Passwords must be hashed before storage
- Never return password in responses

### UserLogin

**Purpose**: Request model for user login

**Fields**:
- `email` (str): User's email
- `password` (str): User's password

**Example**:
```python
login = UserLogin(
    email="user@example.com",
    password="Secure@Pass123"
)
```

### TokenResponse

**Purpose**: Response with authentication tokens

**Fields**:
- `access_token` (str): JWT access token (short-lived, ~15 minutes)
- `refresh_token` (str): Refresh token (long-lived, ~7 days)
- `token_type` (str): Token type (default: "bearer")
- `user_id` (str): Associated user ID

**Example**:
```python
token_response = TokenResponse(
    access_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    refresh_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    token_type="bearer",
    user_id="user_123"
)
```

**Token Validation**:
- Access token used for API requests (Authorization header)
- Refresh token used to get new access token
- Both tokens are JWT signed

### TokenRefreshRequest

**Purpose**: Request to refresh access token

**Fields**:
- `refresh_token` (str): The refresh token

**Example**:
```python
refresh = TokenRefreshRequest(
    refresh_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
)
```

---

## Analysis & Recommendations

### TaskAnalysisRequest

**Purpose**: Request AI analysis of a task

**Fields**:
- `task_id` (str): Task to analyze
- `user_id` (str): User requesting analysis

**Example**:
```python
analysis_request = TaskAnalysisRequest(
    task_id="task_789",
    user_id="user_123"
)
```

### TaskAnalysisResponse

**Purpose**: AI-generated analysis and breakdown of a task

**Fields**:
- `task_id` (str): Analyzed task ID
- `complexity` (TaskComplexity): Estimated complexity
- `estimated_hours` (float): Refined effort estimate
- `subtasks` (List[SubTask]): Suggested subtasks (default: [])
- `risks` (List[str]): Identified risks (default: [])
- `recommendations` (List[str]): Recommendations (default: [])

**Example**:
```python
analysis = TaskAnalysisResponse(
    task_id="task_789",
    complexity=TaskComplexity.MODERATE,
    estimated_hours=8.0,
    subtasks=[
        SubTask(title="Analyze requirements", completed=False),
        SubTask(title="Design solution", completed=False),
        SubTask(title="Implement code", completed=False),
        SubTask(title="Test thoroughly", completed=False)
    ],
    risks=[
        "Database migration complexity",
        "Integration with legacy system",
        "Testing coverage gaps"
    ],
    recommendations=[
        "Break down into smaller tickets",
        "Conduct architecture review",
        "Set up comprehensive logging",
        "Plan rollback strategy"
    ]
)
```

### TaskRecommendation

**Purpose**: AI-recommended task for user

**Fields**:
- `title` (str): Recommended task title
- `description` (str): Task description
- `reasoning` (str): Why this task is recommended
- `priority` (TaskPriority): Recommended priority
- `estimated_hours` (float, optional): Effort estimate
- `tags` (List[str]): Relevant tags

**Example**:
```python
recommendation = TaskRecommendation(
    title="Update dependencies",
    description="Update project dependencies to latest secure versions",
    reasoning="Your project has 5 packages with security vulnerabilities. This should be addressed immediately.",
    priority=TaskPriority.HIGH,
    estimated_hours=4.0,
    tags=["maintenance", "security", "dependencies"]
)
```

---

## Query & Response Models

### UserTaskQuery

**Purpose**: Natural language query about tasks

**Fields**:
- `query` (str): Natural language question/request
- `context` (str, optional): Additional context for the query

**Example**:
```python
query = UserTaskQuery(
    query="What tasks are due this week and are high priority?",
    context="I'm in the backend team"
)

query2 = UserTaskQuery(
    query="Suggest a task for me to work on next"
)

query3 = UserTaskQuery(
    query="Analyze the complexity of task #789",
    context="It's related to our authentication refactor"
)
```

### UserTaskResponse

**Purpose**: Response to task query with AI assistance

**Fields**:
- `message` (str): Response message to the query
- `tasks` (List[Task], optional): Relevant tasks from query
- `suggestions` (List[str]): AI suggestions
- `analysis` (str, optional): Detailed analysis if requested

**Example**:
```python
response = UserTaskResponse(
    message="I found 3 high-priority tasks due this week. Here they are:",
    tasks=[task1, task2, task3],
    suggestions=[
        "Start with 'Fix login bug' as it's critical",
        "Consider pairing with John for 'DB migration'",
        "Schedule 'API documentation' for Friday"
    ],
    analysis="Your current workload allows for about 16 hours of new work..."
)
```

### UserTaskStats

**Purpose**: Statistics about a user's tasks

**Fields**:
- `total_tasks` (int): Total number of tasks
- `completed_tasks` (int): Number of completed tasks
- `in_progress_tasks` (int): Number of in-progress tasks
- `overdue_tasks` (int): Number of overdue tasks
- `completion_rate` (float): Completion percentage (0-100)
- `average_task_duration` (float, optional): Average hours per task

**Example**:
```python
stats = UserTaskStats(
    total_tasks=23,
    completed_tasks=15,
    in_progress_tasks=6,
    overdue_tasks=2,
    completion_rate=65.2,
    average_task_duration=4.5
)
```

---

## API Workflows

### Task Creation Workflow

**Step 1: Create Task**
```
Client → POST /tasks
Body: TaskCreate
Header: Authorization: Bearer <access_token>
```

**Step 2: Processing**
- Validate input
- Assign task ID
- Add timestamps
- Store to database

**Step 3: Response**
```
Server → Task
Returns: complete task with ID
```

### Task Query Workflow

**Step 1: Natural Language Query**
```
Client → POST /tasks/query
Body: UserTaskQuery
Header: Authorization: Bearer <access_token>
```

**Step 2: AI Processing**
- Parse natural language
- Search relevant tasks
- Generate suggestions
- Optional: detailed analysis

**Step 3: Response**
```
Server → UserTaskResponse
Returns: message, tasks, suggestions, analysis
```

### Task Analysis Workflow

**Step 1: Request Analysis**
```
Client → POST /tasks/{task_id}/analyze
Body: TaskAnalysisRequest
Header: Authorization: Bearer <access_token>
```

**Step 2: AI Analysis**
- Analyze task requirements
- Break into subtasks
- Identify risks
- Generate recommendations

**Step 3: Response**
```
Server → TaskAnalysisResponse
Returns: complexity, subtasks, risks, recommendations
```

### Authentication Workflow

**Step 1: Register**
```
Client → POST /auth/register
Body: UserRegister
```

**Step 2: Login**
```
Client → POST /auth/login
Body: UserLogin
```

**Step 3: Token Response**
```
Server → TokenResponse
Returns: access_token, refresh_token, user_id
```

**Step 4: Use Token**
```
Client → GET /tasks
Header: Authorization: Bearer <access_token>
```

**Step 5: Refresh Token**
```
Client → POST /auth/refresh
Body: TokenRefreshRequest
```

---

## Database Integration

### MongoDB Collections

```
Users Collection
├── _id (ObjectId)
├── email (string)
├── password_hash (string)
├── full_name (string)
├── role (string)
├── created_at (datetime)
└── updated_at (datetime)

UserProfiles Collection
├── _id (ObjectId)
├── user_id (ObjectId)
├── name (string)
├── skills (array)
├── preferences (object)
├── current_workload (string)
└── updated_at (datetime)

Tasks Collection
├── _id (ObjectId)
├── user_id (ObjectId)
├── title (string)
├── description (string)
├── status (string)
├── priority (string)
├── assignee (ObjectId)
├── estimated_hours (float)
├── actual_hours (float)
├── due_date (datetime)
├── tags (array)
├── ai_suggestions (array)
├── ai_analysis (string)
├── created_at (datetime)
├── updated_at (datetime)
└── completed_at (datetime)
```

---

## Best Practices

1. **Clear Titles**: Use descriptive task titles
2. **Detailed Descriptions**: Provide sufficient context
3. **Realistic Estimates**: Give accurate effort estimates
4. **Regular Updates**: Keep actual_hours and status current
5. **Appropriate Tags**: Use tags for easy filtering
6. **Workload Management**: Update current_workload appropriately
7. **Password Security**: Never store plain passwords, always hash
8. **Token Handling**: Keep tokens secure, rotate regularly

---

## Validation Rules

1. **Task**:
   - `title`: Required, non-empty
   - `priority`: Must be valid TaskPriority enum
   - `status`: Must be valid TaskStatus enum
   - `estimated_hours`: If provided, must be > 0

2. **UserRegister**:
   - `email`: Must be valid email format
   - `password`: Minimum 8 characters, must include upper, lower, number, special char
   - `full_name`: Non-empty string

3. **UserTaskQuery**:
   - `query`: Non-empty string

---

## Error Handling

**Common Errors**:
- `400 Bad Request`: Invalid input data
- `401 Unauthorized`: Missing or invalid token
- `403 Forbidden`: User doesn't have permission
- `404 Not Found`: Task or user not found
- `409 Conflict`: Status transition not allowed
- `422 Unprocessable Entity`: Validation error

---

## Usage Examples

### Create and Update Task

```python
# Create task
create = TaskCreate(
    title="Implement user profile",
    description="Add user profile page",
    priority=TaskPriority.HIGH,
    estimated_hours=6.0,
    due_date=datetime(2024, 1, 25)
)
task = create_task(user_id, create)

# Update task
update = TaskUpdate(
    status=TaskStatus.IN_PROGRESS,
    actual_hours=2.5
)
updated_task = update_task(task.id, update)
```

### Query Tasks

```python
# Natural language query
query = UserTaskQuery(
    query="Show me urgent tasks due this week"
)
response = query_tasks(user_id, query)
print(response.message)
print(response.suggestions)

# Analyze specific task
analysis_req = TaskAnalysisRequest(
    task_id=task.id,
    user_id=user_id
)
analysis = analyze_task(analysis_req)
print(f"Complexity: {analysis.complexity}")
print(f"Subtasks: {len(analysis.subtasks)}")
```

### Statistics

```python
# Get user stats
stats = get_user_stats(user_id)
print(f"Completion Rate: {stats.completion_rate}%")
print(f"In Progress: {stats.in_progress_tasks}")
print(f"Overdue: {stats.overdue_tasks}")
```

---

## Notes

- All user tasks are isolated per user_id for privacy
- AI suggestions and analysis are generated on-demand
- Timestamps use UTC datetime
- Tasks can be tagged for flexible organization
- Task status transitions follow predefined workflows

