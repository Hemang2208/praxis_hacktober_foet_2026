"""
Enhanced AI Service using the local Ollama model for comprehensive user context.
Provides intelligent responses based on ALL user data.
"""
import json
import logging
import os
from typing import List, Optional, Dict, Any
from datetime import datetime
import asyncio

logger = logging.getLogger(__name__)

from config.settings import OLLAMA_MODEL
from comprehensive_models import UserComprehensiveContext, TaskData
from comprehensive_data_service import ComprehensiveDataService
from context_retrieval_service import ContextRetrievalService
from shared.openrouter import OllamaService


class ComprehensiveAIService:
    """AI service that uses complete user context for intelligent responses."""

    PRIMARY_MODEL = OLLAMA_MODEL
    MAX_OUTPUT_TOKENS: int = max(
        512, min(int(os.getenv("SUPPORT_MAX_OUTPUT_TOKENS", "4096")), 8192)
    )

    # ── Phase 2: Conversation history ────────────────────────────────────────
    MAX_HISTORY_TURNS: int = 10   # keep last N user+assistant pairs (= 20 msgs)
    HISTORY_TTL: int = 3600       # Redis key TTL in seconds (1 hour)
    _memory_store: Dict[str, List[Dict[str, str]]] = {}  # in-memory fallback

    def __init__(self):
        self.model = self.PRIMARY_MODEL
        self.model_name = self.PRIMARY_MODEL
        self.models = [self.PRIMARY_MODEL]
        self.ollama = OllamaService(agent_type="support")
        self.data_service = ComprehensiveDataService()
        self.context_retrieval = ContextRetrievalService(self.data_service)
    
    def _build_system_prompt(self, context_prompt: str) -> str:
        """Single source of truth for the support agent system contract.

        Key rules encoded here:
        - PRAXIS is the AI assistant, NOT the user whose profile is shown.
        - User context is labelled data, never the model's own identity.
        - Answers must be grounded in the data; invent nothing.
        - Concise by default; expand only when explicitly asked.
        - Never open with a profile dump in response to 'introduce yourself'.
        """
        return f"""You are PRAXIS — the official AI Support Agent for the PRAXIS platform.
Your role is to help the signed-in user manage their tasks, projects, and career progress.

--- WHAT YOU ARE ---
PRAXIS is the primary AI assistant across the backend. PRAXIS tracks work, answers questions
about tasks and projects, gives progress summaries, coordinates backend AI capabilities, and
suggests next actions. You are NOT the user.

--- IMPORTANT: RETRIEVED USER DATA BELOW ---
The section below contains live records ABOUT the person you are talking to.
It is their data — it is NOT your identity or backstory.
{context_prompt}
--- END RETRIEVED USER DATA ---

--- RESPONSE CONTRACT ---
1. Identity: If asked who you are or to introduce yourself, say you are PRAXIS and
   describe what PRAXIS does, not the user's profile. Example: "I'm PRAXIS, your AI
   Support Agent. I can help you track tasks, review project progress, and suggest
   what to do next."
2. Evidence-based: Only state facts present in the user data above.
   If a fact is missing, say so clearly (e.g. "I don't see any active projects listed.").
3. Concise: Give short, direct answers unless the user asks for a detailed breakdown.
   Do not list all tasks/projects unprompted.
4. No vague encouragement: Skip filler phrases like "Great question!" or
   "You're doing amazing!". Get straight to the answer.
5. Numbers: When quoting counts or scores, use the exact figures from the data.
   Do not round or estimate unless rounding is trivially obvious.
6. Fallback: If you genuinely cannot answer from the available data, say
   "I don't have enough information to answer that right now."
7. Fresh retrieval: The retrieved block was fetched from MongoDB for this exact
   turn. Prefer it over conversation history or any earlier context summary.
8. Access control: Never mention records that are not in the retrieved block.
   If a named project/task is absent, say it was not found or is not accessible.
9. Specificity: When the user asks about a named project/task, use its exact title,
   status, progress, due date, description, subtasks, milestones, and IDs from the
   retrieved block. Do not reduce a detailed request to only a title list.
"""

    def _build_user_context_prompt(self, context: UserComprehensiveContext) -> str:
        """Build a context prompt with hard per-field caps and a total budget.

        Budgets (chars):
          bio          → 250  (long bios are rarely needed verbatim)
          task title   → 50   (titles only, no descriptions)
          project title→ 60
          skills list  → 300  (top 10 only)
          achievements → 200  (top 3 only)
          TOTAL        → 2800 (hard ceiling — excess trimmed from the bottom)

        Keeping totals small prevents timeouts/disconnects on large profiles
        and keeps Ollama's small context window from overflowing.
        """
        # ── helpers ──────────────────────────────────────────────────────
        def _cap(text: str, limit: int) -> str:
            """Truncate a string and append '…' if over limit."""
            if not text:
                return ""
            text = str(text).strip()
            return text if len(text) <= limit else text[:limit - 1] + "…"

        TOTAL_BUDGET = 2800
        prompt_parts = []

        # ── User Profile ──────────────────────────────────────────────────
        if context.user_profile:
            profile = context.user_profile
            bio = _cap(profile.bio or "Not provided", 250)
            skills_str = ", ".join(profile.skills[:10]) if profile.skills else "None listed"
            prompt_parts.append(
                f"USER PROFILE:\n"
                f"- Name: {profile.full_name}\n"
                f"- Role: {profile.role}\n"
                f"- Skills: {skills_str}\n"
                f"- Headline: {profile.headline or 'None'}\n"
                f"- Bio: {bio}"
            )

            if profile.education:
                edu = profile.education
                prompt_parts.append(
                    f"EDUCATION: {edu.degree or '?'} in {edu.fieldOfStudy or '?'} "
                    f"at {edu.institution or '?'} ({edu.graduationYear or '?'})"
                )

            if profile.experience and profile.experience.previousInternships:
                prompt_parts.append(
                    f"INTERNSHIPS: {len(profile.experience.previousInternships)} completed"
                )

            if profile.careerGoals:
                goals = profile.careerGoals
                industries = ", ".join(goals.industries[:3]) if goals.industries else "Not specified"
                prompt_parts.append(
                    f"CAREER GOALS: {goals.preferredRole or 'Not specified'} | "
                    f"Industries: {industries} | Mode: {goals.workMode or 'Not specified'}"
                )

        # ── Tasks ─────────────────────────────────────────────────────────
        in_progress = len([t for t in context.tasks if t.status == "in-progress"])
        todo = len([t for t in context.tasks if t.status == "todo"])
        completion_pct = (
            context.completed_tasks / context.total_tasks * 100
            if context.total_tasks > 0 else 0
        )
        prompt_parts.append(
            f"TASKS: {context.total_tasks} total | "
            f"{context.completed_tasks} done | {in_progress} in-progress | "
            f"{todo} todo | {completion_pct:.1f}% complete"
        )

        if context.tasks:
            task_lines = [
                f"  [{t.status}] {_cap(t.title, 50)} (priority: {t.priority})"
                for t in context.tasks[:5]
            ]
            prompt_parts.append("RECENT TASKS (latest 5):\n" + "\n".join(task_lines))

        # ── Projects ──────────────────────────────────────────────────────
        prompt_parts.append(
            f"PROJECTS: {len(context.projects)} total | {context.active_projects} active"
        )
        if context.projects:
            proj_lines = [
                f"  {_cap(p.title, 60)}: {p.progress:.0f}% ({p.status})"
                for p in context.projects[:4]
            ]
            prompt_parts.append("TOP PROJECTS:\n" + "\n".join(proj_lines))

        # ── Code Quality ──────────────────────────────────────────────────
        if context.ai_feedback:
            prompt_parts.append(
                f"CODE QUALITY: avg {context.average_code_quality:.1f}/100 | "
                f"{context.total_feedback_received} reviews received"
            )

        # ── Pull Requests ─────────────────────────────────────────────────
        if context.pull_requests:
            prompt_parts.append(f"PULL REQUESTS: {len(context.pull_requests)} total")

        # ── Skills ────────────────────────────────────────────────────────
        if context.skills_from_projects:
            skills_str = _cap(", ".join(context.skills_from_projects[:10]), 300)
            prompt_parts.append(f"SKILLS IN USE: {skills_str}")

        # ── Achievements ──────────────────────────────────────────────────
        if context.recent_achievements:
            ach_lines = [f"  - {_cap(a, 80)}" for a in context.recent_achievements[:3]]
            prompt_parts.append("RECENT ACHIEVEMENTS:\n" + "\n".join(ach_lines))

        # ── Notifications ─────────────────────────────────────────────────
        if context.notifications:
            unread = len([n for n in context.notifications if not n.isRead])
            prompt_parts.append(f"NOTIFICATIONS: {len(context.notifications)} total | {unread} unread")

        # ── Apply total budget ────────────────────────────────────────────
        full_prompt = "\n".join(prompt_parts)
        if len(full_prompt) > TOTAL_BUDGET:
            full_prompt = full_prompt[:TOTAL_BUDGET] + "\n[...context truncated to stay within limits]"

        return full_prompt

    # ── Phase 2: Conversation history helpers ───────────────────────────────

    async def _load_history(self, session_id: str) -> List[Dict[str, str]]:
        """Load conversation history from Redis; fall back to in-memory dict."""
        try:
            from websocket_manager import _get_redis
            r = await _get_redis()
            if r:
                raw = await r.get(f"conv:{session_id}")
                if raw:
                    return json.loads(raw)
        except Exception as e:
            logger.warning(f"Redis history load failed for {session_id}: {e}")
        return list(self._memory_store.get(session_id, []))

    async def _save_to_history(self, session_id: str, role: str, content: str) -> None:
        """Append one message to history and trim to MAX_HISTORY_TURNS pairs."""
        history = await self._load_history(session_id)
        history.append({"role": role, "content": content})
        max_messages = self.MAX_HISTORY_TURNS * 2  # user + assistant per turn
        if len(history) > max_messages:
            history = history[-max_messages:]
        self._memory_store[session_id] = history  # always keep in-memory copy
        try:
            from websocket_manager import _get_redis
            r = await _get_redis()
            if r:
                await r.setex(f"conv:{session_id}", self.HISTORY_TTL, json.dumps(history))
        except Exception as e:
            logger.warning(f"Redis history save failed for {session_id}: {e}")

    @staticmethod
    def _retrieval_context_used(
        retrieved: Dict[str, Any], include_context: bool = True
    ) -> Dict[str, Any]:
        stats = retrieved.get("stats", {})
        return {
            "total_tasks": stats.get("total_accessible_tasks", 0),
            "total_projects": stats.get("total_accessible_projects", 0),
            "selected_tasks": stats.get("selected_tasks", 0),
            "selected_projects": stats.get("selected_projects", 0),
            "selected_plans": len(retrieved.get("plans", [])),
            "selected_pull_requests": len(retrieved.get("pull_requests", [])),
            "selected_feedback": len(retrieved.get("feedback", [])),
            "selected_notifications": len(retrieved.get("notifications", [])),
            "skills_count": len(retrieved.get("skills", []))
            or (
                len(retrieved.get("profile").skills)
                if retrieved.get("profile") and retrieved.get("profile").skills
                else 0
            ),
            "feedback_count": stats.get("total_accessible_feedback", 0),
            "retrieval_source": "mongodb",
            "retrieved_at": retrieved.get("retrieved_at"),
            "sources": retrieved.get("sources", {"mongo": True}),
            "matched_project_ids": retrieved.get("matched_project_ids", []),
            "matched_task_ids": retrieved.get("matched_task_ids", []),
            "include_context": include_context,
        }

    async def _retrieve_context(
        self,
        user_id: str,
        query: str,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self.context_retrieval.retrieve(
            user_id=user_id,
            query=query,
            session_id=session_id,
        )

    async def answer_comprehensive_query(
        self,
        user_id: str,
        query: str,
        context: Optional[UserComprehensiveContext] = None,
        session_id: Optional[str] = None,
        include_context: bool = True,
    ) -> Dict[str, Any]:
        """Answer a query using freshly retrieved, query-relevant user context."""
        try:
            if include_context:
                retrieved = await self._retrieve_context(user_id, query, session_id)
                context_prompt = self.context_retrieval.format_context_for_prompt(retrieved)
            else:
                context = context or await self.data_service.get_comprehensive_user_context(user_id)
                context_prompt = self._build_user_context_prompt(context)
                retrieved = {
                    "stats": {
                        "total_accessible_tasks": context.total_tasks,
                        "total_accessible_projects": len(context.projects),
                        "total_accessible_feedback": len(context.ai_feedback),
                    },
                    "sources": {"mongo": True, "redis_session": bool(session_id)},
                }

            system_message = self._build_system_prompt(context_prompt)
            history = (
                await self._load_history(session_id)
                if session_id and include_context
                else []
            )
            messages = [
                {"role": "system", "content": system_message},
                *history,
                {"role": "user", "content": query},
            ]

            if session_id and include_context:
                await self._save_to_history(session_id, "user", query)

            assistant_message = await self.ollama.generate_completion(
                messages=messages,
                temperature=0.7,
                max_tokens=self.MAX_OUTPUT_TOKENS,
            )

            if session_id and include_context:
                await self._save_to_history(session_id, "assistant", assistant_message)

            return {
                "answer": assistant_message,
                "context_used": self._retrieval_context_used(retrieved, include_context),
            }
        except Exception as e:
            logger.error("PRAXIS comprehensive query failed: %s", e)
            error_type = getattr(e, "error_type", None)
            if error_type == "rate_limit":
                return {
                    "answer": "PRAXIS is temporarily busy right now. Please try again in a moment.",
                    "error": "rate_limited"
                }
            if error_type == "timeout":
                return {
                    "answer": "PRAXIS took too long to respond. Please try again shortly.",
                    "error": "timeout"
                }
            return {
                "answer": "PRAXIS could not process that request right now. Please try again later.",
                "error": "unavailable"
            }

    async def get_personalized_recommendations(
        self,
        user_id: str,
        context: Optional[UserComprehensiveContext] = None
    ) -> List[Dict[str, Any]]:
        """Get personalized recommendations based on all user data"""
        try:
            # Get comprehensive context if not provided
            if context is None:
                context = await self.data_service.get_comprehensive_user_context(user_id)
            
            # Build context prompt
            context_prompt = self._build_user_context_prompt(context)
            
            system_message = f"""You are PRAXIS, the official AI Support Agent and productivity coach.
Analyze the user's comprehensive data and provide personalized recommendations.

{context_prompt}

Provide exactly 3-5 specific, actionable recommendations as a JSON array.
Keep descriptions concise (2-3 sentences max).
[
  {{
    "title": "Brief title (5-8 words)",
    "description": "Concise actionable description (2-3 sentences)",
    "category": "tasks|skills|career|projects|learning",
    "priority": "high|medium|low",
    "reasoning": "Brief reason (1-2 sentences)"
  }}
]
"""
            
            messages = [
                {"role": "system", "content": system_message},
                {"role": "user", "content": "Based on my current situation, what specific recommendations do you have for me? Respond with valid JSON only."}
            ]
            
            recommendations_data = await self.ollama.generate_json_completion(
                messages=messages,
                temperature=0.5,
                max_tokens=2000
            )
            
            if isinstance(recommendations_data, dict):
                for key in ("recommendations", "items", "results", "data"):
                    if isinstance(recommendations_data.get(key), list):
                        recommendations_data = recommendations_data[key]
                        break
                else:
                    if isinstance(recommendations_data.get("title"), str):
                        recommendations_data = [recommendations_data]
                    else:
                        list_values = [
                            value for value in recommendations_data.values()
                            if isinstance(value, list)
                        ]
                        recommendations_data = list_values[0] if list_values else []
            if not isinstance(recommendations_data, list):
                logger.warning("PRAXIS returned an unexpected recommendations payload: %s", type(recommendations_data))
                return []
            return [item for item in recommendations_data if isinstance(item, dict)]
            
        except Exception as e:
            logger.error("PRAXIS recommendations failed: %s", e)
            return []
    
    async def analyze_user_progress(
        self,
        user_id: str,
        context: Optional[UserComprehensiveContext] = None
    ) -> Dict[str, Any]:
        """Analyze user progress across all areas"""
        try:
            # Get comprehensive context if not provided
            if context is None:
                context = await self.data_service.get_comprehensive_user_context(user_id)
            
            # Build context prompt
            context_prompt = self._build_user_context_prompt(context)
            
            system_message = f"""You are PRAXIS, the official AI Support Agent and progress analyst.
Analyze the user's comprehensive data and provide insights into their progress, strengths, and areas for improvement.

{context_prompt}

Provide a comprehensive analysis in JSON format:
{{
  "overall_progress": "Brief summary of overall progress",
  "strengths": ["strength 1", "strength 2"],
  "areas_for_improvement": ["area 1", "area 2"],
  "task_performance": "Analysis of task completion and management",
  "project_performance": "Analysis of project progress",
  "code_quality_trends": "Analysis of code quality over time",
  "skill_development": "Analysis of skill usage and growth",
  "recommendations": ["recommendation 1", "recommendation 2"]
}}
"""
            
            messages = [
                {"role": "system", "content": system_message},
                {
                    "role": "user",
                    "content": "Analyze my overall progress and provide insights. Respond with valid JSON only.",
                },
            ]

            analysis_data = await self.ollama.generate_json_completion(
                messages=messages,
                temperature=0.5,
                max_tokens=2000,
            )
            if not isinstance(analysis_data, dict):
                raise ValueError("PRAXIS returned a non-object progress analysis")
            for field in ("strengths", "areas_for_improvement", "recommendations"):
                if not isinstance(analysis_data.get(field), list):
                    analysis_data[field] = []
            return analysis_data
            
        except Exception as e:
            logger.error("PRAXIS progress analysis failed: %s", e)
            return {
                "error": str(e),
                "overall_progress": "PRAXIS could not analyze progress at this time"
            }
    
    async def get_next_best_action(
        self,
        user_id: str,
        context: Optional[UserComprehensiveContext] = None
    ) -> Dict[str, Any]:
        """Suggest the next best action for the user"""
        try:
            # Get comprehensive context if not provided
            if context is None:
                context = await self.data_service.get_comprehensive_user_context(user_id)
            
            # Build context prompt
            context_prompt = self._build_user_context_prompt(context)
            
            system_message = f"""You are PRAXIS, the official AI Support Agent and productivity assistant.
Based on the user's current situation, suggest the single most impactful action they should take right now.

{context_prompt}

Consider:
- Urgent or overdue tasks
- High-priority items
- Career goals alignment
- Current workload
- Unread feedback or notifications
- Incomplete projects

Provide response in JSON format:
{{
  "action": "Specific action to take",
  "reasoning": "Why this is the best next step",
  "expected_impact": "What benefit this will bring",
  "estimated_time": "How long it will take",
  "related_items": ["task_id or project_id if relevant"]
}}
"""
            
            messages = [
                {"role": "system", "content": system_message},
                {
                    "role": "user",
                    "content": "What should I do next? Respond with valid JSON only.",
                },
            ]

            action_data = await self.ollama.generate_json_completion(
                messages=messages,
                temperature=0.5,
                max_tokens=800,
            )
            if not isinstance(action_data, dict):
                raise ValueError("PRAXIS returned a non-object next action")

            for field in ("action", "reasoning", "expected_impact", "estimated_time"):
                if field not in action_data:
                    action_data[field] = "Not specified"
            if not isinstance(action_data.get("related_items"), list):
                action_data["related_items"] = []
            return action_data
            
        except Exception as e:
            logger.error("PRAXIS next-action failed: %s", e)
            return {
                "action": "Review your tasks and prioritize based on deadlines",
                "reasoning": "PRAXIS could not parse the AI response, so a fallback recommendation is provided",
                "expected_impact": "Better organization and time management",
                "estimated_time": "5-10 minutes",
                "related_items": []
            }

    async def stream_comprehensive_query(
        self,
        user_id: str,
        query: str,
        session_id: str,
        manager
    ):
        """Stream user query answer using comprehensive context over WebSockets"""
        try:
            # 1. Retrieve fresh, query-relevant MongoDB context and session entities.
            retrieved = await self._retrieve_context(user_id, query, session_id)
            context_prompt = self.context_retrieval.format_context_for_prompt(retrieved)
            stats = retrieved.get("stats", {})

            # 2. Build system prompt (shared contract — same for streaming and non-streaming)
            system_message = self._build_system_prompt(context_prompt)

            # 3. Load bounded conversation history for this session
            history = await self._load_history(session_id)

            # 4. Build message list: system + history + current user turn
            messages = [
                {"role": "system", "content": system_message},
                *history,
                {"role": "user", "content": query}
            ]

            # 5. Persist the user's message before streaming starts
            await self._save_to_history(session_id, "user", query)

            # Send typing_start event
            await manager.send_event(session_id, "typing_start")

            success = False
            stream_error: Optional[Exception] = None
            full_response = []

            # ── Stream through the shared local Ollama service ───────────────
            try:
                async for token in self.ollama.generate_completion_stream(
                    messages=messages,
                    temperature=0.7,
                    max_tokens=self.MAX_OUTPUT_TOKENS,
                ):
                    full_response.append(token)
                    await manager.send_event(session_id, "token", token)
                success = True
            except Exception as e:
                stream_error = e
                logger.error("Local Ollama streaming failed: %s", e)

            if not success:
                if full_response:
                    # The stream was interrupted after some output. Keep the
                    # partial answer but report the interruption to the client.
                    await self._save_to_history(
                        session_id, "assistant", "".join(full_response)
                    )
                    await manager.send_event(session_id, "typing_stop")
                    await manager.send_event(session_id, "error", {
                        "message": f"Local Ollama stream was interrupted: {stream_error}"
                    })
                    return

                logger.warning(
                    "Local Ollama unavailable — serving context-aware workspace response."
                )
                total_tasks = stats.get("total_accessible_tasks", 0)
                completed_tasks = stats.get("completed_tasks", 0)
                completion_rate = (
                    (completed_tasks / total_tasks) * 100 if total_tasks else 0.0
                )
                fallback_text = (
                    f"PRAXIS analyzed your workspace context regarding your request: **\"{query}\"**.\n\n"
                    f"📊 **Workspace Overview**:\n"
                    f"- **Tasks**: {completed_tasks} completed out of {total_tasks} accessible tasks ({completion_rate:.1f}% completion rate)\n"
                    f"- **Selected Tasks**: {stats.get('selected_tasks', 0)} relevant to your question\n"
                    f"- **Projects**: {stats.get('total_accessible_projects', 0)} accessible projects\n"
                    f"- **Plans**: {stats.get('total_accessible_plans', 0)} project plans\n\n"
                    f"💡 *Note: PRAXIS could not reach the local Ollama model. Please ensure Ollama is running and that '{self.model}' is installed, then try again.*"
                )
                for chunk in fallback_text.split(" "):
                    token = chunk + " "
                    full_response.append(token)
                    await manager.send_event(session_id, "token", token)
                    await asyncio.sleep(0.015)
                success = True

            if success:
                full_text = "".join(full_response)
                # 6. Persist assistant response so next turn has full context
                await self._save_to_history(session_id, "assistant", full_text)
                await manager.send_event(session_id, "typing_stop")
                await manager.send_event(session_id, "message_complete", {
                    "answer": full_text,
                    "context_used": self._retrieval_context_used(retrieved),
                })

        except Exception as e:
            logger.error(f"Error in stream_comprehensive_query: {e}")
            await manager.send_event(session_id, "error", {"message": f"Error during streaming: {str(e)}"})



# Singleton instance
_comprehensive_ai_service = None

def get_comprehensive_ai_service() -> ComprehensiveAIService:
    """Get singleton instance of comprehensive AI service"""
    global _comprehensive_ai_service
    if _comprehensive_ai_service is None:
        _comprehensive_ai_service = ComprehensiveAIService()
    return _comprehensive_ai_service
