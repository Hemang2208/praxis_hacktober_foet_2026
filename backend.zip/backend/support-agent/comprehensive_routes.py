"""
Comprehensive routes for accessing all user data through AI assistant
"""
from fastapi import APIRouter, HTTPException, Depends, Header, status, WebSocket, WebSocketDisconnect, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel
import json
import asyncio
import logging
import os

logger = logging.getLogger(__name__)

from comprehensive_data_service import get_comprehensive_data_service, ComprehensiveDataService
from comprehensive_ai_service import get_comprehensive_ai_service, ComprehensiveAIService
from comprehensive_models import UserComprehensiveContext
from auth_utils import verify_token
from websocket_manager import manager

router = APIRouter()
security = HTTPBearer()

from auth import require_auth

# Auth helper using shared JWT module
async def get_current_user_id(current_user: dict = Depends(require_auth)) -> str:
    """Extract user ID from authenticated JWT token"""
    user_id = current_user.get("sub") or current_user.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="User ID not found in token")
    return str(user_id)

# Request/Response Models
class AskMeQuery(BaseModel):
    query: str
    include_context: bool = True
    session_id: Optional[str] = None

class AskMeResponse(BaseModel):
    answer: str
    context_used: Optional[Dict[str, Any]] = None
    timestamp: datetime = None

    def __init__(self, **data):
        if 'timestamp' not in data or data['timestamp'] is None:
            data['timestamp'] = datetime.now()
        super().__init__(**data)

class RecommendationItem(BaseModel):
    title: str
    description: str
    category: str
    priority: str
    reasoning: str

class ProgressAnalysis(BaseModel):
    overall_progress: str
    strengths: List[str]
    areas_for_improvement: List[str]
    task_performance: str
    project_performance: str
    code_quality_trends: Optional[str] = None
    skill_development: Optional[str] = None
    recommendations: List[str]

class NextActionResponse(BaseModel):
    action: str
    reasoning: str
    expected_impact: str
    estimated_time: str
    related_items: List[str] = []

# ==================== COMPREHENSIVE AI ENDPOINTS ====================

@router.post("/ask-me", response_model=AskMeResponse, tags=["AI Assistant"])
async def ask_about_me(
    query: AskMeQuery,
    user_id: str = Depends(get_current_user_id),
    ai_service: ComprehensiveAIService = Depends(get_comprehensive_ai_service)
):
    """
    Ask anything about your data: tasks, projects, progress, skills, etc.
    Examples:
    - "What tasks do I have due this week?"
    - "How is my code quality trending?"
    - "What projects am I working on?"
    - "What skills should I focus on?"
    - "Show me my recent achievements"
    """
    try:
        result = await ai_service.answer_comprehensive_query(
            user_id,
            query.query,
            session_id=query.session_id,
            include_context=query.include_context,
        )
        return AskMeResponse(
            answer=result.get("answer", "I couldn't process your query."),
            context_used=result.get("context_used")
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to process query: {str(e)}")

@router.get("/my-complete-profile", response_model=UserComprehensiveContext, tags=["My Data"])
async def get_my_complete_profile(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """
    Get your complete profile including:
    - User profile and preferences
    - All tasks (todo, in-progress, completed)
    - All projects and their progress
    - Pull requests and code reviews
    - AI feedback and code quality metrics
    - Notifications
    - Applications
    - Computed statistics and achievements
    """
    try:
        context = await data_service.get_comprehensive_user_context(user_id)
        return context
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get profile: {str(e)}")

@router.get("/my-progress", response_model=Dict[str, Any], tags=["Analytics"])
async def get_my_progress(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """
    Get comprehensive progress summary:
    - Task completion rates
    - Project progress
    - Code quality trends
    - Skill usage statistics
    - Recent achievements
    """
    try:
        progress = await data_service.get_user_progress_summary(user_id)
        return progress
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get progress: {str(e)}")

@router.get("/analyze-my-progress", response_model=ProgressAnalysis, tags=["AI Assistant"])
async def analyze_my_progress(
    user_id: str = Depends(get_current_user_id),
    ai_service: ComprehensiveAIService = Depends(get_comprehensive_ai_service)
):
    """
    Get AI-powered analysis of your progress across all areas:
    - Overall progress summary
    - Identified strengths
    - Areas for improvement
    - Task and project performance
    - Code quality trends
    - Skill development insights
    - Personalized recommendations
    """
    try:
        analysis = await ai_service.analyze_user_progress(user_id)
        return ProgressAnalysis(**analysis)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to analyze progress: {str(e)}")

@router.get("/recommendations", response_model=List[RecommendationItem], tags=["AI Assistant"])
async def get_my_recommendations(
    user_id: str = Depends(get_current_user_id),
    ai_service: ComprehensiveAIService = Depends(get_comprehensive_ai_service)
):
    """
    Get personalized recommendations based on:
    - Current tasks and workload
    - Project status and deadlines
    - Skills and career goals
    - Code quality feedback
    - Learning opportunities
    """
    try:
        recommendations = await ai_service.get_personalized_recommendations(user_id)
        
        if not recommendations:
            print("Warning: AI service returned empty recommendations list")
            return []
        
        print(f"Converting {len(recommendations)} recommendations to response model")
        result = []
        for i, rec in enumerate(recommendations):
            try:
                result.append(RecommendationItem(**rec))
            except Exception as conv_error:
                print(f"Error converting recommendation {i}: {conv_error}")
                print(f"Problematic recommendation data: {rec}")
                continue
        
        return result
    except Exception as e:
        print(f"Error in get_my_recommendations: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to get recommendations: {str(e)}")

@router.get("/next-action", response_model=NextActionResponse, tags=["AI Assistant"])
async def get_next_best_action(
    user_id: str = Depends(get_current_user_id),
    ai_service: ComprehensiveAIService = Depends(get_comprehensive_ai_service)
):
    """
    Get AI suggestion for your next best action based on:
    - Urgent or overdue tasks
    - High-priority items
    - Career goals alignment
    - Current workload
    - Unread feedback or notifications
    """
    try:
        next_action = await ai_service.get_next_best_action(user_id)
        return NextActionResponse(**next_action)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get next action: {str(e)}")

@router.websocket("/ws/chat/{session_id}")
async def websocket_chat(
    websocket: WebSocket, 
    session_id: str, 
    token: str = Query(None),
    ai_service: ComprehensiveAIService = Depends(get_comprehensive_ai_service)
):
    print(f"DEBUG: websocket_chat reached! session_id: {session_id}, token: {token is not None}", flush=True)
    """
    WebSocket endpoint for real-time token streaming chat.
    Requires JWT token passed via query parameter ?token=...
    """
    try:
        # Verify token
        print("DEBUG: Verifying token...", flush=True)
        user_id = verify_token(token) if token else None
        print(f"DEBUG: user_id: {user_id}", flush=True)
        
        print("DEBUG: Connecting to manager...", flush=True)
        await manager.connect(websocket, session_id, user_id=user_id)
        print("DEBUG: Manager connected!", flush=True)
    except Exception as e:
        print(f"DEBUG: Exception in setup: {e}", flush=True)
        raise
    
    if not user_id:
        await manager.send_event(session_id, "error", {"message": "Authentication failed or token missing"})
        await manager.disconnect_async(session_id)
        await websocket.close(code=1008)
        return

    max_query_chars = int(os.getenv("SUPPORT_MAX_QUERY_CHARS", "20000"))

    async def run_stream(query: str) -> None:
        try:
            await ai_service.stream_comprehensive_query(user_id, query, session_id, manager)
        except Exception as exc:
            logger.exception("[WS_STREAM_FAILED] session_id=%s user_id=%s", session_id, user_id)
            await manager.send_event(
                session_id,
                "error",
                {"message": f"Failed to generate response: {exc}"},
            )

    try:
        while True:
            data = await websocket.receive_text()
            logger.info(f"[WS_MESSAGE_RECEIVED] session_id={session_id} user_id={user_id} data_length={len(data)}")
            try:
                message_data = json.loads(data)
            except json.JSONDecodeError:
                await manager.send_event(session_id, "error", {"message": "Invalid JSON format"})
                continue

            if not isinstance(message_data, dict):
                await manager.send_event(
                    session_id,
                    "error",
                    {"message": "Invalid message format", "code": "invalid_message"},
                )
                continue

            message_type = str(message_data.get("type") or "").strip().lower()
            if message_type in {"ping", "heartbeat"}:
                await manager.send_event(session_id, "pong", {})
                continue
            if message_type == "pong":
                continue

            query = message_data.get("query")
            if query is None:
                query = message_data.get("message")
            if not isinstance(query, str) or not query.strip():
                await manager.send_event(
                    session_id,
                    "error",
                    {
                        "message": "Invalid query payload",
                        "code": "missing_query",
                        "details": "The 'query' field must be a non-empty string.",
                    },
                )
                continue

            query = query.strip()
            if len(query) > max_query_chars:
                await manager.send_event(
                    session_id,
                    "error",
                    {
                        "message": (
                            f"Query is too long ({len(query)} characters). "
                            f"Please limit it to {max_query_chars} characters."
                        ),
                        "code": "query_too_long",
                    },
                )
                continue

            # Start the background task to stream response without blocking receive loop
            asyncio.create_task(run_stream(query))

    except WebSocketDisconnect:
        await manager.disconnect_async(session_id)

# ==================== SPECIFIC DATA ENDPOINTS ====================

@router.get("/my-profile", tags=["My Data"])
async def get_my_profile(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get your user profile"""
    profile = await data_service.get_user_profile(user_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile

@router.get("/my-all-tasks", tags=["My Data"])
async def get_all_my_tasks(
    limit: int = 100,
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get all your tasks from the main tasks collection"""
    tasks = await data_service.get_user_tasks(user_id, limit)
    return {"tasks": tasks, "count": len(tasks)}

@router.get("/my-projects", tags=["My Data"])
async def get_my_projects(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get all your projects"""
    projects = await data_service.get_user_projects(user_id)
    return {"projects": projects, "count": len(projects)}

@router.get("/my-project-plans", tags=["My Data"])
async def get_my_project_plans(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get all your project plans"""
    plans = await data_service.get_project_plans(user_id)
    return {"plans": plans, "count": len(plans)}

@router.get("/my-pull-requests", tags=["My Data"])
async def get_my_pull_requests(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get all your pull requests"""
    prs = await data_service.get_user_pull_requests(user_id)
    return {"pull_requests": prs, "count": len(prs)}

@router.get("/my-code-feedback", tags=["My Data"])
async def get_my_code_feedback(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get all your AI code feedback"""
    feedback = await data_service.get_user_ai_feedback(user_id)
    return {"feedback": feedback, "count": len(feedback)}

@router.get("/my-notifications", tags=["My Data"])
async def get_my_notifications(
    limit: int = 50,
    unread_only: bool = False,
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get your notifications"""
    notifications = await data_service.get_user_notifications(user_id, limit, unread_only)
    return {
        "notifications": notifications,
        "count": len(notifications),
        "unread_count": len([n for n in notifications if not n.isRead])
    }

@router.get("/my-applications", tags=["My Data"])
async def get_my_applications(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Get your job/internship applications"""
    applications = await data_service.get_user_applications(user_id)
    return {"applications": applications, "count": len(applications)}

# ==================== QUICK INSIGHTS ====================

@router.get("/my-stats-summary", tags=["Analytics"])
async def get_stats_summary(
    user_id: str = Depends(get_current_user_id),
    data_service: ComprehensiveDataService = Depends(get_comprehensive_data_service)
):
    """Quick stats summary"""
    context = await data_service.get_comprehensive_user_context(user_id)
    
    return {
        "user": {
            "name": context.user_profile.full_name if context.user_profile else "Unknown",
            "email": context.user_profile.email if context.user_profile else "Unknown",
            "role": context.user_profile.role if context.user_profile else "Unknown",
        },
        "tasks": {
            "total": context.total_tasks,
            "completed": context.completed_tasks,
            "in_progress": len([t for t in context.tasks if t.status == "in-progress"]),
            "todo": len([t for t in context.tasks if t.status == "todo"]),
            "completion_rate": f"{(context.completed_tasks/context.total_tasks*100) if context.total_tasks > 0 else 0:.1f}%"
        },
        "projects": {
            "total": len(context.projects),
            "active": context.active_projects,
        },
        "code_quality": {
            "average_score": context.average_code_quality,
            "total_feedback": context.total_feedback_received
        },
        "skills": {
            "count": len(context.skills_from_projects),
            "top_skills": context.skills_from_projects[:10]
        },
        "recent_achievements": context.recent_achievements
    }

# Health check
@router.get("/health/", tags=["Health"])
async def comprehensive_health_check():
    """Health check for comprehensive assistant"""
    return {
        "status": "healthy",
        "service": "comprehensive-support-agent",
        "features": [
            "Complete user profile access",
            "Tasks, projects, and plans",
            "Pull requests and code feedback",
            "Notifications and applications",
            "AI-powered insights and recommendations",
            "Progress tracking and analytics"
        ],
        "timestamp": datetime.now().isoformat()
    }
