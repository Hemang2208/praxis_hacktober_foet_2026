import motor.motor_asyncio
from config.settings import MONGODB_URI, DATABASE_NAME
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

class Database:
    client: Optional[AsyncIOMotorClient] = None
    database: Optional[AsyncIOMotorDatabase] = None

# Initialize database connection

async def connect_db():
    try:
        Database.client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_URI)
        Database.database = Database.client[DATABASE_NAME]
        
        # Create indexes for performance
        await create_indexes()
        print("Connected to MongoDB")
    except Exception as e:
        print(f"Failed to connect to MongoDB: {e}")
        Database.client = None
        Database.database = None

async def disconnect_db():
    if Database.client:
        await Database.client.close()
        print("Disconnected from MongoDB")

async def create_indexes():
    """Create database indexes for better performance"""
    if Database.database is not None:
        db = Database.database
        
        # User tasks collection indexes (user-specific tasks)
        await db.user_tasks.create_index("user_id")
        await db.user_tasks.create_index("title")
        await db.user_tasks.create_index("status")
        await db.user_tasks.create_index("priority")
        await db.user_tasks.create_index("due_date")
        await db.user_tasks.create_index("created_at")
        await db.user_tasks.create_index("tags")
        await db.user_tasks.create_index([("user_id", 1), ("status", 1)])
        await db.user_tasks.create_index([("user_id", 1), ("due_date", 1)])
        await db.user_tasks.create_index([("user_id", 1), ("priority", 1)])
        
        # User profiles collection indexes
        await db.user_profiles.create_index("user_id", unique=True)
        await db.user_profiles.create_index("email", unique=True)

        # Users collection indexes
        await db.users.create_index("email", unique=True)
        
        # User activity tracking indexes
        await db.user_activity.create_index("user_id")
        await db.user_activity.create_index("timestamp")
        await db.user_activity.create_index([("user_id", 1), ("timestamp", -1)])
        
        print("Database indexes created successfully")
    else:
        print("Database connection not available. Skipping index creation.")

async def get_db():
    return Database.database

def get_database():
    return Database.database

# Helper functions for common database operations
async def get_collection(collection_name: str):
    """Get a collection from the database"""
    if Database.database is not None:
        return Database.database[collection_name]
    return None

async def ping_database():
    """Check database connectivity"""
    if Database.client is not None:
        try:
            await Database.client.admin.command('ping')
            return True
        except Exception:
            return False
    return False