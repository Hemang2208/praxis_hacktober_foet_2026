import sys
import os
from pathlib import Path
from fastapi import Depends, HTTPException, status

# Add shared module to path
shared_path = str(Path(__file__).parent.parent / "shared")
if shared_path not in sys.path:
    sys.path.append(shared_path)

# Now we can import from shared.auth_utils
from auth_utils import get_current_user, get_current_user_optional

# Re-export or add agent-specific auth logic if needed
async def require_auth(user: dict = Depends(get_current_user)):
    """FastAPI dependency to require authentication"""
    return user

async def optional_auth(user: dict = Depends(get_current_user_optional)):
    """FastAPI dependency for optional authentication"""
    return user
