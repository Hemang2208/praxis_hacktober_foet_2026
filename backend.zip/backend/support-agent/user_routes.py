from fastapi import APIRouter, HTTPException, Depends, Header, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import List, Optional
from datetime import datetime

from models import (
    Task, TaskCreate, TaskUpdate, TaskStatus, TaskPriority,
    UserTaskQuery, UserTaskResponse, UserTaskStats, TaskRecommendation
)
from services.user_task_service import UserTaskService, get_user_task_service
from services.user_task_ai_service import UserTaskAIService
from config.settings import DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE
from auth_utils import Token, UserLogin, verify_token, create_access_token

router = APIRouter()
security = HTTPBearer()

from auth import require_auth

# Auth helper using shared JWT module
async def get_current_user_id(current_user: dict = Depends(require_auth)) -> str:
    """Extract user ID from authenticated JWT token"""
    user_id = current_user.get("sub") or current_user.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="User ID not found in token")
    return str(user_id)

# Authentication endpoints
@router.post("/login", response_model=Token, tags=["Authentication"])
async def login(user_credentials: UserLogin):
    """Login and get access token"""
    # For demo purposes, accept any username/password combination
    # In production, verify against database
    if not user_credentials.username or not user_credentials.password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username and password required"
        )

    # Create token with user_id as username (in real app, get from DB)
    # Include both 'sub' (standard) and 'id' (legacy planner-agent compatibility)
    username = user_credentials.username
    access_token = create_access_token(data={"sub": username, "id": username})
    return Token(access_token=access_token, token_type="bearer")

# User Task CRUD Operations
@router.post("/my-tasks", response_model=Task, tags=["My Tasks"])
async def create_my_task(
    task: TaskCreate,
    target_user_id: str,
    admin_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """
    Admin creates a new task and assigns it to a specific user.
    
    Args:
        task: Task details to create
        target_user_id: The user ID to assign the task to
        admin_id: Authenticated admin's user ID (from JWT token)
    
    Returns:
        Created task assigned to the target user
    """
    try:
        return await service.create_task_for_user(target_user_id, task)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create task: {str(e)}")

@router.get("/my-tasks/", response_model=List[Task], tags=["My Tasks"])
async def get_my_tasks(
    status: Optional[List[TaskStatus]] = None,
    priority: Optional[List[TaskPriority]] = None,
    tags: Optional[List[str]] = None,
    limit: int = DEFAULT_PAGE_SIZE,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Get all tasks for the authenticated user"""
    return await service.get_user_tasks(
        user_id=user_id,
        status=status,
        priority=priority,
        tags=tags,
        limit=min(limit, MAX_PAGE_SIZE)
    )

@router.get("/my-tasks/{task_id}", response_model=Task, tags=["My Tasks"])
async def get_my_task(
    task_id: str,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Get a specific task for the authenticated user"""
    task = await service.get_user_task(user_id, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.put("/my-tasks/{task_id}", response_model=Task, tags=["My Tasks"])
async def update_my_task(
    task_id: str,
    task_update: TaskUpdate,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Update a specific task for the authenticated user"""
    task = await service.update_user_task(user_id, task_id, task_update)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.delete("/my-tasks/{task_id}", tags=["My Tasks"])
async def delete_my_task(
    task_id: str,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Delete a specific task for the authenticated user"""
    success = await service.delete_user_task(user_id, task_id)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Task deleted successfully"}

# Search and Filter Operations
@router.get("/my-tasks/search/", response_model=List[Task], tags=["My Tasks"])
async def search_my_tasks(
    q: str,
    limit: int = DEFAULT_PAGE_SIZE,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Search the authenticated user's tasks"""
    return await service.search_user_tasks(user_id, q, min(limit, MAX_PAGE_SIZE))

@router.get("/my-tasks/overdue/", response_model=List[Task], tags=["My Tasks"])
async def get_my_overdue_tasks(
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Get overdue tasks for the authenticated user"""
    return await service.get_user_overdue_tasks(user_id)

# User Statistics
@router.get("/my-stats/", response_model=UserTaskStats, tags=["My Stats"])
async def get_my_task_stats(
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Get task statistics for the authenticated user"""
    return await service.get_user_task_stats(user_id)

# AI-Powered Features
@router.post("/my-tasks/{task_id}/analyze/", response_model=dict, tags=["AI Assistant"])
async def analyze_my_task(
    task_id: str,
    context: Optional[str] = None,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Get AI analysis for a specific task"""
    # Get the task
    task = await service.get_user_task(user_id, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Perform AI analysis
    ai_service = UserTaskAIService()
    
    try:
        analysis = await ai_service.analyze_user_task(user_id, task, context)
        
        # Update the task with AI insights
        await service.update_task_ai_analysis(
            user_id, 
            task_id, 
            analysis.get("analysis", ""), 
            analysis.get("suggestions", [])
        )
        
        return analysis
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI analysis failed: {str(e)}")

@router.get("/recommendations/", response_model=List[TaskRecommendation], tags=["AI Assistant"])
async def get_my_task_recommendations(
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Get personalized task recommendations"""
    ai_service = UserTaskAIService()
    
    try:
        # Get user's current tasks for context
        user_tasks = await service.get_user_tasks(user_id, limit=20)
        
        # Get recommendations
        recommendations = await ai_service.recommend_tasks_for_user(
            user_id, 
            user_profile=None,  # Could be enhanced to get actual user profile
            user_tasks=user_tasks
        )
        
        return recommendations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get recommendations: {str(e)}")

@router.post("/ask/", response_model=UserTaskResponse, tags=["AI Assistant"])
async def ask_about_my_tasks(
    query: UserTaskQuery,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Ask AI assistant about your tasks"""
    ai_service = UserTaskAIService()
    
    try:
        # Get user's tasks for context
        user_tasks = await service.get_user_tasks(user_id, limit=50)
        
        # Get AI response
        response_data = await ai_service.answer_user_query(
            user_id, 
            query.query, 
            user_tasks, 
            query.context
        )
        
        return UserTaskResponse(
            message=response_data.get("message", "I couldn't process your query."),
            tasks=None,  # Could be enhanced to return relevant tasks
            suggestions=response_data.get("suggestions", []),
            analysis=response_data.get("analysis")
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI query failed: {str(e)}")

# Quick Actions
@router.post("/my-tasks/{task_id}/complete/", response_model=Task, tags=["My Tasks"])
async def complete_my_task(
    task_id: str,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Mark a task as completed"""
    task_update = TaskUpdate(status=TaskStatus.DONE)
    task = await service.update_user_task(user_id, task_id, task_update)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.post("/my-tasks/{task_id}/start/", response_model=Task, tags=["My Tasks"])
async def start_my_task(
    task_id: str,
    user_id: str = Depends(get_current_user_id),
    service: UserTaskService = Depends(get_user_task_service)
):
    """Mark a task as in progress"""
    task_update = TaskUpdate(status=TaskStatus.IN_PROGRESS)
    task = await service.update_user_task(user_id, task_id, task_update)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

# Health Check
@router.get("/health/", tags=["Health"])
async def health_check():
    """Health check for the support agent"""
    return {
        "status": "healthy",
        "service": "user-support-agent",
        "timestamp": datetime.now().isoformat()
    }