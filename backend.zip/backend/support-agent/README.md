# Support Agent

AI-powered assistant that has full access to all user data across the platform — tasks, projects, code reviews, assessments, notifications. Answers natural language questions about a user's progress and gives recommendations.

**Port:** 8005

## What it does

- Answers anything about a user's data ("what should I work on next?", "how am I doing?")
- Pulls live data from all other agents
- User profile management
- JWT-based auth (own auth system)
- Recommendations and next-action suggestions

## Key files

| File | Purpose |
|---|---|
| `main.py` | FastAPI app, includes all routers |
| `comprehensive_routes.py` | AI assistant endpoints (`/api/v1/assistant/*`) |
| `comprehensive_ai_service.py` | LLM calls and prompt logic |
| `comprehensive_data_service.py` | Aggregates data from all other agents |
| `comprehensive_models.py` | Models for the assistant feature |
| `user_routes.py` | User profile endpoints |
| `auth_routes.py` | Login, register, token refresh |
| `auth.py` / `auth_utils.py` | JWT helpers |
| `websocket_manager.py` | WebSocket connection manager with Redis session state |
| `models.py` | Core user models |
| `database.py` | MongoDB connection |
| `config/` | Settings |
| `services/` | Additional service layer |

## Main endpoints

```
POST /api/v1/auth/register
POST /api/v1/auth/login
GET  /api/v1/assistant/ask-me/              — ask anything about your data
GET  /api/v1/assistant/my-progress/         — progress summary
GET  /api/v1/assistant/recommendations/     — what to work on next
GET  /api/v1/assistant/next-action/         — single best next action
GET  /api/v1/assistant/my-complete-profile/ — full user data aggregation
WS   /api/v1/assistant/ws/chat/{session_id}  — realtime token streaming (Phase 1)
```

## Env vars

```
MONGODB_URI=
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5-coder:latest
JWT_SECRET_KEY=
REDIS_URL=redis://redis:6379
ASSESSMENT_AGENT_URL=http://assessment-agent:8001
PLANNER_AGENT_URL=http://planner-agent:8002
TASK_MGMT_AGENT_URL=http://task-mgmt-agent:8003
CODE_REVIEW_AGENT_URL=http://code-review-agent:8004
```

## Running locally

```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8005
```

## Tests

```bash
cd tests
pytest test_support_auth.py -v
pytest test_ollama.py -v
```

## Docs

- `MODELS_README.md` — full model reference
- `README.md` (this file)
