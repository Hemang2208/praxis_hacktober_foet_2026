"""
Comprehensive database service to access all MongoDB collections
Provides methods to query all user-specific data
"""
import asyncio
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId

from database import Database
from comprehensive_models import (
    UserProfile, TaskData, ProjectData, ProjectPlan,
    pull_requestData, AIFeedbackData, NotificationItem,
    ApplicationData, UserComprehensiveContext
)

logger = logging.getLogger(__name__)


class ComprehensiveDataService:
    """Service to access all user-related data across collections"""
    
    def __init__(self):
        self.db: Optional[AsyncIOMotorDatabase] = None
    
    def _get_db(self) -> AsyncIOMotorDatabase:
        """Get database instance"""
        if Database.database is None:
            raise Exception("Database not connected")
        return Database.database

    async def _resolve_user_identity_variants(self, user_id: str) -> Dict[str, Any]:
        """Resolve all likely identity representations used across collections."""
        db = self._get_db()

        str_ids = {str(user_id)}
        obj_ids = []

        try:
            obj_ids.append(ObjectId(user_id))
        except Exception:
            pass

        user_doc = None
        if obj_ids:
            user_doc = await db.users.find_one({"_id": obj_ids[0]})

        if not user_doc:
            user_doc = await db.users.find_one(
                {
                    "$or": [
                        {"externaluser_id": user_id},
                        {"email": user_id},
                        {"username": user_id},
                    ]
                }
            )

        if user_doc:
            if user_doc.get("_id") is not None:
                str_ids.add(str(user_doc["_id"]))
                if isinstance(user_doc["_id"], ObjectId):
                    obj_ids.append(user_doc["_id"])
            if user_doc.get("externaluser_id"):
                str_ids.add(str(user_doc["externaluser_id"]))
            if user_doc.get("email"):
                str_ids.add(str(user_doc["email"]))
            if user_doc.get("username"):
                str_ids.add(str(user_doc["username"]))

        # De-duplicate while preserving ObjectId types.
        dedup_obj_ids = []
        seen_obj = set()
        for oid in obj_ids:
            key = str(oid)
            if key not in seen_obj:
                seen_obj.add(key)
                dedup_obj_ids.append(oid)

        return {
            "str_ids": list(str_ids),
            "obj_ids": dedup_obj_ids,
        }
    
    # ==================== SHARED HELPERS ====================
    @staticmethod
    def _to_object_id(value: Any) -> Optional[ObjectId]:
        if isinstance(value, ObjectId):
            return value
        try:
            return ObjectId(str(value))
        except Exception:
            return None

    @staticmethod
    def _id_candidates_from_identities(identities: Dict[str, Any]) -> List[Any]:
        candidates: List[Any] = []
        seen = set()
        for value in [*identities.get("str_ids", []), *identities.get("obj_ids", [])]:
            key = (type(value).__name__, str(value))
            if key not in seen:
                seen.add(key)
                candidates.append(value)
        return candidates

    @staticmethod
    def _project_access_conditions(id_candidates: List[Any]) -> List[Dict[str, Any]]:
        fields = [
            "user",
            "createdBy",
            "created_by",
            "owner",
            "team.user",
            "team.user_id",
            "team",
            "team_members.user",
            "team_members.user_id",
            "team_members",
            "teamMembers.user",
            "teamMembers.user_id",
            "teamMembers",
            "members.user",
            "members.user_id",
            "members._id",
            "members",
            "resources.user",
            "resources.user_id",
        ]
        return [{field: {"$in": id_candidates}} for field in fields]

    @staticmethod
    def _task_assignment_conditions(id_candidates: List[Any]) -> List[Dict[str, Any]]:
        fields = [
            "student_id",
            "assigned_to",
            "assignedTo",
            "assignee",
            "assignee_id",
            "assigned_to_id",
            "user_id",
        ]
        return [{field: {"$in": id_candidates}} for field in fields]

    @staticmethod
    def _task_access_conditions(
        id_candidates: List[Any], project_id_candidates: List[Any]
    ) -> List[Dict[str, Any]]:
        fields = [
            "student_id",
            "assigned_to",
            "assignedTo",
            "assignee",
            "assignee_id",
            "assigned_to_id",
            "createdBy",
            "created_by",
            "user_id",
            "user",
            "owner",
        ]
        conditions = [{field: {"$in": id_candidates}} for field in fields]
        if project_id_candidates:
            conditions.append({"project_id": {"$in": project_id_candidates}})
        return conditions

    async def _get_accessible_project_id_candidates(
        self, id_candidates: List[Any]
    ) -> List[Any]:
        db = self._get_db()
        cursor = db.projects.find(
            {
                "$and": [
                    {"status": {"$ne": "deleted"}},
                    {"$or": self._project_access_conditions(id_candidates)},
                ]
            },
            {"_id": 1},
        )
        candidates: List[Any] = []
        seen = set()
        async for project in cursor:
            project_id = project.get("_id")
            if project_id is None:
                continue
            for candidate in (project_id, str(project_id)):
                key = (type(candidate).__name__, str(candidate))
                if key not in seen:
                    seen.add(key)
                    candidates.append(candidate)
        return candidates

    @staticmethod
    def _task_from_document(raw_task: Dict[str, Any]) -> TaskData:
        task = dict(raw_task)
        task["_id"] = str(task["_id"])
        if not task.get("status"):
            task["status"] = "todo"
        if not task.get("priority"):
            task["priority"] = "medium"
        if not task.get("title"):
            task["title"] = task.get("name") or "Untitled Task"

        for field in (
            "project_id",
            "student_id",
            "assigned_to",
            "createdBy",
            "created_by",
            "user_id",
            "user",
            "owner",
            "linked_pr_id",
            "linked_pull_request",
            "ai_feedback",
        ):
            if isinstance(task.get(field), ObjectId):
                task[field] = str(task[field])

        if isinstance(task.get("tags"), str):
            task["tags"] = [task["tags"]]
        elif not isinstance(task.get("tags"), list):
            task["tags"] = []

        if isinstance(task.get("dependencies"), list):
            task["dependencies"] = [str(dep) for dep in task["dependencies"]]
        else:
            task["dependencies"] = []

        subtasks = []
        for sub in task.get("sub_tasks") or []:
            if not isinstance(sub, dict):
                continue
            sub = dict(sub)
            if sub.get("_id") is not None:
                sub["_id"] = str(sub["_id"])
            if isinstance(sub.get("assignee"), ObjectId):
                sub["assignee"] = str(sub["assignee"])
            if not sub.get("title") and sub.get("name"):
                sub["title"] = sub["name"]
            if sub.get("completed") is None:
                sub["completed"] = False
            if sub.get("title"):
                subtasks.append(sub)
        task["sub_tasks"] = subtasks

        comments = []
        for comment in task.get("comments") or []:
            if not isinstance(comment, dict):
                continue
            comment = dict(comment)
            if comment.get("_id") is not None:
                comment["_id"] = str(comment["_id"])
            if isinstance(comment.get("user_id"), ObjectId):
                comment["user_id"] = str(comment["user_id"])
            if isinstance(comment.get("user"), ObjectId):
                comment["user_id"] = str(comment["user"])
            comment.setdefault("user_id", "")
            comment.setdefault("message", comment.get("content") or "")
            if comment.get("message"):
                comments.append(comment)
        task["comments"] = comments

        attachments = []
        for attachment in task.get("attachments") or []:
            if not isinstance(attachment, dict):
                continue
            attachment = dict(attachment)
            if attachment.get("_id") is not None:
                attachment["_id"] = str(attachment["_id"])
            attachment.setdefault("name", attachment.get("filename") or "Attachment")
            attachment.setdefault("url", attachment.get("link") or "")
            attachment.setdefault("type", attachment.get("mimeType") or "file")
            if attachment.get("size") is None:
                attachment["size"] = 0
            attachments.append(attachment)
        task["attachments"] = attachments

        return TaskData(**task)

    async def _get_accessible_task_id_candidates(
        self, id_candidates: List[Any], project_id_candidates: List[Any]
    ) -> List[Any]:
        db = self._get_db()
        cursor = db.tasks.find(
            {
                "$and": [
                    {"status": {"$ne": "deleted"}},
                    {
                        "$or": self._task_access_conditions(
                            id_candidates, project_id_candidates
                        )
                    },
                ]
            },
            {"_id": 1},
        )
        candidates: List[Any] = []
        seen = set()
        async for task in cursor:
            task_id = task.get("_id")
            if task_id is None:
                continue
            for candidate in (task_id, str(task_id)):
                key = (type(candidate).__name__, str(candidate))
                if key not in seen:
                    seen.add(key)
                    candidates.append(candidate)
        return candidates

    # ==================== USER PROFILE ====================
    async def get_user_profile(self, user_id: str) -> Optional[UserProfile]:
        """Get a normalized profile for students, companies, and admins."""
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            id_candidates = self._id_candidates_from_identities(identities)

            user_data = await db.users.find_one({"_id": {"$in": id_candidates}})
            if not user_data:
                user_data = await db.users.find_one(
                    {
                        "$or": [
                            {"externaluser_id": {"$in": id_candidates}},
                            {"email": {"$in": id_candidates}},
                            {"username": {"$in": id_candidates}},
                            {"contactPersonEmail": {"$in": id_candidates}},
                        ]
                    }
                )
            if not user_data:
                return None

            user_data = dict(user_data)
            user_data["_id"] = str(user_data["_id"])
            for field in ("companyId", "company_id", "organization_id"):
                if isinstance(user_data.get(field), ObjectId):
                    user_data[field] = str(user_data[field])

            if not user_data.get("email"):
                user_data["email"] = (
                    user_data.get("contactPersonEmail")
                    or user_data.get("companyEmail")
                    or ""
                )
            if not user_data.get("full_name"):
                user_data["full_name"] = (
                    user_data.get("contactPersonName")
                    or user_data.get("companyName")
                    or user_data.get("name")
                    or user_data.get("username")
                    or user_data.get("email")
                    or "Unknown User"
                )
            if not user_data.get("role"):
                user_data["role"] = user_data.get("userType") or user_data.get("accountType") or "user"

            return UserProfile(**user_data)
        except Exception as e:
            logger.warning("Error getting user profile: %s", e)
            return None

    # ==================== TASKS ====================
    async def get_user_tasks(self, user_id: str, limit: int = 100) -> List[TaskData]:
        """Get tasks directly assigned to the user.

        Only tasks where an assignment field (student_id, assigned_to, assignedTo,
        assignee, assignee_id, assigned_to_id, user_id) matches the user are
        returned.  Tasks that merely belong to a project the user can access but
        are assigned to someone else are intentionally excluded so that AI
        context is scoped to the authenticated user's own workload.
        """
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            id_candidates = self._id_candidates_from_identities(identities)

            # Strict assignment-only filter — no project-membership fallback.
            query = {
                "$and": [
                    {"status": {"$ne": "deleted"}},
                    {"$or": self._task_assignment_conditions(id_candidates)},
                ]
            }

            tasks_cursor = db.tasks.find(query).sort("updated_at", -1).limit(max(limit, 1))
            tasks: List[TaskData] = []
            async for task in tasks_cursor:
                try:
                    tasks.append(self._task_from_document(task))
                except Exception as parse_error:
                    logger.warning(
                        "Skipping invalid task document %s: %s",
                        task.get("_id"),
                        parse_error,
                    )
            return tasks
        except Exception as e:
            logger.warning("Error getting user tasks: %s", e)
            return []

    async def get_project_tasks(
        self,
        viewer_user_id: str,
        project_ids: List[str],
        limit: int = 100,
    ) -> List[TaskData]:
        """Get all tasks belonging to specified projects, access-gated by viewer.

        Used for project-scoped context queries (e.g. 'show all tasks in Project X').
        Unlike get_user_tasks() this is NOT limited to tasks assigned to the viewer.
        """
        try:
            db = self._get_db()
            viewer_identities = await self._resolve_user_identity_variants(viewer_user_id)
            viewer_ids = self._id_candidates_from_identities(viewer_identities)
            accessible_project_ids = await self._get_accessible_project_id_candidates(viewer_ids)

            # Intersect requested project IDs with viewer-accessible ones
            accessible_str = {str(pid) for pid in accessible_project_ids}
            filtered_ids = [pid for pid in project_ids if str(pid) in accessible_str]

            if not filtered_ids:
                return []

            obj_ids: List[Any] = []
            for pid in filtered_ids:
                obj_id = self._to_object_id(pid)
                if obj_id is not None:
                    obj_ids.append(obj_id)

            project_candidates: List[Any] = filtered_ids + obj_ids
            query = {
                "$and": [
                    {"status": {"$ne": "deleted"}},
                    {"project_id": {"$in": project_candidates}},
                ]
            }
            cursor = db.tasks.find(query).sort("updated_at", -1).limit(max(limit, 1))
            tasks: List[TaskData] = []
            async for task in cursor:
                try:
                    tasks.append(self._task_from_document(task))
                except Exception as parse_error:
                    logger.warning(
                        "Skipping invalid project task %s: %s",
                        task.get("_id"),
                        parse_error,
                    )
            return tasks
        except Exception as e:
            logger.warning(
                "Error getting project tasks viewer=%s projects=%s: %s",
                viewer_user_id,
                project_ids,
                e,
            )
            return []

    async def get_tasks_for_assignee(
        self,
        viewer_user_id: str,
        target_user_id: str,
        limit: int = 100,
    ) -> List[TaskData]:
        """Get tasks assigned to a target user within the viewer's access scope.

        Direct assignment alone is not enough for another user's records: the task
        must also be visible through the viewer's projects. A user always retains
        access to tasks directly assigned to themselves.
        """
        try:
            db = self._get_db()
            viewer_identities = await self._resolve_user_identity_variants(viewer_user_id)
            target_identities = await self._resolve_user_identity_variants(target_user_id)
            viewer_ids = self._id_candidates_from_identities(viewer_identities)
            target_ids = self._id_candidates_from_identities(target_identities)
            viewer_project_ids = await self._get_accessible_project_id_candidates(viewer_ids)

            query = {
                "$and": [
                    {"status": {"$ne": "deleted"}},
                    {"$or": self._task_assignment_conditions(target_ids)},
                    {"$or": self._task_access_conditions(viewer_ids, viewer_project_ids)},
                ]
            }
            cursor = db.tasks.find(query).sort("updated_at", -1).limit(max(limit, 1))
            tasks: List[TaskData] = []
            async for task in cursor:
                try:
                    tasks.append(self._task_from_document(task))
                except Exception as parse_error:
                    logger.warning(
                        "Skipping invalid assigned task %s: %s",
                        task.get("_id"),
                        parse_error,
                    )
            return tasks
        except Exception as e:
            logger.warning(
                "Error getting assigned tasks viewer=%s target=%s: %s",
                viewer_user_id,
                target_user_id,
                e,
            )
            return []
    async def get_project_member_directory(
        self,
        viewer_user_id: str,
        projects: Optional[List[ProjectData]] = None,
    ) -> List[Dict[str, Any]]:
        """Resolve users who share at least one accessible project with the viewer."""
        try:
            projects = projects if projects is not None else await self.get_user_projects(viewer_user_id)
            members: Dict[str, Dict[str, Any]] = {}

            def add_member(user_ref: Any, name: Any, email: Any, project_id: str) -> None:
                user_id = "" if user_ref is None else str(user_ref)
                if not user_id:
                    return
                entry = members.setdefault(
                    user_id,
                    {"id": user_id, "name": "", "email": "", "project_ids": []},
                )
                if name and name != "Member":
                    entry["name"] = str(name)
                if email:
                    entry["email"] = str(email)
                if project_id and project_id not in entry["project_ids"]:
                    entry["project_ids"].append(project_id)

            for project in projects:
                project_id = str(project.id or "")
                add_member(project.user, None, None, project_id)
                add_member(project.created_by, None, None, project_id)
                for member in [*project.team_members, *project.team]:
                    add_member(member.user, member.name, member.email, project_id)
                for resource in project.resources:
                    add_member(resource.user, resource.name, email=None, project_id=project_id)

            if not members:
                return []

            db = self._get_db()
            id_candidates: List[Any] = []
            for user_id in members:
                id_candidates.append(user_id)
                obj_id = self._to_object_id(user_id)
                if obj_id is not None:
                    id_candidates.append(obj_id)

            cursor = db.users.find(
                {"_id": {"$in": id_candidates}},
                {
                    "full_name": 1,
                    "name": 1,
                    "username": 1,
                    "email": 1,
                    "contactPersonName": 1,
                    "companyName": 1,
                    "contactPersonEmail": 1,
                },
            )
            async for user in cursor:
                user_id = str(user.get("_id"))
                entry = members.get(user_id)
                if not entry:
                    continue
                entry["name"] = (
                    user.get("full_name")
                    or user.get("name")
                    or user.get("contactPersonName")
                    or user.get("companyName")
                    or user.get("username")
                    or entry["name"]
                )
                entry["email"] = (
                    user.get("email")
                    or user.get("contactPersonEmail")
                    or entry["email"]
                )

            return list(members.values())
        except Exception as e:
            logger.warning("Error resolving project member directory: %s", e)
            return []

    async def get_task_by_id(self, task_id: str, user_id: Optional[str] = None) -> Optional[TaskData]:
        """Get a task by ID, optionally enforcing user/project ownership."""
        try:
            db = self._get_db()
            task_obj_id = self._to_object_id(task_id)
            id_candidates = [task_id]
            if task_obj_id is not None:
                id_candidates.append(task_obj_id)

            if user_id:
                identities = await self._resolve_user_identity_variants(user_id)
                user_ids = self._id_candidates_from_identities(identities)
                project_ids = await self._get_accessible_project_id_candidates(user_ids)
                query = {
                    "$and": [
                        {"_id": {"$in": id_candidates}},
                        {
                            "$or": self._task_access_conditions(user_ids, project_ids)
                        },
                    ]
                }
            else:
                query = {"_id": {"$in": id_candidates}}

            task_data = await db.tasks.find_one(query)
            if not task_data:
                return None
            return self._task_from_document(task_data)
        except Exception as e:
            logger.warning("Error getting task: %s", e)
            return None

    # ==================== PROJECTS ====================
    async def get_user_projects(self, user_id: str) -> List[ProjectData]:
        """Get all projects owned by or involving user"""
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            str_ids = identities["str_ids"]
            obj_ids = identities["obj_ids"]

            id_candidates: List[Any] = []
            id_candidates.extend(str_ids)
            id_candidates.extend(obj_ids)
            
            # Find projects where user is owner or team member
            projects_cursor = db.projects.find(
                {
                    "$and": [
                        {"status": {"$ne": "deleted"}},
                        {"$or": self._project_access_conditions(id_candidates)},
                    ]
                }
            ).sort("created_at", -1)
            
            projects = []
            async for project in projects_cursor:
                try:
                    project["_id"] = str(project["_id"])
                    # Normalize required or frequently variant fields.
                    if "title" not in project or not project.get("title"):
                        project["title"] = project.get("name") or "Untitled Project"
                    if "description" not in project or project.get("description") is None:
                        project["description"] = ""
                    if "status" not in project or not project.get("status"):
                        project["status"] = "planning"
                    if "progress" not in project or project.get("progress") is None:
                        project["progress"] = 0
                    if "tags" not in project or not isinstance(project.get("tags"), list):
                        project["tags"] = []

                    if "tasks" in project:
                        project["tasks"] = [str(task_id) for task_id in project.get("tasks", [])]
                    elif "task_ids" in project and isinstance(project.get("task_ids"), list):
                        project["tasks"] = [str(task_id) for task_id in project.get("task_ids", [])]
                    else:
                        project["tasks"] = []

                    # Normalize nested arrays that often vary by schema.
                    if "team" not in project or not isinstance(project.get("team"), list):
                        project["team"] = []
                    if "team_members" not in project:
                        if isinstance(project.get("teamMembers"), list):
                            project["team_members"] = project.get("teamMembers")
                        elif isinstance(project.get("members"), list):
                            project["team_members"] = project.get("members")
                        else:
                            project["team_members"] = []
                    if "resources" not in project or not isinstance(project.get("resources"), list):
                        project["resources"] = []

                    # Normalize optional arrays that can contain incompatible shapes.
                    if "sprints" not in project or not isinstance(project.get("sprints"), list):
                        project["sprints"] = []
                    else:
                        normalized_sprints = []
                        for sprint in project.get("sprints", []):
                            if not isinstance(sprint, dict):
                                continue
                            normalized_sprints.append(
                                {
                                    "name": sprint.get("name") or "Sprint",
                                    "progress": float(sprint.get("progress", 0) or 0),
                                    "status": sprint.get("status") or "planned",
                                }
                            )
                        project["sprints"] = normalized_sprints

                    if "timeline" not in project or not isinstance(project.get("timeline"), list):
                        project["timeline"] = []
                    else:
                        normalized_timeline = []
                        for item in project.get("timeline", []):
                            if not isinstance(item, dict):
                                continue
                            event_date = item.get("date")
                            if not isinstance(event_date, datetime):
                                continue
                            normalized_timeline.append(
                                {
                                    "title": item.get("title") or "Event",
                                    "description": item.get("description") or "",
                                    "type": item.get("type") or "info",
                                    "date": event_date,
                                }
                            )
                        project["timeline"] = normalized_timeline

                    # Avoid dropping projects because of malformed commit entries.
                    if "githubCommits" not in project or not isinstance(project.get("githubCommits"), list):
                        project["githubCommits"] = []
                    else:
                        normalized_commits = []
                        for commit in project.get("githubCommits", []):
                            if not isinstance(commit, dict):
                                continue
                            required_fields = [
                                "id",
                                "message",
                                "author",
                                "authorEmail",
                                "timestamp",
                                "repository",
                                "branch",
                                "url",
                            ]
                            if not all(commit.get(field) is not None for field in required_fields):
                                continue
                            normalized_commits.append(commit)
                        project["githubCommits"] = normalized_commits

                    normalized_team_members = []
                    for member in project.get("team_members", []):
                        if not isinstance(member, dict):
                            continue
                        normalized_team_members.append(
                            {
                                "name": member.get("name") or member.get("full_name") or member.get("username") or "Member",
                                "avatar": member.get("avatar") or member.get("image_url") or "",
                                "email": member.get("email"),
                                "role": member.get("role"),
                                "user": str(
                                    member.get("user")
                                    or member.get("user_id")
                                    or member.get("_id")
                                    or ""
                                )
                                or None,
                            }
                        )
                    project["team_members"] = normalized_team_members

                    normalized_team = []
                    for member in project.get("team", []):
                        if not isinstance(member, dict):
                            continue
                        normalized_team.append(
                            {
                                "name": member.get("name") or member.get("full_name") or member.get("username") or "Member",
                                "avatar": member.get("avatar") or member.get("image_url") or "",
                                "email": member.get("email"),
                                "role": member.get("role"),
                                "user": str(
                                    member.get("user")
                                    or member.get("user_id")
                                    or member.get("_id")
                                    or ""
                                )
                                or None,
                            }
                        )
                    project["team"] = normalized_team

                    normalized_resources = []
                    for res in project.get("resources", []):
                        if not isinstance(res, dict):
                            continue
                        normalized_resources.append(
                            {
                                "profile": res.get("profile") or "",
                                "skills": res.get("skills") if isinstance(res.get("skills"), list) else [],
                                "experience": res.get("experience") or "",
                                "description": res.get("description") or "",
                                "type": res.get("type") or "member",
                                "avatar": res.get("avatar") or res.get("image_url") or "",
                                "username": res.get("username") or "",
                                "name": res.get("name") or res.get("full_name") or "",
                                "user": str(
                                    res.get("user")
                                    or res.get("user_id")
                                    or res.get("_id")
                                    or ""
                                )
                                or None,
                            }
                        )
                    project["resources"] = normalized_resources

                    for identity_field in ("user", "created_by", "createdBy", "owner"):
                        if isinstance(project.get(identity_field), ObjectId):
                            project[identity_field] = str(project[identity_field])
                    if not project.get("created_by") and project.get("createdBy"):
                        project["created_by"] = str(project["createdBy"])
                    if not project.get("ai_generated_tags") and isinstance(
                        project.get("aiGeneratedTags"), list
                    ):
                        project["ai_generated_tags"] = project.get("aiGeneratedTags")

                    projects.append(ProjectData(**project))
                except Exception as parse_error:
                    print(f"Skipping invalid project document {project.get('_id')}: {parse_error}")
                    continue
            
            return projects
        except Exception as e:
            print(f"Error getting user projects: {e}")
            return []
    
    async def get_project_by_id(self, project_id: str, user_id: Optional[str] = None) -> Optional[ProjectData]:
        """Get a project by ID, optionally enforcing user ownership/membership."""
        try:
            if user_id:
                projects = await self.get_user_projects(user_id)
                return next((project for project in projects if project.id == project_id), None)

            db = self._get_db()
            project_obj_id = self._to_object_id(project_id)
            id_candidates = [project_id]
            if project_obj_id is not None:
                id_candidates.append(project_obj_id)
            project_data = await db.projects.find_one({"_id": {"$in": id_candidates}})
            if not project_data:
                return None

            project_data = dict(project_data)
            project_data["_id"] = str(project_data["_id"])
            if "tasks" in project_data:
                project_data["tasks"] = [str(task_id) for task_id in project_data.get("tasks", [])]
            for field in ("user", "created_by", "createdBy"):
                if isinstance(project_data.get(field), ObjectId):
                    project_data[field] = str(project_data[field])
            return ProjectData(**project_data)
        except Exception as e:
            logger.warning("Error getting project: %s", e)
            return None

    # ==================== PROJECT PLANS ====================
    async def get_project_plans(self, user_id: str) -> List[ProjectPlan]:
        """Get all project plans for user's projects"""
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            id_candidates: List[Any] = []
            id_candidates.extend(identities["str_ids"])
            id_candidates.extend(identities["obj_ids"])
            
            # First get user's project IDs
            user_projects = await self.get_user_projects(user_id)
            project_ids = [str(p.id) for p in user_projects if p.id]
            project_obj_ids = []
            for pid in project_ids:
                try:
                    project_obj_ids.append(ObjectId(pid))
                except Exception:
                    continue
            
            if not project_ids:
                # Fallback: discover project IDs directly via project membership query.
                fallback_projects_cursor = db.projects.find(
                    {
                        "$or": [
                            {"user": {"$in": id_candidates}},
                            {"createdBy": {"$in": id_candidates}},
                            {"created_by": {"$in": id_candidates}},
                            {"owner": {"$in": id_candidates}},
                            {"team.user": {"$in": id_candidates}},
                            {"team.user_id": {"$in": id_candidates}},
                            {"team": {"$in": id_candidates}},
                            {"team_members.user": {"$in": id_candidates}},
                            {"team_members.user_id": {"$in": id_candidates}},
                            {"team_members": {"$in": id_candidates}},
                            {"teamMembers.user": {"$in": id_candidates}},
                            {"teamMembers.user_id": {"$in": id_candidates}},
                            {"teamMembers": {"$in": id_candidates}},
                            {"members.user": {"$in": id_candidates}},
                            {"members.user_id": {"$in": id_candidates}},
                            {"members._id": {"$in": id_candidates}},
                            {"members": {"$in": id_candidates}},
                            {"resources.user": {"$in": id_candidates}},
                            {"resources.user_id": {"$in": id_candidates}},
                        ]
                    },
                    {"_id": 1}
                )

                async for fallback_project in fallback_projects_cursor:
                    pid = fallback_project.get("_id")
                    if pid is not None:
                        project_ids.append(str(pid))
                        if isinstance(pid, ObjectId):
                            project_obj_ids.append(pid)

                if not project_ids:
                    return []
            
            # Get plans for these projects
            plans_cursor = db.project_plans.find({
                "$or": [
                    {"project_id": {"$in": project_ids}},
                    {"project_id": {"$in": project_obj_ids}},
                    {"project": {"$in": project_ids}},
                    {"project": {"$in": project_obj_ids}},
                    {"projectId": {"$in": project_ids}},
                    {"projectId": {"$in": project_obj_ids}},
                ]
            }).sort("created_at", -1)
            
            plans = []
            async for plan in plans_cursor:
                try:
                    plan["_id"] = str(plan["_id"])
                    if isinstance(plan.get("project_id"), ObjectId):
                        plan["project_id"] = str(plan["project_id"])
                    if "projectId" in plan and plan.get("projectId") is not None and "project_id" not in plan:
                        plan["project_id"] = str(plan.get("projectId"))
                    if "project_id" not in plan and plan.get("project") is not None:
                        plan["project_id"] = str(plan.get("project"))
                    if not plan.get("summary"):
                        plan["summary"] = plan.get("project_summary") or ""
                    if "project_summary" in plan and plan.get("project_summary") is not None:
                        plan["project_summary"] = str(plan.get("project_summary"))

                    normalized_milestones = []
                    for milestone in plan.get("major_milestones") or []:
                        if isinstance(milestone, str):
                            normalized_milestones.append({"name": milestone, "timeline": ""})
                        elif isinstance(milestone, dict):
                            normalized_milestones.append(
                                {
                                    "name": milestone.get("name") or milestone.get("title") or "Milestone",
                                    "timeline": str(
                                        milestone.get("timeline")
                                        or milestone.get("date")
                                        or milestone.get("deadline")
                                        or ""
                                    ),
                                }
                            )
                    plan["major_milestones"] = normalized_milestones

                    normalized_high_level_tasks = []
                    for high_level_task in plan.get("high_level_tasks") or []:
                        if isinstance(high_level_task, str):
                            normalized_high_level_tasks.append({"task_name": high_level_task})
                        elif isinstance(high_level_task, dict):
                            normalized_high_level_tasks.append(
                                {
                                    "task_name": high_level_task.get("task_name")
                                    or high_level_task.get("name")
                                    or high_level_task.get("title")
                                    or "Task",
                                    "description": high_level_task.get("description") or "",
                                    "dependencies": [
                                        str(dep)
                                        for dep in (high_level_task.get("dependencies") or [])
                                    ],
                                    "estimated_duration": high_level_task.get("estimated_duration")
                                    or high_level_task.get("duration")
                                    or "",
                                }
                            )
                    plan["high_level_tasks"] = normalized_high_level_tasks

                    # Convert datetime objects to ISO format strings
                    if "updated_at" in plan and plan.get("updated_at") is not None:
                        if isinstance(plan["updated_at"], datetime):
                            plan["updated_at"] = plan["updated_at"].isoformat()
                    else:
                        plan["updated_at"] = ""
                    
                    if "created_at" in plan and plan.get("created_at") is not None:
                        if isinstance(plan["created_at"], datetime):
                            plan["created_at"] = plan["created_at"].isoformat()
                    else:
                        plan["created_at"] = ""
                    
                    plans.append(ProjectPlan(**plan))
                except Exception as parse_error:
                    print(f"Skipping invalid project plan {plan.get('_id')}: {parse_error}")
                    continue
            
            return plans
        except Exception as e:
            print(f"Error getting project plans: {e}")
            return []
    
    # ==================== PULL REQUESTS ====================
    async def get_user_pull_requests(self, user_id: str) -> List[pull_requestData]:
        """Get pull requests submitted by the user or for their accessible tasks."""
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            id_candidates = self._id_candidates_from_identities(identities)
            project_ids = await self._get_accessible_project_id_candidates(id_candidates)
            task_ids = await self._get_accessible_task_id_candidates(id_candidates, project_ids)

            conditions = [
                {field: {"$in": id_candidates}}
                for field in ("student_id", "studentId", "user_id", "user", "createdBy")
            ]
            if task_ids:
                conditions.append({"task_id": {"$in": task_ids}})

            prs_cursor = db.pull_requests.find({"$or": conditions}).sort("submitted_at", -1)

            prs = []
            async for pr in prs_cursor:
                try:
                    pr = dict(pr)
                    pr["_id"] = str(pr["_id"])
                    for field in ("user_id", "student_id", "studentId", "task_id", "user"):
                        if isinstance(pr.get(field), ObjectId):
                            pr[field] = str(pr[field])
                    pr["user_id"] = (
                        pr.get("user_id")
                        or pr.get("student_id")
                        or pr.get("studentId")
                        or str(id_candidates[0])
                    )
                    pr["task_id"] = pr.get("task_id") or None
                    if not pr.get("submitted_at"):
                        pr["submitted_at"] = pr.get("created_at") or datetime.utcnow()
                    pr.setdefault("status", "unknown")
                    if not isinstance(pr.get("pull_request"), dict):
                        pr["pull_request"] = {
                            "url": pr.get("pull_request_url") or "",
                            "branch": pr.get("branch") or "",
                            "status": pr.get("status") or "",
                        }
                    prs.append(pull_requestData(**pr))
                except Exception as parse_error:
                    logger.warning("Skipping invalid pull request %s: %s", pr.get("_id"), parse_error)
            return prs
        except Exception as e:
            logger.warning("Error getting pull requests: %s", e)
            return []

    # ==================== AI FEEDBACK ====================
    async def get_user_ai_feedback(self, user_id: str) -> List[AIFeedbackData]:
        """Get all AI feedback for the user's code."""
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            id_candidates = self._id_candidates_from_identities(identities)

            query = {
                "$or": [
                    {"user_id": {"$in": id_candidates}},
                    {"student_id": {"$in": id_candidates}},
                    {"studentId": {"$in": id_candidates}},
                    {"user": {"$in": id_candidates}},
                    {"createdBy": {"$in": id_candidates}},
                ]
            }

            feedback_cursor = db.ai_feedback.find(query)
            if await db.ai_feedback.count_documents(query) == 0:
                feedback_cursor = db.aifeedbacks.find(query)

            feedback_cursor = feedback_cursor.sort("created_at", -1)
            feedbacks = []
            async for feedback in feedback_cursor:
                try:
                    feedback = dict(feedback)
                    feedback["_id"] = str(feedback["_id"])
                    for field in (
                        "user_id",
                        "student_id",
                        "studentId",
                        "task_id",
                        "taskId",
                    ):
                        if isinstance(feedback.get(field), ObjectId):
                            feedback[field] = str(feedback[field])
                    feedback["user_id"] = (
                        feedback.get("user_id")
                        or feedback.get("student_id")
                        or feedback.get("studentId")
                        or str(id_candidates[0])
                    )
                    feedback["task_id"] = (
                        feedback.get("task_id") or feedback.get("taskId") or feedback["_id"]
                    )
                    feedback["pull_request_url"] = (
                        feedback.get("pull_request_url")
                        or feedback.get("pullRequestUrl")
                        or ""
                    )
                    feedback["repository_url"] = (
                        feedback.get("repository_url") or feedback.get("repositoryUrl")
                    )
                    if "comments" in feedback and isinstance(feedback["comments"], list):
                        for comment in feedback["comments"]:
                            if isinstance(comment, dict) and isinstance(comment.get("_id"), ObjectId):
                                comment["_id"] = str(comment["_id"])
                    feedbacks.append(AIFeedbackData(**feedback))
                except Exception as parse_error:
                    logger.warning("Skipping invalid AI feedback %s: %s", feedback.get("_id"), parse_error)
            return feedbacks
        except Exception as e:
            logger.warning("Error getting AI feedback: %s", e)
            return []

    # ==================== NOTIFICATIONS ====================
    async def get_user_notifications(self, user_id: str, limit: int = 50, unread_only: bool = False) -> List[NotificationItem]:
        """Get user notifications"""
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            id_candidates: List[Any] = []
            id_candidates.extend(identities["str_ids"])
            id_candidates.extend(identities["obj_ids"])
            
            query: Dict[str, Any] = {
                "$or": [
                    {"user_id": {"$in": id_candidates}},
                    {"user": {"$in": id_candidates}},
                    {"recipient_id": {"$in": id_candidates}},
                ]
            }
            
            if unread_only:
                query["$and"] = [
                    {
                        "$or": [
                            {"isRead": False},
                            {"is_read": False},
                        ]
                    }
                ]
            
            notifications_cursor = db.notifications.find(query).sort("created_at", -1).limit(limit)
            
            notifications = []
            async for notif in notifications_cursor:
                try:
                    notif["_id"] = str(notif["_id"])
                    if isinstance(notif.get("user_id"), ObjectId):
                        notif["user_id"] = str(notif["user_id"])
                    if "user_id" not in notif and notif.get("user") is not None:
                        notif["user_id"] = str(notif.get("user"))
                    if "user_id" not in notif and notif.get("recipient_id") is not None:
                        notif["user_id"] = str(notif.get("recipient_id"))

                    # Add default type if missing
                    if "type" not in notif or notif.get("type") is None:
                        notif["type"] = "info"

                    # Normalize snake_case/camelCase variants.
                    if "isRead" not in notif and "is_read" in notif:
                        notif["isRead"] = bool(notif.get("is_read"))
                    if "readAt" not in notif and notif.get("read_at") is not None:
                        notif["readAt"] = notif.get("read_at")
                    if "createdBy" not in notif and notif.get("created_by") is not None:
                        notif["createdBy"] = str(notif.get("created_by"))
                    if "expiresAt" not in notif and notif.get("expires_at") is not None:
                        notif["expiresAt"] = notif.get("expires_at")
                    if "scheduledFor" not in notif and notif.get("scheduled_for") is not None:
                        notif["scheduledFor"] = notif.get("scheduled_for")

                    # Convert ObjectId to string in nested data field
                    if "data" in notif and isinstance(notif["data"], dict):
                        if isinstance(notif["data"].get("task_id"), ObjectId):
                            notif["data"]["task_id"] = str(notif["data"]["task_id"])
                        if isinstance(notif["data"].get("feedbackId"), ObjectId):
                            notif["data"]["feedbackId"] = str(notif["data"]["feedbackId"])
                        if isinstance(notif["data"].get("project_id"), ObjectId):
                            notif["data"]["project_id"] = str(notif["data"]["project_id"])
                    notifications.append(NotificationItem(**notif))
                except Exception as parse_error:
                    print(f"Skipping invalid notification {notif.get('_id')}: {parse_error}")
                    continue
            
            return notifications
        except Exception as e:
            print(f"Error getting notifications: {e}")
            return []
    
    # ==================== APPLICATIONS ====================
    async def get_user_applications(self, user_id: str) -> List[ApplicationData]:
        """Get user's job/internship applications"""
        try:
            db = self._get_db()
            identities = await self._resolve_user_identity_variants(user_id)
            id_candidates: List[Any] = []
            id_candidates.extend(identities["str_ids"])
            id_candidates.extend(identities["obj_ids"])
            
            # Get user profile first to match by email
            user_profile = await self.get_user_profile(user_id)
            query: Dict[str, Any] = {
                "$or": [
                    {"user_id": {"$in": id_candidates}},
                    {"user": {"$in": id_candidates}},
                ]
            }
            if user_profile and user_profile.email:
                query["$or"].extend([
                    {"contactInfo.email": user_profile.email},
                    {"email": user_profile.email},
                ])

            apps_cursor = db.applications.find(query).sort("created_at", -1)
            
            applications = []
            async for app in apps_cursor:
                try:
                    app["_id"] = str(app["_id"])
                    
                    # Add default full_name if missing
                    if "full_name" not in app or app.get("full_name") is None:
                        app["full_name"] = app.get("name") or app.get("username") or "Applicant"
                    
                    applications.append(ApplicationData(**app))
                except Exception as parse_error:
                    print(f"Skipping invalid application {app.get('_id')}: {parse_error}")
                    continue
            
            return applications
        except Exception as e:
            print(f"Error getting applications: {e}")
            return []
    
    # ==================== COMPREHENSIVE CONTEXT ====================
    async def get_comprehensive_user_context(self, user_id: str) -> UserComprehensiveContext:
        """Get complete user context, keeping partial data if one source fails."""
        user_profile, tasks, projects, project_plans, pull_requests, ai_feedback, notifications, applications = await asyncio.gather(
            self.get_user_profile(user_id),
            self.get_user_tasks(user_id),
            self.get_user_projects(user_id),
            self.get_project_plans(user_id),
            self.get_user_pull_requests(user_id),
            self.get_user_ai_feedback(user_id),
            self.get_user_notifications(user_id),
            self.get_user_applications(user_id),
            return_exceptions=True,
        )

        defaults = {
            "user_profile": None,
            "tasks": [],
            "projects": [],
            "project_plans": [],
            "pull_requests": [],
            "ai_feedback": [],
            "notifications": [],
            "applications": [],
        }
        values = {
            "user_profile": user_profile,
            "tasks": tasks,
            "projects": projects,
            "project_plans": project_plans,
            "pull_requests": pull_requests,
            "ai_feedback": ai_feedback,
            "notifications": notifications,
            "applications": applications,
        }
        for key, default in defaults.items():
            if isinstance(values[key], Exception):
                logger.warning("Context source %s failed: %s", key, values[key])
                values[key] = default

        tasks = values["tasks"]
        projects = values["projects"]
        ai_feedback = values["ai_feedback"]
        notifications = values["notifications"]
        applications = values["applications"]
        user_profile = values["user_profile"]

        total_tasks = len(tasks)
        completed_tasks = len([t for t in tasks if t.status == "completed"])
        active_projects = len([p for p in projects if p.status != "completed"])
        total_feedback = len(ai_feedback)

        quality_scores = [f.assessment.overall for f in ai_feedback if f.assessment]
        avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else None

        skills_set = set()
        if user_profile and user_profile.skills:
            skills_set.update(user_profile.skills)
        for project in projects:
            skills_set.update(project.tags)

        achievements = [
            n.message for n in notifications
            if n.category == "achievements" or n.type == "achievement"
        ][:5]

        return UserComprehensiveContext(
                user_profile=user_profile,
                tasks=tasks,
                projects=projects,
                project_plans=project_plans,
                pull_requests=pull_requests,
                ai_feedback=ai_feedback,
                notifications=notifications,
                applications=applications,
                total_tasks=total_tasks,
                completed_tasks=completed_tasks,
                active_projects=active_projects,
                total_feedback_received=total_feedback,
                average_code_quality=avg_quality,
                skills_from_projects=list(skills_set),
                recent_achievements=achievements,
            )
    
    # ==================== ANALYTICS ====================
    async def get_user_progress_summary(self, user_id: str) -> Dict[str, Any]:
        """Get user progress summary across all areas"""
        try:
            context = await self.get_comprehensive_user_context(user_id)
            
            # Task completion rate
            task_completion_rate = (
                (context.completed_tasks / context.total_tasks * 100) 
                if context.total_tasks > 0 else 0
            )
            
            # Project progress
            project_progress = []
            for project in context.projects:
                project_progress.append({
                    "title": project.title,
                    "progress": project.progress,
                    "status": project.status
                })

            in_progress_tasks = len([
                t for t in context.tasks
                if str(t.status).lower() in ["in-progress", "in_progress", "active"]
            ])
            pending_tasks = max(context.total_tasks - context.completed_tasks - in_progress_tasks, 0)
            
            # Code quality trend
            feedback_trend = []
            for feedback in context.ai_feedback[:10]:  # Last 10
                feedback_trend.append({
                    "date": feedback.analysisDate.isoformat() if feedback.analysisDate else None,
                    "quality": feedback.assessment.overall,
                    "task_id": feedback.task_id
                })
            
            # Skills usage
            skill_counts = {}
            for project in context.projects:
                for tag in project.tags:
                    skill_counts[tag] = skill_counts.get(tag, 0) + 1
            
            return {
                "user_id": user_id,
                "task_completion_rate": round(task_completion_rate, 2),
                "total_tasks": context.total_tasks,
                "completed_tasks": context.completed_tasks,
                "in_progress_tasks": in_progress_tasks,
                "pending_tasks": pending_tasks,
                "active_projects": context.active_projects,
                "total_projects": len(context.projects),
                "average_code_quality": round(context.average_code_quality, 2) if context.average_code_quality else None,
                "total_feedback_received": context.total_feedback_received,
                "project_progress": project_progress,
                "code_quality_trend": feedback_trend,
                "top_skills": sorted(skill_counts.items(), key=lambda x: x[1], reverse=True)[:10],
                "recent_achievements": context.recent_achievements,
                "profile_completeness": context.user_profile.profileCompleteness if context.user_profile else 0
            }
        except Exception as e:
            print(f"Error getting progress summary: {e}")
            return {}


# Singleton instance
_comprehensive_data_service = None

def get_comprehensive_data_service() -> ComprehensiveDataService:
    """Get singleton instance of comprehensive data service"""
    global _comprehensive_data_service
    if _comprehensive_data_service is None:
        _comprehensive_data_service = ComprehensiveDataService()
    return _comprehensive_data_service
