from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

class TaskStatus(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    CANCELLED = "cancelled"

class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

# User-specific models
class UserProfile(BaseModel):
    user_id: str
    name: str
    email: str
    skills: List[str] = []
    preferences: Dict[str, Any] = {}
    current_workload: str = "medium"  # light, medium, heavy
    social_links: Dict[str, str] = {}

# Simple Task Models for user-specific tasks
class Task(BaseModel):
    id: Optional[str] = None
    user_id: str  # Always tied to a specific user
    title: str
    description: Optional[str] = None
    status: TaskStatus = TaskStatus.TODO
    priority: TaskPriority = TaskPriority.MEDIUM
    assignee: Optional[str] = None
    
    # Time tracking
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    
    # Dates
    due_date: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    
    # Simple tags for organization
    tags: List[str] = []
    
    # AI Analysis (populated by AI agent)
    ai_suggestions: List[str] = []
    ai_analysis: Optional[str] = None

# Request/Response Models for user interactions
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    priority: TaskPriority = TaskPriority.MEDIUM
    estimated_hours: Optional[float] = None
    due_date: Optional[datetime] = None
    tags: List[str] = []

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[TaskStatus] = None
    priority: Optional[TaskPriority] = None
    assignee: Optional[str] = None
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    due_date: Optional[datetime] = None
    tags: Optional[List[str]] = None

class UserTaskQuery(BaseModel):
    query: str
    context: Optional[str] = None

class UserTaskResponse(BaseModel):
    message: str
    tasks: Optional[List[Task]] = None
    suggestions: List[str] = []
    analysis: Optional[str] = None

class UserTaskStats(BaseModel):
    total_tasks: int
    completed_tasks: int
    in_progress_tasks: int
    overdue_tasks: int
    completion_rate: float
    average_task_duration: Optional[float] = None

class TaskComment(BaseModel):
    id: str
    content: str
    author: str
    created_at: datetime

class SubTask(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    title: str
    completed: bool = False
    description: Optional[str] = None

class TaskRecommendation(BaseModel):
    title: str
    description: str
    reasoning: str
    priority: TaskPriority
    estimated_hours: Optional[float] = None
    tags: List[str] = []

# --- Authentication Models ---

class UserRegister(BaseModel):
    email: str
    password: str
    full_name: str
    role: str = "student"

class UserLogin(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user_id: str

class TokenRefreshRequest(BaseModel):
    refresh_token: str

# --- Additional Task Enums (from upstream) ---

class TaskType(str, Enum):
    BUG = "bug"
    FEATURE = "feature"
    REFACTOR = "refactor"
    DOCUMENTATION = "documentation"
    CHORE = "chore"

class TaskComplexity(str, Enum):
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"
    VERY_COMPLEX = "very_complex"

class TaskAnalysisRequest(BaseModel):
    task_id: str
    user_id: str

class TaskAnalysisResponse(BaseModel):
    task_id: str
    complexity: TaskComplexity
    estimated_hours: float
    sub_tasks: List[SubTask] = []
    risks: List[str] = []
    recommendations: List[str] = []

class TaskBreakdownRequest(BaseModel):
    title: str
    description: str
    complexity: Optional[TaskComplexity] = None

class TaskBreakdownResponse(BaseModel):
    main_task: str
    sub_tasks: List[str] = []
    estimated_total_hours: float
    breakdown_reasoning: str

class TaskRecommendationRequest(BaseModel):
    user_id: str
    skills: List[str] = []
    workload: Optional[str] = None
    preferences: Dict[str, Any] = {}

class TaskRecommendationResponse(BaseModel):
    recommendations: List[TaskRecommendation] = []
    reasoning: str
    total_estimated_hours: float

class TaskProgressUpdate(BaseModel):
    task_id: str
    status: TaskStatus
    actual_hours: Optional[float] = None
    notes: Optional[str] = None

class TaskSearchRequest(BaseModel):
    query: str
    filters: Optional[Dict[str, Any]] = None

class TaskMetrics(BaseModel):
    total_tasks: int
    completed: int
    in_progress: int
    overdue: int
    by_priority: Dict[str, int]
    by_status: Dict[str, int]

class TaskSummaryResponse(BaseModel):
    message: str
    metrics: TaskMetrics
    recent_tasks: List[Task] = []
    next_actions: List[Task] = []
    description: Optional[str] = None
