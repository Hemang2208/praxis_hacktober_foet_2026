import json
import logging
import time
from typing import Dict, Any, Optional
from datetime import datetime, timezone, date

from fastapi import WebSocket

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Safe JSON serialisation — handles Pydantic models, datetime, ObjectId, etc.
# ---------------------------------------------------------------------------

def _safe_json_default(obj: Any) -> Any:
    """Fallback encoder for json.dumps — converts unserializable objects."""
    # Pydantic v1 and v2
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if hasattr(obj, "dict"):
        return obj.dict()
    # datetime / date
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    # bson ObjectId (optional dep)
    try:
        from bson import ObjectId
        if isinstance(obj, ObjectId):
            return str(obj)
    except ImportError:
        pass
    # bytes
    if isinstance(obj, bytes):
        return obj.decode("utf-8", errors="replace")
    # anything else — coerce to string rather than crash
    return str(obj)


def _safe_dumps(payload: Any, max_bytes: int = 10 * 1024 * 1024) -> str:
    """Serialise *payload* to a JSON string with a configurable byte cap.

    If the serialised string exceeds *max_bytes* the ``content`` field of the
    payload (which carries the AI answer) is preserved and every other field
    in ``content`` except ``answer`` is stripped before a second attempt.
    A final hard-truncation is applied as a last resort.
    """
    raw = json.dumps(payload, default=_safe_json_default, ensure_ascii=False)
    if len(raw.encode("utf-8")) <= max_bytes:
        return raw

    # Attempt 1: keep only the 'answer' inside content (drops context_used etc.)
    slimmed = dict(payload)
    if isinstance(slimmed.get("content"), dict):
        content = slimmed["content"]
        slimmed["content"] = {
            k: v for k, v in content.items() if k in ("answer", "message")
        }
    raw = json.dumps(slimmed, default=_safe_json_default, ensure_ascii=False)
    if len(raw.encode("utf-8")) <= max_bytes:
        logger.warning(
            "WebSocket payload slimmed to %d bytes (context_used dropped)", len(raw.encode("utf-8"))
        )
        return raw

    # Attempt 2: hard byte truncation — truncate the answer text itself
    logger.warning(
        "WebSocket payload still too large (%d bytes); hard-truncating answer",
        len(raw.encode("utf-8")),
    )
    answer_raw = ""
    if isinstance(slimmed.get("content"), dict):
        answer_raw = str(slimmed["content"].get("answer") or slimmed["content"].get("message") or "")
    elif isinstance(slimmed.get("content"), str):
        answer_raw = slimmed["content"]

    # Reserve space for wrapper JSON overhead (~200 chars)
    max_answer_chars = max(100, (max_bytes // 4) - 200)
    truncated_answer = answer_raw[:max_answer_chars]
    if len(answer_raw) > max_answer_chars:
        truncated_answer += "\n\n[Response truncated due to size limits.]"

    if isinstance(slimmed.get("content"), dict):
        slimmed["content"] = {"answer": truncated_answer, "_truncated": True}
    else:
        slimmed["content"] = truncated_answer

    return json.dumps(slimmed, default=_safe_json_default, ensure_ascii=False)

# ---------------------------------------------------------------------------
# Structured event log helpers
# ---------------------------------------------------------------------------

LOG_EVENTS = {
    "WS_CONNECTED": "WS_CONNECTED",
    "WS_RECONNECTED": "WS_RECONNECTED",
    "WS_DISCONNECTED": "WS_DISCONNECTED",
    "WS_MESSAGE_RECEIVED": "WS_MESSAGE_RECEIVED",
    "WS_MESSAGE_SENT": "WS_MESSAGE_SENT",
}

def _log_event(event: str, **kwargs):
    extra = " | ".join(f"{k}={v}" for k, v in kwargs.items() if v is not None)
    logger.info(f"[{event}] {extra}")

# ---------------------------------------------------------------------------
# Redis client — optional, gracefully falls back to in-memory-only mode
# ---------------------------------------------------------------------------
_redis_client = None

async def _get_redis():
    """Lazily initialise the shared async Redis client."""
    global _redis_client
    if _redis_client is not None:
        return _redis_client
    try:
        from config.settings import REDIS_URL
        if not REDIS_URL:
            return None
        import redis.asyncio as aioredis
        _redis_client = await aioredis.from_url(
            REDIS_URL,
            encoding="utf-8",
            decode_responses=True,
        )
        await _redis_client.ping()
        logger.info(f"Redis connected: {REDIS_URL}")
    except Exception as e:
        logger.warning(f"Redis unavailable — running without session persistence: {e}")
        _redis_client = None
    return _redis_client


# ---------------------------------------------------------------------------
# Session state helpers
# ---------------------------------------------------------------------------
SESSION_TTL = 3600


class ConnectionManager:
    """
    Manages active WebSocket connections (in-memory) and persists session
    runtime state to Redis so it survives restarts / horizontal scaling.

    Redis key schema:
        runtime:{session_id}  — session metadata JSON
        stream:{session_id}   — "1" flag while actively streaming
        ws:{session_id}       — connection heartbeat (TTL-only key)
    """

    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        # Track per-user connection count for duplicate detection
        self.user_connection_count: Dict[str, int] = {}

    # ------------------------------------------------------------------
    # Redis helpers
    # ------------------------------------------------------------------

    async def _set_session(self, session_id: str, data: dict):
        r = await _get_redis()
        if r:
            try:
                await r.setex(
                    f"runtime:{session_id}",
                    SESSION_TTL,
                    json.dumps(data),
                )
                await r.setex(f"ws:{session_id}", SESSION_TTL, "1")
            except Exception as e:
                logger.warning(f"Redis write failed for {session_id}: {e}")

    async def _get_session(self, session_id: str) -> Optional[dict]:
        r = await _get_redis()
        if r:
            try:
                raw = await r.get(f"runtime:{session_id}")
                if raw:
                    return json.loads(raw)
            except Exception as e:
                logger.warning(f"Redis read failed for {session_id}: {e}")
        return None

    async def _delete_session(self, session_id: str):
        r = await _get_redis()
        if r:
            try:
                await r.delete(
                    f"runtime:{session_id}",
                    f"stream:{session_id}",
                    f"ws:{session_id}",
                )
            except Exception as e:
                logger.warning(f"Redis delete failed for {session_id}: {e}")

    async def _set_streaming(self, session_id: str, streaming: bool):
        r = await _get_redis()
        if r:
            try:
                key = f"stream:{session_id}"
                if streaming:
                    await r.setex(key, SESSION_TTL, "1")
                else:
                    await r.delete(key)
            except Exception as e:
                logger.warning(f"Redis stream flag failed for {session_id}: {e}")

        session = await self._get_session(session_id)
        if session:
            session["streaming"] = streaming
            await self._set_session(session_id, session)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def connect(self, websocket: WebSocket, session_id: str, user_id: str = None):
        """Accept the WebSocket and initialise Redis session state."""

        # Check for existing active connection for this session
        if session_id in self.active_connections:
            prev_ws = self.active_connections[session_id]
            try:
                await prev_ws.close(code=1000, reason="Replaced by new connection")
            except Exception:
                pass
            del self.active_connections[session_id]

        await websocket.accept()
        self.active_connections[session_id] = websocket
        websocket._user_id = user_id

        now_utc = datetime.now(timezone.utc)
        session_data = {
            "session_id": session_id,
            "user_id": user_id or "",
            "active_project": "",
            "current_task": "",
            "streaming": False,
            "connected_at": now_utc.isoformat(),
            "last_activity": now_utc.isoformat(),
        }
        await self._set_session(session_id, session_data)

        # Track per-user connection count
        if user_id:
            self.user_connection_count[user_id] = self.user_connection_count.get(user_id, 0) + 1

        prev_session = await self._get_session(session_id)
        is_reconnect = prev_session is not None and prev_session.get("connected_at") != now_utc.isoformat()

        event = LOG_EVENTS["WS_RECONNECTED"] if is_reconnect else LOG_EVENTS["WS_CONNECTED"]
        _log_event(
            event,
            session_id=session_id,
            user_id=user_id or "anonymous",
            connection_count=str(self.user_connection_count.get(user_id or "", 0)),
            connected_at=now_utc.isoformat(),
        )

    def disconnect(self, session_id: str):
        """Remove the in-process socket reference."""
        ws = self.active_connections.pop(session_id, None)
        user_id = None
        if ws:
            user_id = getattr(ws, "_user_id", None)

        if user_id:
            current = self.user_connection_count.get(user_id, 0)
            if current > 0:
                self.user_connection_count[user_id] = current - 1

        _log_event(
            LOG_EVENTS["WS_DISCONNECTED"],
            session_id=session_id,
            user_id=str(user_id) if user_id else "unknown",
            active_connections=str(len(self.active_connections)),
        )

    async def disconnect_async(self, session_id: str):
        """Full disconnect: removes socket reference AND clears Redis state."""
        ws = self.active_connections.pop(session_id, None)
        user_id = None
        if ws:
            user_id = getattr(ws, "_user_id", None)

        if user_id:
            current = self.user_connection_count.get(user_id, 0)
            if current > 0:
                self.user_connection_count[user_id] = current - 1

        await self._delete_session(session_id)

        _log_event(
            LOG_EVENTS["WS_DISCONNECTED"],
            session_id=session_id,
            user_id=str(user_id) if user_id else "unknown",
            active_connections=str(len(self.active_connections)),
        )

    async def get_session_state(self, session_id: str) -> Optional[dict]:
        """Return the current runtime state for a session (from Redis)."""
        return await self._get_session(session_id)

    async def update_session(self, session_id: str, **kwargs):
        """Patch arbitrary fields on the session state blob."""
        session = await self._get_session(session_id) or {}
        session.update(kwargs)
        session["last_activity"] = datetime.now(timezone.utc).isoformat()
        await self._set_session(session_id, session)

    async def send_event(self, session_id: str, event_type: str, content: Any = None):
        """
        Send a typed event to a specific session.

        Supported event types:
            token, typing_start, typing_stop, message_complete,
            agent_status, runtime_update, error
        """
        if event_type == "typing_start":
            await self._set_streaming(session_id, True)
        elif event_type in ("typing_stop", "message_complete", "error"):
            await self._set_streaming(session_id, False)

        if session_id in self.active_connections:
            payload: dict = {"type": event_type}
            if content is not None:
                payload["content"] = content
            try:
                # Use _safe_dumps to handle Pydantic objects, datetime, ObjectId
                # and to enforce a per-message byte cap (prevents "Invalid Query
                # Payload" errors caused by oversized or non-serialisable frames).
                raw = _safe_dumps(payload)
                await self.active_connections[session_id].send_text(raw)
                if event_type in ("token", "message_complete", "error"):
                    _log_event(
                        LOG_EVENTS["WS_MESSAGE_SENT"],
                        session_id=session_id,
                        event_type=event_type,
                    )
                # Update last activity timestamp
                session = await self._get_session(session_id) or {}
                session["last_activity"] = datetime.now(timezone.utc).isoformat()
                await self._set_session(session_id, session)
            except Exception as e:
                logger.error(f"Error sending {event_type} to {session_id}: {e}")
                await self.disconnect_async(session_id)


manager = ConnectionManager()
