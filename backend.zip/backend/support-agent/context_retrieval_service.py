"""Query-aware retrieval and prompt formatting for the PRAXIS support agent."""
from __future__ import annotations

import json
import logging
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from bson import ObjectId

from comprehensive_data_service import ComprehensiveDataService
from comprehensive_models import (
    AIFeedbackData,
    NotificationItem,
    ProjectData,
    ProjectPlan,
    TaskData,
    UserComprehensiveContext,
    UserProfile,
    pull_requestData,
)

logger = logging.getLogger(__name__)

_ID_RE = re.compile(r"\b[a-fA-F0-9]{24}\b")
_WORD_RE = re.compile(r"[a-z0-9]+")

_STOPWORDS = {
    "a", "an", "and", "are", "about", "all", "am", "an", "any", "as", "at",
    "be", "been", "being", "but", "by", "can", "could", "did", "do", "does",
    "doing", "for", "from", "get", "give", "got", "had", "has", "have", "he",
    "her", "here", "him", "his", "how", "i", "if", "in", "into", "is", "it",
    "its", "just", "me", "mine", "more", "most", "my", "of", "on", "or", "our",
    "please", "show", "so", "some", "tell", "than", "that", "the", "their",
    "them", "then", "there", "these", "they", "this", "those", "to", "up", "us",
    "was", "we", "were", "what", "when", "where", "which", "who", "why", "will",
    "with", "would", "you", "your", "praxis", "project", "projects", "task",
    "tasks", "work", "working", "status", "current", "currently", "recent",
    "recently", "much", "many", "list", "overview", "summary", "detail",
    "details", "everything", "entire", "workspace", "account", "profile",
}

_BROAD_TERMS = {
    "all", "everything", "entire", "overview", "summary", "list", "workspace",
    "account", "progress", "status", "pending", "todo", "backlog", "open",
    "completed", "overdue", "blocked", "priority", "deadline", "weekly",
    "daily", "recommend", "recommendation", "next", "best", "focus",
}

_FOLLOWUP_MARKERS = {
    "it", "its", "that", "this", "those", "these", "them", "they", "there",
    "same", "above", "former", "latter", "again", "also",
}

_PRONOUN_RE = re.compile(
    r"\b(it|its|that|this|those|these|them|they|there|same|above|former|latter)\b",
    re.IGNORECASE,
)

_STATUS_TERMS = {
    "todo": {"todo", "backlog", "pending", "queued"},
    "in-progress": {"in-progress", "inprogress", "progress", "active", "doing"},
    "completed": {"completed", "complete", "done", "finished", "closed"},
    "blocked": {"blocked", "stuck", "waiting"},
}

_ASSIGNMENT_CONTEXT_RE = re.compile(
    r"\b(tasks?|work|working|assigned|assignee|assignment)\b", re.IGNORECASE
)
_ASSIGNMENT_SELF_RE = re.compile(
    r"\b("
    r"my\s+tasks?|tasks?\s+(?:for|of)\s+me|"
    r"assigned\s+to\s+me|assign(?:ed)?\s+me|my\s+assigned|"
    r"what\s+tasks?\s+do\s+i\s+have|what\s+do\s+i\s+have|"
    r"on\s+my\s+plate|my\s+workload|what\s+am\s+i\s+working\s+on|"
    r"what\s+am\s+i\s+assigned|what\s+am\s+i\s+doing"
    r")\b",
    re.IGNORECASE,
)
_ASSIGNMENT_TARGET_RE = re.compile(
    r"(\b(?:assigned|assignee|assignment)\b|\bworking\s+on\b|"
    r"\bresponsible\s+for\b|'s\s+(?:tasks?|work)\b|"
    r"\btasks?\s+(?:for|of)\b)",
    re.IGNORECASE,
)
_EXPLICIT_ASSIGNMENT_RE = re.compile(
    r"\b(?:assigned\s+to|assignee|assignments?\s+(?:for|of))\b",
    re.IGNORECASE,
)
_ASSIGNED_TO_RE = re.compile(
    r"\b(?:assigned\s+to|tasks?\s+(?:for|of)|working\s+on|responsible\s+for)\s+"
    r"([a-z0-9@._-]+)",
    re.IGNORECASE,
)
_SELF_RE = re.compile(r"\b(i|me|my|mine|myself)\b", re.IGNORECASE)
_NAME_STOPWORDS = {
    "admin", "company", "developer", "dev", "manager", "member", "mentor",
    "student", "team", "test", "unknown", "user",
}


def _env_int(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, str(default))))
    except ValueError:
        return default


def _normalize_text(value: Any) -> str:
    return " ".join(_WORD_RE.findall(str(value or "").lower()))


def _tokens(value: Any) -> Set[str]:
    return {
        token
        for token in _WORD_RE.findall(str(value or "").lower())
        if len(token) > 1 and token not in _STOPWORDS
    }


def _safe_str(value: Any) -> str:
    return "" if value is None else str(value)


def _cap(value: Any, limit: int) -> str:
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 1)].rstrip() + "…"


def _fmt_datetime(value: Any) -> str:
    if value is None:
        return "not set"
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M UTC")
    return str(value)[:16]


def _dedupe(values: Iterable[Any]) -> List[Any]:
    result = []
    seen = set()
    for value in values:
        key = (type(value).__name__, str(value))
        if key not in seen:
            seen.add(key)
            result.append(value)
    return result


class ContextRetrievalService:
    """Retrieve fresh Mongo data, select query-relevant records, and cache entities."""

    SESSION_ENTITY_TTL = _env_int("PRAXIS_CONTEXT_SESSION_TTL", 3600)
    MAX_CONTEXT_CHARS = _env_int("PRAXIS_CONTEXT_MAX_CHARS", 20000)
    MAX_PROJECTS = _env_int("PRAXIS_CONTEXT_MAX_PROJECTS", 20)
    MAX_TASKS = _env_int("PRAXIS_CONTEXT_MAX_TASKS", 100)
    MAX_PLANS = _env_int("PRAXIS_CONTEXT_MAX_PLANS", 10)
    MAX_PULL_REQUESTS = _env_int("PRAXIS_CONTEXT_MAX_PRS", 20)
    MAX_FEEDBACK = _env_int("PRAXIS_CONTEXT_MAX_FEEDBACK", 10)
    MAX_NOTIFICATIONS = _env_int("PRAXIS_CONTEXT_MAX_NOTIFICATIONS", 10)

    def __init__(self, data_service: Optional[ComprehensiveDataService] = None):
        self.data_service = data_service or ComprehensiveDataService()

    async def retrieve(
        self,
        user_id: str,
        query: str,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Return a ranked, prompt-ready snapshot of live user context."""
        context = await self.data_service.get_comprehensive_user_context(user_id)
        previous_entities = await self._load_session_entities(session_id)

        query_text = str(query or "").strip()
        query_norm = _normalize_text(query_text)
        query_tokens = _tokens(query_text)
        explicit_ids = set(_ID_RE.findall(query_text))
        followup = bool(_PRONOUN_RE.search(query_text)) and not explicit_ids

        lower_query = query_text.lower()
        base_assignment_intent = bool(
            _ASSIGNMENT_SELF_RE.search(query_text)
            or _EXPLICIT_ASSIGNMENT_RE.search(query_text)
        )
        target_user = None
        if _ASSIGNMENT_CONTEXT_RE.search(query_text) or base_assignment_intent:
            target_user = await self._resolve_target_user(
                context,
                user_id,
                query_text,
                explicit_ids,
                allow_self_fallback=base_assignment_intent,
            )
        assignment_intent = base_assignment_intent or bool(
            target_user and _ASSIGNMENT_TARGET_RE.search(query_text)
        )
        if not assignment_intent and target_user:
            assignment_intent = bool(
                _ASSIGNMENT_CONTEXT_RE.search(query_text)
                and re.search(r"\b(?:assigned|assignee|working on|responsible for)\b", lower_query)
            )
        assignment_unresolved = base_assignment_intent and target_user is None

        projects = list(context.projects)
        # context.tasks contains tasks assigned to/accessible by the authenticated
        # user (per get_user_tasks strict-assignment filtering).
        tasks = list(context.tasks)
        if assignment_intent:
            if target_user and target_user.get("id"):
                target_id = str(target_user["id"])
                assignment_lookup = getattr(
                    self.data_service, "get_tasks_for_assignee", None
                )
                if callable(assignment_lookup):
                    tasks = await assignment_lookup(
                        user_id, target_id, limit=self.MAX_TASKS
                    )
                else:
                    tasks = [
                        task
                        for task in context.tasks
                        if str(task.assigned_to or task.student_id or "") == target_id
                    ][: self.MAX_TASKS]
            else:
                tasks = []

        project_scores = {
            str(project.id): self._score_project(project, query_norm, query_tokens, explicit_ids)
            for project in projects
            if project.id
        }
        task_scores = {
            str(task.id): self._score_task(task, query_norm, query_tokens, explicit_ids, query_text)
            for task in tasks
            if task.id
        }
        has_named_entity = bool(explicit_ids) or any(
            score >= 100 for score in [*project_scores.values(), *task_scores.values()]
        )
        broad = (
            self._is_broad_query(query_text, query_tokens)
            and not has_named_entity
            and not assignment_intent
        )
        project_by_id = {str(project.id): project for project in projects if project.id}
        task_by_id = {str(task.id): task for task in tasks if task.id}

        selected_project_ids = {
            project_id for project_id, score in project_scores.items() if score >= 35
        }
        selected_task_ids = {
            task_id for task_id, score in task_scores.items() if score >= 35
        }

        if assignment_intent:
            selected_task_ids = set(task_scores.keys())
            selected_project_ids = set()

        # A named project is an explicit scope: do not pull in scored tasks from
        # unrelated projects merely because they share a generic word.
        if selected_project_ids:
            selected_task_ids = {
                task_id
                for task_id in selected_task_ids
                if task_id in task_by_id
                and str(task_by_id[task_id].project_id) in selected_project_ids
            }

        previous_project_ids = {
            str(value) for value in previous_entities.get("project_ids", []) if value
        }
        previous_task_ids = {
            str(value) for value in previous_entities.get("task_ids", []) if value
        }

        if followup:
            selected_project_ids.update(previous_project_ids)
            selected_task_ids.update(previous_task_ids)
            if previous_project_ids or previous_task_ids:
                broad = False

        if broad:
            selected_project_ids.update(project_scores.keys())
            selected_task_ids.update(task_scores.keys())
        elif not selected_project_ids and not selected_task_ids:
            top_projects = sorted(
                project_scores.items(), key=lambda item: item[1], reverse=True
            )
            top_tasks = sorted(task_scores.items(), key=lambda item: item[1], reverse=True)
            selected_project_ids.update(
                project_id for project_id, score in top_projects[:3] if score > 0
            )
            selected_task_ids.update(
                task_id for task_id, score in top_tasks[:8] if score > 0
            )

        for task_id in list(selected_task_ids):
            task = task_by_id.get(task_id)
            if task and task.project_id:
                selected_project_ids.add(str(task.project_id))

        selected_project_names = {
            _normalize_text(project_by_id[project_id].title)
            for project_id in selected_project_ids
            if project_id in project_by_id
        }
        if selected_project_ids:
            project_names = [
                project.title for project in projects
                if str(project.id) in selected_project_ids
            ]
            for task in tasks:
                if str(task.project_id) in selected_project_ids:
                    selected_task_ids.add(str(task.id))
                elif any(
                    name and name in _normalize_text(task.title)
                    for name in selected_project_names
                ):
                    selected_task_ids.add(str(task.id))
            logger.debug("Selected project context: %s", project_names)

            # If a specific project is selected but no tasks matched (because the
            # user has no *assigned* tasks there), fetch all project-level tasks
            # so project-scoped queries ("what tasks are in Project X?") still
            # return useful context without violating assignment-only filtering.
            if not selected_task_ids and not assignment_intent:
                project_task_lookup = getattr(
                    self.data_service, "get_project_tasks", None
                )
                if callable(project_task_lookup):
                    extra_tasks = await project_task_lookup(
                        user_id,
                        list(selected_project_ids),
                        limit=self.MAX_TASKS,
                    )
                    if extra_tasks:
                        for t in extra_tasks:
                            if t.id:
                                task_by_id[str(t.id)] = t
                                task_scores[str(t.id)] = 50.0  # default relevance
                                selected_task_ids.add(str(t.id))
                        tasks = list(task_by_id.values())

        if broad and not selected_project_ids:
            selected_project_ids.update(str(p.id) for p in projects if p.id)
        if broad and not selected_task_ids:
            selected_task_ids.update(str(t.id) for t in tasks if t.id)

        selected_projects = self._rank_projects(
            projects, project_scores, selected_project_ids, broad
        )[: self.MAX_PROJECTS]
        selected_tasks = self._rank_tasks(
            tasks, task_scores, selected_task_ids, broad, query_text
        )[: self.MAX_TASKS]

        final_project_ids = {str(p.id) for p in selected_projects if p.id}
        final_task_ids = {str(t.id) for t in selected_tasks if t.id}

        plans = self._select_plans(
            context.project_plans, final_project_ids, broad
        )[: self.MAX_PLANS]
        pull_requests = self._select_pull_requests(
            context.pull_requests, final_task_ids, broad
        )[: self.MAX_PULL_REQUESTS]
        feedback = self._select_feedback(
            context.ai_feedback, final_task_ids, broad
        )[: self.MAX_FEEDBACK]
        notifications = self._select_notifications(
            context.notifications, final_project_ids, final_task_ids, broad
        )[: self.MAX_NOTIFICATIONS]

        stats = self._build_stats(context, selected_projects, selected_tasks)
        retrieved_at = datetime.now(timezone.utc).isoformat()

        result: Dict[str, Any] = {
            "user_id": str(user_id),
            "query": query_text,
            "retrieved_at": retrieved_at,
            "profile": context.user_profile,
            "projects": selected_projects,
            "tasks": selected_tasks,
            "plans": plans,
            "pull_requests": pull_requests,
            "feedback": feedback,
            "notifications": notifications,
            "stats": stats,
            "is_broad": broad,
            "assignment_filter": (
                {
                    "user_id": str(target_user.get("id")) if target_user else None,
                    "name": (target_user or {}).get("name") or "",
                    "email": (target_user or {}).get("email") or "",
                    "resolved": bool(target_user) and not assignment_unresolved,
                }
                if assignment_intent
                else None
            ),
            "matched_project_ids": sorted(final_project_ids),
            "matched_task_ids": sorted(final_task_ids),
            "sources": {
                "mongo": True,
                "redis_session": bool(previous_entities),
            },
        }

        await self._save_session_entities(
            session_id,
            {
                "project_ids": sorted(final_project_ids) or sorted(previous_project_ids),
                "task_ids": sorted(final_task_ids) or sorted(previous_task_ids),
                "last_query": query_text,
            },
        )
        logger.info(
            "PRAXIS context retrieved user=%s projects=%s tasks=%s broad=%s "
            "assignee=%s session=%s",
            user_id,
            len(selected_projects),
            len(selected_tasks),
            broad,
            (target_user or {}).get("id") or "-",
            session_id or "-",
        )
        return result

    async def _resolve_target_user(
        self,
        context: UserComprehensiveContext,
        viewer_user_id: str,
        query_text: str,
        explicit_ids: Set[str],
        allow_self_fallback: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Resolve a user mentioned in a task-assignment query.

        The directory is intentionally limited to users who share an accessible
        project with the viewer. This prevents a query from widening access to
        unrelated users or their tasks.
        """
        query_lower = query_text.lower()
        query_norm = _normalize_text(query_text)
        query_tokens = _tokens(query_text)
        candidates: Dict[str, Dict[str, Any]] = {}

        def add_candidate(
            user_id: Any,
            name: Any = "",
            email: Any = "",
        ) -> None:
            candidate_id = _safe_str(user_id)
            if not candidate_id:
                return
            entry = candidates.setdefault(
                candidate_id,
                {"id": candidate_id, "name": "", "email": ""},
            )
            if name and (not entry["name"] or entry["name"] == "Member"):
                entry["name"] = _safe_str(name)
            if email and not entry["email"]:
                entry["email"] = _safe_str(email)

        profile = context.user_profile
        if profile:
            add_candidate(profile.id or viewer_user_id, profile.full_name, profile.email)
        else:
            add_candidate(viewer_user_id)

        for project in context.projects:
            add_candidate(project.user)
            add_candidate(project.created_by)
            for member in [*project.team_members, *project.team]:
                add_candidate(member.user, member.name, member.email)
            for resource in project.resources:
                add_candidate(resource.user, resource.name)

        directory_lookup = getattr(
            self.data_service, "get_project_member_directory", None
        )
        if callable(directory_lookup):
            directory = await directory_lookup(
                viewer_user_id, projects=context.projects
            )
            for member in directory:
                add_candidate(member.get("id"), member.get("name"), member.get("email"))

        ranked: List[Tuple[float, Dict[str, Any]]] = []
        for candidate in candidates.values():
            score = 0.0
            candidate_id = str(candidate["id"])
            name = _safe_str(candidate.get("name"))
            email = _safe_str(candidate.get("email"))
            name_norm = _normalize_text(name)
            name_tokens = {
                token
                for token in _WORD_RE.findall(name.lower())
                if len(token) > 2 and token not in _STOPWORDS and token not in _NAME_STOPWORDS
            }

            if candidate_id in explicit_ids:
                score += 1000
            if email and email.lower() in query_lower:
                score += 500
            if name_norm and len(name_norm) >= 3 and name_norm in query_norm:
                score += 240
            overlap = name_tokens & query_tokens
            if overlap:
                score += len(overlap) * 40
                if name_tokens and name_tokens.issubset(query_tokens):
                    score += 40
                if len(name_norm) >= 4 and name_norm in query_norm:
                    score += 20

            if score > 0:
                ranked.append((score, candidate))

        ranked.sort(key=lambda item: item[0], reverse=True)
        if ranked:
            top_score = ranked[0][0]
            top_candidates = [candidate for score, candidate in ranked if score == top_score]
            if len(top_candidates) == 1:
                return top_candidates[0]
            viewer_match = next(
                (
                    candidate
                    for candidate in top_candidates
                    if str(candidate.get("id")) == str(viewer_user_id)
                ),
                None,
            )
            if viewer_match and allow_self_fallback:
                return viewer_match
            logger.info(
                "Ambiguous assignee mention for query %r: %s",
                _cap(query_text, 160),
                [candidate.get("name") or candidate.get("id") for candidate in top_candidates],
            )
            return None

        if _SELF_RE.search(query_text) and allow_self_fallback:
            return candidates.get(_safe_str(viewer_user_id)) or {
                "id": _safe_str(viewer_user_id),
                "name": _safe_str(profile.full_name) if profile else "",
                "email": _safe_str(profile.email) if profile else "",
            }

        assigned_target = _ASSIGNED_TO_RE.search(query_text)
        if assigned_target:
            mentioned = assigned_target.group(1).lower()
            if mentioned in {"me", "my", "myself", "i"} and allow_self_fallback:
                return candidates.get(_safe_str(viewer_user_id))
            return None

        if allow_self_fallback and not explicit_ids:
            return candidates.get(_safe_str(viewer_user_id)) or {
                "id": _safe_str(viewer_user_id),
                "name": _safe_str(profile.full_name) if profile else "",
                "email": _safe_str(profile.email) if profile else "",
            }
        return None

    @staticmethod
    def _is_broad_query(query_text: str, query_tokens: Set[str]) -> bool:
        lowered = query_text.lower()
        if not query_tokens:
            return True
        if any(term in query_tokens for term in _BROAD_TERMS):
            return True
        broad_phrases = (
            "what do i have",
            "what's on my plate",
            "what is on my plate",
            "what should i do",
            "how am i doing",
            "give me an overview",
            "tell me about my work",
            "everything about",
        )
        return any(phrase in lowered for phrase in broad_phrases)

    def _score_project(
        self,
        project: ProjectData,
        query_norm: str,
        query_tokens: Set[str],
        explicit_ids: Set[str],
    ) -> float:
        project_id = str(project.id or "")
        if project_id and project_id in explicit_ids:
            return 1000.0

        title_norm = _normalize_text(project.title)
        title_tokens = _tokens(project.title)
        description_tokens = _tokens(project.description)
        tag_tokens = set()
        for tag in [*project.tags, *project.ai_generated_tags]:
            tag_tokens.update(_tokens(tag))

        score = 0.0
        if title_norm and title_norm in query_norm:
            score += 240
        elif query_norm and len(query_norm) >= 4 and query_norm in title_norm:
            score += 160

        overlap = title_tokens & query_tokens
        score += len(overlap) * 30
        if title_tokens and title_tokens.issubset(query_tokens):
            score += 150

        tag_overlap = tag_tokens & query_tokens
        score += len(tag_overlap) * 8
        score += len(description_tokens & query_tokens) * 2
        return score

    def _score_task(
        self,
        task: TaskData,
        query_norm: str,
        query_tokens: Set[str],
        explicit_ids: Set[str],
        query_text: str,
    ) -> float:
        task_id = str(task.id or "")
        if task_id and task_id in explicit_ids:
            return 1000.0

        title_norm = _normalize_text(task.title)
        title_tokens = _tokens(task.title)
        description_tokens = _tokens(task.description)
        tag_tokens = set()
        for tag in task.tags:
            tag_tokens.update(_tokens(tag))

        score = 0.0
        if title_norm and title_norm in query_norm:
            score += 220
        elif query_norm and len(query_norm) >= 4 and query_norm in title_norm:
            score += 140

        overlap = title_tokens & query_tokens
        score += len(overlap) * 34
        if title_tokens and title_tokens.issubset(query_tokens):
            score += 140

        score += len(tag_tokens & query_tokens) * 10
        score += len(description_tokens & query_tokens) * 2

        lowered = query_text.lower()
        status = str(task.status or "").lower()
        for normalized_status, terms in _STATUS_TERMS.items():
            if any(term in lowered for term in terms) and status == normalized_status:
                score += 65

        if "overdue" in lowered:
            if task.due_date and task.status != "completed" and task.due_date < datetime.now():
                score += 140
        if "high priority" in lowered and str(task.priority).lower() in {"high", "critical"}:
            score += 80
        if "critical" in lowered and str(task.priority).lower() == "critical":
            score += 100
        return score

    @staticmethod
    def _rank_projects(
        projects: Sequence[ProjectData],
        scores: Dict[str, float],
        selected_ids: Set[str],
        broad: bool,
    ) -> List[ProjectData]:
        selected = [project for project in projects if str(project.id) in selected_ids]
        if broad:
            return sorted(
                selected,
                key=lambda project: (
                    str(project.status).lower() == "completed",
                    -float(project.progress or 0),
                    -(scores.get(str(project.id), 0)),
                ),
            )
        return sorted(
            selected,
            key=lambda project: scores.get(str(project.id), 0),
            reverse=True,
        )

    @staticmethod
    def _rank_tasks(
        tasks: Sequence[TaskData],
        scores: Dict[str, float],
        selected_ids: Set[str],
        broad: bool,
        query_text: str,
    ) -> List[TaskData]:
        selected = [task for task in tasks if str(task.id) in selected_ids]
        status_order = {"blocked": 0, "in-progress": 1, "todo": 2, "completed": 3}

        def sort_key(task: TaskData) -> Tuple[Any, ...]:
            score = scores.get(str(task.id), 0)
            if broad or "overdue" in query_text.lower():
                return (
                    status_order.get(str(task.status).lower(), 4),
                    task.due_date is None,
                    task.due_date or datetime.max,
                    -score,
                    str(task.title).lower(),
                )
            effective_score = score if score >= 35 else 0
            return (-effective_score, status_order.get(str(task.status).lower(), 4), str(task.title).lower())

        return sorted(selected, key=sort_key)

    @staticmethod
    def _select_plans(
        plans: Sequence[ProjectPlan], project_ids: Set[str], broad: bool
    ) -> List[ProjectPlan]:
        if not broad:
            return [plan for plan in plans if str(plan.project_id) in project_ids]
        return list(plans)

    @staticmethod
    def _select_pull_requests(
        pull_requests: Sequence[pull_requestData],
        task_ids: Set[str],
        broad: bool,
    ) -> List[pull_requestData]:
        if task_ids:
            matched = [
                pr for pr in pull_requests
                if pr.task_id and str(pr.task_id) in task_ids
            ]
            if matched:
                return matched
            return [] if not broad else list(pull_requests)
        return list(pull_requests) if broad else list(pull_requests[:5])

    @staticmethod
    def _select_feedback(
        feedback: Sequence[AIFeedbackData], task_ids: Set[str], broad: bool
    ) -> List[AIFeedbackData]:
        if task_ids:
            matched = [
                item for item in feedback
                if item.task_id and str(item.task_id) in task_ids
            ]
            if matched:
                return matched
            return [] if not broad else list(feedback)
        return list(feedback) if broad else list(feedback[:5])

    @staticmethod
    def _select_notifications(
        notifications: Sequence[NotificationItem],
        project_ids: Set[str],
        task_ids: Set[str],
        broad: bool,
    ) -> List[NotificationItem]:
        if broad:
            return list(notifications)
        matched = []
        for notification in notifications:
            data = notification.data
            if not data:
                continue
            if (
                (data.project_id and str(data.project_id) in project_ids)
                or (data.task_id and str(data.task_id) in task_ids)
                or (data.feedbackId and str(data.feedbackId) in task_ids)
            ):
                matched.append(notification)
        return matched

    @staticmethod
    def _build_stats(
        context: UserComprehensiveContext,
        projects: Sequence[ProjectData],
        tasks: Sequence[TaskData],
    ) -> Dict[str, Any]:
        now = datetime.now()
        completed = len([task for task in tasks if task.status == "completed"])
        overdue = len(
            [
                task for task in tasks
                if task.status != "completed" and task.due_date and task.due_date < now
            ]
        )
        return {
            "total_accessible_tasks": context.total_tasks,
            "total_accessible_projects": len(context.projects),
            "total_accessible_plans": len(context.project_plans),
            "total_accessible_pull_requests": len(context.pull_requests),
            "total_accessible_feedback": len(context.ai_feedback),
            "total_accessible_notifications": len(context.notifications),
            "selected_tasks": len(tasks),
            "selected_projects": len(projects),
            "completed_tasks": completed,
            "in_progress_tasks": len([t for t in tasks if t.status == "in-progress"]),
            "todo_tasks": len([t for t in tasks if t.status == "todo"]),
            "blocked_tasks": len([t for t in tasks if t.status == "blocked"]),
            "overdue_tasks": overdue,
            "average_code_quality": context.average_code_quality,
        }

    async def _load_session_entities(self, session_id: Optional[str]) -> Dict[str, Any]:
        if not session_id:
            return {}
        try:
            redis = await self._get_redis()
            if not redis:
                return {}
            raw = await redis.get(self._session_key(session_id))
            if not raw:
                return {}
            data = json.loads(raw)
            return data if isinstance(data, dict) else {}
        except Exception as exc:
            logger.debug("Session entity load failed for %s: %s", session_id, exc)
            return {}

    async def _save_session_entities(
        self, session_id: Optional[str], entities: Dict[str, Any]
    ) -> None:
        if not session_id:
            return
        try:
            redis = await self._get_redis()
            if not redis:
                return
            entities["updated_at"] = datetime.now(timezone.utc).isoformat()
            await redis.setex(
                self._session_key(session_id),
                self.SESSION_ENTITY_TTL,
                json.dumps(entities),
            )
        except Exception as exc:
            logger.debug("Session entity save failed for %s: %s", session_id, exc)

    @staticmethod
    def _session_key(session_id: str) -> str:
        return f"support:entities:{session_id}"

    @staticmethod
    async def _get_redis():
        try:
            from websocket_manager import _get_redis

            return await _get_redis()
        except Exception:
            return None

    def format_context_for_prompt(
        self, retrieved: Dict[str, Any], max_chars: Optional[int] = None
    ) -> str:
        """Format the retrieved snapshot into a bounded, explicit prompt block."""
        budget = max_chars or self.MAX_CONTEXT_CHARS
        parts: List[str] = []
        stats = retrieved.get("stats", {})
        profile: Optional[UserProfile] = retrieved.get("profile")
        projects: List[ProjectData] = retrieved.get("projects", [])
        tasks: List[TaskData] = retrieved.get("tasks", [])
        plans: List[ProjectPlan] = retrieved.get("plans", [])
        pull_requests: List[pull_requestData] = retrieved.get("pull_requests", [])
        feedback: List[AIFeedbackData] = retrieved.get("feedback", [])
        notifications: List[NotificationItem] = retrieved.get("notifications", [])

        parts.append(
            "RETRIEVED CONTEXT — LIVE DATA FROM MONGODB\n"
            f"Generated: {retrieved.get('retrieved_at', '')}\n"
            f"Query: {_cap(retrieved.get('query', ''), 300)}\n"
            "This block supersedes older context summaries. Use only records listed here."
        )

        if profile:
            parts.append(
                "AUTHENTICATED USER\n"
                f"- user_id: {_safe_str(profile.id or retrieved.get('user_id'))}\n"
                f"- name: {_safe_str(profile.full_name)}\n"
                f"- role: {_safe_str(profile.role)}\n"
                f"- email: {_safe_str(profile.email)}\n"
                f"- headline: {_cap(profile.headline, 160) or 'not set'}\n"
                f"- bio: {_cap(profile.bio, 240) or 'not set'}\n"
                f"- skills: {_cap(', '.join(profile.skills[:20]), 300) or 'none listed'}"
            )
        else:
            parts.append(
                "AUTHENTICATED USER\n"
                f"- user_id: {retrieved.get('user_id', 'unknown')}\n"
                "- profile: not available in users collection"
            )

        parts.append(
            "ACCESS AND WORKSPACE SUMMARY\n"
            f"- Access scope: only the authenticated user's own tasks, their accessible projects, "
            f"project memberships, and related resources were retrieved.\n"
            f"- Accessible totals: {stats.get('total_accessible_tasks', 0)} tasks, "
            f"{stats.get('total_accessible_projects', 0)} projects, "
            f"{stats.get('total_accessible_plans', 0)} plans, "
            f"{stats.get('total_accessible_pull_requests', 0)} pull requests, "
            f"{stats.get('total_accessible_feedback', 0)} AI reviews, "
            f"{stats.get('total_accessible_notifications', 0)} notifications.\n"
            f"- Selected for this query: {stats.get('selected_tasks', 0)} tasks, "
            f"{stats.get('selected_projects', 0)} projects.\n"
            f"- Selected task states: {stats.get('completed_tasks', 0)} completed, "
            f"{stats.get('in_progress_tasks', 0)} in progress, "
            f"{stats.get('todo_tasks', 0)} todo, "
            f"{stats.get('blocked_tasks', 0)} blocked, "
            f"{stats.get('overdue_tasks', 0)} overdue."
        )

        assignment_filter = retrieved.get("assignment_filter")
        if assignment_filter:
            if assignment_filter.get("resolved") and assignment_filter.get("user_id"):
                parts.append(
                    "TASK ASSIGNMENT FILTER\n"
                    f"- The task list below is filtered to assignments for "
                    f"{assignment_filter.get('name') or 'the requested user'} "
                    f"(user_id: {assignment_filter.get('user_id')}).\n"
                    f"- It contains {stats.get('selected_tasks', 0)} task(s). When the user "
                    "asks to list or show tasks, enumerate every filtered task, including "
                    "completed tasks, unless the user explicitly asks for a status subset.\n"
                    "- Do not include or infer tasks assigned to other users. If no tasks "
                    "are listed, say that no accessible tasks are assigned to that user."
                )
            else:
                parts.append(
                    "TASK ASSIGNMENT FILTER\n"
                    "- The query asks for a specific user's assigned tasks, but that user "
                    "could not be resolved within the authenticated user's accessible "
                    "projects. No task-assignment records are provided. Do not substitute "
                    "all project tasks; ask for the user's name, email, or user ID."
                )

        if projects:
            lines = ["PROJECTS"]
            for index, project in enumerate(projects, 1):
                team_names = [
                    f"{member.name} ({member.role})" if member.role else member.name
                    for member in [*project.team_members, *project.team]
                    if member.name
                ]
                team_names = list(dict.fromkeys(team_names))[:8]
                project_tasks = [task for task in tasks if str(task.project_id) == str(project.id)]
                project_task_summary = (
                    f"{len(project_tasks)} selected tasks, "
                    f"{len([t for t in project_tasks if t.status == 'completed'])} completed"
                    if project_tasks else "no selected tasks"
                )
                resource_names = [
                    f"{res.profile or res.name or 'resource'}"
                    + (f": {', '.join(res.skills[:7])}" if res.skills else "")
                    for res in project.resources[:6]
                ]
                lines.append(
                    f"{index}. [{project.status}] {project.title} (project_id: {project.id})\n"
                    f"   progress: {float(project.progress or 0):.0f}% | deadline: {_fmt_datetime(project.deadline)}\n"
                    f"   description: {_cap(project.description, 260) or 'none'}\n"
                    f"   tags: {_cap(', '.join(project.tags[:15]), 220) or 'none'}\n"
                    f"   team: {_cap(', '.join(team_names), 260) or 'none listed'}\n"
                    f"   tasks: {project_task_summary}\n"
                    f"   resources: {_cap('; '.join(resource_names), 320) or 'none listed'}"
                )
                if project.sprints:
                    sprint_text = "; ".join(
                        f"{sprint.name} ({sprint.progress:.0f}%, {sprint.status})"
                        for sprint in project.sprints[:5]
                    )
                    lines.append(f"   sprints: {_cap(sprint_text, 260)}")
            parts.append("\n".join(lines))
        else:
            parts.append("PROJECTS\n- No accessible projects matched this query.")

        if tasks:
            lines = ["TASKS"]
            for index, task in enumerate(tasks, 1):
                project = next(
                    (p for p in projects if str(p.id) == str(task.project_id)), None
                )
                subtask_lines = []
                for subtask in task.sub_tasks[:12]:
                    marker = "x" if subtask.completed else " "
                    subtask_lines.append(
                        f"[{marker}] {_cap(subtask.title, 90)}"
                        + (f" — {_cap(subtask.description, 90)}" if subtask.description else "")
                    )
                comments = [
                    f"{_cap(comment.user_id, 30)}: {_cap(comment.message, 120)}"
                    for comment in task.comments[-3:]
                ]
                attachments = [attachment.name for attachment in task.attachments[:5]]
                lines.append(
                    f"{index}. [{task.status}] {task.title} (task_id: {task.id})\n"
                    f"   project: {project.title if project else 'unknown'} "
                    f"(project_id: {task.project_id or 'none'})\n"
                    f"   priority: {task.priority} | due: {_fmt_datetime(task.due_date)} | "
                    f"created: {_fmt_datetime(task.created_at)} | updated: {_fmt_datetime(task.updated_at)}\n"
                    f"   description: {_cap(task.description, 220) or 'none'}\n"
                    f"   tags: {_cap(', '.join(task.tags[:12]), 180) or 'none'}\n"
                    f"   assignee: {task.assigned_to or task.student_id or 'not listed'} | "
                    f"feedback: {task.feedback_status or ('available' if task.has_feedback else 'none')}\n"
                    f"   subtasks ({len(task.sub_tasks)}): "
                    f"{_cap(' | '.join(subtask_lines), 700) or 'none'}\n"
                    f"   dependencies: {_cap(', '.join(map(str, task.dependencies[:8])), 220) or 'none'}\n"
                    f"   comments: {_cap(' | '.join(comments), 400) or 'none'}\n"
                    f"   attachments: {_cap(', '.join(attachments), 200) or 'none'}"
                )
            parts.append("\n".join(lines))
        else:
            parts.append("TASKS\n- No accessible tasks matched this query.")

        if plans:
            lines = ["PROJECT PLANS / MILESTONES"]
            for plan in plans:
                project = next(
                    (p for p in projects if str(p.id) == str(plan.project_id)), None
                )
                milestones = [
                    f"{milestone.name} ({milestone.timeline})"
                    if milestone.timeline else _safe_str(milestone.name)
                    for milestone in plan.major_milestones[:10]
                ]
                high_level = [
                    _safe_str(item.task_name)
                    + (f" ({item.estimated_duration})" if item.estimated_duration else "")
                    for item in plan.high_level_tasks[:12]
                ]
                lines.append(
                    f"- {project.title if project else 'project'} (project_id: {plan.project_id})\n"
                    f"   summary: {_cap(plan.summary or plan.project_summary, 500) or 'none'}\n"
                    f"   tech_stack: {_cap(', '.join(plan.tech_stack[:20]), 260) or 'none'}\n"
                    f"   deliverables: {_cap(', '.join(plan.key_features_deliverables[:12]), 380) or 'none'}\n"
                    f"   milestones: {_cap(' | '.join(milestones), 600) or 'none'}\n"
                    f"   high_level_tasks: {_cap(' | '.join(high_level), 700) or 'none'}"
                )
            parts.append("\n".join(lines))

        if pull_requests:
            lines = ["PULL REQUESTS"]
            for pr in pull_requests:
                lines.append(
                    f"- task_id: {pr.task_id or 'none'} | status: {pr.status} | "
                    f"submitted: {_fmt_datetime(pr.submitted_at)} | url: {pr.pull_request.url}\n"
                    f"  title: {_cap(pr.pull_request.title, 180) or 'not provided'}"
                )
            parts.append("\n".join(lines))

        if feedback:
            lines = ["AI CODE REVIEWS"]
            for item in feedback:
                lines.append(
                    f"- task_id: {item.task_id or 'none'} | status: {item.status} | "
                    f"overall: {item.assessment.overall:.0f}/100 | issues: {item.totalIssues}\n"
                    f"  summary: {_cap(item.summary, 420) or 'none'}\n"
                    f"  strengths: {_cap(', '.join(item.strengths[:5]), 260) or 'none'}\n"
                    f"  improvements: {_cap(', '.join(item.improvements[:5]), 300) or 'none'}\n"
                    f"  recommendations: {_cap(', '.join(item.recommendations[:5]), 320) or 'none'}"
                )
            parts.append("\n".join(lines))

        if notifications:
            lines = ["NOTIFICATIONS"]
            for notification in notifications:
                lines.append(
                    f"- [{notification.category}/{notification.type}] {notification.title}: "
                    f"{_cap(notification.message, 240)} "
                    f"(read: {notification.isRead}, created: {_fmt_datetime(notification.created_at)})"
                )
            parts.append("\n".join(lines))

        full_prompt = "\n\n".join(parts)
        if len(full_prompt) > budget:
            marker = (
                "\n\n[Context truncated at configured character budget. "
                "Ask for a specific project or task to see its complete details.]"
            )
            available = max(0, budget - len(marker))
            full_prompt = full_prompt[:available].rsplit("\n", 1)[0] + marker
        return full_prompt
