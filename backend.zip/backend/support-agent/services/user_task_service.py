from typing import List, Optional, Dict, Any
from datetime import datetime
from bson import ObjectId
from database import get_database
from models import Task, TaskCreate, TaskUpdate, TaskStatus, TaskPriority, UserTaskStats

class UserTaskService:
    """User-specific task service - all operations are scoped to the authenticated user"""
    
    def __init__(self):
        self.db = None
    
    async def get_db(self):
        """Get database instance"""
        if self.db is None:
            self.db = get_database()
        return self.db
    
    async def create_task_for_user(self, user_id: str, task_data: TaskCreate) -> Task:
        """Create a new task for a specific user"""
        db = await self.get_db()
        if db is None:
            raise Exception("Database connection not available")
        
        # Convert TaskCreate to dict and add user-specific metadata
        task_dict = task_data.dict()
        task_dict["_id"] = ObjectId()
        task_dict["id"] = str(task_dict["_id"])
        task_dict["user_id"] = user_id
        task_dict["created_at"] = datetime.now()
        task_dict["updated_at"] = datetime.now()
        task_dict["status"] = TaskStatus.TODO
        task_dict["ai_suggestions"] = []
        task_dict["ai_analysis"] = None
        
        # Insert into database
        result = await db.user_tasks.insert_one(task_dict)
        
        # Retrieve and return the created task
        created_task = await db.user_tasks.find_one({"_id": result.inserted_id})
        if created_task is None:
            raise Exception("Failed to retrieve created task")
        return Task(**self._convert_mongo_doc(created_task))
    
    async def get_user_task(self, user_id: str, task_id: str) -> Optional[Task]:
        """Get a specific task for a user"""
        db = await self.get_db()
        if db is None:
            return None
        
        task_doc = await db.user_tasks.find_one({
            "_id": ObjectId(task_id),
            "user_id": user_id
        })
        if task_doc is None:
            return None
        
        return Task(**self._convert_mongo_doc(task_doc))
    
    async def get_user_tasks(
        self,
        user_id: str,
        status: Optional[List[TaskStatus]] = None,
        priority: Optional[List[TaskPriority]] = None,
        tags: Optional[List[str]] = None,
        limit: int = 50
    ) -> List[Task]:
        """Get all tasks for a specific user with optional filtering"""
        db = await self.get_db()
        if db is None:
            return []
        
        # Build filter query for user
        filter_query: Dict[str, Any] = {"user_id": user_id}
        
        if status:
            filter_query["status"] = {"$in": [s.value for s in status]}
        
        if priority:
            filter_query["priority"] = {"$in": [p.value for p in priority]}
        
        if tags:
            filter_query["tags"] = {"$in": tags}
        
        # Execute query
        cursor = db.user_tasks.find(filter_query).limit(limit).sort("created_at", -1)
        tasks = []
        
        async for task_doc in cursor:
            tasks.append(Task(**self._convert_mongo_doc(task_doc)))
        
        return tasks
    
    async def update_user_task(self, user_id: str, task_id: str, task_update: TaskUpdate) -> Optional[Task]:
        """Update a user's task"""
        db = await self.get_db()
        if db is None:
            return None
        
        # Prepare update data
        update_data = {k: v for k, v in task_update.dict().items() if v is not None}
        update_data["updated_at"] = datetime.now()
        
        # If marking as done, set completion time
        if update_data.get("status") == TaskStatus.DONE:
            update_data["completed_at"] = datetime.now()
        
        # Update in database (only for this user)
        result = await db.user_tasks.update_one(
            {"_id": ObjectId(task_id), "user_id": user_id},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            return None
        
        # Return updated task
        return await self.get_user_task(user_id, task_id)
    
    async def delete_user_task(self, user_id: str, task_id: str) -> bool:
        """Delete a user's task"""
        db = await self.get_db()
        if db is None:
            return False
        
        result = await db.user_tasks.delete_one({
            "_id": ObjectId(task_id),
            "user_id": user_id
        })
        return result.deleted_count > 0
    
    async def search_user_tasks(self, user_id: str, query: str, limit: int = 20) -> List[Task]:
        """Search user's tasks by text query"""
        db = await self.get_db()
        if db is None:
            return []
        
        # Build search filter for user
        search_filter: Dict[str, Any] = {
            "user_id": user_id,
            "$or": [
                {"title": {"$regex": query, "$options": "i"}},
                {"description": {"$regex": query, "$options": "i"}},
                {"tags": {"$regex": query, "$options": "i"}}
            ]
        }
        
        cursor = db.user_tasks.find(search_filter).limit(limit).sort("created_at", -1)
        tasks = []
        
        async for task_doc in cursor:
            tasks.append(Task(**self._convert_mongo_doc(task_doc)))
        
        return tasks
    
    async def get_user_overdue_tasks(self, user_id: str) -> List[Task]:
        """Get user's overdue tasks"""
        db = await self.get_db()
        if db is None:
            return []
        
        filter_query: Dict[str, Any] = {
            "user_id": user_id,
            "due_date": {"$lt": datetime.now()},
            "status": {"$ne": TaskStatus.DONE.value}
        }
        
        cursor = db.user_tasks.find(filter_query).sort("due_date", 1)
        tasks = []
        
        async for task_doc in cursor:
            tasks.append(Task(**self._convert_mongo_doc(task_doc)))
        
        return tasks
    
    async def get_user_task_stats(self, user_id: str) -> UserTaskStats:
        """Get task statistics for a user"""
        db = await self.get_db()
        if db is None:
            return UserTaskStats(
                total_tasks=0,
                completed_tasks=0,
                in_progress_tasks=0,
                overdue_tasks=0,
                completion_rate=0
            )
        
        # Aggregation pipeline for user stats
        pipeline = [
            {"$match": {"user_id": user_id}},
            {
                "$group": {
                    "_id": None,
                    "total_tasks": {"$sum": 1},
                    "completed_tasks": {
                        "$sum": {"$cond": [{"$eq": ["$status", TaskStatus.DONE.value]}, 1, 0]}
                    },
                    "in_progress_tasks": {
                        "$sum": {"$cond": [{"$eq": ["$status", TaskStatus.IN_PROGRESS.value]}, 1, 0]}
                    },
                    "overdue_tasks": {
                        "$sum": {
                            "$cond": [
                                {
                                    "$and": [
                                        {"$ne": ["$status", TaskStatus.DONE.value]},
                                        {"$lt": ["$due_date", datetime.now()]}
                                    ]
                                },
                                1,
                                0
                            ]
                        }
                    },
                    "avg_completion_time": {
                        "$avg": {
                            "$cond": [
                                {"$ne": ["$completed_at", None]},
                                {
                                    "$divide": [
                                        {"$subtract": ["$completed_at", "$created_at"]},
                                        1000 * 60 * 60 * 24  # Convert to days
                                    ]
                                },
                                None
                            ]
                        }
                    }
                }
            }
        ]
        
        async for result in db.user_tasks.aggregate(pipeline):
            total = result.get("total_tasks", 0)
            completed = result.get("completed_tasks", 0)
            
            return UserTaskStats(
                total_tasks=total,
                completed_tasks=completed,
                in_progress_tasks=result.get("in_progress_tasks", 0),
                overdue_tasks=result.get("overdue_tasks", 0),
                completion_rate=(completed / total * 100) if total > 0 else 0,
                average_task_duration=result.get("avg_completion_time")
            )
        
        return UserTaskStats(
            total_tasks=0,
            completed_tasks=0,
            in_progress_tasks=0,
            overdue_tasks=0,
            completion_rate=0
        )
    
    async def update_task_ai_analysis(self, user_id: str, task_id: str, analysis: str, suggestions: List[str]) -> bool:
        """Update AI analysis for a user's task"""
        db = await self.get_db()
        if db is None:
            return False
        
        result = await db.user_tasks.update_one(
            {"_id": ObjectId(task_id), "user_id": user_id},
            {
                "$set": {
                    "ai_analysis": analysis,
                    "ai_suggestions": suggestions,
                    "updated_at": datetime.now()
                }
            }
        )
        
        return result.modified_count > 0
    
    def _convert_mongo_doc(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        """Convert MongoDB document to Pydantic-compatible dict"""
        if doc is None:
            return {}
        
        # Convert ObjectId to string
        if "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        
        return doc

# Dependency injection
def get_user_task_service() -> UserTaskService:
    """Get UserTaskService instance for dependency injection"""
    return UserTaskService()