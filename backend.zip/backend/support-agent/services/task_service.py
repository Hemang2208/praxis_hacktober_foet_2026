from typing import List, Optional, Dict, Any
from datetime import datetime
from bson import ObjectId
from database import get_database
from models import Task, TaskCreate, TaskUpdate, TaskStatus, TaskPriority, UserTaskStats, TaskComment, SubTask

class TaskService:
    """User-specific task service - all operations are scoped to the authenticated user"""
    
    def __init__(self):
        self.db = None
    
    async def get_db(self):
        """Get database instance"""
        if self.db is None:
            self.db = get_database()
        return self.db
    
    async def create_task(self, task_data: TaskCreate, created_by: Optional[str] = None) -> Task:
        """Create a new task (legacy method for compatibility)"""
        return await self.create_task_for_user(created_by or "", task_data)
    
    async def create_task_for_user(self, user_id: str, task_data: TaskCreate) -> Task:
        """Create a new task"""
        db = await self.get_db()
        if db is None:
            raise Exception("Database connection not available")
        
        # Convert TaskCreate to dict and add metadata
        task_dict = task_data.dict()
        task_dict["_id"] = ObjectId()
        task_dict["id"] = str(task_dict["_id"])
        task_dict["created_at"] = datetime.now()
        task_dict["updated_at"] = datetime.now()
        task_dict["status"] = TaskStatus.TODO
        
        if user_id:
            task_dict["reporter"] = user_id
        
        # Insert into database
        result = await db.tasks.insert_one(task_dict)
        
        # Retrieve and return the created task
        created_task = await db.tasks.find_one({"_id": result.inserted_id})
        if created_task is None:
            raise Exception("Failed to retrieve created task")
        return Task(**self._convert_mongo_doc(created_task))
    
    async def get_task(self, task_id: str) -> Optional[Task]:
        """Get a task by ID"""
        db = await self.get_db()
        if db is None:
            return None
        
        task_doc = await db.tasks.find_one({"_id": ObjectId(task_id)})
        if not task_doc:
            return None
        
        return Task(**self._convert_mongo_doc(task_doc))
    
    async def update_task(self, task_id: str, task_update: TaskUpdate, updated_by: Optional[str] = None) -> Optional[Task]:
        """Update an existing task"""
        db = await self.get_db()
        if db is None:
            return None
        
        # Prepare update data
        update_data = {k: v for k, v in task_update.dict().items() if v is not None}
        update_data["updated_at"] = datetime.now()
        
        # Update in database
        result = await db.tasks.update_one(
            {"_id": ObjectId(task_id)},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            return None
        
        # Return updated task
        return await self.get_task(task_id)
    
    async def assign_task(self, task_id: str, assignee: str, assigned_by: Optional[str] = None) -> Optional[Task]:
        """Assign a task to a user (overwrites any existing assignment)"""
        db = await self.get_db()
        if db is None:
            return None
        
        # Prepare update data - explicitly set assignee and overwrite any existing assignment
        update_data = {
            "assignee": assignee,
            "updated_at": datetime.now()
        }
        
        # Update in database
        result = await db.tasks.update_one(
            {"_id": ObjectId(task_id)},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            return None
        
        # Return updated task
        return await self.get_task(task_id)
    
    async def delete_task(self, task_id: str) -> bool:
        """Delete a task"""
        db = await self.get_db()
        if db is None:
            return False
        
        result = await db.tasks.delete_one({"_id": ObjectId(task_id)})
        return result.deleted_count > 0
    
    async def get_tasks(
        self,
        project_id: Optional[str] = None,
        assignee: Optional[str] = None,
        status: Optional[List[TaskStatus]] = None,
        priority: Optional[List[TaskPriority]] = None,
        tags: Optional[List[str]] = None,
        parent_task_id: Optional[str] = None,
        limit: int = 20,
        skip: int = 0
    ) -> List[Task]:
        """Get tasks with filtering options"""
        db = await self.get_db()
        if db is None:
            return []
        
        # Build filter query
        filter_query: Dict[str, Any] = {}
        
        if project_id:
            filter_query["project_id"] = project_id
        
        if assignee:
            filter_query["assignee"] = assignee
        
        if status:
            filter_query["status"] = {"$in": [s.value for s in status]}
        
        if priority:
            filter_query["priority"] = {"$in": [p.value for p in priority]}
        
        if tags:
            filter_query["tags"] = {"$in": tags}
        
        if parent_task_id:
            filter_query["parent_task_id"] = parent_task_id
        
        # Execute query
        cursor = db.tasks.find(filter_query).skip(skip).limit(limit).sort("created_at", -1)
        tasks = []
        
        async for task_doc in cursor:
            tasks.append(Task(**self._convert_mongo_doc(task_doc)))
        
        return tasks
    
    async def search_tasks(self, query: str, project_id: Optional[str] = None, limit: int = 20) -> List[Task]:
        """Search tasks by text query"""
        db = await self.get_db()
        if db is None:
            return []
        
        # Build search filter
        search_filter: Dict[str, Any] = {
            "$or": [
                {"title": {"$regex": query, "$options": "i"}},
                {"description": {"$regex": query, "$options": "i"}},
                {"tags": {"$regex": query, "$options": "i"}}
            ]
        }
        
        if project_id:
            search_filter["project_id"] = project_id
        
        cursor = db.tasks.find(search_filter).limit(limit).sort("created_at", -1)
        tasks = []
        
        async for task_doc in cursor:
            tasks.append(Task(**self._convert_mongo_doc(task_doc)))
        
        return tasks
    
    async def get_user_tasks(self, user_id: str, status: Optional[List[TaskStatus]] = None) -> List[Task]:
        """Get all tasks assigned to a user"""
        if status:
            return await self.get_tasks(assignee=user_id, status=status)
        return await self.get_tasks(assignee=user_id)
    
    async def get_overdue_tasks(self, project_id: Optional[str] = None) -> List[Task]:
        """Get overdue tasks"""
        db = await self.get_db()
        if db is None:
            return []
        
        filter_query: Dict[str, Any] = {
            "due_date": {"$lt": datetime.now()},
            "status": {"$nin": [TaskStatus.DONE.value, TaskStatus.CANCELLED.value]}
        }
        
        if project_id:
            filter_query["project_id"] = project_id
        
        cursor = db.tasks.find(filter_query).sort("due_date", 1)
        tasks = []
        
        async for task_doc in cursor:
            tasks.append(Task(**self._convert_mongo_doc(task_doc)))
        
        return tasks
    
    async def add_comment(self, task_id: str, content: str, author: str) -> bool:
        """Add a comment to a task"""
        db = await self.get_db()
        if db is None:
            return False
        
        comment = TaskComment(
            id=str(ObjectId()),
            content=content,
            author=author,
            created_at=datetime.now()
        )
        
        result = await db.tasks.update_one(
            {"_id": ObjectId(task_id)},
            {"$push": {"comments": comment.dict()}}
        )
        
        return result.modified_count > 0
    
    async def add_subtask(self, task_id: str, subtask: SubTask) -> bool:
        """Add a subtask to a task"""
        db = await self.get_db()
        if db is None:
            return False
        
        subtask.id = str(ObjectId())
        
        result = await db.tasks.update_one(
            {"_id": ObjectId(task_id)},
            {"$push": {"sub_tasks": subtask.dict()}}
        )
        
        return result.modified_count > 0
    
    async def update_subtask_status(self, task_id: str, subtask_id: str, status: TaskStatus) -> bool:
        """Update the status of a subtask"""
        db = await self.get_db()
        if db is None:
            return False
        
        update_data: Dict[str, Any] = {"sub_tasks.$.status": status.value}
        if status == TaskStatus.DONE:
            update_data["sub_tasks.$.completed_at"] = datetime.now()
        
        result = await db.tasks.update_one(
            {"_id": ObjectId(task_id), "sub_tasks.id": subtask_id},
            {"$set": update_data}
        )
        
        return result.modified_count > 0
    
    async def get_task_metrics(self, project_id: Optional[str] = None, assignee: Optional[str] = None) -> Dict[str, Any]:
        """Get task metrics and analytics"""
        db = await self.get_db()
        if db is None:
            return {}
        
        # Build base filter
        base_filter = {}
        if project_id:
            base_filter["project_id"] = project_id
        if assignee:
            base_filter["assignee"] = assignee
        
        # Aggregation pipeline for metrics
        pipeline = [
            {"$match": base_filter},
            {
                "$group": {
                    "_id": None,
                    "total_tasks": {"$sum": 1},
                    "completed_tasks": {
                        "$sum": {"$cond": [{"$eq": ["$status", TaskStatus.DONE.value]}, 1, 0]}
                    },
                    "in_progress_tasks": {
                        "$sum": {"$cond": [{"$eq": ["$status", TaskStatus.IN_PROGRESS.value]}, 1, 0]}
                    },
                    "overdue_tasks": {
                        "$sum": {
                            "$cond": [
                                {
                                    "$and": [
                                        {"$ne": ["$status", TaskStatus.DONE.value]},
                                        {"$ne": ["$status", TaskStatus.CANCELLED.value]},
                                        {"$lt": ["$due_date", datetime.now()]}
                                    ]
                                },
                                1,
                                0
                            ]
                        }
                    },
                    "avg_completion_time": {
                        "$avg": {
                            "$cond": [
                                {"$ne": ["$completed_at", None]},
                                {
                                    "$divide": [
                                        {"$subtract": ["$completed_at", "$created_at"]},
                                        1000 * 60 * 60 * 24  # Convert to days
                                    ]
                                },
                                None
                            ]
                        }
                    },
                    "by_priority": {
                        "$push": {
                            "priority": "$priority",
                            "count": 1
                        }
                    },
                    "by_status": {
                        "$push": {
                            "status": "$status",
                            "count": 1
                        }
                    },
                    "by_type": {
                        "$push": {
                            "type": "$type",
                            "count": 1
                        }
                    }
                }
            }
        ]
        
        async for result in db.tasks.aggregate(pipeline):
            total = result.get("total_tasks", 0)
            completed = result.get("completed_tasks", 0)
            
            return {
                "total_tasks": total,
                "completed_tasks": completed,
                "in_progress_tasks": result.get("in_progress_tasks", 0),
                "overdue_tasks": result.get("overdue_tasks", 0),
                "completion_rate": (completed / total * 100) if total > 0 else 0,
                "average_completion_time": result.get("avg_completion_time"),
                "by_priority": self._aggregate_counts(result.get("by_priority", [])),
                "by_status": self._aggregate_counts(result.get("by_status", [])),
                "by_type": self._aggregate_counts(result.get("by_type", []))
            }
        
        return {
            "total_tasks": 0,
            "completed_tasks": 0,
            "in_progress_tasks": 0,
            "overdue_tasks": 0,
            "completion_rate": 0,
            "by_priority": {},
            "by_status": {},
            "by_type": {}
        }
    
    def _convert_mongo_doc(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        """Convert MongoDB document to Pydantic-compatible dict"""
        if doc is None:
            return {}
        
        # Convert ObjectId to string
        if "_id" in doc:
            doc["id"] = str(doc["_id"])
            del doc["_id"]
        
        return doc
    
    def _aggregate_counts(self, items: List[Dict[str, Any]]) -> Dict[str, int]:
        """Aggregate count data from MongoDB results"""
        counts = {}
        for item in items:
            key = item.get("priority") or item.get("status") or item.get("type")
            if key:
                counts[key] = counts.get(key, 0) + 1
        return counts

# Dependency injection
def get_task_service() -> TaskService:
    """Get TaskService instance for dependency injection"""
    return TaskService()