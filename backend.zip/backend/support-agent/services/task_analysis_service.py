import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
logger = logging.getLogger(__name__)
from config.settings import (
    SITE_NAME,
    TASK_ANALYSIS_MAX_TOKENS,
    TASK_ANALYSIS_TEMPERATURE
)
from shared.ollama_service import OllamaService
from models import Task, TaskAnalysisResponse, TaskBreakdownResponse, TaskRecommendationResponse, TaskComplexity, TaskPriority, TaskType, SubTask

class TaskAnalysisService:
    """Service for AI-powered task analysis using the local Ollama model."""

    def __init__(self):
        self.ollama = OllamaService(agent_type="support")

    async def _call_ollama(self, prompt: str, max_tokens: int = TASK_ANALYSIS_MAX_TOKENS, temperature: float = TASK_ANALYSIS_TEMPERATURE) -> Optional[Dict[str, Any]]:
        """Call the local Ollama model and parse a JSON response."""
        try:
            return await self.ollama.generate_json_completion(
                messages=[
                    {
                        "role": "system",
                        "content": "You are PRAXIS, an expert AI project manager and task analyst. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=temperature,
                max_tokens=max_tokens,
            )
        except Exception as e:
            logger.error(f"Error calling local Ollama: {str(e)}")
            return None

    async def analyze_task(self, task: Task, context: Optional[str] = None) -> TaskAnalysisResponse:
        """Analyze a task using AI to provide insights, recommendations, and risk assessment"""
        task_type = getattr(task, "type", "feature")
        task_complexity = getattr(task, "complexity", "moderate")

        prompt = f"""
        As PRAXIS, an expert project manager and task analyst, analyze the following task and provide comprehensive insights:
        
        Task Details:
        - Title: {task.title}
        - Description: {task.description or 'No description provided'}
        - Priority: {task.priority}
        - Type: {task_type}
        - Complexity: {task_complexity}
        - Estimated Hours: {task.estimated_hours or 'Not estimated'}
        - Due Date: {task.due_date or 'No due date'}
        - Status: {task.status}
        - Tags: {', '.join(task.tags) if task.tags else 'None'}
        
        Additional Context: {context or 'No additional context provided'}
        
        Return ONLY valid JSON (no markdown, no code blocks):
        {{
            "analysis": {{
                "overview": "Overall task analysis",
                "challenges": ["Challenge 1", "Challenge 2"],
                "opportunities": ["Opportunity 1"],
                "technical_complexity": "assessment of technical difficulty",
                "business_impact": "assessment of business value",
                "skills_required": ["Skill 1"]
            }},
            "recommendations": ["Recommendation 1"],
            "risk_assessment": {{
                "overall_risk": "low/medium/high",
                "risks": [{{"description": "Risk", "likelihood": 3, "impact": 4, "mitigation": "Solution"}}],
                "risk_score": 3.5
            }},
            "suggested_improvements": ["Improvement 1"],
            "estimated_effort": 8.5
        }}
        """
        
        result = await self._call_ollama(prompt)
        if result:
            return TaskAnalysisResponse(
                task_id=task.id or "",
                analysis=result.get("analysis", {}),
                recommendations=result.get("recommendations", []),
                risk_assessment=result.get("risk_assessment", {}),
                suggested_improvements=result.get("suggested_improvements", []),
                estimated_effort=result.get("estimated_effort")
            )
        return self._fallback_analysis(task)
    
    async def break_down_task(self, title: str, description: str, complexity: TaskComplexity, project_context: Optional[str] = None) -> TaskBreakdownResponse:
        """Break down a complex task into smaller, manageable sub_tasks"""
        
        prompt = f"""
        As an expert project manager, break down this task into smaller, manageable sub_tasks:
        
        Main Task:
        - Title: {title}
        - Description: {description}
        - Complexity: {complexity}
        - Project Context: {project_context or 'No specific project context'}
        
        Return ONLY valid JSON (no markdown, no code blocks):
        {{
            "main_task": {{
                "title": "Refined title",
                "description": "Enhanced description",
                "priority": "medium",
                "type": "development",
                "complexity": "medium",
                "estimated_hours": 20,
                "tags": ["tag1", "tag2"]
            }},
            "sub_tasks": [
                {{
                    "title": "Subtask 1",
                    "description": "Subtask description",
                    "estimated_hours": 4
                }}
            ],
            "dependencies": ["Subtask 1 must be completed before Subtask 2"],
            "recommendations": ["Recommendation 1"]
        }}
        """
        
        result = await self._call_ollama(prompt)
        if result:
            try:
                main_task_data = result.get("main_task", {})
                from models import TaskCreate
                main_task = TaskCreate(
                    title=main_task_data.get("title", title),
                    description=main_task_data.get("description", description),
                    priority=TaskPriority(main_task_data.get("priority", "medium")),
                    type=TaskType(main_task_data.get("type", "development")),
                    complexity=TaskComplexity(main_task_data.get("complexity", complexity)),
                    estimated_hours=main_task_data.get("estimated_hours"),
                    tags=main_task_data.get("tags", [])
                )
                
                sub_tasks = []
                for subtask_data in result.get("sub_tasks", []):
                    subtask = SubTask(
                        title=subtask_data.get("title", ""),
                        description=subtask_data.get("description"),
                        estimated_hours=subtask_data.get("estimated_hours")
                    )
                    sub_tasks.append(subtask)
                
                return TaskBreakdownResponse(
                    main_task=main_task,
                    sub_tasks=sub_tasks,
                    dependencies=result.get("dependencies", []),
                    recommendations=result.get("recommendations", [])
                )
            except Exception as e:
                logger.error(f"Error processing breakdown result: {e}")
        return self._fallback_breakdown(title, description, complexity)
    
    async def recommend_tasks(self, user_id: str, skills: List[str], workload: Optional[str] = None, preferences: Dict[str, Any] = {}) -> TaskRecommendationResponse:
        """Recommend tasks for a user based on their skills, workload, and preferences"""
        
        prompt = f"""
        As an AI task recommendation system, recommend suitable tasks for this user:
        
        User Profile:
        - User ID: {user_id}
        - Skills: {', '.join(skills) if skills else 'No specific skills listed'}
        - Current Workload: {workload or 'Not specified'}
        - Preferences: {json.dumps(preferences) if preferences else 'No specific preferences'}
        
        Return ONLY valid JSON (no markdown, no code blocks):
        {{
            "task_recommendations": [
                {{
                    "title": "Recommended Task Title",
                    "description": "Task description",
                    "priority": "medium",
                    "type": "development",
                    "complexity": "medium",
                    "estimated_hours": 5,
                    "tags": ["skill-match"],
                    "reason": "Why this task is recommended"
                }}
            ],
            "reasoning": ["Reason 1 for these recommendations"],
            "priority_suggestions": {{
                "focus_areas": "What the user should prioritize",
                "skill_development": "Skills to develop",
                "workload_advice": "Workload management advice"
            }}
        }}
        """
        
        result = await self._call_ollama(prompt)
        if result:
            try:
                recommended_tasks = []
                for task_data in result.get("task_recommendations", []):
                    task = Task(
                        title=task_data.get("title", "Recommended Task"),
                        description=task_data.get("description", ""),
                        priority=TaskPriority(task_data.get("priority", "medium")),
                        type=TaskType(task_data.get("type", "development")),
                        complexity=TaskComplexity(task_data.get("complexity", "medium")),
                        estimated_hours=task_data.get("estimated_hours"),
                        tags=task_data.get("tags", [])
                    )
                    recommended_tasks.append(task)
                
                return TaskRecommendationResponse(
                    recommended_tasks=recommended_tasks,
                    reasoning=result.get("reasoning", []),
                    priority_suggestions=result.get("priority_suggestions", {})
                )
            except Exception as e:
                logger.error(f"Error processing recommendations: {e}")
        return self._fallback_recommendations(user_id, skills)
    
    def _fallback_analysis(self, task: Task) -> TaskAnalysisResponse:
        """Provide fallback analysis when AI fails"""
        return TaskAnalysisResponse(
            task_id=task.id or "",
            analysis={
                "overview": "AI analysis temporarily unavailable. Basic assessment provided.",
                "challenges": ["No specific challenges identified"],
                "opportunities": ["Complete task as specified"],
                "technical_complexity": "As specified in task complexity",
                "business_impact": "Standard business value expected"
            },
            recommendations=["Break down task if complex", "Set clear acceptance criteria", "Regular progress updates"],
            risk_assessment={
                "overall_risk": "medium",
                "risks": [{"description": "Standard project risks apply", "likelihood": 3, "impact": 3, "mitigation": "Regular monitoring"}],
                "risk_score": 3.0
            },
            suggested_improvements=["Add more detailed description", "Set clear acceptance criteria"],
            estimated_effort=task.estimated_hours
        )
    
    def _fallback_breakdown(self, title: str, description: str, complexity: TaskComplexity) -> TaskBreakdownResponse:
        """Provide fallback breakdown when AI fails"""
        from models import TaskCreate
        
        main_task = TaskCreate(
            title=title,
            description=description,
            complexity=complexity,
            estimated_hours=8.0 if complexity == TaskComplexity.SIMPLE else 16.0 if complexity == TaskComplexity.MEDIUM else 32.0
        )
        
        sub_tasks = [
            SubTask(title="Planning and Analysis", estimated_hours=2.0),
            SubTask(title="Implementation", estimated_hours=main_task.estimated_hours * 0.6),
            SubTask(title="Testing and Review", estimated_hours=main_task.estimated_hours * 0.3)
        ]
        
        return TaskBreakdownResponse(
            main_task=main_task,
            sub_tasks=sub_tasks,
            recommendations=["AI breakdown temporarily unavailable. Basic breakdown provided.", "Refine sub_tasks based on specific requirements"]
        )
    
    def _fallback_recommendations(self, user_id: str, skills: List[str]) -> TaskRecommendationResponse:
        """Provide fallback recommendations when AI fails"""
        return TaskRecommendationResponse(
            recommended_tasks=[],
            reasoning=["AI recommendations temporarily unavailable"],
            priority_suggestions={"general_advice": "Focus on tasks matching your core skills"}
        )