import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
logger = logging.getLogger(__name__)
from config.settings import (
    TASK_ANALYSIS_MAX_TOKENS,
    TASK_ANALYSIS_TEMPERATURE
)
from shared.ollama_service import OllamaService
from models import Task, TaskRecommendation, TaskPriority, UserProfile

class UserTaskAIService:
    """AI service for user-specific task analysis and recommendations using local Ollama."""

    def __init__(self):
        self.ollama = OllamaService(agent_type="support")

    async def _call_ollama(self, prompt: str, max_tokens: int = TASK_ANALYSIS_MAX_TOKENS, temperature: float = TASK_ANALYSIS_TEMPERATURE) -> Any:
        """Call the local Ollama model and parse a JSON response."""
        try:
            return await self.ollama.generate_json_completion(
                messages=[
                    {
                        "role": "system",
                        "content": "You are PRAXIS, the official AI Support Agent. Always respond with valid JSON."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=temperature,
                max_tokens=max_tokens,
            )
        except Exception as e:
            logger.error(f"Error calling local Ollama: {str(e)}")
            return None
    
    async def analyze_user_task(self, user_id: str, task: Task, user_context: Optional[str] = None) -> Dict[str, Any]:
        """Analyze a user's task and provide personalized insights"""
        
        prompt = f"""
        As a personal AI task assistant, analyze this task for user {user_id}:
        
        Task Details:
        - Title: {task.title}
        - Description: {task.description or 'No description provided'}
        - Priority: {task.priority}
        - Status: {task.status}
        - Estimated Hours: {task.estimated_hours or 'Not estimated'}
        - Due Date: {task.due_date or 'No due date'}
        - Tags: {', '.join(task.tags) if task.tags else 'None'}
        
        User Context: {user_context or 'No additional context provided'}
        
        Provide:
        1. A brief analysis of the task (2-3 sentences)
        2. 3-5 actionable suggestions to help complete this task effectively
        3. Potential challenges and how to overcome them
        4. Time management advice if applicable
        
        Return ONLY valid JSON (no markdown, no code blocks):
        {{
            "analysis": "Brief task analysis focused on helping the user succeed",
            "suggestions": [
                "Specific actionable suggestion 1",
                "Specific actionable suggestion 2",
                "Specific actionable suggestion 3"
            ],
            "challenges": [
                "Potential challenge and solution"
            ],
            "time_advice": "Time management recommendation"
        }}
        """
        
        result = await self._call_ollama(prompt)
        if result:
            return result
        return self._fallback_analysis()
    
    async def recommend_tasks_for_user(self, user_id: str, user_profile: Optional[UserProfile] = None, user_tasks: Optional[List[Task]] = None) -> List[TaskRecommendation]:
        """Recommend new tasks for a user based on their profile and current tasks"""
        
        # Prepare user context
        skills_str = ', '.join(user_profile.skills) if user_profile and user_profile.skills else 'No specific skills listed'
        workload = user_profile.current_workload if user_profile else 'medium'
        
        # Analyze current tasks
        current_tasks_summary = ""
        if user_tasks:
            total_tasks = len(user_tasks)
            completed_tasks = len([t for t in user_tasks if t.status == "done"])
            in_progress_tasks = len([t for t in user_tasks if t.status == "in_progress"])
            current_tasks_summary = f"Currently has {total_tasks} tasks total, {completed_tasks} completed, {in_progress_tasks} in progress"
        else:
            current_tasks_summary = "No current tasks"
        
        prompt = f"""
        As a personal AI productivity assistant, recommend 3-5 new tasks for user {user_id}:
        
        User Profile:
        - Skills: {skills_str}
        - Current Workload: {workload}
        - Task Status: {current_tasks_summary}
        
        Based on this information, suggest tasks that would:
        1. Help the user grow their skills
        2. Be appropriate for their current workload
        3. Provide value in their personal or professional development
        4. Be achievable and motivating
        
        Return ONLY valid JSON array (no markdown, no code blocks):
        [
            {{
                "title": "Task title",
                "description": "Clear, actionable task description",
                "reasoning": "Why this task is recommended for this user",
                "priority": "medium",
                "estimated_hours": 2,
                "tags": ["skill-building", "productivity"]
            }}
        ]
        """
        
        result = await self._call_ollama(prompt)
        if result and isinstance(result, list):
            recommendations = []
            for rec_data in result:
                try:
                    recommendation = TaskRecommendation(
                        title=rec_data.get("title", "Recommended Task"),
                        description=rec_data.get("description", ""),
                        reasoning=rec_data.get("reasoning", "AI recommended"),
                        priority=TaskPriority(rec_data.get("priority", "medium")),
                        estimated_hours=rec_data.get("estimated_hours"),
                        tags=rec_data.get("tags", [])
                    )
                    recommendations.append(recommendation)
                except Exception as e:
                    logger.error(f"Error processing recommendation: {e}")
            if recommendations:
                return recommendations
        return self._fallback_recommendations()
    
    async def answer_user_query(self, user_id: str, query: str, user_tasks: List[Task], context: Optional[str] = None) -> Dict[str, Any]:
        """Answer user queries about their tasks using AI"""
        
        # Prepare task context
        tasks_summary = []
        for task in user_tasks[:10]:  # Limit to recent 10 tasks
            tasks_summary.append(f"- {task.title} ({task.status}, {task.priority} priority)")
        
        tasks_context = "\n".join(tasks_summary) if tasks_summary else "No tasks available"
        
        prompt = f"""
        User {user_id} is asking about their tasks. Here are their current tasks:
        
        {tasks_context}
        
        User Query: "{query}"
        Additional Context: {context or 'None'}
        
        Provide a helpful response that:
        1. Directly answers their question
        2. References their specific tasks when relevant
        3. Provides actionable advice
        4. Is conversational and personal
        
        Return ONLY valid JSON (no markdown, no code blocks):
        {{
            "message": "Your response to the user",
            "suggestions": ["Optional actionable suggestion 1", "Optional suggestion 2"],
            "related_tasks": ["task_id_1", "task_id_2"]
        }}
        """
        
        result = await self._call_ollama(prompt, temperature=0.7)
        if result:
            return result
        return self._fallback_query_response()
    
    def _fallback_analysis(self) -> Dict[str, Any]:
        """Provide fallback analysis when AI fails"""
        return {
            "analysis": "PRAXIS analysis is temporarily unavailable. Focus on breaking down this task into smaller steps and setting a clear timeline.",
            "suggestions": [
                "Break the task into smaller, manageable steps",
                "Set a specific timeline for completion",
                "Identify any resources or help you might need"
            ],
            "challenges": ["Standard task completion challenges may apply"],
            "time_advice": "Allocate focused time blocks for task completion"
        }
    
    def _fallback_recommendations(self) -> List[TaskRecommendation]:
        """Provide fallback recommendations when AI fails"""
        return [
            TaskRecommendation(
                title="Review and organize current tasks",
                description="Take time to review your current task list and prioritize items",
                reasoning="Regular task review helps maintain productivity",
                priority=TaskPriority.MEDIUM,
                estimated_hours=1.0,
                tags=["organization", "productivity"]
            )
        ]
    
    def _fallback_query_response(self) -> Dict[str, Any]:
        """Provide fallback response when AI fails"""
        return {
            "message": "PRAXIS is having trouble processing your request right now. Please try asking about specific tasks or check back later.",
            "suggestions": ["Try breaking down your question into smaller parts", "Check your task list for recent updates"],
            "related_tasks": []
        }