import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer
from contextlib import asynccontextmanager
import uvicorn

from database import connect_db, disconnect_db
from config.settings import API_VERSION, OLLAMA_MODEL

# Security scheme for OpenAPI docs
security = HTTPBearer()

# Lifespan manager for startup/shutdown events
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    try:
        await connect_db()
        print("Database connected successfully")
    except Exception as e:
        print(f"Failed to connect to database: {e}")
    yield
    # Shutdown
    try:
        await disconnect_db()
        print("Database disconnected successfully")
    except Exception as e:
        print(f"Failed to disconnect from database: {e}")

# Create FastAPI app
app = FastAPI(
    title="Support Agent API",
    description=f"An intelligent AI support system powered by the local Ollama model ({OLLAMA_MODEL}) for personalized assistance, recommendations, and automation with large context window support",
    version=API_VERSION,
    lifespan=lifespan
)

# Add CORS middleware
def _get_allowed_origins():
    """Read CORS origins from the environment and always allow local development."""
    configured = os.getenv("ALLOWED_ORIGINS", "")
    origins = [origin.strip() for origin in configured.split(",") if origin.strip()]
    for local in ("http://localhost:3000", "http://localhost:8000", "http://localhost"):
        if local not in origins:
            origins.append(local)
    return origins


app.add_middleware(
    CORSMiddleware,
    allow_origins=_get_allowed_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure OpenAPI security scheme
from fastapi.openapi.utils import get_openapi
from fastapi.openapi.models import OAuthFlows as OAuthFlowsModel, OAuthFlow as OAuthFlow

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Support Agent API",
        version=API_VERSION,
        description=f"An intelligent AI support system powered by the local Ollama model ({OLLAMA_MODEL}) for personalized assistance, recommendations, and automation with large context window support",
        routes=app.routes,
    )
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
        }
    }
    openapi_schema["security"] = [{"BearerAuth": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

# Include user-focused routes
from user_routes import router as user_router
app.include_router(user_router, prefix="/api/v1")

# Include comprehensive AI assistant routes
from comprehensive_routes import router as comprehensive_router
app.include_router(comprehensive_router, prefix="/api/v1/assistant")

# Include Authentication routes
from auth_routes import router as auth_router
app.include_router(auth_router, prefix="/api/v1/auth")

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Support Agent API - Comprehensive AI Assistant",
        "version": API_VERSION,
        "status": "running",
        "description": "Intelligent AI support with access to ALL user data: profile, tasks, projects, code reviews, feedback, notifications, and more",
        "features": [
            "Complete user profile access",
            "Task management with AI insights",
            "Project tracking and planning",
            "Pull request and code review integration",
            "AI-powered recommendations",
            "Progress analytics and insights",
            "Natural language queries about your data"
        ],
        "endpoints": {
            "ask_anything": "/v1/assistant/ask-me/",
            "my_progress": "/v1/assistant/my-progress/",
            "recommendations": "/v1/assistant/recommendations/",
            "next_action": "/v1/assistant/next-action/",
            "complete_profile": "/v1/assistant/my-complete-profile/"
        }
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8005))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)