"""
Auth utilities for support-agent, using shared auth module
"""
import sys
from pathlib import Path
from typing import Optional
from pydantic import BaseModel

# Add shared module to path
shared_path = str(Path(__file__).parent.parent / "shared")
if shared_path not in sys.path:
    sys.path.append(shared_path)

# Import from shared
from shared.auth_utils import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    create_token_pair,
    verify_access_token,
    verify_refresh_token,
    get_current_user,
    get_current_user_optional
)

# Re-export for compatibility
__all__ = [
    'hash_password',
    'verify_password',
    'create_access_token',
    'create_refresh_token',
    'create_token_pair',
    'verify_access_token',
    'verify_refresh_token',
    'get_current_user',
    'get_current_user_optional',
    'verify_token',
    'get_password_hash',
    'Token',
    'TokenData',
    'UserLogin'
]

# Compatibility wrappers
def verify_token(token: str) -> Optional[str]:
    """Verify JWT token and return user_id (compatibility wrapper)"""
    payload = verify_access_token(token)
    if payload is None:
        return None
    user_id = payload.get("sub") or payload.get("user_id")
    return user_id

def get_password_hash(password: str) -> str:
    """Alias for hash_password"""
    return hash_password(password)

# Legacy models (for compatibility - prefer using models.py)
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    user_id: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str
