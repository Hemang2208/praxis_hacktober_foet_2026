import sys
from fastapi import APIRouter, HTTPException, Depends, status
from typing import Optional, Dict, Any
from datetime import datetime
from pathlib import Path

# Add shared module to path
shared_path = str(Path(__file__).parent.parent / "shared")
if shared_path not in sys.path:
    sys.path.append(shared_path)

from auth_utils import (
    hash_password, 
    verify_password, 
    create_token_pair, 
    verify_refresh_token,
    create_access_token,
    get_current_user
)
from models import UserRegister, UserLogin, TokenResponse, TokenRefreshRequest
from database import get_db

router = APIRouter(tags=["Authentication"])

@router.post("/register", response_model=Dict[str, Any])
async def register(user_data: UserRegister):
    """Register a new user (Internal/Testing)"""
    db = await get_db()
    
    # Check if user already exists
    existing_user = await db.users.find_one({"email": user_data.email})
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Hash password and create user
    hashed_pwd = hash_password(user_data.password)
    user_dict = {
        "email": user_data.email,
        "password": hashed_pwd,
        "full_name": user_data.full_name,
        "role": user_data.role,
        "created_at": datetime.utcnow()
    }
    
    result = await db.users.insert_one(user_dict)
    
    return {
        "message": "User registered successfully",
        "user_id": str(result.inserted_id)
    }

@router.post("/login", response_model=TokenResponse)
async def login(credentials: UserLogin):
    """Login and receive a token pair"""
    db = await get_db()
    
    # Find user
    user = await db.users.find_one({"email": credentials.email})
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    # Verify password
    if not verify_password(credentials.password, user["password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    # Create tokens
    user_id = str(user["_id"])
    # Include both 'sub' (standard) and 'id' (legacy planner-agent compatibility)
    token_pair = create_token_pair({"sub": user_id, "id": user_id, "email": user["email"]})
    
    # Store refresh token in DB for rotation/revocation logic
    await db.refresh_tokens.update_one(
        {"user_id": user_id},
        {"$set": {
            "token": token_pair["refresh_token"],
            "created_at": datetime.utcnow()
        }},
        upsert=True
    )
    
    return TokenResponse(
        access_token=token_pair["access_token"],
        refresh_token=token_pair["refresh_token"],
        user_id=user_id
    )

@router.post("/refresh", response_model=Dict[str, str])
async def refresh(request: TokenRefreshRequest):
    """Refresh access token using a valid refresh token"""
    db = await get_db()
    
    payload = verify_refresh_token(request.refresh_token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token"
        )
    
    user_id = payload.get("sub")
    
    # Verify token exists in database (rotation check)
    stored_token = await db.refresh_tokens.find_one({"user_id": user_id, "token": request.refresh_token})
    if not stored_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token has been revoked"
        )
    
    # Create new access token
    # Include both 'sub' (standard) and 'id' (legacy planner-agent compatibility)
    new_access_token = create_access_token({"sub": user_id, "id": user_id})
    
    return {
        "access_token": new_access_token,
        "token_type": "bearer"
    }

@router.post("/logout")
async def logout(current_user: dict = Depends(get_current_user)):
    """Logout and revoke refresh token"""
    if not current_user:
        raise HTTPException(status_code=401, detail="Not authenticated")
        
    db = await get_db()
    user_id = current_user.get("sub")
    await db.refresh_tokens.delete_one({"user_id": user_id})
    
    return {"message": "Logged out successfully"}

@router.post("/service-login", response_model=TokenResponse)
async def service_login(user_data: Dict[str, Any]):
    """
    Trusted service login - creates a user if not exists and returns tokens.
    This should be called from a trusted backend (e.g., Next.js server).
    """
    db = await get_db()
    email = user_data.get("email")
    user_id_from_source = user_data.get("user_id")

    if not email or not user_id_from_source:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email and user_id are required"
        )

    # Find or create user
    user = await db.users.find_one({"email": email})
    if not user:
        user_dict = {
            "email": email,
            "full_name": user_data.get("full_name", "User"),
            "role": user_data.get("role", "student"),
            "source_id": user_id_from_source, # Link to the original user ID
            "created_at": datetime.utcnow()
        }
        result = await db.users.insert_one(user_dict)
        user_id = str(result.inserted_id)
    else:
        user_id = str(user["_id"])

    # Create tokens
    # Include both 'sub' (standard) and 'id' (legacy planner-agent compatibility)
    token_pair = create_token_pair({"sub": user_id, "id": user_id, "email": email})

    return TokenResponse(
        access_token=token_pair["access_token"],
        refresh_token=token_pair["refresh_token"],
        user_id=user_id
    )
