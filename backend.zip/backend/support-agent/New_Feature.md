# PRAXIS Support Runtime

Realtime AI support infrastructure powering PRAXIS's conversational runtime, context management system, agent orchestration, and live streaming architecture.

---

# Overview

PRAXIS Support Runtime transforms a traditional request-response chatbot into a realtime AI runtime capable of:

- Token-level response streaming
- Persistent conversation context
- Session runtime management
- Context-aware reasoning
- Multi-agent orchestration
- Realtime event broadcasting
- Project-aware assistance
- Scalable AI infrastructure

The system is intentionally designed to remain lightweight while providing a strong foundation for future expansion.

---

# Core Philosophy

Traditional Chatbot

```text
User
 ↓
API
 ↓
LLM
 ↓
Response
```

PRAXIS Runtime

```text
User
 ↕
WebSocket Layer
 ↕
Support Runtime
 ↕
Context Manager
 ↕
AI Gateway
 ↕
LLM Providers
```

The Support Runtime is more than a chatbot.

It acts as:

- Session Manager
- Context Engine
- Agent Coordinator
- Event Streaming Hub
- Runtime Controller

---

# Architecture

```text
┌─────────────────────┐
│     Frontend UI     │
│    Next.js App      │
└──────────┬──────────┘
           │
           │ WebSocket
           ▼
┌─────────────────────┐
│ Realtime Gateway    │
│ Connection Manager  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  Support Runtime    │
│ Runtime Controller  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  Context Manager    │
│ Context Assembly    │
└───────┬─────┬───────┘
        │     │
        ▼     ▼
    MongoDB Redis
        │
        ▼
┌─────────────────────┐
│    AI Gateway       │
│ Model Routing Layer │
└──────────┬──────────┘
           │
           ▼
     LLM Providers
```

---

# Core Features

## Realtime AI Streaming

Provides ChatGPT-style streaming responses.

Features:

- Token streaming
- Typing indicators
- Live response updates
- Interruptible generations
- Realtime websocket communication

---

## Session Runtime

Each active conversation maintains runtime state.

Example:

```json
{
  "session_id": "",
  "user_id": "",
  "active_project": "",
  "current_task": "",
  "streaming": true
}
```

Runtime state is stored in Redis for fast access.

---

## Context Management

PRAXIS uses structured context instead of vector search.

Context sources include:

### Conversation History

Recent messages from the current session.

### Project Context

Current repository, project, sprint, or workflow.

### User Memory

Pinned information such as:

- Active project
- Preferred tech stack
- Current goals
- Important instructions

### Runtime State

Current execution context and active tasks.

---

# Context Assembly Flow

```text
User Message
      ↓
Load Session State
      ↓
Load Recent Messages
      ↓
Load Project Context
      ↓
Load User Memory
      ↓
Build Prompt
      ↓
AI Gateway
      ↓
LLM
```

---

# Memory System

PRAXIS currently implements a lightweight memory architecture.

## Short-Term Memory

Stores:

- Recent conversation history
- Active session data

Technology:

- MongoDB
- Redis

---

## Project Context

Stores:

- Active project
- Current repository
- Open tasks
- Runtime state

Technology:

- MongoDB

---

## User Memory

Stores:

- User preferences
- Saved project information
- Important context

Technology:

- MongoDB

---

# Multi-Agent Runtime

The Support Runtime can orchestrate specialized agents.

Examples:

- Planner Agent
- Assessment Agent
- Code Review Agent
- Task Agent

The Support Runtime remains the primary coordinator.

---

# Example Workflow

```text
User Request
      ↓
Support Runtime
      ↓
Planner Agent
      ↓
Assessment Agent
      ↓
Response Synthesis
      ↓
Stream To User
```

---

# Event Streaming System

Realtime events are streamed to connected clients.

## Event Types

| Event            | Description              |
| ---------------- | ------------------------ |
| token            | Streamed token           |
| typing_start     | Generation started       |
| typing_stop      | Generation completed     |
| message_complete | Final response delivered |
| agent_status     | Agent execution update   |
| runtime_update   | Runtime state changed    |
| error            | Runtime error            |

---

## Example Token Event

```json
{
  "type": "token",
  "content": "Hello"
}
```

---

# Redis Architecture

Redis is used for realtime operations.

## Session State

```text
runtime:{session_id}
```

## Active Streams

```text
stream:{session_id}
```

## WebSocket Connections

```text
ws:{session_id}
```

## Background Jobs

```text
queue:default
queue:agent
```

---

# MongoDB Collections

## Users

```json
{
  "_id": "",
  "name": ""
}
```

---

## Sessions

```json
{
  "_id": "",
  "user_id": "",
  "started_at": ""
}
```

---

## Messages

```json
{
  "session_id": "",
  "role": "",
  "content": "",
  "created_at": ""
}
```

---

## Memories

```json
{
  "user_id": "",
  "key": "",
  "value": "",
  "updated_at": ""
}
```

---

## Projects

```json
{
  "_id": "",
  "name": "",
  "description": ""
}
```

---

## Tasks

```json
{
  "_id": "",
  "project_id": "",
  "title": "",
  "status": ""
}
```

---

# AI Gateway

The AI Gateway provides a unified interface for all LLM providers.

Responsibilities:

- Model routing
- Provider abstraction
- Streaming normalization
- Retry handling
- Cost tracking
- Fallback providers

---

# Example Routing

```text
Claude   → Long-context reasoning
GPT      → General intelligence
Gemini   → Multimodal tasks
DeepSeek → Cost-efficient workloads
```

---

# Security

## Authentication

- JWT Authentication
- Session validation
- Tenant isolation

## Runtime Security

- Prompt filtering
- Context isolation
- Audit logging
- Rate limiting

---

# Observability

Tracked Metrics:

- Active websocket connections
- Response latency
- Token generation speed
- Queue processing time
- Agent execution duration
- LLM usage and cost

---

# Tech Stack

| Layer      | Technology           |
| ---------- | -------------------- |
| Backend    | FastAPI              |
| Streaming  | WebSockets           |
| Queue      | Redis                |
| Database   | MongoDB              |
| AI Gateway | LiteLLM / OpenRouter |
| Frontend   | Next.js              |
| Deployment | Docker               |
| Monitoring | OpenTelemetry        |

---

# Development Roadmap

## Phase 1 ✅

Realtime Streaming

- WebSocket infrastructure
- Token streaming
- Session runtime

**Done:**

- `websocket_manager.py` — ConnectionManager that tracks active WebSocket connections and stores session state in Redis with a 1 hour TTL.
- Token streaming is handled in `comprehensive_ai_service.py`. When a message is sent, the response streams token by token over the WebSocket with typing start and stop events.
- Session state (user ID, streaming flag, active project) is saved in Redis under `runtime:{session_id}` so it persists across restarts.
- API Gateway now has a WebSocket proxy route that forwards chat connections from the frontend through to the support agent on port 8005.

---

## Phase 2

Context Management

- Conversation persistence
- User memory
- Project context
- Prompt assembly

---

## Phase 3

AI Gateway

- Provider abstraction
- Model routing
- Cost tracking

---

## Phase 4

Agent Runtime

- Planner Agent
- Assessment Agent
- Code Review Agent
- Workflow orchestration

---

## Phase 5

Scalability

- Distributed workers
- Redis Pub/Sub
- Kubernetes deployment
- Advanced observability

---

# Deployment

## Local Development

```bash
docker-compose up --build
```

---

## Production

Recommended:

- Docker
- Kubernetes
- Redis
- MongoDB Atlas
- OpenRouter

---

# Vision

PRAXIS Support Runtime is designed to evolve from:

```text
AI Chatbot
```

into:

```text
AI Runtime Platform
```

A system capable of:

- Managing persistent context
- Orchestrating AI agents
- Streaming realtime intelligence
- Supporting collaborative workflows
- Powering intelligent developer experiences

---
