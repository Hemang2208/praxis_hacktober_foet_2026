from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional
from datetime import datetime

from models import (
    Task, TaskCreate, TaskUpdate, TaskStatus, TaskPriority, TaskType,
    TaskAnalysisRequest, TaskAnalysisResponse, TaskBreakdownRequest, TaskBreakdownResponse,
    TaskRecommendationRequest, TaskRecommendationResponse, TaskProgressUpdate,
    TaskSearchRequest, TaskMetrics, TaskSummaryResponse, SubTask, TaskComment
)
from services.task_service import TaskService, get_task_service
from services.task_analysis_service import TaskAnalysisService
from config.settings import DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE

router = APIRouter()

# Task CRUD Operations
@router.post("/tasks/", response_model=Task, tags=["Tasks"])
async def create_task(
    task: TaskCreate,
    created_by: Optional[str] = None,
    service: TaskService = Depends(get_task_service)
):
    """Create a new task"""
    try:
        return await service.create_task(task, created_by)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to create task: {str(e)}")

@router.get("/tasks/{task_id}", response_model=Task, tags=["Tasks"])
async def get_task(
    task_id: str,
    service: TaskService = Depends(get_task_service)
):
    """Get a task by ID"""
    task = await service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.put("/tasks/{task_id}", response_model=Task, tags=["Tasks"])
async def update_task(
    task_id: str,
    task_update: TaskUpdate,
    updated_by: Optional[str] = None,
    service: TaskService = Depends(get_task_service)
):
    """Update an existing task"""
    task = await service.update_task(task_id, task_update, updated_by)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@router.delete("/tasks/{task_id}", tags=["Tasks"])
async def delete_task(
    task_id: str,
    service: TaskService = Depends(get_task_service)
):
    """Delete a task"""
    success = await service.delete_task(task_id)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Task deleted successfully"}

@router.get("/tasks/", response_model=List[Task], tags=["Tasks"])
async def get_tasks(
    project_id: Optional[str] = Query(None, description="Filter by project ID"),
    assignee: Optional[str] = Query(None, description="Filter by assignee"),
    status: Optional[List[TaskStatus]] = Query(None, description="Filter by status"),
    priority: Optional[List[TaskPriority]] = Query(None, description="Filter by priority"),
    tags: Optional[List[str]] = Query(None, description="Filter by tags"),
    parent_task_id: Optional[str] = Query(None, description="Filter by parent task"),
    limit: int = Query(DEFAULT_PAGE_SIZE, le=MAX_PAGE_SIZE, description="Number of tasks to return"),
    skip: int = Query(0, ge=0, description="Number of tasks to skip"),
    service: TaskService = Depends(get_task_service)
):
    """Get tasks with filtering options"""
    return await service.get_tasks(
        project_id=project_id,
        assignee=assignee,
        status=status,
        priority=priority,
        tags=tags,
        parent_task_id=parent_task_id,
        limit=limit,
        skip=skip
    )

@router.get("/tasks/search/", response_model=List[Task], tags=["Tasks"])
async def search_tasks(
    q: str = Query(..., description="Search query"),
    project_id: Optional[str] = Query(None, description="Filter by project ID"),
    limit: int = Query(DEFAULT_PAGE_SIZE, le=MAX_PAGE_SIZE),
    service: TaskService = Depends(get_task_service)
):
    """Search tasks by text query"""
    return await service.search_tasks(q, project_id, limit)

@router.get("/users/{user_id}/tasks/", response_model=List[Task], tags=["Tasks", "Users"])
async def get_user_tasks(
    user_id: str,
    status: Optional[List[TaskStatus]] = Query(None),
    service: TaskService = Depends(get_task_service)
):
    """Get all tasks assigned to a user"""
    return await service.get_user_tasks(user_id, status)

@router.get("/tasks/overdue/", response_model=List[Task], tags=["Tasks"])
async def get_overdue_tasks(
    project_id: Optional[str] = Query(None),
    service: TaskService = Depends(get_task_service)
):
    """Get overdue tasks"""
    return await service.get_overdue_tasks(project_id)

# Task Progress and Comments
@router.post("/tasks/{task_id}/comments/", tags=["Tasks", "Comments"])
async def add_comment(
    task_id: str,
    content: str,
    author: str,
    service: TaskService = Depends(get_task_service)
):
    """Add a comment to a task"""
    success = await service.add_comment(task_id, content, author)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Comment added successfully"}

@router.post("/tasks/{task_id}/sub_tasks/", tags=["Tasks", "Subtasks"])
async def add_subtask(
    task_id: str,
    subtask: SubTask,
    service: TaskService = Depends(get_task_service)
):
    """Add a subtask to a task"""
    success = await service.add_subtask(task_id, subtask)
    if not success:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"message": "Subtask added successfully"}

@router.put("/tasks/{task_id}/sub_tasks/{subtask_id}/status/", tags=["Tasks", "Subtasks"])
async def update_subtask_status(
    task_id: str,
    subtask_id: str,
    status: TaskStatus,
    service: TaskService = Depends(get_task_service)
):
    """Update the status of a subtask"""
    success = await service.update_subtask_status(task_id, subtask_id, status)
    if not success:
        raise HTTPException(status_code=404, detail="Task or subtask not found")
    return {"message": "Subtask status updated successfully"}

# AI-Powered Features
@router.post("/tasks/{task_id}/analyze/", response_model=TaskAnalysisResponse, tags=["AI", "Tasks"])
async def analyze_task(
    task_id: str,
    analysis_request: Optional[TaskAnalysisRequest] = None,
    service: TaskService = Depends(get_task_service)
):
    """Analyze a task using AI to provide insights and recommendations"""
    # Get the task
    task = await service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Perform AI analysis
    analysis_service = TaskAnalysisService()
    context = analysis_request.context if analysis_request else None
    
    try:
        return await analysis_service.analyze_task(task, context)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI analysis failed: {str(e)}")

@router.post("/tasks/breakdown/", response_model=TaskBreakdownResponse, tags=["AI", "Tasks"])
async def breakdown_task(
    breakdown_request: TaskBreakdownRequest
):
    """Break down a complex task into smaller, manageable sub_tasks using AI"""
    analysis_service = TaskAnalysisService()
    
    try:
        return await analysis_service.break_down_task(
            breakdown_request.title,
            breakdown_request.description,
            breakdown_request.complexity,
            breakdown_request.project_context
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Task breakdown failed: {str(e)}")

@router.post("/tasks/recommend/", response_model=TaskRecommendationResponse, tags=["AI", "Tasks"])
async def recommend_tasks(
    recommendation_request: TaskRecommendationRequest
):
    """Get AI-powered task recommendations for a user"""
    analysis_service = TaskAnalysisService()
    
    try:
        return await analysis_service.recommend_tasks(
            recommendation_request.user_id,
            recommendation_request.skills,
            recommendation_request.workload,
            recommendation_request.preferences
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Task recommendation failed: {str(e)}")

# Analytics and Metrics
@router.get("/metrics/tasks/", response_model=TaskMetrics, tags=["Analytics", "Tasks"])
async def get_task_metrics(
    project_id: Optional[str] = Query(None),
    assignee: Optional[str] = Query(None),
    service: TaskService = Depends(get_task_service)
):
    """Get task metrics and analytics"""
    try:
        metrics_data = await service.get_task_metrics(project_id, assignee)
        
        return TaskMetrics(
            total_tasks=metrics_data.get("total_tasks", 0),
            completed_tasks=metrics_data.get("completed_tasks", 0),
            in_progress_tasks=metrics_data.get("in_progress_tasks", 0),
            overdue_tasks=metrics_data.get("overdue_tasks", 0),
            average_completion_time=metrics_data.get("average_completion_time"),
            completion_rate=metrics_data.get("completion_rate", 0),
            by_priority=metrics_data.get("by_priority", {}),
            by_status=metrics_data.get("by_status", {}),
            by_type=metrics_data.get("by_type", {})
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get metrics: {str(e)}")

@router.get("/projects/{project_id}/summary/", response_model=TaskSummaryResponse, tags=["Analytics", "Projects"])
async def get_project_task_summary(
    project_id: str,
    service: TaskService = Depends(get_task_service)
):
    """Get a comprehensive task summary for a project with AI insights"""
    try:
        # Get tasks for the project
        tasks = await service.get_tasks(project_id=project_id, limit=1000)
        
        # Get metrics
        metrics_data = await service.get_task_metrics(project_id=project_id)
        metrics = TaskMetrics(
            total_tasks=metrics_data.get("total_tasks", 0),
            completed_tasks=metrics_data.get("completed_tasks", 0),
            in_progress_tasks=metrics_data.get("in_progress_tasks", 0),
            overdue_tasks=metrics_data.get("overdue_tasks", 0),
            average_completion_time=metrics_data.get("average_completion_time"),
            completion_rate=metrics_data.get("completion_rate", 0),
            by_priority=metrics_data.get("by_priority", {}),
            by_status=metrics_data.get("by_status", {}),
            by_type=metrics_data.get("by_type", {})
        )
        
        # Generate AI insights (simplified for now)
        ai_insights = []
        if metrics.completion_rate > 80:
            ai_insights.append("Project is progressing well with high completion rate")
        elif metrics.completion_rate < 50:
            ai_insights.append("Project may need attention due to low completion rate")
        
        if metrics.overdue_tasks > 0:
            ai_insights.append(f"{metrics.overdue_tasks} tasks are overdue and need immediate attention")
        
        return TaskSummaryResponse(
            tasks=tasks,
            metrics=metrics,
            ai_insights=ai_insights
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get project summary: {str(e)}")

# Health and Status
@router.get("/health/", tags=["Health"])
async def health_check():
    """Health check for the support agent"""
    return {
        "status": "healthy",
        "service": "support-agent",
        "timestamp": datetime.now().isoformat()
    }