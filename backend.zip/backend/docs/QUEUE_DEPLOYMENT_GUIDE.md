# Redis Queue System - Deployment & Verification Guide

## Overview

The Redis-backed queue system has been successfully implemented for the PRAXIS API Gateway. This guide helps you deploy and verify the system.

## What Was Built

### Core Components

1. **queue_manager.py** (~600 lines)
   - `QueueClient`: Redis connection and job lifecycle management
   - `JobMetadata`: Pydantic model for job data
   - `WorkerPool`: Concurrency management
   - `QueueMetrics`: Performance tracking

2. **Modified main.py**
   - Queue initialization in lifespan
   - Background worker loops (one per agent)
   - Job processing logic with retry/timeout
   - New API endpoints for status/results
   - Queue decision logic (pass-through vs queue)

3. **Infrastructure Updates**
   - Added `redis>=5.0.0` to requirements.txt
   - Added queue environment variables to docker-compose.yml
   - Added pytest dependencies for testing

4. **Tests & Tools**
   - `test_queue.py`: Unit tests for queue manager
   - `test_integration_simple.py`: Integration test script
   - `load_test.py`: Load testing tool

## Deployment Steps

### 1. Install Dependencies

```bash
cd api-gateway
pip install -r requirements.txt
```

### 2. Verify Docker Compose Configuration

Check that `docker-compose.yml` has queue variables:

```yaml
api-gateway:
  environment:
    - QUEUE_ENABLED=true              # ← Enable queue
    - QUEUE_MAX_WORKERS=5             # ← Concurrent workers
    - QUEUE_MAX_SIZE=500              # ← Max queued jobs
    - QUEUE_RESULT_TTL=1800           # ← Result TTL (30 min)
    - QUEUE_JOB_TIMEOUT=3600          # ← Job timeout (1 hour)
    - QUEUE_RETRY_MAX=3               # ← Max retries
    - REDIS_URL=redis://redis:6379    # ← Already configured
```

### 3. Start the System

```bash
# From repository root
docker-compose up --build
```

Watch for these log messages:
- `✅ Connected to Redis at redis://redis:6379`
- `✅ Queue system started with 5 workers per agent`
- `Worker loop started for assessment-agent` (x5 agents)

### 4. Verify Queue is Running

**Check health endpoint:**
```bash
curl http://localhost/health
```

**Check queue metrics:**
```bash
curl http://localhost/api/v1/queue/metrics
```

Expected response:
```json
{
  "queue_size": 0,
  "active_jobs": 0,
  "total_processed": 0,
  "total_failed": 0,
  "total_retried": 0,
  "avg_wait_time_seconds": 0.0,
  "avg_processing_time_seconds": 0.0,
  "timestamp": "2026-04-02T19:20:00Z"
}
```

If you get `501 Not Implemented`, queue is disabled. Check `QUEUE_ENABLED` in docker-compose.yml.

## Verification Tests

### Test 1: Submit a Job

```bash
curl -X POST http://localhost/api/v1/assessment/generate \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": "test-123",
    "skill_level": "intermediate",
    "topics": ["Python", "FastAPI"]
  }'
```

Expected response (202 Accepted):
```json
{
  "status": "queued",
  "request_id": "550e8400-e29b-41d4-a716-446655440000",
  "queue_position": 0,
  "estimated_wait_seconds": 30,
  "status_url": "/api/v1/queue/550e8400-e29b-41d4-a716-446655440000",
  "result_url": "/api/v1/queue/550e8400-e29b-41d4-a716-446655440000/result",
  "message": "Request queued for processing. Poll status_url for updates."
}
```

### Test 2: Check Job Status

```bash
curl http://localhost/api/v1/queue/550e8400-e29b-41d4-a716-446655440000
```

Status progression:
- `queued` → `processing` → `completed` (or `failed`)

### Test 3: Get Result

```bash
curl http://localhost/api/v1/queue/550e8400-e29b-41d4-a716-446655440000/result
```

If `202`, job still processing. If `200`, result ready.

### Test 4: Run Integration Test

```bash
cd api-gateway
python test_integration_simple.py
```

Should show:
- ✅ API is healthy
- ✅ Queue metrics
- ✅ Job queued
- ✅ Job completed
- ✅ Result retrieved
- ✅ Deduplication working
- ✅ INTEGRATION TEST COMPLETED SUCCESSFULLY

### Test 5: Run Load Test

```bash
cd api-gateway
python load_test.py
```

Sends 100 concurrent requests. Should show:
- ✅ Successfully queued: 95+/100
- ⚠️  Backpressure triggered: (if queue full - this is good!)
- ✅ Concurrency respected (active ≤ max_workers)
- 🎉 LOAD TEST PASSED

### Test 6: Check Redis Logs

```bash
docker-compose logs redis | grep -E "LPUSH|BLPOP"
```

Should see Redis operations:
- `LPUSH queue:assessment-agent` (enqueue)
- `BLPOP queue:assessment-agent` (dequeue)

### Test 7: Verify Pass-Through

GET requests should NOT be queued:

```bash
curl http://localhost/api/v1/task/list
```

Should get direct response (not 202).

## Monitoring in Production

### Key Metrics to Track

1. **Queue Depth** (`queue_size`)
   - Alert if > 400 (approaching max 500)
   - Indicates workers can't keep up

2. **Active Jobs** (`active_jobs`)
   - Should be ≤ QUEUE_MAX_WORKERS
   - If consistently at max, consider scaling

3. **Processing Time** (`avg_processing_time_seconds`)
   - Track trends over time
   - Spikes indicate agent slowness

4. **Failed Jobs** (`total_failed`)
   - Alert on increases
   - Investigate errors in logs

5. **Retry Rate** (`total_retried / total_processed`)
   - High rate indicates instability

### Grafana Dashboard (Future)

Add these queries to Grafana:

```promql
# Queue depth
redis_queue_size{agent="assessment-agent"}

# Processing rate
rate(queue_total_processed[5m])

# Failure rate
rate(queue_total_failed[5m]) / rate(queue_total_processed[5m])
```

## Troubleshooting

### Queue Not Enabled

**Symptom:** API returns 501 on `/api/v1/queue/metrics`

**Fix:**
```bash
# Check docker-compose.yml
grep QUEUE_ENABLED docker-compose.yml

# Should show: QUEUE_ENABLED=true
# If not, add it and restart:
docker-compose restart api-gateway
```

### Redis Connection Failed

**Symptom:** Logs show `❌ Failed to connect to Redis`

**Fix:**
```bash
# Check Redis is running
docker-compose ps redis

# Check Redis logs
docker-compose logs redis

# Verify REDIS_URL
docker-compose exec api-gateway env | grep REDIS_URL
# Should be: redis://redis:6379
```

### Jobs Not Processing

**Symptom:** Queue size keeps increasing, no jobs completing

**Fix:**
```bash
# Check worker loops started
docker-compose logs api-gateway | grep "Worker loop started"
# Should see 5 agents

# Check for errors in processing
docker-compose logs api-gateway | grep "Error processing job"

# Check agents are running
docker-compose ps assessment-agent planner-agent code-review-agent support-agent task-mgmt-agent
```

### High Failure Rate

**Symptom:** `total_failed` increasing

**Fix:**
```bash
# Check agent logs for errors
docker-compose logs assessment-agent | tail -100

# Check job error messages
curl http://localhost/api/v1/queue/{request_id}
# Look at "error" field

# Common causes:
# - Agent timeout (increase QUEUE_JOB_TIMEOUT)
# - Agent crash (check agent health)
# - Invalid payload (check sanitization)
```

### Queue Full (429 Responses)

**Symptom:** Clients getting 429 Too Many Requests

**Fix:**
```bash
# This is intentional backpressure, but if persistent:

# Option 1: Increase queue size
# In docker-compose.yml: QUEUE_MAX_SIZE=1000

# Option 2: Increase workers
# In docker-compose.yml: QUEUE_MAX_WORKERS=10

# Option 3: Scale agents horizontally
# Add more agent containers in docker-compose.yml

docker-compose up --build -d
```

## Rollback Strategy

If queue causes issues, disable immediately:

```yaml
# docker-compose.yml
environment:
  - QUEUE_ENABLED=false  # ← Disable queue
```

```bash
docker-compose restart api-gateway
```

All requests will pass through directly (original behavior).

## Performance Tuning

### Optimal Worker Count

Start with 5, adjust based on:
- **CPU usage**: If < 50%, can increase workers
- **Memory usage**: Each worker uses ~100MB
- **Agent capacity**: Don't overwhelm agents

Recommended:
- Development: 3-5 workers
- Production (single server): 5-10 workers
- Production (scaled): 10-20 workers per gateway instance

### Queue Size Limits

- **Too small** (< 100): Frequent 429 errors during spikes
- **Too large** (> 1000): Long wait times frustrate users
- **Recommended**: 500 (30s-2min wait at 5 workers)

### Result TTL

- **Too short** (< 300s): Users can't retrieve results
- **Too long** (> 3600s): Redis memory bloat
- **Recommended**: 1800s (30 min)

## Next Steps (Phase 2)

Future enhancements:

1. **Priority Queues**
   - Add `X-Request-Priority: high` header support
   - Process high-priority jobs first

2. **Webhook Callbacks**
   - Add `X-Callback-Webhook` header
   - POST results to user webhook when complete

3. **Dead Letter Queue**
   - Store permanently failed jobs for analysis
   - Add admin endpoint to retry

4. **Queue Visualization**
   - Web UI to see queue state
   - Real-time job tracking

5. **Per-User Limits**
   - Rate limit by user ID
   - Prevent single user from filling queue

## Success Criteria ✅

All implemented:
- ✅ Burst requests (100+) handled gracefully with queuing
- ✅ Concurrency limited to configured max (never exceeds)
- ✅ 429 backpressure triggers when queue exceeds threshold
- ✅ Request completes even if client disconnects (async processing)
- ✅ Results retrievable for 30 minutes after completion
- ✅ No duplicate processing for identical requests
- ✅ Retry logic works transparently (client doesn't see transient failures)
- ✅ Metrics accurately reflect queue state and throughput
- ✅ Zero impact to Nginx configuration (stays lightweight)
- ✅ Agents unchanged (remain HTTP services)

## Support

For issues, check:
1. Docker Compose logs: `docker-compose logs api-gateway`
2. Queue metrics: `curl http://localhost/api/v1/queue/metrics`
3. Redis logs: `docker-compose logs redis`
4. Agent health: `curl http://localhost/api/health`
