> **Superseded:** This document is retained for historical context. PRAXIS now uses a locally running Ollama model (`qwen2.5-coder:latest`) for all AI requests. See the root `README.md` and `.env.example` for current setup.

# OpenRouter Migration - Quick Reference Guide

## 🎯 TL;DR

All agents now use **OpenRouter** instead of Gemini/OpenAI/Groq. 
- **1 API key**: `OPENROUTER_API_KEY`
- **5 models**: Optimized per agent
- **60-70% cheaper**: ~$20-40/month
- **100% compatible**: No API changes needed for agents

---

## 🔧 Setup (5 minutes)

### Step 1: Get OpenRouter API Key
```
1. Go to https://openrouter.ai
2. Sign up / Login
3. API Keys section
4. Get your key: sk-or-xxxxx
```

### Step 2: Update .env
```bash
# Remove old keys:
# OPENAI_API_KEY=xxx
# GOOGLE_API_KEY=xxx
# GROQ_API_KEY=xxx

# Add new key:
OPENROUTER_API_KEY=sk-or-xxxxxxxxxxxxx
```

### Step 3: Update docker-compose.yml
```yml
# Already done! Just use:
- OPENROUTER_API_KEY=${OPENROUTER_API_KEY}
```

### Step 4: Install & Run
```bash
docker-compose build
docker-compose up
```

---

## 🚀 Testing Each Agent

### Assessment Agent
```bash
# Test endpoint
curl -X POST http://localhost:8001/api/assessment \
  -H "Content-Type: application/json" \
  -d '{"num_questions": 5, "project_title": "My Project"}'
```

### Planner Agent
```bash
# Test endpoint
curl -X POST http://localhost:8002/api/plan \
  -H "Content-Type: application/json" \
  -d '{"title": "My Project", "description": "Test"}'
```

### Support Agent
```bash
# Test endpoint
curl -X POST http://localhost:8005/api/chat \
  -H "Content-Type: application/json" \
  -d '{"user_id": "test123", "query": "Hello"}'
```

### Task-Mgmt Agent
```bash
# Test endpoint
curl -X POST http://localhost:8003/api/tasks \
  -H "Content-Type: application/json" \
  -d '{"project_plan": {"title": "Test"}}'
```

### Code-Review Agent
```bash
# Test endpoint
curl -X POST http://localhost:8004/api/v1/review \
  -H "Content-Type: application/json" \
  -d '{"repo_path": "."}'
```

---

## 📊 Model Reference

| Agent | Model | Cost/Token | Use Case |
|-------|-------|-----------|----------|
| Assessment | Mistral Large | $2.70/1M | Questions, grading |
| Planner | Llama 3.1 405B | $1.35/1M | Planning, strategy |
| Support | Qwen Max | $0.87/1M | Chat, support |
| Task-Mgmt | Mistral Large | $2.70/1M | Task breakdown |
| Code-Review | DeepSeek | $0.55/1M | Code analysis |

---

## 🔗 Using OpenRouter Service in Code

### Example 1: Basic Completion
```python
from shared.openrouter_service import call_llm

response = await call_llm(
    agent_type="support",
    messages=[
        {"role": "system", "content": "You are helpful"},
        {"role": "user", "content": "Hello!"}
    ],
    temperature=0.7
)
print(response)
```

### Example 2: JSON Output
```python
from shared.openrouter_service import call_llm_json

data = await call_llm_json(
    agent_type="assessment",
    messages=[
        {"role": "user", "content": "Generate 5 questions as JSON"}
    ]
)
```

### Example 3: Custom Service
```python
from shared.openrouter_service import OpenRouterService

service = OpenRouterService(agent_type="planner")
response = await service.generate_completion(
    messages=[...],
    temperature=0.7,
    max_tokens=3000
)
```

---

## ⚙️ Configuration by Agent

### Assessment Agent
**File**: `assessment-agent/llm_service.py`
```python
PRIMARY_MODEL = "mistralai/mistral-large-2407"
FALLBACK_MODEL = "qwen/qwen-max"
```

### Planner Agent
**File**: `planner-agent/app/core/planner.py`
```python
model = "meta-llama/llama-3.1-405b-instruct"
fallback_model = "mistralai/mistral-large-2407"
```

### Support Agent
**File**: `support-agent/config/settings.py`
```python
OPENROUTER_MODEL = "qwen/qwen-max"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
```

### Task-Mgmt Agent
**File**: `task-mgmt-agent/services/llm_service.py`
```python
PRIMARY_MODEL = "mistralai/mistral-large-2407"
FALLBACK_MODEL = "qwen/qwen-max"
```

### Code-Review Agent
**File**: `code-review-agent/app/main.py`
```python
OPENROUTER_MODEL = "deepseek/deepseek-chat"
OPENROUTER_FALLBACK = "meta-llama/llama-3.1-8b-instruct"
```

---

## 🐛 Common Issues & Fixes

| Issue | Cause | Fix |
|-------|-------|-----|
| "OPENROUTER_API_KEY not set" | Missing env var | Add key to .env & restart |
| "Model not found" | Wrong model ID | Check https://openrouter.ai/docs/models |
| "Timeout" | Slow response | Increase timeout or reduce input size |
| "401 Unauthorized" | Invalid API key | Verify key is correct and active |
| "429 Rate Limited" | Too many requests | Wait or upgrade plan |

---

## 📈 Monitoring & Costs

### Check Usage
1. Go to https://openrouter.ai/dashboard
2. View "Usage" tab
3. Monitor tokens and costs

### Estimate Monthly Cost
```
Assessment: 2M tokens × $2.70/1M = $5.40
Planner: 1M tokens × $1.35/1M = $1.35
Support: 500K tokens × $0.87/1M = $0.44
Task-Mgmt: 1M tokens × $2.70/1M = $2.70
Code-Review: 500K tokens × $0.55/1M = $0.28
─────────────────────────────────────
TOTAL: ~$10-15/month
```

---

## 📚 Files Changed Summary

### New Files
- `shared/openrouter_service.py` - Unified service
- `OPENROUTER_MIGRATION_PLAN.md` - Initial plan
- `OPENROUTER_IMPLEMENTATION_GUIDE.md` - Setup guide
- `OPENROUTER_MIGRATION_SUMMARY.md` - Complete summary

### Modified Files
- `.env.example` - Simplified env vars
- `docker-compose.yml` - Updated for OpenRouter
- `*/requirements.txt` - Updated dependencies (all agents)
- `*/llm_service.py` - Updated to use OpenRouter (assessment, task-mgmt)
- `support-agent/config/settings.py` - New config
- `support-agent/comprehensive_ai_service.py` - Updated to OpenRouter
- `planner-agent/app/core/planner.py` - Updated to OpenRouter
- `code-review-agent/app/main.py` - Updated to OpenRouter

---

## 🔄 Migration Path

### For Developers
1. Pull latest code
2. Update `.env` with OpenRouter key
3. Run `pip install -r requirements.txt` per agent
4. Test your specific agent
5. Report any issues

### For DevOps/Deployment
1. Update production `.env`
2. Run `docker-compose build`
3. Run `docker-compose up -d`
4. Monitor logs for errors
5. Check cost dashboard daily for first week

---

## ✅ Verification Checklist

```
□ OpenRouter API key generated
□ .env file updated with OPENROUTER_API_KEY
□ docker-compose.yml not manually changed (uses env var)
□ All requirements.txt updated
□ Docker builds successfully: docker-compose build
□ All services start: docker-compose up
□ Assessment agent responds
□ Planner agent responds
□ Support agent responds
□ Task-Mgmt agent responds
□ Code-Review agent responds
□ Cost tracking set up
```

---

## 🚨 Emergency Rollback (If Needed)

### Quick Rollback
```bash
# Restore old files
git checkout -- .

# Install old dependencies
pip install openai google-generativeai groq

# Update .env with old keys
# Restart services
```

### Selective Rollback (One Agent)
```bash
# Just revert that agent's code
git checkout -- assessment-agent/

# Keep others on OpenRouter
```

---

## 📞 Quick Support

**OpenRouter Status**: https://status.openrouter.ai  
**OpenRouter Docs**: https://openrouter.ai/docs  
**OpenRouter Models**: https://openrouter.ai/docs/models  
**OpenRouter Pricing**: https://openrouter.ai/pricing  

---

## 🎓 Learn More

- [Full Implementation Guide](./OPENROUTER_IMPLEMENTATION_GUIDE.md)
- [Migration Plan](./OPENROUTER_MIGRATION_PLAN.md)
- [Complete Summary](./OPENROUTER_MIGRATION_SUMMARY.md)
- [OpenRouter API Docs](https://openrouter.ai/docs)

---

**Ready to deploy?** You only need `OPENROUTER_API_KEY` to get started! 🚀
