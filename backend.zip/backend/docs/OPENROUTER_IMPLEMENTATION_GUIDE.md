> **Superseded:** This document is retained for historical context. PRAXIS now uses a locally running Ollama model (`qwen2.5-coder:latest`) for all AI requests. See the root `README.md` and `.env.example` for current setup.

# OpenRouter Migration - Implementation Guide

## Status: IN PROGRESS ✅

This document tracks the complete migration from Gemini, OpenAI, and Groq to OpenRouter across all PRAXIS agents.

---

## What Changed

### Provider Migration Summary

| Agent | Before | After | Cost Saving | Model |
|-------|--------|-------|-------------|-------|
| Assessment | Gemini 2.0-flash | OpenRouter | ~70% | Mistral Large 2407 |
| Planner | OpenAI GPT-4o | OpenRouter | ~90% | Llama 3.1 405B |
| Task-Mgmt | OpenAI GPT-4o-mini | OpenRouter | ~85% | Mistral Large 2407 |
| Support | Gemini 2.5-flash | OpenRouter | ~95% | Qwen Max |
| Code-Review | Groq Mixtral | OpenRouter | ~5% | DeepSeek Chat |

---

## Files Modified

### Core Services
- ✅ [shared/openrouter_service.py](../shared/openrouter_service.py) - NEW unified OpenRouter service
- ✅ [assessment-agent/llm_service.py](../assessment-agent/llm_service.py) - Updated to OpenRouter
- ✅ [task-mgmt-agent/services/llm_service.py](../task-mgmt-agent/services/llm_service.py) - Updated to OpenRouter
- ✅ [support-agent/config/settings.py](../support-agent/config/settings.py) - OpenRouter config
- ✅ [support-agent/comprehensive_ai_service.py](../support-agent/comprehensive_ai_service.py) - OpenRouter integration
- ⏳ [planner-agent/app/core/planner.py](../planner-agent/app/core/planner.py) - PENDING
- ⏳ [code-review-agent/app/main.py](../code-review-agent/app/main.py) - PENDING

### Configuration Files
- ✅ [assessment-agent/requirements.txt](../assessment-agent/requirements.txt) - Removed google-generativeai, added aiohttp
- ✅ [task-mgmt-agent/requirements.txt](../task-mgmt-agent/requirements.txt) - Removed openai, added aiohttp
- ✅ [support-agent/requirements.txt](../support-agent/requirements.txt) - Removed google-generativeai, added aiohttp
- ⏳ [code-review-agent/requirements.txt](../code-review-agent/requirements.txt) - PENDING
- ⏳ [planner-agent/requirements.txt](../planner-agent/requirements.txt) - PENDING
- ⏳ [.env.example](../.env.example) - PENDING (update api keys)
- ⏳ [docker-compose.yml](../docker-compose.yml) - PENDING (update env vars)

---

## Setup Instructions

### 1. Get OpenRouter API Key
1. Go to [openrouter.ai](https://openrouter.ai)
2. Sign up or login
3. Navigate to API Keys section
4. Generate a new API key
5. Keep it safe and secure

### 2. Update Environment Variables

#### Option A: Local Development (.env)
```bash
# Remove these:
# OPENAI_API_KEY=...
# GOOGLE_API_KEY=...
# GROQ_API_KEY=...

# Add this:
OPENROUTER_API_KEY=sk-or-xxxxxxxxxxxxxxxxxxxx
```

#### Option B: Docker Environment
Update your `.env` file used for docker-compose:
```bash
OPENROUTER_API_KEY=sk-or-xxxxxxxxxxxxxxxxxxxx
```

Then update docker-compose.yml environment variables (see docker-compose.yml updates below).

### 3. Update Docker Compose

Update [docker-compose.yml](../docker-compose.yml):
```yml
assessment-agent:
  build: ./assessment-agent
  environment:
    - PORT=8001
    - MONGODB_URI=${MONGODB_URI}
    - DATABASE_NAME=${DATABASE_NAME}
    - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}  # Changed

planner-agent:
  build: ./planner-agent
  environment:
    - PORT=8002
    - MONGODB_URI=${MONGODB_URI}
    - DATABASE_NAME=${DATABASE_NAME}
    - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}  # Changed

task-mgmt-agent:
  build: ./task-mgmt-agent
  environment:
    - PORT=8003
    - MONGODB_URI=${MONGODB_URI}
    - DATABASE_NAME=${DATABASE_NAME}
    - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}  # Changed

code-review-agent:
  build:
    context: .
    dockerfile: ./code-review-agent/Dockerfile
  environment:
    - PORT=8004
    - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}  # Changed
    - GITHUB_TOKEN=${GITHUB_TOKEN}
    - GITHUB_WEBHOOK_SECRET=${GITHUB_WEBHOOK_SECRET}
    - JWT_SECRET_KEY=${JWT_SECRET_KEY}
    - MONGODB_URI=${MONGODB_URI}
    - DATABASE_NAME=${DATABASE_NAME}

support-agent:
  build:
    context: .
    dockerfile: ./support-agent/Dockerfile
  environment:
    - PORT=8005
    - MONGODB_URI=${MONGODB_URI}
    - DATABASE_NAME=${DATABASE_NAME}
    - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}  # Changed
```

### 4. Install Dependencies

For each agent, update requirements:
```bash
# Assessment Agent
cd assessment-agent && pip install -r requirements.txt

# Planner Agent
cd planner-agent && pip install -r requirements.txt

# Task-Mgmt Agent
cd task-mgmt-agent && pip install -r requirements.txt

# Support Agent
cd support-agent && pip install -r requirements.txt

# Code-Review Agent
cd code-review-agent && pip install -r requirements.txt
```

Or if using docker:
```bash
docker-compose build
```

### 5. Start the Services

```bash
# Local development
docker-compose up

# Or with specific service
docker-compose up assessment-agent
```

---

## Model Selection Rationale

### Assessment Agent: Mistral Large 2407
**Why?** 
- Excellent at structured analysis and question generation
- Superior JSON output formatting
- Good at understanding educational contexts
- **Cost**: ~$2.70 per 1M input tokens

### Planner Agent: Llama 3.1 405B
**Why?**
-  Most capable model for complex planning tasks
- Better reasoning about project dependencies
- Excellent at multi-step decision making
- **Cost**: ~$1.35 per 1M input tokens

### Task-Mgmt Agent: Mistral Large 2407
**Why?**
- Consistent output format for task decomposition
- Good at task prioritization
- Reliable JSON generation
- **Cost**: ~$2.70 per 1M input tokens

### Support Agent: Qwen Max
**Why?**
- Cost-effective for conversational tasks
- Fast response times
- Good at understanding context and user sentiment
- **Cost**: ~$0.87 per 1M input tokens (Most affordable)

### Code-Review Agent: DeepSeek Chat
**Why?**
- Superior code understanding and analysis
- Better at identifying potential bugs
- Excellent code review comments
- **Cost**: ~$0.55 per 1M input tokens (Most affordable + best for code)

---

## Testing Checklist

- [ ] Assessment Agent generates questions correctly
- [ ] Planner Agent creates detailed project plans
- [ ] Task-Mgmt Agent breaks down tasks properly
- [ ] Support Agent provides relevant assistance
- [ ] Code-Review Agent analyzes code effectively
- [ ] All agents handle errors gracefully
- [ ] Response times are acceptable
- [ ] JSON parsing works correctly
- [ ] Fallback models work when needed
- [ ] Load testing completed

---

## Troubleshooting

### Issue: "OPENROUTER_API_KEY not set"
**Solution**: 
- Check `.env` file has `OPENROUTER_API_KEY` set
- In Docker, check docker-compose.yml has the env var
- Restart containers after changing env vars

### Issue: "OpenRouter API error: 401"
**Solution**:
- Verify API key is correct
- Check API key is still active on openrouter.ai
- Ensure no extra spaces in API key

### Issue: "Model not found" errors
**Solution**:
- Check model ID in code matches OpenRouter's available models
- Some models may require authentication upgrade
- Check OpenRouter's model list: https://openrouter.ai/docs/models

### Issue: "Timeout after XX seconds"
**Solution**:
- Check OpenRouter API status
- Increase timeout value if needed
- Verify internet connection
- Check if API is rate limiting requests

### Issue: JSON parsing errors
**Solution**:
- OpenRouter responses may have markdown wrappers
- Clean response before parsing JSON (already handled in code)
- Check model's JSON capabilities

---

## Rollback Plan

If issues occur, you can quickly rollback:

### Quick Rollback
1. Update `.env` file with old API keys
2. Revert the code changes:
   ```bash
   git checkout -- .
   ```
3. Reinstall old dependencies:
   ```bash
   pip install google-generativeai openai groq
   ```
4. Restart services

### Partial Rollback
If only one agent has issues:
1. Keep that agent's old code/env
2. Update each agent individually
3. Test in isolation before full rollback

---

## Cost Analysis

### Monthly Cost Estimate

**Before Migration** (Current Setup):
- OpenAI: $30-50/month
- Google Gemini: $20-30/month
- Groq: $0-10/month
- **Total: $50-90/month**

**After Migration** (OpenRouter):
- Mistral Large 2 (Assessment + Task-Mgmt): $5-10/month
- Llama 3.1 405B (Planner): $10-15/month
- Qwen Max (Support): $2-5/month
- DeepSeek Chat (Code-Review): $3-8/month
- **Total: $20-40/month** ✅ **60-70% Savings!**

---

## Next Steps

1. [ ] Generate OpenRouter API key
2. [ ] Update .env and docker-compose.yml
3. [ ] Run tests on each agent
4. [ ] Deploy to staging environment
5. [ ] Performance benchmarking
6. [ ] Deploy to production
7. [ ] Monitor API usage and costs

---

## Additional Resources

- [OpenRouter Documentation](https://openrouter.ai/docs)
- [Available Models](https://openrouter.ai/docs/models)
- [API Reference](https://openrouter.ai/api/v1/docs)
- [Pricing](https://openrouter.ai/pricing)

---

## Contact & Support

For issues or questions:
- Check logs: `docker logs <service-name>`
- Check OpenRouter status: https://status.openrouter.ai
- Review OpenRouter docs: https://openrouter.ai/docs
