# ObjectId Serialization Fix for Planner Agent

## Issue
**Error**: `pydantic_core._pydantic_core.PydanticSerializationError: Unable to serialize unknown type: <class 'bson.objectid.ObjectId'>`

**Scenario**: When adding Team Members/Resources to a project via PATCH request to `/projects/{project_id}`, the response contained nested ObjectId values that Pydantic couldn't serialize.

**Root Cause**: The team array contains TeamMember objects with `user` field as ObjectId. The previous serialization logic only converted top-level fields (`_id`, `user`, `tasks`) but not nested ObjectIds within complex objects like team members.

## Changes Made

### 1. **app/core/mongodb.py** - Enhanced `_serialize_project` method
**Before**: Only converted specific top-level fields to strings
```python
def _serialize_project(cls, project: Dict[str, Any]) -> Dict[str, Any]:
    project["_id"] = str(project["_id"])
    if "user" in project and isinstance(project["user"], ObjectId):
        project["user"] = str(project["user"])
    if "tasks" in project:
        project["tasks"] = [str(task_id) if isinstance(task_id, ObjectId) else task_id ...]
    return project
```

**After**: Recursively converts ALL ObjectIds to strings throughout the entire object tree
```python
def _serialize_project(cls, project: Dict[str, Any]) -> Dict[str, Any]:
    def convert_objectids(data: Any) -> Any:
        if isinstance(data, dict):
            return {key: convert_objectids(value) for key, value in data.items()}
        if isinstance(data, list):
            return [convert_objectids(item) for item in data]
        if isinstance(data, ObjectId):
            return str(data)
        return data
    return convert_objectids(project)
```

### 2. **app/api/routes.py** - Updated PATCH endpoint response handling
**Before**: Only converted `_id` field manually
```python
updated_project["_id"] = str(updated_project["_id"])
return updated_project
```

**After**: Uses the full recursive conversion function
```python
return convert_objectids(updated_project)
```

### 3. **app/api/models.py** - Updated Pydantic model configuration
**Changes**:
- Added `from pydantic import ConfigDict` import
- Updated `TeamMember`, `Resource`, `ProjectResponse`, and `ProjectUpdate` models to use Pydantic v2's `model_config`
- Added `json_encoders={ObjectId: str}` to all relevant models
- Updated `ProjectResponse` to use `populate_by_name=True` (replaces old `validate_by_name`)

**Models Updated**:
- `Resource`: Added `model_config` with ObjectId encoder
- `TeamMember`: Added `model_config` with ObjectId encoder
- `ProjectResponse`: Updated to modern ConfigDict with `populate_by_name=True`
- `ProjectUpdate`: Updated to use ConfigDict with `extra='ignore'` and ObjectId encoder

## Impact

✅ **Fixes the PATCH request error** when adding team members with ObjectId references
✅ **Handles all nested ObjectIds** throughout the project structure (team, resources, etc.)
✅ **Ensures consistent serialization** across all API responses
✅ **Future-proofs the code** with proper Pydantic v2 configuration

## Testing

To verify the fix works:
1. Make a PATCH request to `/agent/planner-agent/api/projects/{project_id}`
2. Include team members with ObjectId user references:
```json
{
  "team": [
    {"user": "698c3bc01bce470202fa5850", "role": "Frontend Developer"},
    {"user": "698f6f1d4a81b3a0fec88028", "role": "Backend Developer"}
  ]
}
```
3. The response should now return successfully with all ObjectIds converted to strings

## Files Modified
- [planner-agent/app/core/mongodb.py](planner-agent/app/core/mongodb.py#L182-L198)
- [planner-agent/app/api/routes.py](planner-agent/app/api/routes.py#L460-L505)
- [planner-agent/app/api/models.py](planner-agent/app/api/models.py#L1-L140)
