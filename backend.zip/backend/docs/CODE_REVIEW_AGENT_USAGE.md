# Code Review Agent - Quick Start Guide

## Overview
The Code Review Agent now saves all code reviews to MongoDB with complete structured data including comments, improvements, warnings, and recommendations.

## What Changed?

### Before
- Reviews generated but not persisted to database
- Fields like `comments`, `improvements`, `warningIssues` remained empty

### After
- Reviews automatically parsed into structured data
- All fields properly populated in database
- Full integration with MongoDB storage
- User association with reviews
- PR metadata captured

## Running the Service

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Set Environment Variables
```bash
export MONGODB_URI="mongodb+srv://user:pass@cluster.mongodb.net"
export DATABASE_NAME="praxis-aipm"
export OLLAMA_BASE_URL="http://localhost:11434"
export OLLAMA_MODEL="qwen2.5-coder:latest"
export GITHUB_TOKEN="ghp_..."
export GITHUB_WEBHOOK_SECRET="your-secret"
```

### 3. Start the Service
```bash
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Using the API

### Option 1: GitHub Webhook (Automatic)
GitHub will automatically send PR events. The service will:
1. Fetch the PR diff
2. Generate review with the local Ollama model
3. Parse review into structured data
4. Save to MongoDB
5. Return review_id

**Response:**
```json
{
  "status": "success",
  "review": "...",
  "review_id": "507f1f77bcf86cd799439011"
}
```

### Option 2: Direct API Call
```bash
curl -X POST http://localhost:8000/api/v1/review \
  -H "Authorization: Bearer <your-jwt-token>" \
  -H "Content-Type: application/json" \
  -d '{
    "repo_path": "https://github.com/user/repo/pull/123",
    "max_chunks": 6
  }'
```

**Response:**
```json
{
  "status": "success",
  "review": "...",
  "review_id": "507f1f77bcf86cd799439011",
  "repo_path": "https://github.com/user/repo/pull/123"
}
```

## Checking the Database

### View a Single Review
```bash
mongo
use praxis-aipm
db.ai_feedback.findOne({ _id: ObjectId("507f1f77bcf86cd799439011") })
```

### View All Reviews
```bash
db.ai_feedback.find().pretty()
```

### Count Issues
```bash
db.ai_feedback.aggregate([
  {
    $group: {
      _id: null,
      totalIssues: { $sum: "$totalIssues" },
      criticalIssues: { $sum: "$criticalIssues" },
      warningIssues: { $sum: "$warningIssues" }
    }
  }
])
```

### Find Reviews by User
```bash
db.ai_feedback.find({ user_id: "user-123" })
```

### Find Reviews by PR
```bash
db.ai_feedback.findOne({ pull_request_url: "https://github.com/org/repo/pull/42" })
```

## Response Structure

Each saved review contains:

### Metadata
- `_id`: Unique review identifier
- `user_id`: User who created the review
- `pull_request_url`: GitHub PR URL
- `created_at`: When review was created
- `updated_at`: Last update time
- `status`: "completed", "pending", "failed", or "reviewing"

### Analysis Data
```json
{
  "comments": [
    {
      "line": 15,
      "fileName": "src/main.py",
      "message": "Variable name is not descriptive",
      "severity": "warning",
      "category": "code-quality",
      "suggestion": "Use 'user_count' instead of 'uc'"
    }
  ],
  "strengths": [
    "Well-structured error handling",
    "Good variable naming conventions"
  ],
  "improvements": [
    "Add type hints to function parameters",
    "Extract complex logic into separate function"
  ],
  "recommendations": [
    "Address all code quality issues",
    "Consider optimizing database queries"
  ],
  "summary": "Code review completed"
}
```

### Issue Counts
- `totalIssues`: Total number of issues found
- `criticalIssues`: Security vulnerabilities + bugs
- `warningIssues`: Performance issues
- `infoIssues`: Suggestions and improvements

## Troubleshooting

### MongoDBException / Connection Error
**Error:** `Failed to connect to MongoDB`
- Check `MONGODB_URI` is set correctly
- Verify MongoDB service is running
- Check network connectivity

### Database Collection Not Found
- Database will be created on first write
- Indexes are created automatically

### Empty Comments/Improvements
- Check that the local Ollama service is responding correctly
- Review `review_text` contains proper markdown sections
- Check logs for parse errors

### Authentication Failed on /api/v1/review
- Ensure JWT token is passed in `Authorization: Bearer <token>` header
- Verify token is valid and not expired

## API Endpoints

### Health Check
```
GET /health
```

### Generate Review (Authenticated)
```
POST /api/v1/review
Headers: Authorization: Bearer <token>
Body: {
  "repo_path": "...",
  "max_chunks": 6,
  "chunk_size": 5000,
  "exclude_patterns": []
}
```

### GitHub Webhook
```
POST /api/v1/webhook/github
Headers: X-Hub-Signature-256: sha256=...
```

## Configuration Options

Environment variables for customization:

```bash
# Review size limits
REVIEW_MAX_CHUNKS=6              # Maximum chunks to review
REVIEW_CHUNK_SIZE=5000           # Characters per chunk
REVIEW_MAX_DIFF_CHARS=120000     # Maximum diff size

# Caching
REVIEW_USE_CACHE=true            # Enable response caching
REVIEW_CACHE_TTL_SECONDS=600     # Cache duration
REVIEW_RESULT_CACHE_TTL_SECONDS=600

# Model selection
OLLAMA_MODEL=qwen2.5-coder:latest
OLLAMA_BASE_URL=http://localhost:11434

# Database
MONGODB_URI=mongodb+srv://...
DATABASE_NAME=praxis-aipm
```

## Performance Notes

- Reviews are cached in memory to avoid redundant API calls
- MongoDB queries are indexed for fast lookups
- Async operations allow handling multiple reviews concurrently
- Review parsing is fast (typically < 100ms)

## Security

- GitHub webhook signatures are verified
- JWT tokens required for authenticated endpoints
- MongoDB credentials should be in environment variables
- API keys not logged in responses

## Support

For issues or questions, check the logs:

```bash
# View logs
tail -f logs.txt

# Or in Docker
docker logs <container-id>
```
