# PRAXIS Backend - Models Documentation

## Overview

This document provides comprehensive documentation for all data models used across the PRAXIS backend system. The models are organized by agent and use Pydantic for validation and serialization.

## Table of Contents

- [Architecture Overview](#architecture-overview)
- [Agent Models](#agent-models)
  - [Assessment Agent Models](#assessment-agent-models)
  - [Code Review Agent Models](#code-review-agent-models)
  - [Planner Agent Models](#planner-agent-models)
  - [Support Agent Models](#support-agent-models)
  - [Task Management Agent Models](#task-management-agent-models)
- [Common Patterns](#common-patterns)
- [Enum Types](#enum-types)

---

## Architecture Overview

The PRAXIS backend is divided into specialized agents, each managing specific functionality:

| Agent | Purpose | Key Models |
|-------|---------|-----------|
| **Assessment Agent** | Generate and evaluate skill assessments | Assessment, Question, AssessmentResult, AssessmentFeedback |
| **Code Review Agent** | Perform code reviews on pull requests | ReviewRequest, ReviewResponse, pull_requestInfo |
| **Planner Agent** | Create and manage project plans | ProjectCreate, ProjectResponse, ProjectPlanResponse |
| **Support Agent** | Manage user tasks and support requests | Task, UserProfile, TaskRecommendation |
| **Task Management Agent** | Track project tasks and progress | Task, SubTask, ProgressUpdate, GitHubCommit |

---

## Agent Models

### Assessment Agent Models

**Location:** `assessment-agent/models.py`

The Assessment Agent handles the creation, delivery, and evaluation of skill assessments.

#### Core Models

**DifficultyLevel** (Enum)
- `BEGINNER` - Beginner level difficulty
- `INTERMEDIATE` - Intermediate level difficulty
- `ADVANCED` - Advanced level difficulty

**QuestionType** (Enum)
- `MULTIPLE_CHOICE` - Multiple choice questions
- `TRUE_FALSE` - True/false questions
- `SHORT_ANSWER` - Short answer questions

**Question**
- `question` (str): The question text
- `type` (QuestionType): Type of the question
- `options` (List[str], optional): Answer options for MC/T-F
- `correct_answer` (str): The correct answer
- `explanation` (str): Explanation for the correct answer
- `points` (int, >= 1): Points awarded for correct answer

**Assessment**
- `id` (str, optional): Assessment ID
- `project_id` (str): Associated project ID
- `title` (str): Assessment title
- `description` (str): Assessment description
- `difficulty` (DifficultyLevel): Difficulty level
- `questions` (List[Question]): List of questions
- `total_points` (int): Sum of all question points
- `time_limit` (int): Time limit in minutes (default: 60)
- `created_at` (datetime): Creation timestamp
- `created_by` (str, optional): Creator identifier
- `status` (str): Assessment status (default: "active")

**AssessmentGenerationRequest**
- `project_id` (str): Project ID for assessment context
- `num_questions` (int): Number of questions (1-50, default: 10)
- `difficulty_level` (DifficultyLevel): Difficulty level (default: INTERMEDIATE)

#### Submission & Evaluation Models

**StudentAnswer**
- `question_index` (int): Index of the question
- `answer` (str): Student's answer

**AssessmentSubmission**
- `assessment_id` (str): Assessment being submitted
- `student_id` (str): Student identifier
- `answers` (List[StudentAnswer]): List of student answers
- `submitted_at` (datetime): Submission timestamp

**ScoreResult**
- `total_score` (int): Score obtained by student
- `max_score` (int): Maximum possible score
- `percentage` (float): Percentage score (0-100)
- `correct_answers` (int): Number of correct answers
- `total_questions` (int): Total number of questions

**QuestionFeedbackItem**
- `question_index` (int): Question index
- `question` (str): Question text
- `student_answer` (str): Student's answer
- `correct_answer` (str): Correct answer
- `is_correct` (bool): Whether answer is correct
- `points_earned` (int): Points earned
- `max_points` (int): Maximum points for question
- `feedback` (str): AI-generated feedback

**AssessmentFeedback**
- `overall_feedback` (str): Overall assessment feedback
- `strengths` (List[str]): Identified strengths
- `improvements` (List[str]): Areas for improvement
- `recommendations` (List[str]): Learning recommendations

**AssessmentResult**
- `id` (str, optional): Result ID
- `submission_id` (str): Associated submission ID
- `assessment_id` (str): Assessment ID
- `student_id` (str): Student identifier
- `score` (ScoreResult): Score breakdown
- `feedback` (AssessmentFeedback): Overall feedback
- `question_feedback` (List[QuestionFeedbackItem]): Per-question feedback
- `completed_at` (datetime): Completion timestamp
- `status` (str): Result status (default: "completed")

#### Comparison Models

**AssessmentComparisonStats**
- `assessment_id` (str): Assessment ID
- `assessment_title` (str): Assessment title
- `total_participants` (int): Total students who completed
- `your_score` (int): Your score
- `your_percentage` (float): Your percentage
- `your_rank` (int): Your rank among participants
- `students_scored_lower` (int): Students with lower scores
- `students_scored_higher` (int): Students with higher scores
- `average_score` (float): Average score of all
- `highest_score` (int): Highest score achieved
- `lowest_score` (int): Lowest score achieved
- `median_score` (float): Median score
- `top_performers` (List[TopPerformer]): Top 3 performers
- `performance_summary` (str): Human-readable summary

---

### Code Review Agent Models

**Location:** `code-review-agent/app/models.py`

The Code Review Agent handles GitHub integration and code review functionality.

**pull_requestInfo**
- `repo_owner` (str): Repository owner
- `repo_name` (str): Repository name
- `pr_number` (int): Pull request number
- `head_sha` (str): Head commit SHA
- `base_sha` (str): Base commit SHA

**WebhookPayload**
- `action` (str): Webhook action (opened, synchronize, etc.)
- `pull_request` (Dict[str, Any]): PR details from GitHub
- `repository` (Dict[str, Any]): Repository details from GitHub

**ReviewRequest**
- `diff` (str): Code diff to review
- `pr_info` (pull_requestInfo): PR information
- `language` (str, optional): Programming language
- `focus_areas` (List[str]): Areas to focus on (default: ["code_quality", "security", "performance", "best_practices"])

**ReviewResponse**
- `status` (str): Response status
- `review_id` (str): Unique review identifier
- `message` (str): Review message/comments
- `timestamp` (str): Review timestamp

**HealthResponse**
- `status` (str): Service status
- `version` (str): Service version
- `timestamp` (str): Response timestamp

---

### Planner Agent Models

**Location:** `planner-agent/app/api/models.py`

The Planner Agent manages project planning, resources, and timelines.

**Resource**
- `profile` (str): User profile type
- `skills` (List[str]): List of skills
- `experience` (str): Experience level
- `description` (str): Resource description
- `type` (str): Resource type
- `avatar` (str, optional): Avatar URL
- `username` (str, optional): Username
- `name` (str, optional): Full name
- `user` (str, optional): User identifier

**Sprint**
- `name` (str): Sprint name
- `progress` (float): Progress percentage
- `status` (str): Sprint status

**TimelineEvent**
- `title` (str): Event title
- `description` (str): Event description
- `type` (str): Event type
- `date` (datetime): Event date

**TeamMember**
- `user` (str): User identifier
- `role` (str): Role in the project

**ProjectCreate**
- `title` (str): Project title
- `description` (str): Project description
- `deadline` (datetime, optional): Project deadline
- `tags` (List[str]): Project tags
- `document` (str): Project document/SRS
- `created_by` (str): Creator identifier
- `status` (str): Project status (default: "planning")
- `tasks` (List[str]): Task identifiers
- `progress` (float): Progress percentage (default: 0)
- `team` (List[TeamMember]): Team members
- `sprints` (List[Sprint]): Project sprints
- `timeline` (List[TimelineEvent]): Timeline events
- `resources` (List[Resource]): Project resources

**ProjectResponse**
- Extends ProjectCreate with:
- `id` (PyObjectId): MongoDB ObjectId
- `created_at` (datetime): Creation timestamp
- `updated_at` (datetime): Last update timestamp

**ProjectPlanResponse**
- `project_id` (str): Project ID
- `summary` (str): Plan summary
- `skills_required` (List[str]): Required skills
- `milestones` (List[PlanMilestone]): Project milestones
- `high_level_tasks` (List[PlanHighLevelTask]): High-level tasks
- `risk_factors` (List[str]): Identified risks
- `generated_by` (str): AI service that generated plan
- `generated_at` (datetime): Generation timestamp

**Task**
- `task_name` (str): Task name
- `description` (str): Task description
- `dependencies` (List[str]): Task dependencies

**SubTask**
- `name` (str): Subtask name
- `description` (str): Subtask description
- `effort` (str): Effort estimation
- `technical_requirements` (List[str]): Technical requirements

**Milestone**
- `name` (str): Milestone name
- `timeline` (str): Timeline for milestone
- `deliverables` (List[str]): Deliverables

---

### Support Agent Models

**Location:** `support-agent/models.py`

The Support Agent handles user tasks, profiles, and support requests.

#### Enums

**TaskStatus**
- `TODO` - Task not started
- `IN_PROGRESS` - Task in progress
- `DONE` - Task completed
- `CANCELLED` - Task cancelled

**TaskPriority**
- `LOW` - Low priority
- `MEDIUM` - Medium priority
- `HIGH` - High priority
- `URGENT` - Urgent priority

**TaskType**
- `BUG` - Bug fix
- `FEATURE` - Feature development
- `REFACTOR` - Code refactoring
- `DOCUMENTATION` - Documentation
- `CHORE` - Maintenance task

**TaskComplexity**
- `SIMPLE` - Simple task
- `MODERATE` - Moderate complexity
- `COMPLEX` - Complex task
- `VERY_COMPLEX` - Very complex task

#### Core Models

**UserProfile**
- `user_id` (str): User identifier
- `name` (str): User name
- `email` (str): Email address
- `skills` (List[str]): List of skills
- `preferences` (Dict[str, Any]): User preferences
- `current_workload` (str): Current workload (light, medium, heavy)

**Task**
- `id` (str, optional): Task ID
- `user_id` (str): Associated user ID
- `title` (str): Task title
- `description` (str, optional): Task description
- `status` (TaskStatus): Task status (default: TODO)
- `priority` (TaskPriority): Task priority (default: MEDIUM)
- `assignee` (str, optional): Assigned user
- `estimated_hours` (float, optional): Estimated hours
- `actual_hours` (float, optional): Actual hours spent
- `due_date` (datetime, optional): Due date
- `created_at` (datetime): Creation timestamp
- `updated_at` (datetime): Last update timestamp
- `completed_at` (datetime, optional): Completion timestamp
- `tags` (List[str]): Task tags
- `ai_suggestions` (List[str]): AI-generated suggestions
- `ai_analysis` (str, optional): AI analysis

**TaskCreate**
- `title` (str): Task title
- `description` (str, optional): Task description
- `priority` (TaskPriority): Task priority (default: MEDIUM)
- `estimated_hours` (float, optional): Estimated hours
- `due_date` (datetime, optional): Due date
- `tags` (List[str]): Task tags

**TaskUpdate**
- All Task fields are optional for partial updates

**UserTaskQuery**
- `query` (str): Natural language query
- `context` (str, optional): Additional context

**UserTaskResponse**
- `message` (str): Response message
- `tasks` (List[Task], optional): Relevant tasks
- `suggestions` (List[str]): AI suggestions
- `analysis` (str, optional): Analysis result

**TaskRecommendation**
- `title` (str): Recommended task title
- `description` (str): Task description
- `reasoning` (str): Why this is recommended
- `priority` (TaskPriority): Recommended priority
- `estimated_hours` (float, optional): Estimated effort
- `tags` (List[str]): Relevant tags

#### Authentication Models

**UserRegister**
- `email` (str): Email address
- `password` (str): Password
- `full_name` (str): Full name
- `role` (str): User role (default: "student")

**UserLogin**
- `email` (str): Email address
- `password` (str): Password

**TokenResponse**
- `access_token` (str): JWT access token
- `refresh_token` (str): Refresh token
- `token_type` (str): Token type (default: "bearer")
- `user_id` (str): User identifier

#### Analysis Models

**TaskAnalysisRequest**
- `task_id` (str): Task to analyze
- `user_id` (str): User identifier

**TaskAnalysisResponse**
- `task_id` (str): Task ID
- `complexity` (TaskComplexity): Estimated complexity
- `estimated_hours` (float): Estimated effort
- `subtasks` (List[SubTask]): Suggested subtasks
- `risks` (List[str]): Identified risks
- `recommendations` (List[str]): Recommendations

---

### Task Management Agent Models

**Location:** `task-mgmt-agent/models.py`

The Task Management Agent handles project task tracking and GitHub integration.

**SubTask**
- `title` (str): Subtask title
- `description` (str): Subtask description
- `estimated_hours` (int): Estimated hours (default: 1)
- `status` (str): Status (default: "pending")

**Task**
- `id` (str, optional): Task ID
- `project_id` (str): Associated project ID
- `title` (str): Task title
- `description` (str): Task description
- `status` (str): Status (pending, in_progress, completed, blocked)
- `priority` (str): Priority (low, medium, high)
- `estimated_hours` (int): Estimated hours (default: 1)
- `actual_hours` (int): Actual hours spent (default: 0)
- `dependencies` (List[str]): List of dependency task IDs
- `sub_tasks` (List[SubTask]): List of subtasks
- `assigned_to` (str, optional): Assigned user
- `created_at` (datetime, optional): Creation timestamp
- `updated_at` (datetime, optional): Last update timestamp
- `due_date` (datetime, optional): Due date

**TaskCreate**
- `title` (str): Task title
- `description` (str): Task description
- `priority` (str): Priority (default: "medium")
- `estimated_hours` (int): Estimated hours (default: 1)
- `dependencies` (List[str]): Dependencies (default: [])
- `sub_tasks` (List[SubTask]): Subtasks (default: [])
- `assigned_to` (str, optional): Assigned user
- `due_date` (datetime, optional): Due date

**ProgressUpdate**
- `task_id` (str): Task being updated
- `status` (str): New status
- `hours_worked` (int): Hours worked in this update (default: 0)
- `notes` (str, optional): Update notes

**GitHubCommit**
- `commit_sha` (str): Commit SHA
- `message` (str): Commit message
- `author` (str): Commit author
- `timestamp` (datetime): Commit timestamp
- `files_changed` (List[str]): Files changed (default: [])
- `additions` (int): Lines added (default: 0)
- `deletions` (int): Lines deleted (default: 0)

**TaskAssignment**
- `task_id` (str): Task to assign
- `user_id` (str): Single user (for backward compatibility)
- `user_ids` (List[str], optional): Multiple users (new functionality)
- `notes` (str, optional): Assignment notes

**ProjectDashboard**
- `project_id` (str): Project ID
- `statistics` (Dict): Project statistics
- `tasks` (List[Task]): Project tasks
- `recent_commits` (List[Dict]): Recent GitHub commits
- `recent_progress` (List[Dict]): Recent progress updates

---

## Common Patterns

### Timestamps
All timestamp fields use `datetime` type:
- `created_at`: When the entity was created
- `updated_at`: When the entity was last modified
- `completed_at`: When the entity was completed
- `submitted_at`: When something was submitted

Use Pydantic's `Field(default_factory=datetime.now)` for automatic timestamp generation.

### Optional Fields
Fields marked as `Optional[T]` can be `None`. Always check if they exist before using:

```python
if task.completed_at is not None:
    print(f"Completed: {task.completed_at}")
```

### List Fields
Initialize empty lists with `Field(default_factory=list)`:

```python
questions: List[Question] = Field(default_factory=list)
```

### Enums
Use Enums for fixed sets of values. Always access the value with `.value`:

```python
priority: TaskPriority = TaskPriority.HIGH
print(priority.value)  # "high"
```

### MongoDB ObjectId
The `PyObjectId` class provides OpenAPI-compatible ObjectId handling:

```python
id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
```

---

## Enum Types Reference

### Assessment Agent
- **DifficultyLevel**: BEGINNER, INTERMEDIATE, ADVANCED
- **QuestionType**: MULTIPLE_CHOICE, TRUE_FALSE, SHORT_ANSWER

### Support Agent
- **TaskStatus**: TODO, IN_PROGRESS, DONE, CANCELLED
- **TaskPriority**: LOW, MEDIUM, HIGH, URGENT
- **TaskType**: BUG, FEATURE, REFACTOR, DOCUMENTATION, CHORE
- **TaskComplexity**: SIMPLE, MODERATE, COMPLEX, VERY_COMPLEX

### Task Management Agent
- **Status**: pending, in_progress, completed, blocked
- **Priority**: low, medium, high

---

## Usage Examples

### Creating an Assessment

```python
from assessment_agent.models import Assessment, Question, QuestionType, DifficultyLevel
from datetime import datetime

assessment = Assessment(
    project_id="proj_123",
    title="Python Fundamentals",
    description="Test Python basics",
    difficulty=DifficultyLevel.INTERMEDIATE,
    questions=[
        Question(
            question="What is Python?",
            type=QuestionType.SHORT_ANSWER,
            correct_answer="Python is a programming language",
            explanation="Python is a high-level, interpreted programming language",
            points=5
        )
    ],
    total_points=5,
    created_by="teacher_123"
)
```

### Creating a Task with Subtasks

```python
from task_mgmt_agent.models import Task, SubTask

task = Task(
    project_id="proj_456",
    title="Implement Authentication",
    description="Add JWT authentication",
    priority="high",
    estimated_hours=8,
    sub_tasks=[
        SubTask(
            title="Design auth flow",
            description="Design JWT authentication flow",
            estimated_hours=2
        ),
        SubTask(
            title="Implement login",
            description="Implement login endpoint",
            estimated_hours=3
        )
    ]
)
```

### Creating a Project Plan

```python
from planner_agent.models import ProjectCreate, TeamMember, Sprint

project = ProjectCreate(
    title="Web Application",
    description="Build a web application",
    document="SRS Document",
    created_by="user_789",
    team=[
        TeamMember(user="dev_001", role="backend"),
        TeamMember(user="dev_002", role="frontend")
    ],
    sprints=[
        Sprint(name="Sprint 1", progress=0.0, status="planning")
    ]
)
```

---

## Notes and Best Practices

1. **Always validate**: Pydantic automatically validates data on model instantiation
2. **Use type hints**: All models use strict type hints for IDE support
3. **Document changes**: Update this documentation when adding new models
4. **Default values**: Provide sensible defaults for optional fields
5. **Enum usage**: Prefer Enums over strings for categorical fields
6. **DateTime handling**: Always use `datetime` type, not string
7. **Database IDs**: Use `ObjectId` for MongoDB and `PyObjectId` for API compatibility

---

## Contributing

When adding new models:
1. Add them to the appropriate agent's `models.py`
2. Update this documentation with the new model schema
3. Include type hints and field descriptions
4. Use Pydantic's `Field` for validation and documentation
5. Add usage examples if the model is commonly used

