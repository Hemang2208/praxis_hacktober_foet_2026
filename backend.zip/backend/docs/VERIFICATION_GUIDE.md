# Code Review Agent - Verification & Testing Guide

## Quick Start Verification (5 minutes)

### Step 1: Run the Verification Script
```bash
cd s:\praxis-backend
python verify_code_review_integration.py
```

**Expected Output:**
```
✅ PASS   Environment Variables
✅ PASS   Dependencies
✅ PASS   Review Parser
✅ PASS   MongoDB Connection
✅ PASS   Database Save
```

If all pass, your setup is correct! ✅

---

## Manual Verification (Detailed)

### Step 1: Start the Service
```bash
cd s:\praxis-backend\code-review-agent
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Expected Output:**
```
✅ Connected to MongoDB
INFO:     Uvicorn running on http://0.0.0.0:8000
```

### Step 2: Check Health Endpoint
```bash
curl http://localhost:8000/health
```

**Response:**
```json
{"status": "healthy", "service": "code-review-agent"}
```

### Step 3: Test Review Generation & Save

#### Option A: Using API Endpoint
```bash
# Get a JWT token first (from your auth service)
TOKEN="your-jwt-token-here"

# Call review endpoint
curl -X POST http://localhost:8000/api/v1/review \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "repo_path": "https://github.com/torvalds/linux/pull/1",
    "max_chunks": 2
  }'
```

**Response should look like:**
```json
{
  "status": "success",
  "review": "### 🤖 AI Code Review\n\n Hello! I've taken a look...",
  "repo_path": "https://github.com/torvalds/linux/pull/1",
  "review_id": "507f1f77bcf86cd799439011"
}
```

#### Option B: Using GitHub Webhook
1. Go to GitHub repository → Settings → Webhooks
2. Add webhook: `http://your-server:8000/api/v1/webhook/github`
3. Set Secret to your `GITHUB_WEBHOOK_SECRET`
4. Trigger: Push event or create/update a PR
5. Service will auto-save review

### Step 4: Verify Data in MongoDB

```bash
# Connect to MongoDB
mongo "mongodb+srv://user:pass@cluster.mongodb.net"

# Switch to database
use praxis-aipm

# Find the review using review_id from response
db.ai_feedback.findOne({
  _id: ObjectId("507f1f77bcf86cd799439011")
})
```

**Verify these fields are populated:**
```javascript
{
  _id: ObjectId("507f1f77bcf86cd799439011"),
  
  // ✅ These should NOT be empty anymore:
  comments: [ ... ],           // Should have array of CodeComment objects
  improvements: [ ... ],       // Should have array of improvement strings
  recommendations: [ ... ],    // Should have actionable recommendations
  strengths: [ ... ],          // Should have strengths array
  
  // ✅ Issue counts should be > 0 if any issues found:
  totalIssues: 5,              // Total issues found
  criticalIssues: 1,           // Bugs + security issues
  warningIssues: 2,            // Performance issues
  infoIssues: 2,               // Info/suggestions
  
  // Metadata:
  user_id: "user-123",
  pull_request_url: "https://github.com/...",
  status: "completed",
  created_at: ISODate("2024-01-15T..."),
  analysisDate: ISODate("2024-01-15T...")
}
```

---

## What to Look For

### ✅ Success Indicators

1. **Comments Array Not Empty**
   ```javascript
   db.ai_feedback.findOne()
   // Should show: comments: [{ line: 15, message: "...", severity: "warning", ... }, ...]
   ```

2. **Issue Counts Are Numbers**
   ```javascript
   db.ai_feedback.findOne()
   // Should show: warningIssues: 3, not warningIssues: 0
   ```

3. **Improvements/Recommendations Populated**
   ```javascript
   db.ai_feedback.findOne()
   // Should show: improvements: ["Use type hints", "Extract functions"]
   ```

4. **Review ID Returned from API**
   ```
   Response includes: "review_id": "507f1f77bcf86cd799439011"
   ```

### ❌ Problem Indicators

1. **Empty Arrays After Save**
   - Check: Is the review_text being passed correctly?
   - Check: Does the review contain markdown sections (###)?
   - Check: Is the review_parser being called?

2. **Database Connection Error**
   - Check: MONGODB_URI environment variable
   - Check: MongoDB service is running
   - Check: Network connectivity to MongoDB

3. **"review_id: null" in Response**
   - Check: Database connection succeeded
   - Check: insert_one() returned an ID
   - Check: No exceptions in logs

4. **API Returns 401 Unauthorized**
   - Check: JWT token is valid
   - Check: Token is passed in Authorization header
   - Check: Token hasn't expired

---

## Testing Different Scenarios

### Scenario 1: PR Review via GitHub
**Steps:**
1. Create a PR in GitHub
2. Service receives webhook
3. Fetches diff
4. Generates review
5. Saves to DB

**Verify:**
```javascript
db.ai_feedback.findOne({
  pull_request_url: { $regex: /github.com.*pull/ }
})
```

### Scenario 2: Direct API Review
**Steps:**
1. Call `/api/v1/review` with PR URL
2. Service generates review
3. Saves to DB
4. Returns review_id

**Verify:**
```javascript
db.ai_feedback.findOne({ 
  _id: ObjectId("review_id_from_response") 
})
```

### Scenario 3: Local Repository Review
**Steps:**
1. Call `/api/v1/review` with local path
2. Service finds latest commit diff
3. Generates review
4. Saves to DB

**Verify:**
```javascript
db.ai_feedback.findOne({
  repository_url: "unknown"  // Local repos show "unknown"
})
```

---

## MongoDB Queries for Verification

### Count Total Reviews Saved
```javascript
db.ai_feedback.countDocuments({})
```

### Find Reviews with Issues
```javascript
db.ai_feedback.find({ totalIssues: { $gt: 0 } }).pretty()
```

### Find Reviews by User
```javascript
db.ai_feedback.find({ user_id: "user-123" }).pretty()
```

### Find Reviews by Status
```javascript
db.ai_feedback.find({ status: "completed" }).pretty()
```

### Get Statistics
```javascript
db.ai_feedback.aggregate([
  {
    $group: {
      _id: null,
      avgIssues: { $avg: "$totalIssues" },
      totalReviews: { $sum: 1 },
      totalIssuesFound: { $sum: "$totalIssues" }
    }
  }
])
```

### Find Latest Review
```javascript
db.ai_feedback.findOne({}, { sort: { created_at: -1 } }).pretty()
```

---

## Common Issues & Solutions

### Issue: "comments: []"
**Cause:** Review text might not contain the `### 🐛 Potential Bugs` section

**Solution:** 
- Check if the local Ollama model is returning a properly formatted review
- Verify review_text is not truncated
- Check parse_review_response() logs

### Issue: "warningIssues: 0" when there should be issues
**Cause:** Parser might not be identifying the sections correctly

**Solution:**
- Run `verify_code_review_integration.py` to test parser
- Check if review uses exact markdown format (###)
- Verify emoji characters are included

### Issue: Database connection fails with "auth failed"
**Cause:** Invalid MongoDB credentials

**Solution:**
- Check MONGODB_URI is correct
- Verify connection string format: `mongodb+srv://user:password@host`
- Ensure IP is whitelisted in MongoDB Atlas

### Issue: API returns "user_id not found in token"
**Cause:** JWT token doesn't have sub or user_id field

**Solution:**
- Check token is valid JWT
- Verify token contains sub or user_id claim
- Check authorization header format: `Authorization: Bearer <token>`

---

## Performance Testing

### Test Response Time
```bash
# Measure /api/v1/review endpoint response time
time curl -X POST http://localhost:8000/api/v1/review \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"repo_path": "..."}'
```

**Expected:** < 10 seconds for typical PR

### Test Database Performance
```javascript
// Check index usage
db.ai_feedback.aggregate([
  { $match: { user_id: "user-123" } },
  { $group: { _id: "$status", count: { $sum: 1 } } }
]).explain("executionStats")

// Should show COLLSCAN index used (indexed query)
```

### Stress Test
```bash
# Generate 100 API requests in parallel
for i in {1..100}; do
  curl -X POST http://localhost:8000/api/v1/review \
    -H "Authorization: Bearer $TOKEN" \
    -d "{\"repo_path\": \"...\"}" &
done
wait
```

---

## Debugging Steps

### Enable Verbose Logging
```python
# In app/main.py or app/database.py
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Check Logs
```bash
# Service logs
tail -f logs.txt

# Docker logs (if containerized)
docker logs code-review-agent -f

# MongoDB logs
# Check MongoDB Atlas logs for query performance
```

### Print Debug Info
```bash
# Add to app/service.py save_code_review_to_db()
logger.debug(f"Review text: {review_text[:200]}...")
logger.debug(f"Parsed data: {parsed}")
logger.debug(f"Feedback object: {feedback_dict}")
```

---

## Testing Checklist

- [ ] Environment variables are set
- [ ] Dependencies are installed
- [ ] MongoDB connection works
- [ ] Service starts without errors
- [ ] Health endpoint responds
- [ ] Review API returns 200 OK
- [ ] Review response includes review_id
- [ ] Database has new ai_feedback document
- [ ] Document has comments array (not empty)
- [ ] Document has improvements array (not empty)
- [ ] warningIssues count is > 0
- [ ] totalIssues count is > 0
- [ ] created_at timestamp is recent
- [ ] user_id matches authenticated user
- [ ] pull_request_url is correct

---

## Next Steps After Verification

Once everything is working:

1. **Integrate with UI**: Display reviews from `ai_feedback` collection
2. **Add Notifications**: Alert users when reviews are ready
3. **Mark as Read**: Add endpoint to update `isRead` field
4. **Student Feedback**: Allow students to rate reviews and add comments
5. **Analytics**: Track code quality trends over time
6. **Export**: Generate PDF reports of reviews

---

## Support & Troubleshooting

If you encounter issues:

1. Run `python verify_code_review_integration.py`
2. Check logs for error messages
3. Verify environment variables
4. Test MongoDB connection independently
5. Check that parser extracts expected sections

For detailed error logs, see `logs.txt` or container logs.
