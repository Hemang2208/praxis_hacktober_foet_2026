# Queue System Quick Start

## What This Does

The Redis-backed queue system transforms your API gateway from synchronous to asynchronous request handling with 2-tier priority routing:

**Before (Synchronous):**
```
Client → API Gateway → Agent → Response (wait 30s+)
```

**After (Async with Priority Queue):**
```
Client → API Gateway → queue:high:{agent}  ─┐
                     → queue:normal:{agent} ─┤→ Worker Pool → Agent → Store Result
                     → 202 Accepted (instant) ↓
Client polls → Get Result
```

Workers always drain `queue:high:{agent}` first. Normal jobs only get picked up when the high queue is empty.

## Quick Start (30 seconds)

### 1. Start the system
```bash
docker-compose up --build
```

### 2. Verify it's working
```bash
curl http://localhost/api/v1/queue/metrics
```

Should return queue stats (not 501).

### 3. Test a normal job
```bash
curl -X POST http://localhost/api/v1/assessment/generate \
  -H "Content-Type: application/json" \
  -d '{"project_id": "test", "skill_level": "intermediate", "topics": ["Python"]}'
```

### 4. Test a high-priority job
```bash
curl -X POST http://localhost/api/v1/assessment/generate \
  -H "Content-Type: application/json" \
  -H "X-Request-Priority: high" \
  -d '{"project_id": "test", "skill_level": "intermediate", "topics": ["Python"]}'
```

Both return 202. High-priority one jumps the queue.

### 4. Check status
```bash
curl http://localhost/api/v1/queue/{request_id}
```

### 5. Get result
```bash
curl http://localhost/api/v1/queue/{request_id}/result
```

## Files Overview

| File | Purpose |
|------|---------|
| `queue_manager.py` | Core queue logic (600 lines) |
| `main.py` | Modified gateway with workers |
| `test_queue.py` | Unit tests |
| `test_integration_simple.py` | Integration test |
| `load_test.py` | Load test (100 requests) |
| `QUEUE_DEPLOYMENT_GUIDE.md` | Full deployment docs |

## Configuration

Environment variables in `docker-compose.yml`:

```yaml
QUEUE_ENABLED=true          # Enable/disable queue
QUEUE_MAX_WORKERS=5         # Concurrent workers (1-20)
QUEUE_MAX_SIZE=500          # Max queue before 429
QUEUE_RESULT_TTL=1800       # Result TTL seconds (30 min)
QUEUE_JOB_TIMEOUT=3600      # Job timeout seconds (1 hour)
QUEUE_RETRY_MAX=3           # Max retries per job
```

## How It Works

### Request Flow

1. **Client sends POST** to `/api/v1/assessment/generate`
2. **Gateway checks:** Should this be queued?
   - ✅ Queue: POST/PUT/PATCH to AI agents
   - ❌ Pass-through: GET requests, health checks
3. **If queued:**
   - Read `X-Request-Priority` header (`high` or `normal`, default `normal`)
   - Generate unique `request_id`
   - Check for duplicates
   - Push to `queue:high:{agent}` or `queue:normal:{agent}`
   - Return `202 Accepted` immediately with `priority` field
4. **Worker loop:**
   - Non-blocking RPOP from `queue:high:{agent}` first
   - If empty, blocking BRPOP from `queue:normal:{agent}`
   - Forwards to agent via HTTP
   - Stores result in Redis
   - Updates job status
5. **Client polls:**
   - GET `/api/v1/queue/{request_id}` → status + priority
   - GET `/api/v1/queue/{request_id}/result` → final result

### Queue Decision Logic

**Queued Requests:**
- `POST /api/v1/assessment/*`
- `POST /api/v1/planner/*`
- `POST /api/v1/code-review/*`
- `POST /api/v1/support/*`
- `POST /api/v1/task/*` (write operations)

**Pass-Through (Direct):**
- All `GET` requests
- `OPTIONS` (CORS)
- Health endpoints
- Admin endpoints

## Testing

### Run all tests
```bash
cd api-gateway

# Unit tests (requires Redis)
pytest test_queue.py -v --asyncio-mode=auto

# Integration test (requires full stack)
python test_integration_simple.py

# Load test (100 concurrent requests)
python load_test.py
```

## Monitoring

### Check queue health
```bash
curl http://localhost/api/v1/queue/metrics | jq
```

Returns:
```json
{
  "queue_size": 14,
  "high_queue_size": 2,
  "normal_queue_size": 12,
  "active_jobs": 5,
  "total_processed": 1543,
  "total_failed": 7,
  "total_retried": 15,
  "avg_wait_time_seconds": 8.3,
  "avg_processing_time_seconds": 45.2,
  "per_agent": {
    "assessment-agent": {"high": 1, "normal": 4, "total": 5},
    "planner-agent":    {"high": 1, "normal": 8, "total": 9},
    "support-agent":    {"high": 0, "normal": 0, "total": 0}
  }
}
```

### Watch Redis operations
```bash
docker-compose logs redis | grep -E "LPUSH|BLPOP"
```

### Monitor worker logs
```bash
docker-compose logs -f api-gateway | grep "Processing job"
```

## Troubleshooting

### Queue returns 501
```bash
# Queue disabled - enable it:
# Edit docker-compose.yml → QUEUE_ENABLED=true
docker-compose restart api-gateway
```

### Jobs not processing
```bash
# Check workers started
docker-compose logs api-gateway | grep "Worker loop started"

# Should see 5 lines (one per agent)
```

### Queue full (429 errors)
```bash
# Temporary spike - normal backpressure
# If persistent, increase workers or queue size

# Edit docker-compose.yml:
# QUEUE_MAX_WORKERS=10
# QUEUE_MAX_SIZE=1000
docker-compose restart api-gateway
```

## Disable Queue (Rollback)

```yaml
# docker-compose.yml
environment:
  - QUEUE_ENABLED=false  # ← Set to false
```

```bash
docker-compose restart api-gateway
```

All requests pass through directly (original behavior).

## Architecture Diagram

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ POST /api/v1/assessment/generate
       ▼
┌─────────────────────────────────────┐
│       API Gateway (Port 8000)       │
│  ┌────────────────────────────┐     │
│  │  Queue Decision Logic      │     │
│  │  • POST → Queue            │     │
│  │  • GET → Pass-through      │     │
│  └────────────────────────────┘     │
│         ↓                    ↓       │
│  ┌──────────┐        ┌──────────┐   │
│  │  Enqueue │        │  Direct  │   │
│  │  to Redis│        │  Proxy   │   │
│  └──────────┘        └──────────┘   │
└───────┬──────────────────┬──────────┘
        │                  │
        ▼                  ▼
  ┌─────────┐      ┌─────────────┐
  │  Redis  │      │  Agents     │
  │  Queue  │      │  (Direct)   │
  └────┬────┘      └─────────────┘
       │
       ▼
┌────────────────────┐
│   Worker Pool (5)  │
│  ┌──────────────┐  │
│  │ Worker Loop  │  │  (per agent)
│  │ • Dequeue    │  │
│  │ • Proxy      │  │
│  │ • Store      │  │
│  └──────────────┘  │
└─────────┬──────────┘
          │
          ▼
    ┌──────────┐
    │  Agents  │
    │  (HTTP)  │
    └──────────┘
```

## Priority Queue

Just send `X-Request-Priority: high` and it goes to the front of the line:

```bash
# no header = normal, goes into regular queue
curl -X POST http://localhost/api/v1/planner/projects/123/plan \
  -H "Content-Type: application/json" -d '{}'

# high priority — jumps ahead of everything in the normal queue
curl -X POST http://localhost/api/v1/planner/projects/123/plan \
  -H "Content-Type: application/json" \
  -H "X-Request-Priority: high" \
  -d '{}'
```

The 202 tells you which tier it landed in:
```json
{
  "status": "queued",
  "priority": "high",
  "request_id": "550e8400-...",
  "queue_position": 0,
  "status_url": "/api/v1/queue/550e8400-...",
  "result_url": "/api/v1/queue/550e8400-.../result"
}
```

Redis keys:
```
queue:high:{agent}    # RPOP first, non-blocking
queue:normal:{agent}  # BRPOP fallback, blocks until something arrives
```

## Benefits

✅ **Handles traffic spikes** - Queue buffers burst requests  
✅ **Controlled concurrency** - Never overwhelm agents/DB  
✅ **2-tier priority** - High-priority jobs never wait behind batch work  
✅ **Graceful degradation** - 429 instead of crashes  
✅ **Better UX** - Instant 202, poll for results  
✅ **Fault tolerant** - Jobs persist in Redis, survive restarts  
✅ **No duplicate work** - Request fingerprinting prevents duplication  
✅ **Easy monitoring** - Metrics endpoint with per-agent breakdown  
✅ **Zero agent changes** - Agents remain simple HTTP services  

For detailed docs, see `QUEUE_DEPLOYMENT_GUIDE.md`.
