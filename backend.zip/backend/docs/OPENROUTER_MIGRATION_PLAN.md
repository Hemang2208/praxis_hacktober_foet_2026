> **Superseded:** This document is retained for historical context. PRAXIS now uses a locally running Ollama model (`qwen2.5-coder:latest`) for all AI requests. See the root `README.md` and `.env.example` for current setup.

# OpenRouter Migration Plan for PRAXIS Backend

## Current Model Usage Summary

| Agent | Current Provider | Current Model | Use Case |
|-------|------------------|---------------|----------|
| **Assessment Agent** | Google Generative AI | Gemini 2.0-flash | Data analysis, question generation, grading |
| **Planner Agent** | OpenAI | GPT-4o (with fallback) | Project planning, detailed task breakdown |
| **Support Agent** | Google Generative AI | Gemini 2.5-flash | User support, Q&A, task recommendations |
| **Task-Mgmt Agent** | OpenAI | GPT-4o-mini | Task decomposition, planning |
| **Code-Review Agent** | Groq | Mixtral 8x7B | Code review, diff analysis |

---

## OpenRouter Best Models by Use Case

### Tier 1: High-Performance Models (Best Quality)
- **Anthropic Claude 3.5 Sonnet** - Best for reasoning, code, planning
  - Model ID: `anthropic/claude-3.5-sonnet`
  - Pricing: Moderate (~$3/$15 per 1M tokens)
  - Best for: Complex planning, code review, detailed analysis

- **OpenAI GPT-4 Turbo** - High performance
  - Model ID: `openai/gpt-4-turbo`
  - Pricing: Premium (~$10/$30 per 1M tokens)
  - Best for: Complex tasks requiring high reliability

### Tier 2: Mid-Tier Models (Good Balance - RECOMMENDED)
- **Mistral Large 2** - Excellent for planning & analysis
  - Model ID: `mistralai/mistral-large-2407`
  - Pricing: ~$2/$6 per 1M tokens
  - Best for: Project planning, task generation ✓

- **DeepSeek-V3** - Strong reasoning, balanced
  - Model ID: `deepseek/deepseek-chat`
  - Pricing: Very affordable
  - Best for: Code review, general tasks ✓

- **Meta Llama 3.1 405B** - Open source, powerful
  - Model ID: `meta-llama/llama-3.1-405b-instruct`
  - Pricing: Moderate (~$1.35/$4.05 per 1M tokens)
  - Best for: General purpose, planning ✓

### Tier 3: Lightweight/Free Models (Cost-Effective)
- **Qwen 2.5 7B** - Fast, affordable
  - Model ID: `qwen/qwen-max`
  - Pricing: Very low (~$0.87/$2.60 per 1M tokens)
  - Best for: Support tasks, general Q&A ✓

- **Neural Chat 7B** - Fast responses
  - Model ID: `intel/neural-chat-7b`
  - Pricing: ~$0.87/$2.60 per 1M tokens
  - Best for: Support, Q&A ✓

---

## Recommended Migration Strategy

### Priority Assignment by Agent

#### 1. **Assessment Agent** (Gemini 2.0-flash → Mistral Large 2)
- **Reason**: Needs strong analysis for question generation and grading
- **Model**: `mistralai/mistral-large-2407`
- **Cost Savings**: ~70% cheaper than Gemini
- **Capabilities**: Excellent at structured responses (JSON grading)

#### 2. **Planner Agent** (GPT-4o → Mistral Large 2 or Llama 3.1 405B)
- **Reason**: Needs complex planning capabilities
- **Primary Model**: `meta-llama/llama-3.1-405b-instruct`
- **Fallback Model**: `mistralai/mistral-large-2407`
- **Cost Savings**: ~80-90% cheaper than GPT-4o

#### 3. **Support Agent** (Gemini 2.5-flash → Qwen 2.5 7B)
- **Reason**: Conversational, supportive responses - doesn't need complex reasoning
- **Model**: `qwen/qwen-max`
- **Cost Savings**: ~95% cheaper
- **Rationale**: Fast, user-friendly responses for support queries

#### 4. **Task-Mgmt Agent** (GPT-4o-mini → Mistral Large 2)
- **Reason**: Task generation requires good structure and grammar
- **Model**: `mistralai/mistral-large-2407`
- **Cost Savings**: ~85% cheaper than GPT-4o-mini

#### 5. **Code-Review Agent** (Groq Mixtral → DeepSeek-V3)
- **Reason**: Already using open source - DeepSeek is better for code
- **Model**: `deepseek/deepseek-chat`
- **Cost Savings**: Similar cost, better code understanding

---

## Complete Model Assignment Table

| Agent | New Model | Model ID | Reasoning |
|-------|-----------|----------|-----------|
| Assessment | Mistral Large 2 | `mistralai/mistral-large-2407` | Good at structured analysis |
| Planner | Llama 3.1 405B | `meta-llama/llama-3.1-405b-instruct` | Best for complex planning |
| Support | Qwen 2.5 7B | `qwen/qwen-max` | Cost-effective for support |
| Task-Mgmt | Mistral Large 2 | `mistralai/mistral-large-2407` | Good JSON/task structure |
| Code-Review | DeepSeek-V3 | `deepseek/deepseek-chat` | Superior code understanding |

---

## Migration Steps

### Phase 1: Setup
- [ ] Update `.env.example` to use `OPENROUTER_API_KEY` instead of individual keys
- [ ] Update `docker-compose.yml` to use `OPENROUTER_API_KEY`
- [ ] Install OpenRouter-compatible Python SDK

### Phase 2: Code Updates
- [ ] Assessment Agent: Replace Google Generative AI with OpenRouter
- [ ] Planner Agent: Replace OpenAI with OpenRouter
- [ ] Support Agent: Replace Google Generative AI with OpenRouter
- [ ] Task-Mgmt Agent: Replace OpenAI with OpenRouter
- [ ] Code-Review Agent: Replace Groq with OpenRouter

### Phase 3: Testing & Validation
- [ ] Test each agent with new models
- [ ] Validate output quality and speed
- [ ] Performance benchmarking

### Phase 4: Documentation
- [ ] Update README files
- [ ] Document model choices and rationale
- [ ] Create fallback strategy

---

## Environment Variable Changes

**From:**
```
OPENAI_API_KEY=xxx
GOOGLE_API_KEY=xxx
GROQ_API_KEY=xxx
```

**To:**
```
OPENROUTER_API_KEY=xxx
```

---

## Cost Comparison (Approximate Monthly)

### Current Setup (Estimated)
- OpenAI GPT-4o: ~$30-50/month
- Google Gemini: ~$20-30/month
- Groq: Free-$10/month
- **Total**: ~$50-90/month

### Proposed OpenRouter Setup
- Mistral Large 2 (Assessment + Task-Mgmt): ~$5-10/month
- Llama 3.1 405B (Planner): ~$10-15/month
- Qwen 7B (Support): ~$2-5/month
- DeepSeek-V3 (Code-Review): ~$3-8/month
- **Total**: ~$20-40/month (**60-70% savings**)

---

## Next Steps
1. Create replacement implementations for each agent
2. Test with OpenRouter API
3. Gradually migrate services
4. Monitor quality and performance
