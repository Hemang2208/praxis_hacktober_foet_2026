# Authentication Guide - PRAXIS Backend

This guide explains how to authenticate with the PRAXIS backend services using JWT (JSON Web Tokens). Clerk has been removed; all authentication is now handled natively.

---

## Overview

Two services require authentication:
- **Support-Agent** (port 8005): Full user account management + protected task/assistant routes
- **Code-Review-Agent** (port 8004): Protected `/review` endpoints

Both use the same shared JWT secret (`JWT_SECRET_KEY`).

---

## Flow

```
1. Register  →  POST /api/v1/auth/register
2. Login     →  POST /api/v1/auth/login  →  get access_token + refresh_token
3. Use API   →  Authorization: Bearer <access_token>
4. Refresh   →  POST /api/v1/auth/refresh  (when access token expires)
5. Logout    →  POST /api/v1/auth/logout
```

---

## Endpoints (Support-Agent)

### Register
```http
POST http://localhost:8005/api/v1/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "your_password",
  "full_name": "Your Name",
  "role": "student"
}
```
**Response:**
```json
{ "message": "User registered successfully", "user_id": "64abc..." }
```

### Login
```http
POST http://localhost:8005/api/v1/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "your_password"
}
```
**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "user_id": "64abc..."
}
```

### Refresh Token
```http
POST http://localhost:8005/api/v1/auth/refresh
Content-Type: application/json

{ "refresh_token": "<your_refresh_token>" }
```

### Logout
```http
POST http://localhost:8005/api/v1/auth/logout
Authorization: Bearer <your_access_token>
```

---

## Using Protected Endpoints

Add the `Authorization` header to every request:

```bash
curl -X GET "http://localhost:8005/api/v1/my-tasks/" \
  -H "Authorization: Bearer <your_access_token>"
```

```python
import requests

headers = {"Authorization": f"Bearer {access_token}"}
response = requests.get("http://localhost:8005/api/v1/my-tasks/", headers=headers)
```

```typescript
const response = await fetch("http://localhost:8005/api/v1/my-tasks/", {
  headers: { "Authorization": `Bearer ${accessToken}` }
});
```

---

## Token Details

| Token | Expiry | Purpose |
|-------|--------|---------|
| Access Token | 30 minutes | Authenticate API requests |
| Refresh Token | 7 days | Get a new access token |

---

## Public Endpoints (no auth required)

| Service | Endpoint |
|---------|----------|
| Support-Agent | `GET /` |
| Support-Agent | `GET /health` |
| Code-Review-Agent | `GET /health` |
| Code-Review-Agent | `POST /webhook/github` |

---

## Code-Review-Agent

The Code-Review-Agent uses the same JWT tokens. Protected routes:
- `POST /review`
- `POST /review/sync`

```bash
curl -X POST "http://localhost:8004/review/sync" \
  -H "Authorization: Bearer <your_access_token>" \
  -H "Content-Type: application/json" \
  -d '{"repo": "owner/repo", "pr_number": 42}'
```

---

## Environment Variables

Add to your `.env` file:

```env
JWT_SECRET_KEY=your-very-long-random-secret-key-at-least-32-characters
```

> ⚠️ **Important**: Use a strong, random secret in production. Never commit this value.

---

## Shared Module

The JWT logic lives in `shared/auth_utils.py` and is used by both agents. Any new microservice can import from it by adding the `shared/` directory to the Python path.
