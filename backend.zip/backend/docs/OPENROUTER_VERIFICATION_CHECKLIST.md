> **Superseded:** This document is retained for historical context. PRAXIS now uses a locally running Ollama model (`qwen2.5-coder:latest`) for all AI requests. See the root `README.md` and `.env.example` for current setup.

# OpenRouter Migration - Verification Checklist

## Pre-Deployment Verification

Use this checklist to verify the migration is complete and working correctly.

---

## ✅ Prerequisites (Before Starting)

- [ ] You have Docker installed
- [ ] You have a OpenRouter account
- [ ] You have a valid OpenRouter API key
- [ ] MongoDB is running and accessible
- [ ] All git changes are committed

---

## ✅ Configuration Verification

### Check Environment Variables
```bash
# Verify .env exists
test -f .env && echo "✓ .env exists" || echo "✗ .env missing"

# Check OPENROUTER_API_KEY is set
grep -q "OPENROUTER_API_KEY" .env && echo "✓ OPENROUTER_API_KEY found" || echo "✗ OPENROUTER_API_KEY missing"

# Check old keys are NOT present (optional - for cleanup)
echo "Old keys to remove:"
grep "OPENAI_API_KEY\|GOOGLE_API_KEY\|GROQ_API_KEY" .env || echo "✓ Old keys already removed"
```

### Check Docker Compose
```bash
# Verify all services use OPENROUTER_API_KEY
grep -c "OPENROUTER_API_KEY" docker-compose.yml
# Should output: 5 (one for each agent)
```

---

## ✅ Dependencies Verification

### Check Requirements Files
```bash
# Assessment Agent
grep -q "aiohttp" assessment-agent/requirements.txt && echo "✓ Assessment Agent: aiohttp present" || echo "✗ Missing aiohttp"
grep -q "google-generativeai" assessment-agent/requirements.txt && echo "✗ Assessment Agent: Old google-generativeai still present" || echo "✓ Assessment Agent: Old dependency removed"

# Task-Mgmt Agent
grep -q "aiohttp" task-mgmt-agent/requirements.txt && echo "✓ Task-Mgmt Agent: aiohttp present" || echo "✗ Missing aiohttp"
grep -q "openai" task-mgmt-agent/requirements.txt && echo "✗ Task-Mgmt Agent: Old openai still present" || echo "✓ Task-Mgmt Agent: Old dependency removed"

# Support Agent
grep -q "aiohttp" support-agent/requirements.txt && echo "✓ Support Agent: aiohttp present" || echo "✗ Missing aiohttp"
grep -q "google-generativeai" support-agent/requirements.txt && echo "✗ Support Agent: Old google-generativeai still present" || echo "✓ Support Agent: Old dependency removed"

# Code-Review Agent
grep -q "groq" code-review-agent/requirements.txt && echo "✗ Code-Review Agent: Old groq still present" || echo "✓ Code-Review Agent: Old dependency removed"

# Planner Agent
grep -q "openai" planner-agent/app/requirements.txt && echo "✗ Planner Agent: Old openai still present" || echo "✓ Planner Agent: Old dependency removed"
```

---

## ✅ Code Changes Verification

### Check OpenRouter Service
```bash
# Verify service file exists
test -f shared/openrouter_service.py && echo "✓ OpenRouter service created" || echo "✗ OpenRouter service missing"

# Verify service has required methods
grep -q "generate_completion" shared/openrouter_service.py && echo "✓ generate_completion method found"
grep -q "generate_json_completion" shared/openrouter_service.py && echo "✓ generate_json_completion method found"
grep -q "MODELS = {" shared/openrouter_service.py && echo "✓ Model configurations found"
```

### Check Agent Updates
```bash
# Assessment Agent
grep -q "OPENROUTER_API_KEY" assessment-agent/llm_service.py && echo "✓ Assessment Agent updated" || echo "✗ Assessment Agent not updated"

# Task-Mgmt Agent
grep -q "OPENROUTER_API_KEY" task-mgmt-agent/services/llm_service.py && echo "✓ Task-Mgmt Agent updated" || echo "✗ Task-Mgmt Agent not updated"

# Support Agent
grep -q "OPENROUTER_API_KEY" support-agent/config/settings.py && echo "✓ Support Agent config updated" || echo "✗ Support Agent config not updated"
grep -q "aiohttp" support-agent/comprehensive_ai_service.py && echo "✓ Support Agent service updated" || echo "✗ Support Agent service not updated"

# Planner Agent
grep -q "OPENROUTER_API_KEY" planner-agent/app/core/planner.py && echo "✓ Planner Agent updated" || echo "✗ Planner Agent not updated"

# Code-Review Agent
grep -q "OPENROUTER_API_KEY" code-review-agent/app/main.py && echo "✓ Code-Review Agent updated" || echo "✗ Code-Review Agent not updated"
```

---

## ✅ Docker Build Verification

### Build All Services
```bash
# Clean build
docker-compose build --no-cache

# Expected output: "Successfully tagged..." for all services
```

### Check Build Success
```bash
# List all images
docker images | grep praxis

# Should show all agents present:
# - assessment-agent
# - planner-agent
# - task-mgmt-agent
# - support-agent
# - code-review-agent
```

---

## ✅ Runtime Verification

### Start Services
```bash
# Start all services
docker-compose up -d

# Wait 10 seconds for startup
sleep 10

# Check running containers
docker-compose ps

# All services should show "Up"
```

### Check Service Health
```bash
# Assessment Agent
curl -s http://localhost:8001/health | grep -q "healthy" && echo "✓ Assessment Agent healthy" || echo "✗ Assessment Agent not responding"

# Planner Agent
curl -s http://localhost:8002/health | grep -q "healthy" && echo "✓ Planner Agent healthy" || echo "✗ Planner Agent not responding"

# Task-Mgmt Agent
curl -s http://localhost:8003/health | grep -q "healthy" && echo "✓ Task-Mgmt Agent healthy" || echo "✗ Task-Mgmt Agent not responding"

# Code-Review Agent
curl -s http://localhost:8004/health | grep -q "healthy" && echo "✓ Code-Review Agent healthy" || echo "✗ Code-Review Agent not responding"

# Support Agent
curl -s http://localhost:8005/health | grep -q "healthy" && echo "✓ Support Agent healthy" || echo "✗ Support Agent not responding"
```

### Check API Gateway
```bash
curl -s http://localhost:80/health && echo "✓ API Gateway responding"
```

---

## ✅ Functional Verification

### Assessment Agent
```bash
curl -X GET http://localhost:8001/health
# Expected: {"status": "healthy"}
```

### Task-Mgmt Agent
```bash
curl -X GET http://localhost:8003/health
# Expected: {"status": "healthy"}
```

### Code-Review Agent
```bash
curl -X GET http://localhost:8004/health
# Expected: {"status": "healthy"}
```

### Support Agent
```bash
curl -X GET http://localhost:8005/health
# Expected: {"status": "healthy"}
```

---

## ✅ Logs Verification

### Check for Errors
```bash
# View logs for each service
docker-compose logs assessment-agent | grep -i "error\|warning" || echo "✓ No errors in assessment-agent"
docker-compose logs planner-agent | grep -i "error\|warning" || echo "✓ No errors in planner-agent"
docker-compose logs task-mgmt-agent | grep -i "error\|warning" || echo "✓ No errors in task-mgmt-agent"
docker-compose logs support-agent | grep -i "error\|warning" || echo "✓ No errors in support-agent"
docker-compose logs code-review-agent | grep -i "error\|warning" || echo "✓ No errors in code-review-agent"

# Check specifically for OpenRouter initialization
docker-compose logs | grep "OpenRouter" | head -10
```

---

## ✅ API Key Verification

### Verify API Key is Loaded
```bash
# Check if any service complains about missing key
docker-compose logs | grep -i "OPENROUTER_API_KEY.*not set" && echo "✗ API key not set" || echo "✓ API key appears to be set"

# Check if OpenRouter API is being called
docker-compose logs | grep -i "openrouter" | head -5
```

---

## ✅ Model Verification

### Check Model Assignments
```bash
# Assessment Agent uses Mistral Large
grep -q "mistralai/mistral-large" assessment-agent/llm_service.py && echo "✓ Assessment Agent models correct"

# Planner Agent uses Llama 3.1 405B
grep -q "meta-llama/llama-3.1-405b" planner-agent/app/core/planner.py && echo "✓ Planner Agent models correct"

# Support Agent uses Qwen
grep -q "qwen/qwen-max" support-agent/config/settings.py && echo "✓ Support Agent models correct"

# Task-Mgmt Agent uses Mistral Large
grep -q "mistralai/mistral-large" task-mgmt-agent/services/llm_service.py && echo "✓ Task-Mgmt Agent models correct"

# Code-Review Agent uses DeepSeek
grep -q "deepseek/deepseek-chat" code-review-agent/app/main.py && echo "✓ Code-Review Agent models correct"
```

---

## ✅ Documentation Verification

### Check Migration Docs
```bash
# All documentation files should exist
test -f OPENROUTER_MIGRATION_PLAN.md && echo "✓ Migration plan exists"
test -f OPENROUTER_IMPLEMENTATION_GUIDE.md && echo "✓ Implementation guide exists"
test -f OPENROUTER_MIGRATION_SUMMARY.md && echo "✓ Migration summary exists"
test -f OPENROUTER_QUICK_REFERENCE.md && echo "✓ Quick reference exists"
```

---

## ✅ Final Checklist

```
Configuration:
  [ ] .env has OPENROUTER_API_KEY
  [ ] docker-compose.yml updated
  [ ] Old API keys removed from docker-compose

Dependencies:
  [ ] assessment-agent: aiohttp added, google-generativeai removed
  [ ] task-mgmt-agent: aiohttp added, openai removed
  [ ] support-agent: aiohttp added, google-generativeai removed
  [ ] code-review-agent: groq removed
  [ ] planner-agent: openai removed

Code:
  [ ] OpenRouter service created (shared/openrouter_service.py)
  [ ] All agents use OPENROUTER_API_KEY
  [ ] All agents import aiohttp (not old SDKs)
  [ ] Model IDs are correct

Docker:
  [ ] All images build successfully
  [ ] All containers can start
  [ ] All services pass health checks

API:
  [ ] Assessment Agent responds on 8001
  [ ] Planner Agent responds on 8002
  [ ] Task-Mgmt Agent responds on 8003
  [ ] Code-Review Agent responds on 8004
  [ ] Support Agent responds on 8005
  [ ] API Gateway responds on 80

Logs:
  [ ] No "API key not set" errors
  [ ] No "KeyError" for old environment variables
  [ ] No import errors for old modules
  [ ] OpenRouter initialization messages appear

Cost Tracking:
  [ ] Monitor dashboard at https://openrouter.ai/dashboard
  [ ] Set up usage alerts
  [ ] Verify expected cost reduction
```

---

## 🚨 If Something Goes Wrong

### Issue: "OPENROUTER_API_KEY not set"
```bash
# Ensure .env is in root directory
ls -la .env

# Verify format
cat .env | grep OPENROUTER_API_KEY

# Try exporting manually
export OPENROUTER_API_KEY="sk-or-xxxxx"
docker-compose up
```

### Issue: "Docker build fails"
```bash
# Clean build
docker-compose down
docker system prune -a -f
docker-compose build --no-cache

# Check for syntax errors
docker-compose config
```

### Issue: "Services can't connect to OpenRouter"
```bash
# Test API key manually
curl -X GET "https://openrouter.ai/api/v1/auth/key" \
  -H "Authorization: Bearer sk-or-xxxxx"

# Should return account info if valid
```

### Issue: "Models returning empty responses"
```bash
# Check OpenRouter status
curl https://status.openrouter.ai/api

# View full logs
docker-compose logs -f

# Check OpenRouter dashboard for usage/errors
```

---

## 📞 Need Help?

1. **Check logs**: `docker-compose logs <service-name>`
2. **Check API Key**: Verify key is correct at https://openrouter.ai
3. **Check Models**: Browse available models at https://openrouter.ai/docs/models
4. **Check Status**: Monitor https://status.openrouter.ai
5. **Check Docs**: Read implementation guide (OPENROUTER_IMPLEMENTATION_GUIDE.md)

---

## ✨ Success Indicators

You'll know migration is complete when:
- ✅ All services start without errors
- ✅ All health checks pass
- ✅ Log show "OpenRouter" initialization
- ✅ API calls return responses
- ✅ Cost dashboard shows new models
- ✅ No errors about missing old API keys

---

**Last Updated**: 2024  
**Migration Version**: 1.0.0  
**Status**: Complete ✅
