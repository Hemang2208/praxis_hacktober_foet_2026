#!/usr/bin/env python3
"""
Simple integration test for queue system.

Verifies:
1. Queue system is operational
2. Jobs can be enqueued via API
3. Status polling works
4. Results can be retrieved
5. Metrics endpoint works

Run after starting Docker Compose with:
    python test_integration_simple.py
"""

import asyncio
import httpx
import time
import sys


BASE_URL = "http://localhost:80"


async def test_queue_integration():
    """Run integration test."""
    
    print("=" * 70)
    print("REDIS QUEUE INTEGRATION TEST")
    print("=" * 70)
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        
        # 1. Check health
        print("\n1. Checking API health...")
        response = await client.get(f"{BASE_URL}/health")
        if response.status_code != 200:
            print(f"❌ Health check failed: {response.status_code}")
            return False
        print("✅ API is healthy")
        
        # 2. Check queue metrics
        print("\n2. Checking queue metrics...")
        response = await client.get(f"{BASE_URL}/api/v1/queue/metrics")
        if response.status_code == 501:
            print("⚠️  Queue system not enabled (QUEUE_ENABLED=false)")
            print("   Enable queue in docker-compose.yml and restart")
            return False
        elif response.status_code == 200:
            metrics = response.json()
            print(f"✅ Queue metrics: {metrics['queue_size']} queued, {metrics['active_jobs']} active")
        else:
            print(f"❌ Metrics failed: {response.status_code}")
            return False
        
        # 3. Submit a test job
        print("\n3. Submitting test job...")
        test_payload = {
            "project_id": "test-project-123",
            "skill_level": "intermediate",
            "topics": ["Python", "FastAPI"]
        }
        
        response = await client.post(
            f"{BASE_URL}/api/v1/assessments/generate",  # Fixed: was /assessment/, now /assessments/
            json=test_payload,
            headers={"content-type": "application/json"}
        )
        
        if response.status_code == 202:
            data = response.json()
            print(f"✅ Job queued: {data['request_id']}")
            print(f"   Queue position: {data['queue_position']}")
            print(f"   Estimated wait: {data['estimated_wait_seconds']}s")
            request_id = data["request_id"]
        elif response.status_code == 429:
            print("⚠️  Queue is full (429 Too Many Requests)")
            print("   This is expected under heavy load")
            return True  # Not a failure, just backpressure working
        else:
            print(f"❌ Job submission failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
        
        # 4. Poll job status
        print("\n4. Polling job status...")
        max_polls = 20
        for i in range(max_polls):
            await asyncio.sleep(2)
            
            response = await client.get(f"{BASE_URL}/api/v1/queue/{request_id}")
            if response.status_code != 200:
                print(f"❌ Status check failed: {response.status_code}")
                return False
            
            status_data = response.json()
            status = status_data["status"]
            print(f"   Poll {i+1}/{max_polls}: {status}")
            
            if status == "completed":
                print("✅ Job completed successfully")
                break
            elif status == "failed":
                print(f"❌ Job failed: {status_data.get('error', 'Unknown error')}")
                return False
        else:
            print("⚠️  Job did not complete within timeout (but may still be processing)")
            # Not necessarily a failure - job might just be slow
        
        # 5. Try to get result
        print("\n5. Retrieving result...")
        response = await client.get(f"{BASE_URL}/api/v1/queue/{request_id}/result")
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Result retrieved (status code: {result.get('status_code', 'N/A')})")
            if "data" in result:
                print(f"   Result preview: {str(result['data'])[:100]}...")
        elif response.status_code == 202:
            print("⚠️  Job still processing (202)")
            print("   This is normal for long-running jobs")
        elif response.status_code == 404:
            print("⚠️  Result expired or not found")
        else:
            print(f"⚠️  Result retrieval status: {response.status_code}")
        
        # 6. Test deduplication
        print("\n6. Testing deduplication...")
        response = await client.post(
            f"{BASE_URL}/api/v1/assessments/generate",  # Fixed: was /assessment/, now /assessments/
            json=test_payload,
            headers={"content-type": "application/json"}
        )
        
        if response.status_code == 202:
            data = response.json()
            if "Duplicate" in data.get("message", ""):
                print("✅ Deduplication working (duplicate detected)")
            else:
                print(f"✅ New job created: {data['request_id']}")
        
        # 7. Final metrics check
        print("\n7. Final queue metrics...")
        response = await client.get(f"{BASE_URL}/api/v1/queue/metrics")
        if response.status_code == 200:
            metrics = response.json()
            print(f"✅ Final metrics:")
            print(f"   Queue size: {metrics['queue_size']}")
            print(f"   Active jobs: {metrics['active_jobs']}")
            print(f"   Total processed: {metrics['total_processed']}")
            print(f"   Total failed: {metrics['total_failed']}")
            print(f"   Avg wait time: {metrics['avg_wait_time_seconds']:.2f}s")
            print(f"   Avg processing time: {metrics['avg_processing_time_seconds']:.2f}s")
    
    print("\n" + "=" * 70)
    print("✅ INTEGRATION TEST COMPLETED SUCCESSFULLY")
    print("=" * 70)
    return True


if __name__ == "__main__":
    try:
        result = asyncio.run(test_queue_integration())
        sys.exit(0 if result else 1)
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
