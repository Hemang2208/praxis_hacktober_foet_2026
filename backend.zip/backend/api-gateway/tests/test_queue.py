"""
Unit and integration tests for Redis queue system.

Tests cover:
- Queue manager operations (enqueue/dequeue)
- Job lifecycle management
- Retry logic and exponential backoff
- Backpressure (429 responses)
- TTL expiration
- Deduplication
- Integration with API Gateway endpoints
"""

import asyncio
import json
import pytest
import time
from datetime import datetime, timezone
from unittest.mock import Mock, patch, AsyncMock

# Allow imports from parent directory
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from queue_manager import QueueClient, WorkerPool, JobMetadata, generate_request_id, QueueMetrics
from fastapi.testclient import TestClient


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
async def redis_client():
    """Create Redis client for tests."""
    client = QueueClient("redis://localhost:6379")
    await client.connect()
    
    # Clean up any existing test data
    if client.redis:
        await client.redis.flushdb()
    
    yield client
    
    # Cleanup
    if client.redis:
        await client.redis.flushdb()
    await client.disconnect()


@pytest.fixture
def sample_job():
    """Create sample job metadata."""
    return JobMetadata(
        request_id="test-job-123",
        agent="assessment-agent",
        path="api/v1/generate",
        method="POST",
        payload={"test": "data"},
        headers={"content-type": "application/json"},
        query_params={}
    )


# ============================================================================
# Unit Tests - QueueClient
# ============================================================================

@pytest.mark.asyncio
async def test_enqueue_job(redis_client, sample_job):
    """Test job enqueuing."""
    success = await redis_client.enqueue_job(sample_job)
    assert success is True
    
    # Verify job in queue
    queue_size = await redis_client.get_queue_size("assessment-agent")
    assert queue_size == 1


@pytest.mark.asyncio
async def test_dequeue_job(redis_client, sample_job):
    """Test job dequeuing (FIFO)."""
    await redis_client.enqueue_job(sample_job)
    
    # Dequeue
    job = await redis_client.dequeue_job("assessment-agent", timeout=1.0)
    assert job is not None
    assert job.request_id == "test-job-123"
    assert job.agent == "assessment-agent"
    
    # Queue should be empty now
    queue_size = await redis_client.get_queue_size("assessment-agent")
    assert queue_size == 0


@pytest.mark.asyncio
async def test_dequeue_timeout(redis_client):
    """Test dequeue timeout when queue is empty."""
    job = await redis_client.dequeue_job("assessment-agent", timeout=0.5)
    assert job is None


@pytest.mark.asyncio
async def test_fifo_ordering(redis_client):
    """Test FIFO ordering of jobs."""
    jobs = [
        JobMetadata(request_id=f"job-{i}", agent="assessment-agent", path="api/v1/test", method="POST", payload={})
        for i in range(5)
    ]
    
    # Enqueue all
    for job in jobs:
        await redis_client.enqueue_job(job)
    
    # Dequeue and verify order
    for i in range(5):
        job = await redis_client.dequeue_job("assessment-agent", timeout=1.0)
        assert job.request_id == f"job-{i}"


@pytest.mark.asyncio
async def test_backpressure(redis_client):
    """Test queue full backpressure."""
    # Set small max size for testing
    redis_client.max_queue_size = 5
    
    # Fill queue
    jobs = [
        JobMetadata(request_id=f"job-{i}", agent="assessment-agent", path="api/v1/test", method="POST", payload={})
        for i in range(5)
    ]
    
    for job in jobs:
        success = await redis_client.enqueue_job(job)
        assert success is True
    
    # Try to add one more - should fail
    overflow_job = JobMetadata(request_id="job-overflow", agent="assessment-agent", path="api/v1/test", method="POST", payload={})
    success = await redis_client.enqueue_job(overflow_job)
    assert success is False


@pytest.mark.asyncio
async def test_job_metadata_storage(redis_client, sample_job):
    """Test job metadata storage and retrieval."""
    await redis_client.enqueue_job(sample_job)
    
    # Retrieve metadata
    metadata = await redis_client.get_job_metadata("test-job-123")
    assert metadata is not None
    assert metadata.request_id == "test-job-123"
    assert metadata.agent == "assessment-agent"
    assert metadata.status == "queued"


@pytest.mark.asyncio
async def test_result_storage_and_retrieval(redis_client):
    """Test result storage with TTL."""
    request_id = "test-result-123"
    result_data = {"status": "success", "data": {"test": "result"}}
    
    # Store result
    await redis_client.store_result(request_id, result_data, ttl_seconds=10)
    
    # Retrieve result
    result = await redis_client.get_result(request_id)
    assert result is not None
    assert result["status"] == "success"
    assert result["data"]["test"] == "result"


@pytest.mark.asyncio
async def test_result_ttl_expiration(redis_client):
    """Test result TTL expiration."""
    request_id = "test-ttl-123"
    result_data = {"test": "data"}
    
    # Store with 1 second TTL
    await redis_client.store_result(request_id, result_data, ttl_seconds=1)
    
    # Should exist immediately
    result = await redis_client.get_result(request_id)
    assert result is not None
    
    # Wait for expiration
    await asyncio.sleep(2)
    
    # Should be gone
    result = await redis_client.get_result(request_id)
    assert result is None


@pytest.mark.asyncio
async def test_deduplication(redis_client):
    """Test request deduplication."""
    agent = "assessment-agent"
    path = "api/v1/generate"
    method = "POST"
    payload = {"test": "data"}
    
    # Register first request
    request_id_1 = "req-001"
    await redis_client.register_request(request_id_1, agent, path, method, payload)
    
    # Check for duplicate
    duplicate_id = await redis_client.check_duplicate(agent, path, method, payload)
    assert duplicate_id == request_id_1
    
    # Different payload should not be duplicate
    different_payload = {"test": "different"}
    duplicate_id = await redis_client.check_duplicate(agent, path, method, different_payload)
    assert duplicate_id is None


@pytest.mark.asyncio
async def test_deduplication_ttl(redis_client):
    """Test deduplication TTL expiration."""
    agent = "assessment-agent"
    path = "api/v1/generate"
    method = "POST"
    payload = {"test": "data"}
    
    # Register with 1 second TTL
    request_id = "req-ttl-001"
    await redis_client.register_request(request_id, agent, path, method, payload, ttl=1)
    
    # Should be duplicate immediately
    duplicate_id = await redis_client.check_duplicate(agent, path, method, payload)
    assert duplicate_id == request_id
    
    # Wait for expiration
    await asyncio.sleep(2)
    
    # Should not be duplicate anymore
    duplicate_id = await redis_client.check_duplicate(agent, path, method, payload)
    assert duplicate_id is None


@pytest.mark.asyncio
async def test_queue_position(redis_client):
    """Test queue position calculation."""
    jobs = [
        JobMetadata(request_id=f"job-{i}", agent="assessment-agent", path="api/v1/test", method="POST", payload={})
        for i in range(5)
    ]
    
    # Enqueue all
    for job in jobs:
        await redis_client.enqueue_job(job)
    
    # Check positions (0 = next to be processed)
    for i in range(5):
        position = await redis_client.get_queue_position(f"job-{i}")
        assert position is not None
        assert position == i


@pytest.mark.asyncio
async def test_metrics_tracking(redis_client, sample_job):
    """Test metrics collection."""
    # Process a job to generate metrics
    await redis_client.enqueue_job(sample_job)
    
    # Simulate processing
    sample_job.started_at = time.time()
    redis_client.record_job_complete(sample_job, success=True)
    
    # Get metrics
    metrics = await redis_client.get_metrics()
    assert metrics.total_processed == 1
    assert metrics.total_failed == 0


# ============================================================================
# Unit Tests - WorkerPool
# ============================================================================

@pytest.mark.asyncio
async def test_worker_pool_acquire():
    """Test worker pool acquire."""
    pool = WorkerPool(max_workers=3)
    
    # Acquire slots
    assert await pool.acquire("job-1") is True
    assert await pool.acquire("job-2") is True
    assert await pool.acquire("job-3") is True
    
    # Pool full
    assert await pool.acquire("job-4") is False
    
    # Release and acquire again
    await pool.release("job-1")
    assert await pool.acquire("job-4") is True


@pytest.mark.asyncio
async def test_worker_pool_count():
    """Test worker pool active count."""
    pool = WorkerPool(max_workers=5)
    
    assert pool.get_active_count() == 0
    
    await pool.acquire("job-1")
    await pool.acquire("job-2")
    assert pool.get_active_count() == 2
    
    await pool.release("job-1")
    assert pool.get_active_count() == 1


# ============================================================================
# Integration Tests - API Gateway
# ============================================================================

@pytest.fixture
def api_client():
    """Create FastAPI test client."""
    # Import here to avoid circular imports
    from main import app
    return TestClient(app)


def test_health_endpoint(api_client):
    """Test health endpoint returns 200."""
    response = api_client.get("/health")
    assert response.status_code == 200


@pytest.mark.skipif("not config.getoption('--integration')", reason="Integration tests disabled")
def test_queue_job_creation(api_client):
    """Test job creation via API (integration test)."""
    # This requires Redis to be running and QUEUE_ENABLED=true
    
    # POST request that should be queued
    response = api_client.post(
        "/api/v1/assessment/generate",
        json={"test": "data"},
        headers={"content-type": "application/json"}
    )
    
    # Should return 202 Accepted
    assert response.status_code == 202
    
    data = response.json()
    assert "request_id" in data
    assert "status_url" in data
    assert "result_url" in data
    assert data["status"] == "queued"
    
    request_id = data["request_id"]
    
    # Poll status
    status_response = api_client.get(f"/api/v1/queue/{request_id}")
    assert status_response.status_code == 200
    
    status_data = status_response.json()
    assert status_data["request_id"] == request_id
    assert status_data["status"] in ["queued", "processing", "completed"]


@pytest.mark.skipif("not config.getoption('--integration')", reason="Integration tests disabled")
def test_queue_metrics_endpoint(api_client):
    """Test metrics endpoint."""
    response = api_client.get("/api/v1/queue/metrics")
    
    # Should return 200 if queue enabled, 501 if disabled
    assert response.status_code in [200, 501]
    
    if response.status_code == 200:
        data = response.json()
        assert "queue_size" in data
        assert "active_jobs" in data
        assert "total_processed" in data


@pytest.mark.skipif("not config.getoption('--integration')", reason="Integration tests disabled")
def test_passthrough_for_get_requests(api_client):
    """Test that GET requests pass through (not queued)."""
    # GET request should NOT be queued
    response = api_client.get("/api/v1/task/list")
    
    # Should get direct response, not 202
    assert response.status_code != 202


@pytest.mark.skipif("not config.getoption('--integration')", reason="Integration tests disabled")
def test_backpressure_429(api_client):
    """Test that queue returns 429 when full."""
    # This requires filling the queue
    # In production this would need many concurrent requests
    pass  # TODO: Implement load test


# ============================================================================
# Test Configuration
# ============================================================================

# Option defined in conftest.py


# ============================================================================
# Run Tests
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--asyncio-mode=auto"])
