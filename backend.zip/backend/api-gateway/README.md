# API Gateway

Central entry point for all PRAXIS backend requests. Handles routing, auth validation, rate limiting, and the priority job queue.

**Port:** 8000 (internal) — exposed via Nginx on port 80

## What it does

- Proxies requests to the right agent based on path (`/api/v1/assessment/*` → assessment-agent, etc.)
- Validates JWT tokens before forwarding
- Queue system: high-volume AI requests get queued instead of hitting agents directly
- Rate limiting via `slowapi`
- Deduplication — same request twice returns the existing job

## Key files

| File | Purpose |
|---|---|
| `main.py` | FastAPI app, all route handlers, proxy logic, queue endpoints |
| `queue_manager.py` | Redis queue client, job lifecycle, priority dequeue logic, metrics |
| `docs/QUEUE_PLAN.md` | Queue system design and roadmap |
| `docs/` — see also `../docs/QUEUE_README.md` | Queue usage guide |

## Queue system

Requests to AI-heavy agents are queued instead of proxied directly.

```bash
# Send a normal job
curl -X POST http://localhost/api/v1/assessment/generate \
  -H "Content-Type: application/json" \
  -d '{"project_id": "abc"}'
# → 202 with request_id

# Send a high-priority job
curl -X POST http://localhost/api/v1/assessment/generate \
  -H "Content-Type: application/json" \
  -H "X-Request-Priority: high" \
  -d '{"project_id": "abc"}'

# Poll status
curl http://localhost/api/v1/queue/{request_id}

# Get result when done
curl http://localhost/api/v1/queue/{request_id}/result

# Queue health
curl http://localhost/api/v1/queue/metrics
```

## Env vars

```
QUEUE_ENABLED=true
QUEUE_MAX_WORKERS=5
QUEUE_MAX_SIZE=500
QUEUE_RESULT_TTL=1800
QUEUE_JOB_TIMEOUT=3600
REDIS_URL=redis://redis:6379
JWT_SECRET=
```

## Tests

```bash
cd tests
pytest test_queue.py -v --asyncio-mode=auto       # unit tests (needs Redis)
python test_integration_simple.py                  # integration (needs full stack)
```
