"""
Queue Manager for Redis-backed async job processing in API Gateway.

Provides QueueClient for job lifecycle management, metrics tracking, and
deduplication. Supports 2-tier priority queue processing (high | normal),
configurable concurrency, retry logic, and backpressure handling.

Priority Queue Architecture:
  Redis keys:
    queue:high:{agent}   — urgent requests drained first
    queue:normal:{agent} — background/batch requests
  Dequeue order: always drain queue:high:{agent} first (non-blocking RPOP),
  then fall back to queue:normal:{agent} (blocking BRPOP with timeout).
"""

import asyncio
import hashlib
import inspect
import json
import logging
import os
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional, List, Set
from uuid import uuid4

import redis.asyncio as aioredis
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


# ============================================================================
# Status Progression
# ============================================================================
# Monotonic status order: statuses can only move forward in this sequence.
# "retrying" may transition back to "processing" (retry attempt begins anew).
ALLOWED_TRANSITIONS: Dict[str, set] = {
    # First write (no existing status) — any initial status is allowed
    None: {"queued", "processing", "completed", "failed"},
    # From queued — can move to any active/terminal state
    "queued": {"queued", "processing", "retrying", "completed", "failed"},
    # From processing — can retry, complete, or fail (cannot go back to queued)
    "processing": {"processing", "retrying", "completed", "failed"},
    # From retrying — can retry processing, complete, or fail (cannot go back to queued)
    "retrying": {"retrying", "processing", "completed", "failed"},
    # Terminal states — no further writes allowed
    "completed": set(),
    "failed": set(),
}


def _is_valid_transition(old_status: Optional[str], new_status: str) -> bool:
    """Check if the status transition is valid (monotonic progression)."""
    allowed = ALLOWED_TRANSITIONS.get(old_status)
    if allowed is None:
        return False
    return new_status in allowed


# ============================================================================
# Data Models
# ============================================================================

class JobMetadata(BaseModel):
    """Metadata for a queued job."""
    
    request_id: str = Field(description="Unique job identifier (UUID)")
    agent: str = Field(description="Target agent name (e.g., 'assessment-agent')")
    path: str = Field(description="API path relative to agent (e.g., 'api/v1/generate')")
    method: str = Field(description="HTTP method (GET, POST, etc.)")
    headers: Dict[str, str] = Field(default_factory=dict, description="Request headers")
    query_params: Dict[str, Any] = Field(default_factory=dict, description="Query parameters")
    payload: Dict[str, Any] = Field(default_factory=dict, description="Request body")
    
    # Priority field — determines which Redis queue this job enters
    priority: str = Field(default="normal", description="Job priority: high | normal")
    
    created_at: float = Field(default_factory=lambda: datetime.now(timezone.utc).timestamp())
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    
    retry_count: int = Field(default=0, description="Number of retry attempts")
    status: str = Field(default="queued", description="Job status: queued/processing/completed/failed/retrying")
    error: Optional[str] = None
    
    ttl_seconds: int = Field(default=1800, description="Result TTL in seconds (default: 30 min)")
    timeout_seconds: int = Field(default=3600, description="Job timeout in seconds (default: 1 hour)")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.timestamp()
        }


class QueueMetrics(BaseModel):
    """Queue performance and health metrics."""
    
    queue_size: int = Field(description="Total jobs in queue (high + normal)")
    high_queue_size: int = Field(default=0, description="Jobs in high-priority queue")
    normal_queue_size: int = Field(default=0, description="Jobs in normal-priority queue")
    active_jobs: int = Field(description="Number of jobs currently processing")
    total_processed: int = Field(default=0, description="Total jobs processed since startup")
    total_failed: int = Field(default=0, description="Total jobs that failed permanently")
    total_retried: int = Field(default=0, description="Total retry attempts")
    
    avg_wait_time_seconds: float = Field(default=0.0, description="Average time jobs wait in queue")
    avg_processing_time_seconds: float = Field(default=0.0, description="Average job processing time")
    
    # Per-agent breakdown
    per_agent: Dict[str, Dict[str, int]] = Field(
        default_factory=dict,
        description="Per-agent queue sizes: {agent: {high: N, normal: N, total: N}}"
    )
    
    timestamp: float = Field(default_factory=lambda: datetime.now(timezone.utc).timestamp())


# ============================================================================
# Queue Client
# ============================================================================

class QueueClient:
    """
    Redis-backed queue client for async job processing.
    
    Manages job lifecycle: enqueue → process → store result.
    Supports deduplication, metrics tracking, and TTL-based cleanup.
    """
    
    def __init__(self, redis_url: str = "redis://localhost:6379"):
        """
        Initialize queue client.
        
        Args:
            redis_url: Redis connection URL
        """
        self.redis_url = redis_url
        self.redis: Optional[aioredis.Redis] = None
        
        # Configuration from environment
        self.max_queue_size = int(os.getenv("QUEUE_MAX_SIZE", "500"))
        self.result_ttl = int(os.getenv("QUEUE_RESULT_TTL", "1800"))
        self.job_timeout = int(os.getenv("QUEUE_JOB_TIMEOUT", "3600"))
        self.max_retries = int(os.getenv("QUEUE_RETRY_MAX", "3"))
        
        # Metrics tracking
        self._total_processed = 0
        self._total_failed = 0
        self._total_retried = 0
        self._wait_times: List[float] = []
        self._processing_times: List[float] = []
        
        logger.info(f"🔧 QueueClient initialized | max_size={self.max_queue_size} | result_ttl={self.result_ttl}s | job_timeout={self.job_timeout}s | max_retries={self.max_retries}")
    
    async def connect(self):
        """Establish Redis connection."""
        try:
            self.redis = await aioredis.from_url(
                self.redis_url,
                encoding="utf-8",
                decode_responses=True
            )
            # Test connection
            await self.redis.ping()
            logger.info(f"✅ REDIS CONNECTED | url={self.redis_url}")
        except Exception as e:
            logger.error(f"❌ REDIS CONNECTION FAILED | url={self.redis_url} | error={str(e)}")
            raise
    
    async def disconnect(self):
        """Close Redis connection."""
        if self.redis:
            await self.redis.close()
            logger.info("🔌 REDIS DISCONNECTED")
    
    # ------------------------------------------------------------------------
    # Job Lifecycle Methods
    # ------------------------------------------------------------------------
    
    async def enqueue_job(self, job: JobMetadata) -> bool:
        """
        Add job to the appropriate priority queue.
        
        Jobs with priority='high' go to queue:high:{agent}.
        Jobs with priority='normal' go to queue:normal:{agent}.
        
        Args:
            job: Job metadata to enqueue
            
        Returns:
            True if enqueued, False if queue is full
            
        Raises:
            Exception if Redis operation fails
        """
        if not self.redis:
            raise RuntimeError("Redis not connected. Call connect() first.")
        
        # Clamp to valid values
        if job.priority not in ("high", "normal"):
            job.priority = "normal"
        
        # Backpressure check
        current_size = await self.get_queue_size()
        if current_size >= self.max_queue_size:
            logger.warning(f"⚠️  QUEUE FULL | size={current_size}/{self.max_queue_size} | agent={job.agent} | priority={job.priority}")
            return False
        
        job_json = job.model_dump_json()
        
        # Write metadata BEFORE adding to queue to prevent a race where the
        # worker dequeues the job (visible via BRPOP after LPUSH) and writes
        # "processing" before this method writes the initial "queued" status.
        # By writing metadata first, we guarantee the initial "queued" status
        # is in Redis before the worker can see the job.
        await self._store_job_metadata(job)
        
        # LPUSH + RPOP = FIFO within each priority tier
        # (now safe: metadata already written, worker will see "queued" and
        #  can only transition forward to "processing")
        queue_key = self._get_queue_key(job.agent, job.priority)
        await self.redis.lpush(queue_key, job_json)
        
        logger.info(f"📥 JOB ENQUEUED | request_id={job.request_id} | agent={job.agent} | priority={job.priority} | method={job.method} | path={job.path} | total_queue={current_size + 1}")
        return True
    
    async def dequeue_job(self, agent: str, timeout: float = 1.0) -> Optional[JobMetadata]:
        """
        Priority-aware dequeue: drains queue:high:{agent} first (non-blocking RPOP),
        then falls back to queue:normal:{agent} (blocking BRPOP with timeout).
        """
        if not self.redis:
            raise RuntimeError("Redis not connected. Call connect() first.")
        
        job_json: Optional[str] = None
        
        # High queue first — non-blocking
        high_key = self._get_queue_key(agent, "high")
        job_json = await self.redis.rpop(high_key)
        
        if job_json is None:
            # Normal queue — blocking with timeout
            normal_key = self._get_queue_key(agent, "normal")
            result = await self.redis.brpop(normal_key, timeout=timeout)
            if result:
                _, job_json = result
        
        if job_json is None:
            return None
        
        job = JobMetadata.model_validate_json(job_json)
        wait_time = time.time() - job.created_at
        self._wait_times.append(wait_time)
        
        logger.info(f"📤 JOB DEQUEUED | request_id={job.request_id} | agent={job.agent} | priority={job.priority} | wait_time={wait_time:.2f}s")
        return job
    
    async def update_job_status(self, job: JobMetadata):
        """Update job metadata in Redis."""
        await self._store_job_metadata(job)
        logger.info(f"🔄 JOB STATUS UPDATED | request_id={job.request_id} | status={job.status} | agent={job.agent}")
    
    async def store_result(self, request_id: str, result: Any, ttl_seconds: Optional[int] = None):
        """
        Store job result with TTL.
        
        Args:
            request_id: Job identifier
            result: Result data (will be JSON serialized)
            ttl_seconds: TTL in seconds (default: from config)
        """
        if not self.redis:
            raise RuntimeError("Redis not connected. Call connect() first.")
        
        ttl = ttl_seconds or self.result_ttl
        result_key = self._get_result_key(request_id)
        
        # Serialize result
        result_json = json.dumps(result)
        
        # Store with TTL
        await self.redis.setex(result_key, ttl, result_json)
        logger.info(f"💾 RESULT STORED | request_id={request_id} | ttl={ttl}s")
    
    async def get_result(self, request_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve job result.
        
        Args:
            request_id: Job identifier
            
        Returns:
            Result dict if available, None if not found or expired
        """
        if not self.redis:
            raise RuntimeError("Redis not connected. Call connect() first.")
        
        result_key = self._get_result_key(request_id)
        result_json = await self.redis.get(result_key)
        
        if not result_json:
            return None
        
        return json.loads(result_json)
    
    async def requeue_job(self, job: JobMetadata, delay_ms: int = 0):
        """
        Re-add job to queue (for retries).
        
        Args:
            job: Job to requeue
            delay_ms: Delay before requeue (milliseconds)
        """
        if delay_ms > 0:
            await asyncio.sleep(delay_ms / 1000.0)
        
        await self.enqueue_job(job)
        self._total_retried += 1
        logger.info(f"🔁 JOB REQUEUED | request_id={job.request_id} | agent={job.agent} | retry={job.retry_count}/{self.max_retries} | delay_ms={delay_ms}")
    
    async def get_job_metadata(self, request_id: str) -> Optional[JobMetadata]:
        """
        Retrieve job metadata by request ID.
        
        Args:
            request_id: Job identifier
            
        Returns:
            JobMetadata if found, None otherwise
        """
        if not self.redis:
            raise RuntimeError("Redis not connected. Call connect() first.")
        
        metadata_key = self._get_metadata_key(request_id)
        logger.info(f"🚨 QUEUE_ENDPOINT_READ | request_id={request_id} | key={metadata_key}")
        
        metadata_json = await self.redis.get(metadata_key)
        
        if not metadata_json:
            logger.warning(f"🚨 REDIS_READ_MISS | request_id={request_id} | key={metadata_key}")
            return None
        
        logger.info(f"🚨 REDIS_READ_VALUE | request_id={request_id} | key={metadata_key} | value={metadata_json[:500]}")
        
        return JobMetadata.model_validate_json(metadata_json)
    
    # ------------------------------------------------------------------------
    # Deduplication
    # ------------------------------------------------------------------------
    
    async def check_duplicate(self, agent: str, path: str, method: str, payload: Dict[str, Any]) -> Optional[str]:
        """
        Check if identical request already exists.
        
        Args:
            agent: Agent name
            path: API path
            method: HTTP method
            payload: Request payload
            
        Returns:
            Existing request_id if duplicate found, None otherwise
        """
        if not self.redis:
            raise RuntimeError("Redis not connected. Call connect() first.")
        
        # Create fingerprint
        fingerprint = self._create_fingerprint(agent, path, method, payload)
        dedup_key = f"dedup:{fingerprint}"
        
        # Check if exists
        existing_request_id = await self.redis.get(dedup_key)
        
        if existing_request_id:
            logger.info(f"🔍 DUPLICATE REQUEST DETECTED | request_id={existing_request_id} | agent={agent} | method={method} | path={path}")
        
        return existing_request_id
    
    async def register_request(self, request_id: str, agent: str, path: str, method: str, payload: Dict[str, Any], ttl: int = 60):
        """
        Register request fingerprint for deduplication.
        
        Args:
            request_id: Job identifier
            agent: Agent name
            path: API path
            method: HTTP method
            payload: Request payload
            ttl: Deduplication window in seconds
        """
        if not self.redis:
            raise RuntimeError("Redis not connected. Call connect() first.")
        
        fingerprint = self._create_fingerprint(agent, path, method, payload)
        dedup_key = f"dedup:{fingerprint}"
        
        await self.redis.setex(dedup_key, ttl, request_id)
        logger.info(f"📝 REQUEST REGISTERED | request_id={request_id} | agent={agent} | dedup_ttl={ttl}s")
    
    def _create_fingerprint(self, agent: str, path: str, method: str, payload: Dict[str, Any]) -> str:
        """Create unique fingerprint for request."""
        data = f"{agent}:{path}:{method}:{json.dumps(payload, sort_keys=True)}"
        return hashlib.sha256(data.encode()).hexdigest()
    
    # ------------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------------
    
    async def get_metrics(self) -> QueueMetrics:
        """
        Get current queue metrics with per-priority and per-agent breakdown.
        
        Returns:
            QueueMetrics with current stats including high/normal split
        """
        total_high = 0
        total_normal = 0
        per_agent: Dict[str, Dict[str, int]] = {}
        
        agents = ["assessment-agent", "planner-agent", "task-mgmt-agent", "code-review-agent", "support-agent"]
        
        for agent in agents:
            h = await self._get_priority_queue_size(agent, "high")
            n = await self._get_priority_queue_size(agent, "normal")
            total_high += h
            total_normal += n
            per_agent[agent] = {"high": h, "normal": n, "total": h + n}
        
        # Calculate averages (last 100 samples)
        avg_wait = sum(self._wait_times[-100:]) / len(self._wait_times[-100:]) if self._wait_times else 0.0
        avg_processing = sum(self._processing_times[-100:]) / len(self._processing_times[-100:]) if self._processing_times else 0.0
        
        return QueueMetrics(
            queue_size=total_high + total_normal,
            high_queue_size=total_high,
            normal_queue_size=total_normal,
            active_jobs=0,  # Will be set by WorkerPool
            total_processed=self._total_processed,
            total_failed=self._total_failed,
            total_retried=self._total_retried,
            avg_wait_time_seconds=avg_wait,
            avg_processing_time_seconds=avg_processing,
            per_agent=per_agent
        )
    
    async def get_queue_size(self, agent: Optional[str] = None) -> int:
        """
        Get total queue size (high + normal).
        
        Args:
            agent: Specific agent, or None for total across all agents
            
        Returns:
            Total number of jobs across both priority queues
        """
        if not self.redis:
            return 0
        
        if agent:
            high = await self._get_priority_queue_size(agent, "high")
            normal = await self._get_priority_queue_size(agent, "normal")
            return high + normal
        else:
            total = 0
            for agent_name in ["assessment-agent", "planner-agent", "task-mgmt-agent", "code-review-agent", "support-agent"]:
                total += await self.get_queue_size(agent_name)
            return total
    
    async def get_queue_position(self, request_id: str) -> Optional[int]:
        """
        Get job position in queue, searching high queue first then normal.
        
        High-queue jobs always report their position as lower (higher priority)
        than any normal-queue job.
        
        Args:
            request_id: Job identifier
            
        Returns:
            Position (0-indexed from next-to-be-processed), or None if not in queue
        """
        job = await self.get_job_metadata(request_id)
        if not job or job.status != "queued":
            return None
        
        # Search high-priority queue first
        high_key = self._get_queue_key(job.agent, "high")
        high_jobs = await self.redis.lrange(high_key, 0, -1)
        
        for i, job_json in enumerate(high_jobs):
            job_data = JobMetadata.model_validate_json(job_json)
            if job_data.request_id == request_id:
                return len(high_jobs) - i - 1  # RPOP removes from right
        
        # Not in high queue — search normal queue
        # Position is offset by the size of the high queue (high jobs go first)
        normal_key = self._get_queue_key(job.agent, "normal")
        normal_jobs = await self.redis.lrange(normal_key, 0, -1)
        
        for i, job_json in enumerate(normal_jobs):
            job_data = JobMetadata.model_validate_json(job_json)
            if job_data.request_id == request_id:
                # Offset by high queue length since those are processed first
                return len(high_jobs) + (len(normal_jobs) - i - 1)
        
        return None
    
    async def estimate_wait_time(self, agent: Optional[str] = None) -> float:
        """
        Estimate wait time for new job.
        
        Args:
            agent: Specific agent queue, or None for average
            
        Returns:
            Estimated wait time in seconds
        """
        queue_size = await self.get_queue_size(agent)
        
        # Use recent average processing time
        avg_processing = sum(self._processing_times[-50:]) / len(self._processing_times[-50:]) if self._processing_times else 30.0
        
        # Assume max workers (5) processing in parallel
        max_workers = int(os.getenv("QUEUE_MAX_WORKERS", "5"))
        estimated = (queue_size / max_workers) * avg_processing
        
        return estimated
    
    def record_job_complete(self, job: JobMetadata, success: bool = True):
        """Record job completion for metrics."""
        if job.started_at:
            processing_time = time.time() - job.started_at
            self._processing_times.append(processing_time)
        
        if success:
            self._total_processed += 1
        else:
            self._total_failed += 1
    
    # ------------------------------------------------------------------------
    # Helper Methods
    # ------------------------------------------------------------------------
    
    def _get_queue_key(self, agent: str, priority: str = "normal") -> str:
        """
        Get Redis key for agent queue by priority tier.
        
        Args:
            agent: Agent name (e.g., 'planner-agent')
            priority: 'high' or 'normal'
            
        Returns:
            Redis key string — 'queue:high:{agent}' or 'queue:normal:{agent}'
        """
        return f"queue:{priority}:{agent}"
    
    async def _get_priority_queue_size(self, agent: str, priority: str) -> int:
        """Get size of a specific priority queue for an agent."""
        if not self.redis:
            return 0
        queue_key = self._get_queue_key(agent, priority)
        return await self.redis.llen(queue_key)
    
    def _get_metadata_key(self, request_id: str) -> str:
        """Get Redis key for job metadata."""
        return f"job:meta:{request_id}"
    
    def _get_result_key(self, request_id: str) -> str:
        """Get Redis key for job result."""
        return f"job:result:{request_id}"
    
    async def _store_job_metadata(self, job: JobMetadata):
        """Store job metadata with extended TTL and monotonic status guard."""
        if not self.redis:
            logger.error(f"🚨 REDIS_CLIENT_NONE | request_id={job.request_id} | action=skipping_metadata_write")
            return
        
        metadata_key = self._get_metadata_key(job.request_id)
        metadata_json = job.model_dump_json()
        
        # Read current metadata to check status progression (atomicity not required;
        # worst case a stale read lets one extra write through — the guard is
        # defense-in-depth, not a lock)
        existing_raw = await self.redis.get(metadata_key)
        old_status: Optional[str] = None
        if existing_raw:
            try:
                existing_data = json.loads(existing_raw)
                old_status = existing_data.get("status")
            except (json.JSONDecodeError, TypeError):
                pass
        
        new_status = job.status
        caller = inspect.currentframe().f_back.f_code.co_name if inspect.currentframe() else "unknown"
        
        # Check monotonic progression
        if not _is_valid_transition(old_status, new_status):
            logger.warning(
                f"🚨 METADATA_WRITE_DENIED | request_id={job.request_id} | "
                f"key={metadata_key} | caller={caller} | "
                f"old_status={old_status} | new_status={new_status} | "
                f"reason=non_monotonic_progression"
            )
            return  # Skip write — prevents status regression
        
        # Log every write with full transition info
        logger.info(
            f"🚨 METADATA_WRITE | request_id={job.request_id} | "
            f"key={metadata_key} | caller={caller} | "
            f"old_status={old_status} | new_status={new_status}"
        )
        
        # Store with TTL (2x result TTL to ensure metadata persists after result)
        ttl = job.ttl_seconds * 2
        await self.redis.setex(metadata_key, ttl, metadata_json)


# ============================================================================
# Worker Pool
# ============================================================================

class WorkerPool:
    """
    Manages worker tasks for job processing.
    
    Maintains concurrency limits and tracks active jobs.
    """
    
    def __init__(self, max_workers: int = 5):
        """
        Initialize worker pool.
        
        Args:
            max_workers: Maximum concurrent workers
        """
        self.max_workers = max_workers
        self.active_jobs: Set[str] = set()
        self._lock = asyncio.Lock()
        
        logger.info(f"👷 WORKER POOL INITIALIZED | max_workers={max_workers}")
    
    async def acquire(self, job_id: str) -> bool:
        """
        Try to acquire worker slot for job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            True if acquired, False if at capacity
        """
        async with self._lock:
            if len(self.active_jobs) >= self.max_workers:
                return False
            
            self.active_jobs.add(job_id)
            logger.info(f"🔒 WORKER ACQUIRED | job_id={job_id} | active={len(self.active_jobs)}/{self.max_workers}")
            return True
    
    async def release(self, job_id: str):
        """Release worker slot."""
        async with self._lock:
            self.active_jobs.discard(job_id)
            logger.info(f"🔓 WORKER RELEASED | job_id={job_id} | active={len(self.active_jobs)}/{self.max_workers}")
    
    def get_active_count(self) -> int:
        """Get number of active workers."""
        return len(self.active_jobs)
    
    def is_available(self) -> bool:
        """Check if workers are available."""
        return len(self.active_jobs) < self.max_workers


# ============================================================================
# Utility Functions
# ============================================================================

def generate_request_id() -> str:
    """Generate unique request ID."""
    return str(uuid4())
