# Request-Queueing Mechanism for API Gateway - Implementation Plan

## Context

The praxis-backend system is currently operating with an async-first architecture where all requests are processed synchronously per-request with no queue management. While this works for moderate loads, burst traffic on AI-heavy endpoints (assessment, planner, code-review, support agents) can cause:

- CPU/memory overload when multiple users hit long-running AI operations simultaneously
- Timeouts for clients when system capacity is exceeded
- No graceful degradation under load

**Goal**: Implement a Redis-backed request queue at the API Gateway layer for controlled burst handling with immediate user acknowledgment and bounded concurrency (5-10 workers).

## Architecture Overview

```
┌─────────────────────────────┐
│   NGINX (Port 80)           │
│   (Lightweight reverse proxy)│
└──────────────┬──────────────┘
               │
        ┌──────┴───────┐
        │              │
┌───────▼──────────────────────────────────────────────────────────┐
│            API GATEWAY (Port 8000, FastAPI)                       │
│ ┌────────────────────────────────────────────────────────────┐   │
│ │ Queue Manager Module (NEW)                                 │   │
│ │ ├─ QueueClient: Redis connection & job lifecycle           │   │
│ │ ├─ Worker Pool: Concurrent processor with limits           │   │
│ │ ├─ Metrics: Queue size, processing rate, throughput        │   │
│ │ └─ Backpressure: 429 when queue > threshold                │   │
│ ├────────────────────────────────────────────────────────────┤   │
│ │ Request Handler (MODIFIED)                                 │   │
│ │ ├─ Validate request                                        │   │
│ │ ├─ Assign request ID (UUID)                                │   │
│ │ ├─ Push to queue → immediate 202 response                  │   │
│ │ └─ Return request ID for polling                           │   │
│ ├────────────────────────────────────────────────────────────┤   │
│ │ Worker Loop (NEW)                                          │   │
│ │ ├─ Pull from queue (concurrency limit: 5-10)              │   │
│ │ ├─ Forward to agent                                        │   │
│ │ ├─ Store result (Redis) with TTL                           │   │
│ │ ├─ Handle retry/timeout                                    │   │
│ │ └─ Log metrics                                             │   │
│ ├────────────────────────────────────────────────────────────┤   │
│ │ Result Retrieval Endpoint (NEW)                            │   │
│ │ └─ GET /api/v1/queue/{request_id}/result                  │   │
│ └────────────────────────────────────────────────────────────┘   │
│                                                                   │
│  Existing middleware:                                             │
│  • CORS, Rate Limiting (slowapi), Input Sanitization            │
└───────┬─────────────────────────────────────────────────────────┘
        │
        └─────┬─────────────────┬──────────────┬──────────────┐
              │                 │              │              │
        ┌─────▼─┐         ┌─────▼──┐      ┌───▼────┐    ┌────▼──┐
        │Redis  │         │Agent   │      │Agent   │    │Agent  │
        │:6379  │         │8001    │      │8002    │    │8003   │
        └───────┘         └────────┘      └────────┘    └───────┘
```

## Implementation Details

### 1. Queue Management Module (`queue_manager.py`)

**Purpose**: Encapsulate all Redis queue logic with async/await support

**Components**:

- `QueueClient`:
  - Connect to Redis via `aioredis`
  - Manage FIFO queue (Redis List)
  - Store job metadata (request_id, payload, priority, created_at)
  - Store results with TTL (30 minutes default)

- `JobMetadata` (Pydantic):

  ```
  request_id: str (UUID)
  agent: str (e.g., "assessment-agent")
  path: str (e.g., "api/v1/assessment/generate")
  method: str (GET/POST/etc)
  payload: dict
  priority: str ("high" | "normal", default "normal")  ← shipped
  created_at: datetime
  started_at: Optional[datetime]
  completed_at: Optional[datetime]
  retry_count: int
  status: str (queued/processing/completed/failed)
  ttl_seconds: int
  ```

- `WorkerPool`:
  - Maintains configurable concurrency limit (default: 5, range: 1-20)
  - Pulls jobs from queue using Redis BLPOP (blocking)
  - Manages active job tracking
  - Implements retry logic with exponential backoff (max 3 retries)
  - Timeout handling (individual job timeout + circuit breaker)

- `QueueMetrics`:
  - Track queue_size, job_count, processing_rate, avg_latency
  - Persist metrics in Redis for monitoring

### 2. Modified Request Handler Flow

**For each incoming request to `/api/v1/{agent}/{path}`**:

````python
1. Validation Phase:
   - Check if agent exists
   - Validate JWT/auth (existing)
   - Sanitize payload (existing)
   - Determine if request should be queued:
     * AI-heavy agents (assessment, planner, code-review, support): ALWAYS queue
     * Task-mgmt POST/PUT/PATCH: Queue
     * Health/admin/GET requests: Pass-through directly

2. Queueing Phase (Automatic):
   - Generate request_id (UUID)
   - Create JobMetadata (with resolved priority from X-Request-Priority header)
   - Push to Redis: queue:high:{agent} or queue:normal:{agent}
   - Check backpressure:
     * If total queue_size > MAX_QUEUE_SIZE (default: 500):
       - Return 429 (Too Many Requests)
       - Include Retry-After header (in seconds)

3. Return 202 Accepted:
   - Include request_id and polling URL
   - Example response:
     ```json
     {
       "status": "queued",
       "request_id": "550e8400-e29b-41d4-a716-446655440000",
       "queue_position": 3,
       "estimated_wait_seconds": 45,
       "status_url": "/api/v1/queue/550e8400-e29b-41d4-a716-446655440000",
       "result_url": "/api/v1/queue/550e8400-e29b-41d4-a716-446655440000/result"
     }
     ```
   - Note: Clients must poll result_url to retrieve completion status
````

### 3. Worker Loop (Background Task)

**Started on app startup, runs continuously**:

```python
async def worker_loop():
    max_workers = int(os.getenv("QUEUE_MAX_WORKERS", "5"))

    while True:
        # Get current active job count
        active_count = len(worker_pool.active_jobs)

        if active_count < max_workers:
            # Try to dequeue (with timeout to check periodically)
            job = await queue_client.dequeue_job(timeout=1.0)

            if job:
                asyncio.create_task(process_job(job))
        else:
            # Wait before checking again
            await asyncio.sleep(0.5)

async def process_job(job: JobMetadata):
    try:
        job.started_at = datetime.now()
        job.status = "processing"
        await queue_client.update_job_metadata(job)

        # Forward to agent (uses existing _proxy_request logic)
        response = await _proxy_request(job.agent, job.path, job)

        # Store result
        job.completed_at = datetime.now()
        job.status = "completed"
        await queue_client.store_result(job.request_id, response, job.ttl_seconds)
        await queue_client.update_job_metadata(job)

    except Exception as e:
        if job.retry_count < MAX_RETRIES:
            job.retry_count += 1
            job.status = "retrying"
            # Push back to queue with slight delay
            await queue_client.requeue_job(job, delay_ms=1000 * (2 ** job.retry_count))
        else:
            job.status = "failed"
            job.error = str(e)
            await queue_client.store_result(job.request_id, {"error": str(e)}, job.ttl_seconds)
```

### 4. Result Retrieval Endpoints (NEW)

Clients poll these endpoints to retrieve status and results:

```python
@app.get("/api/v1/queue/{request_id}")
async def get_job_status(request_id: str):
    """Poll job status - returns current state without blocking"""
    metadata = await queue_client.get_job_metadata(request_id)
    if not metadata:
        raise HTTPException(404, "Request not found")

    return {
        "request_id": request_id,
        "status": metadata.status,
        "created_at": metadata.created_at,
        "started_at": metadata.started_at,
        "completed_at": metadata.completed_at,
        "queue_position": await queue_client.get_job_position(request_id),
        "estimated_wait_seconds": await queue_client.estimate_wait_time()
    }

@app.get("/api/v1/queue/{request_id}/result")
async def get_job_result(request_id: str):
    """Get completed result - returns original agent response or error"""
    result = await queue_client.get_result(request_id)
    if not result:
        metadata = await queue_client.get_job_metadata(request_id)
        if not metadata:
            raise HTTPException(404, "Request not found")
        if metadata.status != "completed":
            raise HTTPException(202, "Job not yet completed")

    return result

@app.get("/api/v1/queue/metrics")
@limiter.limit("10/minute")
async def get_queue_metrics(request: Request):
    """Return queue metrics for monitoring"""
    metrics = await queue_client.get_metrics()
    return metrics
```

### 5. Configuration

**Environment Variables** (add to docker-compose.yml and .env):

```
QUEUE_ENABLED=true                 # Enable/disable queueing
QUEUE_MAX_WORKERS=5                # Concurrency limit (1-20)
QUEUE_MAX_SIZE=500                 # Max queued jobs before 429
QUEUE_RESULT_TTL=1800              # Result storage TTL (seconds)
QUEUE_JOB_TIMEOUT=3600             # Per-job timeout (seconds)
QUEUE_RETRY_MAX=3                  # Max retries per job
```

### 6. Queue Management Operations

**Monitoring/Admin Endpoints** (optional):

```python
@app.get("/admin/queue/stats")
async def get_queue_stats():
    """Queue statistics"""

@app.post("/admin/queue/flush")
async def flush_queue():
    """Clear all pending jobs (admin only)"""

@app.post("/admin/queue/worker/pause")
async def pause_workers():
    """Pause job processing"""

@app.post("/admin/queue/worker/resume")
async def resume_workers():
    """Resume job processing"""
```

## Files to Create

1. **`api-gateway/queue_manager.py`** (600-700 lines)
   - QueueClient class
   - JobMetadata Pydantic model
   - WorkerPool class
   - Retry/backoff logic
   - Metrics collection

2. **`api-gateway/.env.queue`** (optional, for local testing)
   - Queue configuration overrides

## Files to Modify

1. **`api-gateway/main.py`**
   - Add aioredis import
   - Initialize QueueClient on startup
   - Add worker loop to lifespan
   - Modify proxy route handlers to enqueue AI-heavy requests
   - Add `/api/v1/queue/*` endpoints
   - Add health check for queue/Redis status

2. **`api-gateway/requirements.txt`**
   - Add `aioredis>=2.0.0`
   - Add `pydantic>=2.0.0` (already present likely)

3. **`docker-compose.yml`**
   - Add QUEUE\_\* environment variables to api-gateway service
   - Ensure redis service is available

## Idempotency & Deduplication

**Strategy**:

- Use request_id as deduplication key
- Store request fingerprint (hash of agent + path + payload) in Redis
- If duplicate detected (same fingerprint within 60s):
  - Return 202 with same request_id
  - Don't requeue
  - Return existing result if completed

```python
async def check_duplicate(agent: str, path: str, payload: dict) -> Optional[str]:
    fingerprint = hashlib.sha256(f"{agent}:{path}:{json.dumps(payload, sort_keys=True)}".encode()).hexdigest()
    existing_request_id = await redis.get(f"dedup:{fingerprint}")
    return existing_request_id
```

## Pass-Through vs Queue Decision Logic

**Queue (FIFO processing)**:

- POST/PUT/PATCH to assessment, planner, code-review, support agents
- Complex queries to support agent (`/api/v1/support/assistant/ask-me`)

**Pass-Through (direct proxy)**:

- GET requests (read-only)
- Health checks
- POST for quick operations (< 5 seconds expected)
- Task management agent GET operations
- Admin endpoints

## Testing Strategy

1. **Unit Tests** (test_queue_manager.py):
   - Test job enqueue/dequeue
   - Test retry logic
   - Test backpressure (429 when full)
   - Test TTL expiration
   - Test deduplication

2. **Integration Tests**:
   - Make POST to /api/v1/assessment/generate
   - Verify 202 response with request_id
   - Poll /api/v1/queue/{request_id} for status
   - Retrieve result after completion
   - Verify queue_size increases/decreases

3. **Load Tests**:
   - Send 100 concurrent requests
   - Verify queue size = 100
   - Verify only 5 (or configured limit) process in parallel
   - Verify all requests complete successfully
   - Measure latency vs direct proxy

4. **Verification**:
   - Redis logs show LPUSH/BLPOP operations
   - Metrics endpoint shows queue depth and worker count
   - Observability: log all job lifecycle events

## Rollback Strategy

Queue can be disabled quickly:

```
QUEUE_ENABLED=false → All requests pass directly to agents (existing behavior)
```

## Dependencies

- `aioredis>=2.0.0` (async Redis client)
- `pydantic>=2.0.0` (already present)
- `redis` service running (already provisioned)

## Critical Success Metrics

- ✅ Burst requests (100+) handled gracefully with queuing
- ✅ Concurrency limited to configured max (never exceeds)
- ✅ 429 backpressure triggers when queue exceeds threshold
- ✅ Request completes even if client disconnects (async processing)
- ✅ Results retrievable for 30 minutes after completion
- ✅ No duplicate processing for identical requests
- ✅ Retry logic works transparently (client doesn't see transient failures)
- ✅ Metrics accurately reflect queue state and throughput
- ✅ Zero impact to Nginx configuration (stays lightweight)

## Phase 2 Roadmap (Future Enhancements)

- ~~Add priority queue support (high/normal)~~ ✅ **Shipped** — `X-Request-Priority` header, `queue:high:{agent}` / `queue:normal:{agent}` Redis keys
- Add webhook callback option (X-Callback-Webhook) for async notifications
- Add queue visualizer UI for ops team
- Implement per-user request limits
- Add circuit breaker pattern for downstream agents
- Performance tuning and benchmarking

## Notes

- Nginx remains unchanged (still pure reverse proxy)
- All business logic lives in API Gateway
- Redis provides durability for jobs (survives restarts)
- Async/await design integrates seamlessly with existing FastAPI code
- Future: Can be upgraded to BullMQ-style queue with UI dashboard
