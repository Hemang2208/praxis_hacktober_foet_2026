import asyncio
import datetime
import json
import re
import bleach
import os
import signal
import sys
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Dict, Optional, Any
from urllib.parse import urljoin

import httpx
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse, JSONResponse
from dotenv import load_dotenv

from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

# Queue management imports
from queue_manager import QueueClient, WorkerPool, JobMetadata, generate_request_id

limiter = Limiter(key_func=get_remote_address)

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _is_docker_mode() -> bool:
	"""Interpret DOCKER_MODE from env in a predictable boolean way."""
	value = os.getenv("DOCKER_MODE", "").strip().lower()
	return value in {"1", "true", "yes", "on"}


# Configuration: map agent name -> (path to agent main, port)
ROOT = Path(__file__).resolve().parent
AGENTS = {
	"assessment-agent": {
		"path": (ROOT / ".." / "assessment-agent" / "main.py").resolve(),
		"port": 8001,
	},
	"planner-agent": {
		"path": (ROOT / ".." / "planner-agent" / "app" / "main.py").resolve(),
		"port": 8002,
	},
	"task-mgmt-agent": {
		"path": (ROOT / ".." / "task-mgmt-agent" / "main.py").resolve(),
		"port": 8003,
	},
	"support-agent": {
		"path": (ROOT / ".." / "support-agent" / "main.py").resolve(),
		"port": 8005,
	},
	"code-review-agent": {
		"path": (ROOT / ".." / "code-review-agent" / "app" / "main.py").resolve(),
		"port": 8004,
	},
}
 

class AgentProcess:
	def __init__(self, name: str, path: Path, port: int):
		self.name = name
		self.path = str(path)
		self.port = str(port)
		self.proc: Optional[asyncio.subprocess.Process] = None
		self._log_task: Optional[asyncio.Task] = None

	async def start(self):
		env = os.environ.copy()
		env["PORT"] = self.port

		# Load .env file from agent's directory into env dict
		agent_dir = Path(self.path).parent
		env_file = agent_dir / ".env"
		if env_file.exists():
			from dotenv import dotenv_values
			env_vars = dotenv_values(env_file)
			env.update(env_vars)

		# Add repository root and agent directory to PYTHONPATH
		path_sep = ";" if os.name == "nt" else ":"
		repo_root = str(ROOT.parent)
		pythonpaths = [repo_root, str(agent_dir)]
		existing_pythonpath = env.get("PYTHONPATH", "")
		if existing_pythonpath:
			pythonpaths.append(existing_pythonpath)
		env["PYTHONPATH"] = path_sep.join(pythonpaths)

		# Use the venv Python executable
		venv_python = Path(__file__).parent / ".venv" / "Scripts" / "python.exe"
		venv_python_unix = Path(__file__).parent / ".venv" / "bin" / "python"
		if venv_python.exists():
			cmd = [str(venv_python), self.path]
		elif venv_python_unix.exists():
			cmd = [str(venv_python_unix), self.path]
		else:
			# Fallback to the Python interpreter running the gateway
			cmd = [sys.executable, self.path]

		# Launch the child process
		self.proc = await asyncio.create_subprocess_exec(
			*cmd,
			stdout=asyncio.subprocess.PIPE,
			stderr=asyncio.subprocess.PIPE,
			env=env,
		)

		# Start tasks to stream logs
		self._log_task = asyncio.create_task(self._stream_logs())

	async def _stream_logs(self):
		assert self.proc is not None
		async def read_stream(stream, prefix: str):
			while True:
				line = await stream.readline()
				if not line:
					break
				print(f"[{self.name} {prefix}] {line.decode().rstrip()}")

		await asyncio.gather(
			read_stream(self.proc.stdout, "OUT"),
			read_stream(self.proc.stderr, "ERR"),
		)

	async def stop(self):
		if self.proc is None:
			return
		try:
			self.proc.send_signal(signal.SIGINT)
			await asyncio.wait_for(self.proc.wait(), timeout=5.0)
		except Exception:
			try:
				self.proc.kill()
			except Exception:
				pass
		self.proc = None
		if self._log_task:
			await asyncio.sleep(0.1)
			self._log_task.cancel()


MANAGED: Dict[str, AgentProcess] = {}

# Global queue client and worker pool
queue_client: Optional[QueueClient] = None
worker_pool: Optional[WorkerPool] = None
worker_tasks: list = []


def _is_queue_enabled() -> bool:
	"""Check if queue is enabled via environment."""
	value = os.getenv("QUEUE_ENABLED", "false").strip().lower()
	return value in {"1", "true", "yes", "on"}


async def worker_loop(agent: str):
	"""
	Background worker loop for processing jobs from queue.
	
	Args:
		agent: Agent name to process jobs for
	"""
	global queue_client, worker_pool
	
	logger.info(f"👷 WORKER LOOP STARTED | agent={agent}")
	
	while True:
		try:
			# Check if we can process more jobs
			if not worker_pool or not worker_pool.is_available():
				await asyncio.sleep(0.5)
				continue
			
			# Try to dequeue job (blocking with timeout)
			job = await queue_client.dequeue_job(agent, timeout=1.0)
			
			if job:
				# Spawn task to process job
				asyncio.create_task(process_job(job))
		
		except asyncio.CancelledError:
			logger.info(f"🛑 WORKER LOOP CANCELLED | agent={agent}")
			break
		except Exception as e:
			logger.error(f"❌ WORKER LOOP ERROR | agent={agent} | error={str(e)}")
			await asyncio.sleep(1.0)


async def process_job(job: JobMetadata):
	"""
	Process a single job from the queue.
	
	Args:
		job: Job metadata
	"""
	global queue_client, worker_pool
	
	# Acquire worker slot
	if not await worker_pool.acquire(job.request_id):
		# Shouldn't happen, but requeue if it does
		logger.warning(f"⚠️  WORKER ACQUISITION FAILED | request_id={job.request_id} | action=requeuing")
		await queue_client.requeue_job(job)
		return
	
	try:
		# Update status to processing
		job.status = "processing"
		job.started_at = datetime.datetime.now(datetime.timezone.utc).timestamp()
		await queue_client.update_job_status(job)
		
		logger.info(f"⚙️  JOB PROCESSING STARTED | request_id={job.request_id} | agent={job.agent} | method={job.method} | path={job.path}")
		
		# Create a mock request object for _proxy_request
		# We'll build the request data from job metadata
		class MockRequest:
			def __init__(self, job: JobMetadata):
				self.method = job.method
				# Normalize header keys to lowercase so content-type checks in
				# _proxy_request work regardless of the original casing.
				self.headers = {k.lower(): v for k, v in job.headers.items()}
				self.query_params = job.query_params
				self._body = json.dumps(job.payload).encode('utf-8') if job.payload else b''
				# Payload was already sanitized during enqueue — skip re-sanitization
				self._already_sanitized = True
			
			async def body(self):
				return self._body
		
		mock_request = MockRequest(job)
		
		# Forward to agent using existing proxy logic
		response = await _proxy_request(job.agent, job.path, mock_request)
		
		# Extract response data (strip transport-level headers so stored
		# metadata doesn't mislead downstream consumers)
		clean_headers = {
			k: v
			for k, v in response.headers.items()
			if k.lower() not in ("content-length", "content-encoding", "transfer-encoding", "connection")
		}
		result = {
			"status_code": response.status_code,
			"headers": clean_headers,
			"body": response.body.decode('utf-8') if response.body else None
		}
		
		# Try to parse as JSON for cleaner storage
		try:
			if result["body"]:
				result["data"] = json.loads(result["body"])
		except:
			pass
		
		# Store result
		await queue_client.store_result(job.request_id, result, job.ttl_seconds)
		
		# Update job status
		job.status = "completed"
		job.completed_at = datetime.datetime.now(datetime.timezone.utc).timestamp()
		await queue_client.update_job_status(job)
		
		# Record metrics
		queue_client.record_job_complete(job, success=True)
		
		logger.info(f"✅ JOB COMPLETED | request_id={job.request_id} | agent={job.agent} | status_code={response.status_code}")
	
	except Exception as e:
		logger.error(f"❌ JOB PROCESSING ERROR | request_id={job.request_id} | agent={job.agent} | error={str(e)}")
		
		# Check if we should retry
		if job.retry_count < queue_client.max_retries:
			job.retry_count += 1
			job.status = "retrying"
			await queue_client.update_job_status(job)
			
			# Requeue with exponential backoff
			delay_ms = 1000 * (2 ** job.retry_count)
			await queue_client.requeue_job(job, delay_ms=delay_ms)
		else:
			# Max retries exceeded, mark as failed
			job.status = "failed"
			job.error = str(e)
			job.completed_at = datetime.datetime.now(datetime.timezone.utc).timestamp()
			await queue_client.update_job_status(job)
			
			# Store error as result
			error_result = {
				"error": str(e),
				"status": "failed",
				"retry_count": job.retry_count
			}
			await queue_client.store_result(job.request_id, error_result, job.ttl_seconds)
			
			# Record metrics
			queue_client.record_job_complete(job, success=False)
	
	finally:
		# Release worker slot
		await worker_pool.release(job.request_id)


@asynccontextmanager
async def lifespan(app: FastAPI):
	global queue_client, worker_pool, worker_tasks
	
	# Initialize queue if enabled
	if _is_queue_enabled():
		redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
		max_workers = int(os.getenv("QUEUE_MAX_WORKERS", "5"))
		
		logger.info(f"🔄 QUEUE SYSTEM STARTING | redis_url={redis_url} | max_workers={max_workers}")
		
		queue_client = QueueClient(redis_url)
		await queue_client.connect()
		
		worker_pool = WorkerPool(max_workers)
		
		# Start worker loops for each agent
		agents_to_queue = ["assessment-agent", "planner-agent", "code-review-agent", "task-mgmt-agent"]
		for agent in agents_to_queue:
			task = asyncio.create_task(worker_loop(agent))
			worker_tasks.append(task)
		
		logger.info(f"✅ QUEUE SYSTEM STARTED | max_workers={max_workers} | agents={len(agents_to_queue)}")
	
	# In Docker Compose each agent runs as its own service; do not spawn local subprocesses.
	if _is_docker_mode():
		yield
		
		# Shutdown queue
		if _is_queue_enabled() and queue_client:
			logger.info("🔻 QUEUE SYSTEM SHUTTING DOWN...")
			
			# Cancel worker tasks
			for task in worker_tasks:
				task.cancel()
			
			await asyncio.gather(*worker_tasks, return_exceptions=True)
			
			# Disconnect from Redis
			await queue_client.disconnect()
			logger.info("✅ QUEUE SYSTEM SHUT DOWN")
		
		return

	# Startup: Start all agents
	started_agents = []
	for name, info in AGENTS.items():
		path = info["path"]
		port = info["port"]
		if not Path(path).exists():
			print(f"Warning: agent {name} main not found at {path}; skipping start")
			continue
		agent = AgentProcess(name, Path(path), port)
		MANAGED[name] = agent
		print(f"Starting agent {name} at port {port} -> {path}")
		asyncio.create_task(agent.start())
		started_agents.append((name, port))
	# Print all STARTED lines together before app startup completes
	for name, port in started_agents:
		print(f"STARTED {name.upper()} AT http://127.0.0.1:{port}")
	
	yield
	
	# Shutdown: Stop queue system
	if _is_queue_enabled() and queue_client:
		logger.info("🔻 QUEUE SYSTEM SHUTTING DOWN...")
		
		# Cancel worker tasks
		for task in worker_tasks:
			task.cancel()
		
		await asyncio.gather(*worker_tasks, return_exceptions=True)
		
		# Disconnect from Redis
		await queue_client.disconnect()
		logger.info("✅ QUEUE SYSTEM SHUT DOWN")
	
	# Shutdown: Stop all agents
	stop_tasks = []
	for name, agent in MANAGED.items():
		stop_tasks.append(agent.stop())
	if stop_tasks:
		await asyncio.gather(*stop_tasks, return_exceptions=True)


app = FastAPI(
	title="PRAXIS API Gateway - local process manager",
	lifespan=lifespan
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Add CORS middleware to allow frontend requests
def get_allowed_origins():
	"""Read CORS origins from the environment and always allow local development."""
	configured = os.getenv("ALLOWED_ORIGINS", "")
	origins = [origin.strip() for origin in configured.split(",") if origin.strip()]
	for local in ("http://localhost:3000", "http://localhost:8000", "http://localhost", "http://127.0.0.1:3000"):
		if local not in origins:
			origins.append(local)
	return origins

app.add_middleware(
	CORSMiddleware,
	allow_origins=get_allowed_origins(),
	allow_credentials=True,
	allow_methods=["*"],
	allow_headers=["*"],
	expose_headers=["*"]
)


def _agent_url(name: str, path: str = "") -> str:
	info = AGENTS.get(name)
	if not info:
		raise KeyError(name)
	port = info["port"]
	host = "127.0.0.1"
	if _is_docker_mode():
		host = name
	base = f"http://{host}:{port}"
	if path:
		return base + ("/" + path.lstrip("/"))
	return base


@app.get("/agents")
@limiter.limit("10/minute")
async def list_agents(request: Request):
	# returns the configured agents and their ports
	return {k: {"port": v["port"], "path": str(v["path"])} for k, v in AGENTS.items()}


@app.get("/api/health")
@limiter.limit("20/minute")
async def health_check(request: Request):
	"""Health check endpoint that verifies all services are running"""
	import datetime
	
	health_status = {
		"status": "healthy",
		"timestamp": datetime.datetime.now().isoformat(),
		"api_gateway": {
			"status": "running",
			"port": 8000,
			"message": "API Gateway is operational"
		},
		"services": {}
	}
	
	# Check each agent service
	async with httpx.AsyncClient(timeout=5.0) as client:
		for agent_name, agent_config in AGENTS.items():
			try:
				port = agent_config["port"]
				url = _agent_url(agent_name, "/")
				
				# Try to reach the service
				resp = await client.get(url)
				
				health_status["services"][agent_name] = {
					"status": "running" if resp.status_code < 500 else "error",
					"port": port,
					"response_code": resp.status_code,
					"message": "Service is responding"
				}
				
			except httpx.RequestError as e:
				health_status["services"][agent_name] = {
					"status": "error",
					"port": port,
					"message": f"Service unreachable: {str(e)}"
				}
			except Exception as e:
				health_status["services"][agent_name] = {
					"status": "error", 
					"port": port,
					"message": f"Unknown error: {str(e)}"
				}
	
	# Determine overall health
	service_statuses = [service["status"] for service in health_status["services"].values()]
	if any(status == "error" for status in service_statuses):
		health_status["status"] = "degraded"
	
	return health_status


@app.get("/v1/models")
@limiter.limit("20/minute")
async def list_models(request: Request):
	"""Model list endpoint for the local Ollama model."""
	model = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:latest")
	return {
		"object": "list",
		"data": [
			{
				"id": model,
				"object": "model",
				"created": int(datetime.datetime.now().timestamp()),
				"owned_by": "ollama",
			}
		],
	}


@app.get("/health")
@limiter.limit("20/minute")
async def simple_health(request: Request):
	"""Simple health check for basic status"""
	return {
		"status": "healthy",
		"message": "PRAXIS API Gateway is running",
		"timestamp": datetime.datetime.now().isoformat()
	}


@app.get("/")
@limiter.limit("30/minute")
async def root_live(request: Request):
	"""Root liveness endpoint."""
	return PlainTextResponse("Live! 🚀")


def _should_queue_request(agent_name: str, method: str, path: str) -> bool:
	"""
	Determine if request should be queued or passed through.
	
	Queue: POST/PUT/PATCH/DELETE operations to AI agents
	Pass-through: GET requests, health checks, admin endpoints, plan checks
	"""
	if not _is_queue_enabled():
		return False
	
	# Always pass through GET requests (read operations should be fast)
	if method == "GET":
		return False
	
	# Always pass through OPTIONS (CORS preflight)
	if method == "OPTIONS":
		return False
	
	# Health and admin endpoints - pass through
	if "health" in path.lower() or "admin" in path.lower():
		return False
	
	# Pass through plan-check POSTs — the frontend uses POST to check if a
	# plan exists (read-like operation).  These must respond synchronously
	# so the UI can decide whether to show "Generate" or "View" buttons.
	# Pattern: .../projects/{id}/plan  (planner-agent and task-mgmt-agent)
	norm_path = path.strip("/").lower()
	if re.search(r"projects/[^/]+/plan$", norm_path) and method == "POST":
		logger.info(f"⏩ PASS-THROUGH (plan check) | agent={agent_name} | method={method} | path={path}")
		return False
	
	# Queue AI-heavy agents for write/delete operations
	ai_agents = {"assessment-agent", "planner-agent", "code-review-agent", "task-mgmt-agent"}
	if agent_name in ai_agents and method in ["POST", "PUT", "PATCH", "DELETE"]:
		logger.info(f"📥 QUEUEING REQUEST | agent={agent_name} | method={method} | path={path}")
		return True
	

	
	return False


# Every queue endpoint response MUST include these headers to prevent
# Cloudflare / nginx / browsers from caching status or result data.
_NO_CACHE_HEADERS = {
	"Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0",
	"Pragma": "no-cache",
	"Expires": "0",
	"Surrogate-Control": "no-store",
}


async def _enqueue_request(agent_name: str, path: str, request: Request) -> JSONResponse:
	"""
	Enqueue request and return 202 Accepted with job info.
	
	Reads the X-Request-Priority header to determine queue tier:
	  'high'   → queue:high:{agent}   (drained first by workers)
	  'normal' → queue:normal:{agent} (default, background processing)
	
	Args:
		agent_name: Target agent
		path: API path
		request: FastAPI request object
		
	Returns:
		202 response with job details including priority
	"""
	global queue_client
	
	# Extract request data
	method = request.method
	headers = {k.lower(): v for k, v in request.headers.items() if k.lower() != "host"}
	query_params = dict(request.query_params)
	
	# Read X-Request-Priority header, default to 'normal'
	raw_priority = request.headers.get("x-request-priority", "normal").strip().lower()
	priority = "high" if raw_priority == "high" else "normal"
	logger.info(f"🏷️  PRIORITY RESOLVED | agent={agent_name} | header='{raw_priority}' | resolved='{priority}'")
	
	# Get payload
	payload = {}
	if method in ["POST", "PUT", "PATCH"]:
		try:
			body_bytes = await request.body()
			if body_bytes:
				if "application/json" in headers.get("content-type", ""):
					payload = json.loads(body_bytes)
					# Sanitize payload
					payload = sanitize_payload(payload)
		except Exception as e:
			logger.warning(f"⚠️  REQUEST BODY ERROR | error={str(e)}")
	
	# Check for duplicate request
	existing_request_id = await queue_client.check_duplicate(agent_name, path, method, payload)
	if existing_request_id:
		# Return existing job info
		existing_job = await queue_client.get_job_metadata(existing_request_id)
		if existing_job:
			queue_position = await queue_client.get_queue_position(existing_request_id)
			estimated_wait = await queue_client.estimate_wait_time(agent_name)
			
			return JSONResponse(
				status_code=202,
				content={
					"status": existing_job.status,
					"priority": existing_job.priority,
					"request_id": existing_request_id,
					"message": "Duplicate request detected, returning existing job",
					"queue_position": queue_position,
					"estimated_wait_seconds": int(estimated_wait),
					"status_url": f"/api/v1/queue/{existing_request_id}",
					"result_url": f"/api/v1/queue/{existing_request_id}/result"
				},
				headers=_NO_CACHE_HEADERS,
			)
	
	request_id = generate_request_id()
	
	job = JobMetadata(
		request_id=request_id,
		agent=agent_name,
		path=path,
		method=method,
		headers=headers,
		query_params=query_params,
		payload=payload,
		priority=priority
	)
	
	enqueued = await queue_client.enqueue_job(job)
	
	if not enqueued:
		# Queue is full - backpressure
		estimated_wait = await queue_client.estimate_wait_time(agent_name)
		return JSONResponse(
			status_code=429,
			content={
				"error": "Queue is full",
				"message": "Too many requests. Please try again later.",
				"retry_after_seconds": int(estimated_wait)
			},
			headers={
				"Retry-After": str(int(estimated_wait)),
				**_NO_CACHE_HEADERS,
			}
		)
	
	await queue_client.register_request(request_id, agent_name, path, method, payload)
	
	queue_position = await queue_client.get_queue_position(request_id)
	estimated_wait = await queue_client.estimate_wait_time(agent_name)
	
	return JSONResponse(
		status_code=202,
		content={
			"status": "queued",
			"priority": priority,
			"request_id": request_id,
			"queue_position": queue_position if queue_position is not None else 0,
			"estimated_wait_seconds": int(estimated_wait),
			"status_url": f"/api/v1/queue/{request_id}",
			"result_url": f"/api/v1/queue/{request_id}/result",
			"message": f"Request queued as '{priority}' priority. Poll status_url for updates."
		},
		headers=_NO_CACHE_HEADERS,
	)


# ============================================================================
# Queue Endpoints
# ============================================================================


@app.get("/api/v1/queue/{request_id}")
@limiter.limit("60/minute")
async def get_job_status(request: Request, request_id: str):
	"""Get job status and metadata (never cached)."""
	global queue_client
	
	if not _is_queue_enabled() or not queue_client:
		raise HTTPException(status_code=501, detail="Queue system not enabled")
	
	metadata = await queue_client.get_job_metadata(request_id)
	if not metadata:
		logger.warning(f"🚨 QUEUE_ENDPOINT_404 | request_id={request_id} | action=returning_404")
		raise HTTPException(status_code=404, detail="Request not found")
	
	# Get additional info
	queue_position = await queue_client.get_queue_position(request_id)
	estimated_wait = await queue_client.estimate_wait_time(metadata.agent)
	
	logger.info(f"🚨 QUEUE_ENDPOINT_RESPONSE | request_id={request_id} | status={metadata.status} | completed_at={metadata.completed_at}")
	
	return JSONResponse(
		content={
			"request_id": request_id,
			"status": metadata.status,
			"priority": metadata.priority,
			"agent": metadata.agent,
			"created_at": datetime.datetime.fromtimestamp(metadata.created_at, tz=datetime.timezone.utc).isoformat(),
			"started_at": datetime.datetime.fromtimestamp(metadata.started_at, tz=datetime.timezone.utc).isoformat() if metadata.started_at else None,
			"completed_at": datetime.datetime.fromtimestamp(metadata.completed_at, tz=datetime.timezone.utc).isoformat() if metadata.completed_at else None,
			"queue_position": queue_position,
			"estimated_wait_seconds": int(estimated_wait) if queue_position is not None else 0,
			"retry_count": metadata.retry_count,
			"error": metadata.error,
		},
		headers=_NO_CACHE_HEADERS,
	)


@app.get("/api/v1/queue/{request_id}/result")
@limiter.limit("30/minute")
async def get_job_result(request: Request, request_id: str):
	"""Get job result (completed jobs only, never cached)."""
	global queue_client
	
	if not _is_queue_enabled() or not queue_client:
		raise HTTPException(status_code=501, detail="Queue system not enabled")
	
	# Check job status first
	metadata = await queue_client.get_job_metadata(request_id)
	if not metadata:
		raise HTTPException(status_code=404, detail="Request not found")
	
	if metadata.status == "queued":
		raise HTTPException(status_code=202, detail="Job is queued and not yet started")
	
	if metadata.status == "processing":
		raise HTTPException(status_code=202, detail="Job is currently processing")
	
	if metadata.status == "retrying":
		raise HTTPException(status_code=202, detail="Job is retrying after failure")
	
	# Get result
	result = await queue_client.get_result(request_id)
	if not result:
		if metadata.status == "failed":
			raise HTTPException(status_code=500, detail=metadata.error or "Job failed")
		raise HTTPException(status_code=404, detail="Result not found or expired")
	
	return JSONResponse(content=result, headers=_NO_CACHE_HEADERS)


@app.get("/api/v1/queue/metrics")
@limiter.limit("10/minute")
async def get_queue_metrics_endpoint(request: Request):
	"""Get queue metrics and statistics."""
	global queue_client, worker_pool
	
	if not _is_queue_enabled() or not queue_client:
		raise HTTPException(status_code=501, detail="Queue system not enabled")
	
	metrics = await queue_client.get_metrics()
	
	# Update active jobs count from worker pool
	if worker_pool:
		metrics.active_jobs = worker_pool.get_active_count()
	
	return JSONResponse(
		content={
			"queue_size": metrics.queue_size,
			"high_queue_size": metrics.high_queue_size,
			"normal_queue_size": metrics.normal_queue_size,
			"active_jobs": metrics.active_jobs,
			"total_processed": metrics.total_processed,
			"total_failed": metrics.total_failed,
			"total_retried": metrics.total_retried,
			"avg_wait_time_seconds": round(metrics.avg_wait_time_seconds, 2),
			"avg_processing_time_seconds": round(metrics.avg_processing_time_seconds, 2),
			"per_agent": metrics.per_agent,
			"timestamp": datetime.datetime.fromtimestamp(metrics.timestamp, tz=datetime.timezone.utc).isoformat(),
		},
		headers=_NO_CACHE_HEADERS,
	)


@app.get("/api/v1/queue/{request_id}/debug")
@limiter.limit("30/minute")
async def get_job_debug(request: Request, request_id: str):
	"""Debug endpoint: dump raw Redis contents for a given request_id."""
	global queue_client
	
	if not _is_queue_enabled() or not queue_client or not queue_client.redis:
		raise HTTPException(status_code=501, detail="Queue system not enabled")
	
	meta_key = queue_client._get_metadata_key(request_id)
	result_key = queue_client._get_result_key(request_id)
	
	meta_raw = await queue_client.redis.get(meta_key)
	result_raw = await queue_client.redis.get(result_key)
	
	meta_ttl = await queue_client.redis.ttl(meta_key)
	result_ttl = await queue_client.redis.ttl(result_key)
	
	return JSONResponse(
		content={
			"request_id": request_id,
			"meta_key": meta_key,
			"result_key": result_key,
			"meta_exists": meta_raw is not None,
			"result_exists": result_raw is not None,
			"meta_ttl_seconds": meta_ttl if meta_ttl and meta_ttl > 0 else None,
			"result_ttl_seconds": result_ttl if result_ttl and result_ttl > 0 else None,
			"meta_raw": json.loads(meta_raw) if meta_raw else None,
			"result_raw": json.loads(result_raw) if result_raw else None,
			"meta_size_bytes": len(meta_raw) if meta_raw else 0,
			"result_size_bytes": len(result_raw) if result_raw else 0,
		},
		headers=_NO_CACHE_HEADERS,
	)


# ============================================================================
# Proxy Routes (with queue decision logic)
# ============================================================================


async def _proxy_request(agent_name: str, path: str, request: Request) -> Response:
	"""Common proxy logic for all agent routes"""
	if agent_name not in AGENTS:
		raise HTTPException(status_code=404, detail=f"Unknown agent {agent_name}")

	target = _agent_url(agent_name, path)
	# Allow longer timeouts for AI-heavy agents.
	request_timeout = 30.0
	if agent_name in {"code-review-agent", "assessment-agent", "planner-agent", "support-agent", "task-mgmt-agent"}:
		request_timeout = 3300.0

	headers = {k.lower(): v for k, v in request.headers.items()}
	# remove host header to avoid conflicts
	headers.pop("host", None)

	content_to_send = None
	# Check if the request was already sanitized (queued job replay)
	already_sanitized = getattr(request, '_already_sanitized', False)
	if request.method in ["POST", "PUT", "PATCH"]:
		try:
			body_bytes = await request.body()
			if body_bytes:
				# Check if it's JSON to sanitize
				if "application/json" in headers.get("content-type", ""):
					if already_sanitized:
						# Already sanitized during enqueue — skip re-sanitization
						content_to_send = body_bytes
					else:
						try:
							payload = json.loads(body_bytes)
							sanitized = sanitize_payload(payload)
							content_to_send = json.dumps(sanitized).encode("utf-8")
							# Update content-length to match sanitized body
							headers["content-length"] = str(len(content_to_send))
						except json.JSONDecodeError:
							content_to_send = body_bytes
				else:
					content_to_send = body_bytes
			else:
				content_to_send = b''
		except Exception as e:
			logger.warning(f"⚠️  BODY SANITIZATION ERROR | error={str(e)}")
			content_to_send = body_bytes if 'body_bytes' in locals() else b''
	else:
		# For GET/DELETE, etc., no body to send
		content_to_send = None # Or explicitly pass None, httpx handles it

	if content_to_send is not None:
		headers["content-length"] = str(len(content_to_send))
	else:
		headers.pop("content-length", None)

	async with httpx.AsyncClient(timeout=request_timeout) as client:
		try:
			resp = await client.request(
				request.method,
				target,
				content=content_to_send,
				params=dict(request.query_params),
				headers=headers,
			)
		except httpx.RequestError as e:
			raise HTTPException(status_code=502, detail=str(e))

	# Strip transport-level headers from the agent response that may not match
	# the actual body after httpx decompression/reassembly. Starlette will
	# recalculate Content-Length based on resp.content automatically.
	resp_headers = {
		k: v
		for k, v in resp.headers.items()
		if k.lower() not in ("content-length", "content-encoding", "transfer-encoding", "connection")
	}
	logger.debug(
		"PROXY RESPONSE | agent=%s | path=%s | method=%s | status=%d | body_bytes=%d | orig_content_length=%s",
		agent_name, path, request.method, resp.status_code, len(resp.content),
		resp.headers.get("content-length", "N/A"),
	)
	return Response(content=resp.content, status_code=resp.status_code, headers=resp_headers)


# Assessment Agent Routes - /api/v1/assessments/* (note: plural)
@app.api_route("/api/v1/assessments/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@limiter.limit("60/minute")
async def assessments_proxy(request: Request, path: str):
	"""Proxy requests to assessment-agent"""
	if _should_queue_request("assessment-agent", request.method, path):
		return await _enqueue_request("assessment-agent", f"api/v1/assessments/{path}", request)
	return await _proxy_request("assessment-agent", f"api/v1/assessments/{path}", request)


# Legacy route (singular) - redirect to plural
@app.api_route("/api/v1/assessment/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@limiter.limit("60/minute")
async def assessment_proxy(request: Request, path: str):
	"""Legacy proxy - redirects to plural route"""
	if _should_queue_request("assessment-agent", request.method, path):
		return await _enqueue_request("assessment-agent", f"api/v1/assessments/{path}", request)
	return await _proxy_request("assessment-agent", f"api/v1/assessments/{path}", request)


# Task Management Agent Routes - /api/v1/task/*
@app.api_route("/api/v1/task/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@limiter.limit("60/minute")
async def task_proxy(request: Request, path: str):
	"""Proxy requests to task-mgmt-agent"""
	if _should_queue_request("task-mgmt-agent", request.method, path):
		return await _enqueue_request("task-mgmt-agent", f"api/v1/{path}", request)
	return await _proxy_request("task-mgmt-agent", f"api/v1/{path}", request)


# Planner Agent proxy - /api/v1/planner/*
@app.api_route("/api/v1/planner/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@limiter.limit("60/minute")
async def planner_proxy(request: Request, path: str):
	"""Proxy requests to planner-agent"""
	if _should_queue_request("planner-agent", request.method, path):
		return await _enqueue_request("planner-agent", f"api/v1/{path}", request)
	return await _proxy_request("planner-agent", f"api/v1/{path}", request)

# Support Agent proxy - /api/v1/support/*
@app.api_route("/api/v1/support/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@limiter.limit("60/minute")
async def support_proxy(request: Request, path: str):
	"""Proxy requests to support-agent"""
	if _should_queue_request("support-agent", request.method, path):
		return await _enqueue_request("support-agent", f"api/v1/{path}", request)
	return await _proxy_request("support-agent", f"api/v1/{path}", request)

# Code Review Agent proxy - /api/v1/code-review/*
@app.api_route("/api/v1/code-review/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@limiter.limit("60/minute")
async def code_review_proxy(request: Request, path: str):
	"""Proxy requests to code-review-agent"""
	if _should_queue_request("code-review-agent", request.method, path):
		return await _enqueue_request("code-review-agent", f"api/v1/{path}", request)
	return await _proxy_request("code-review-agent", f"api/v1/{path}", request)

# --- Global Input Sanitization Middleware ---
def sanitize_payload(data: Any) -> Any:
    """Recursively sanitize strings in the payload to prevent XSS."""
    if isinstance(data, str):
        # Allow basic safe tags if needed, or strip entirely.
        sanitized = bleach.clean(data, tags=[], attributes={}, strip=True)
        return sanitized.strip()
    elif isinstance(data, dict):
        return {k: sanitize_payload(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [sanitize_payload(v) for v in data]
    return data

# --- End Input Sanitization Middleware ---

# WebSocket Proxy - /agent/support-agent/v1/assistant/ws/chat/{session_id}
# FastAPI's api_route does NOT handle WebSocket upgrades, so we need an explicit
# WebSocket route that bidirectionally pipes frames between client and agent.
from fastapi import WebSocket as GWWebSocket, WebSocketDisconnect as GWWebSocketDisconnect
import websockets as _ws_lib

@app.websocket("/agent/support-agent/{path:path}")
async def ws_support_proxy(gateway_ws: GWWebSocket, path: str):
	"""WebSocket reverse-proxy: forwards chat connections to support-agent."""
	# Build the upstream WS URL (ws:// to support-agent directly)
	query = gateway_ws.scope.get("query_string", b"").decode()
	host = "support-agent" if _is_docker_mode() else "127.0.0.1"
	port = AGENTS["support-agent"]["port"]
	upstream_url = f"ws://{host}:{port}/{path}"
	if query:
		upstream_url += f"?{query}"

	await gateway_ws.accept()
	logger.info(f"WS PROXY | upstream={upstream_url}")

	try:
		async with _ws_lib.connect(upstream_url) as upstream_ws:
			async def forward_to_upstream():
				try:
					while True:
						data = await gateway_ws.receive_text()
						await upstream_ws.send(data)
				except GWWebSocketDisconnect:
					await upstream_ws.close()
				except Exception:
					pass

			async def forward_to_client():
				try:
					async for message in upstream_ws:
						await gateway_ws.send_text(message if isinstance(message, str) else message.decode())
				except Exception:
					pass

			await asyncio.gather(forward_to_upstream(), forward_to_client())
	except Exception as e:
		logger.error(f"WS PROXY ERROR | path={path} | error={e}")
		try:
			await gateway_ws.close(code=1011)
		except Exception:
			pass


# Generic Agent Proxy - /agent/{agent_name}/{path}
# This remains for backward compatibility and direct agent access
@app.api_route("/agent/{agent_name}/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
@limiter.limit("60/minute")
async def proxy(request: Request, agent_name: str, path: str):
	"""Generic proxy to any agent (backward compatibility)
	
	Example: /agent/assessment-agent/health -> http://127.0.0.1:8001/health
	"""
	if _should_queue_request(agent_name, request.method, path):
		return await _enqueue_request(agent_name, path, request)
	return await _proxy_request(agent_name, path, request)


if __name__ == "__main__":
	# Run with uvicorn when executed directly
	import uvicorn

	# Run the ASGI app object directly so running this file works regardless of module name
	uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
