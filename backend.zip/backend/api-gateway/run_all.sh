
#!/usr/bin/env bash
set -euo pipefail


BASE_DIR="$(cd "$(dirname "$0")" && pwd)"   # api-gateway directory
VENV_DIR="$BASE_DIR/.venv"

echo "Working in $BASE_DIR"
cd "$BASE_DIR"

# Check Python version
PYVER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
if [[ "$PYVER" != "3.12" ]]; then
  echo "[WARNING] You are using Python $PYVER. This project expects Python 3.12 for best compatibility."
  echo "To switch, use: pyenv install 3.12.12 && pyenv local 3.12.12"
fi

# create venv if missing
if [ ! -d "$VENV_DIR" ]; then
  echo "Creating venv at $VENV_DIR"
  python3 -m venv "$VENV_DIR"
fi

# activate
source "$VENV_DIR/bin/activate"

# upgrade pip quickly (optional)
python -m pip install --upgrade pip setuptools wheel

# install gateway deps
pip install fastapi uvicorn httpx langgraph

# install each agent's requirements if present (best-effort)
AGENTS_DIR="$(cd "$BASE_DIR/.." && pwd)"

# install shared requirements if present
if [ -f "$AGENTS_DIR/shared/requirements.txt" ]; then
  echo "Installing shared requirements..."
  pip install -r "$AGENTS_DIR/shared/requirements.txt"
fi

for agent in assessment-agent planner-agent task-mgmt-agent; do
  REQ="$AGENTS_DIR/$agent/requirements.txt"
  # planner-agent has requirements under app/requirements.txt sometimes
  if [ ! -f "$REQ" ] && [ -f "$AGENTS_DIR/$agent/app/requirements.txt" ]; then
    REQ="$AGENTS_DIR/$agent/app/requirements.txt"
  fi
  if [ -f "$REQ" ]; then
    echo "Installing requirements for $agent from $REQ"
    pip install -r "$REQ"
  else
    echo "No requirements.txt for $agent (skipping)"
  fi
done

echo "Starting gateway (this will spawn the agents). Press Ctrl-C to stop."
# Run gateway in foreground so you see logs; gateway will spawn agents as subprocesses
python main.py

deactivate