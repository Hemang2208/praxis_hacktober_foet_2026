# Code Review Agent

AI-powered code review on pull requests. Integrates with GitHub, analyzes diffs, and returns structured feedback.

**Port:** 8004

## What it does

- Fetches PR diffs from GitHub and runs AI review
- Returns structured feedback: issues, suggestions, severity levels
- Supports multiple review passes (security, style, logic)
- Stores review history per PR

## Structure

Uses an `app/` package layout:

```
code-review-agent/
├── app/
│   ├── main.py         — FastAPI app
│   ├── models.py       — Pydantic models
│   ├── routes.py       — Route handlers
│   ├── services.py     — GitHub + LLM logic
│   └── database.py     — MongoDB connection
├── shared/             — Shared utilities (mounted from root shared/)
├── tests/              — Test files
├── Dockerfile
└── requirements.txt
```

## Main endpoints

```
POST /api/v1/reviews/               — trigger a code review on a PR
GET  /api/v1/reviews/{id}           — get review by ID
GET  /api/v1/reviews/pr/{pr_number} — get review for a specific PR
```

## Env vars

```
MONGODB_URI=
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5-coder:latest
GITHUB_TOKEN=
JWT_SECRET_KEY=
```

## Running locally

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8004
```

## Tests

```bash
cd tests
pytest test_agent.py -v
pytest test_api_auth.py -v
```

## Docs

- `MODELS_README.md` — full model reference
- `START_HERE.md` — setup and auth guide
