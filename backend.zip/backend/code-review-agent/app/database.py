import motor.motor_asyncio
import os
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from pymongo import ASCENDING
from dotenv import load_dotenv

load_dotenv()


class Database:
    client: Optional[AsyncIOMotorClient] = None
    database: Optional[AsyncIOMotorDatabase] = None


# Initialize database connection
async def connect_db():
    try:
        mongo_uri = os.getenv("MONGODB_URI")
        database_name = os.getenv("DATABASE_NAME", "praxis-aipm")
        
        if not mongo_uri:
            print("⚠️ WARNING: MONGODB_URI not set in environment variables")
            return
        
        Database.client = motor.motor_asyncio.AsyncIOMotorClient(mongo_uri)
        Database.database = Database.client[database_name]
        
        # Create indexes for performance
        await create_indexes()
        print("✅ Connected to MongoDB")
    except Exception as e:
        print(f"❌ Failed to connect to MongoDB: {e}")
        Database.client = None
        Database.database = None


async def disconnect_db():
    if Database.client:
        Database.client.close()
        print("Disconnected from MongoDB")


async def create_indexes():
    """Create database indexes for better performance"""
    if Database.database is not None:
        db = Database.database
        
        # AI Feedback collection indexes
        await db.ai_feedback.create_index("user_id")
        await db.ai_feedback.create_index("task_id")
        await db.ai_feedback.create_index("pull_request_url")
        await db.ai_feedback.create_index("status")
        await db.ai_feedback.create_index("created_at")
        await db.ai_feedback.create_index([("user_id", ASCENDING), ("created_at", ASCENDING)])
        await db.ai_feedback.create_index([("task_id", ASCENDING), ("created_at", ASCENDING)])
        
        print("✅ Database indexes created")
    else:
        print("⚠️ Database connection not available. Skipping index creation.")


def get_database():
    """Get the database instance"""
    return Database.database
