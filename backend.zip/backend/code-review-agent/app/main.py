import os
import time
import fnmatch
import logging
from typing import Optional
from datetime import datetime
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
import hmac
import hashlib
import json
import traceback
import tempfile
import shutil
import stat
import gc
import aiohttp
import asyncio
from dotenv import load_dotenv
from bson.errors import InvalidId
from bson import ObjectId
from git import Repo  # type: ignore
from github_integration import GitHubIntegration
from database import connect_db, disconnect_db, get_database
from pydantic import BaseModel
from auth import require_auth
from shared.ollama_service import OllamaService

logger = logging.getLogger(__name__)

load_dotenv()

def remove_readonly(func, path, excinfo):
    """Error handler for shutil.rmtree to handle read-only files on Windows."""
    os.chmod(path, stat.S_IWRITE)
    func(path)

# --- Configuration ---
webhook_secret = os.getenv("GITHUB_WEBHOOK_SECRET")
# Set this to 'True' in your .env to skip signature checks for now
bypass_auth = os.getenv("BYPASS_SIGNATURE", "False").lower() == "true"



app = FastAPI(title="Code Review Agent")

# --- Database Startup/Shutdown ---
@app.on_event("startup")
async def startup_event():
    """Initialize database connection on app startup"""
    await connect_db()

@app.on_event("shutdown")
async def shutdown_event():
    """Close database connection and cleanup sessions on app shutdown"""
    await disconnect_db()
    # Close any remaining aiohttp sessions
    for obj in gc.get_objects():
        if isinstance(obj, aiohttp.ClientSession) and not obj.closed:
            await obj.close()
    logger.info("Cleaned up remaining aiohttp sessions")

# --- CORS Middleware ---
def _get_allowed_origins():
    """Read CORS origins from the environment and always allow local development."""
    configured = os.getenv("ALLOWED_ORIGINS", "")
    origins = [origin.strip() for origin in configured.split(",") if origin.strip()]
    for local in ("http://localhost:3000", "http://localhost:8000", "http://localhost"):
        if local not in origins:
            origins.append(local)
    return origins


app.add_middleware(
    CORSMiddleware,
    allow_origins=_get_allowed_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ReviewRequest(BaseModel):
    repo_path: str = ".."  # Can be local path or GitHub URL (https://github.com/user/repo.git)
    exclude_patterns: Optional[list[str]] = None
    max_chunks: Optional[int] = None
    chunk_size: Optional[int] = None
    max_diff_chars: Optional[int] = None
    use_cache: Optional[bool] = None
    task_id: Optional[str] = None
    project_id: Optional[str] = None

# --- Helper Functions ---

def verify_github_signature(request_body: bytes, signature: str) -> bool:
    if bypass_auth:
        logger.warning("BYPASS MODE: Skipping signature verification.")
        return True
    
    if not webhook_secret:
        logger.error("GITHUB_WEBHOOK_SECRET not set in .env")
        return False
        
    if not signature:
        logger.warning("No signature header found. Ensure GitHub has a 'Secret' set.")
        return False

    secret_bytes = webhook_secret.strip().encode('utf-8')
    expected_signature = "sha256=" + hmac.new(
        secret_bytes,
        msg=request_body,
        digestmod=hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(expected_signature, signature)

DEFAULT_EXCLUDE_PATTERNS = [
    "**/node_modules/**",
    "**/.next/**",
    "**/dist/**",
    "**/build/**",
    "**/coverage/**",
    "**/.cache/**",
    "**/__pycache__/**",
    "**/.venv/**",
    "**/venv/**",
    "**/.git/**",
    "**/.idea/**",
    "**/.vscode/**",
    "**/*.min.*",
    "**/*.map",
    "**/*.lock",
]

_DIFF_CACHE: dict[str, tuple[float, str]] = {}
_REVIEW_CACHE: dict[str, tuple[float, str]] = {}


def _normalize_path(path: str) -> str:
    path = path.replace("\\", "/")
    if path.startswith("a/") or path.startswith("b/"):
        path = path[2:]
    return path.lstrip("/")


def _load_exclude_patterns(extra: Optional[list[str]] = None) -> list[str]:
    env_patterns = os.getenv("REVIEW_EXCLUDE_PATTERNS", "").strip()
    patterns = list(DEFAULT_EXCLUDE_PATTERNS)
    if env_patterns:
        patterns.extend([p.strip() for p in env_patterns.split(",") if p.strip()])
    if extra:
        patterns.extend([p.strip() for p in extra if p and p.strip()])
    return patterns


def _should_exclude(path: str, patterns: list[str]) -> bool:
    normalized = _normalize_path(path)
    for pattern in patterns:
        if fnmatch.fnmatch(normalized, pattern):
            return True
    return False


def filter_diff_by_paths(code_diff: str, patterns: list[str]) -> str:
    if not code_diff:
        return code_diff
    lines = code_diff.splitlines(keepends=True)
    blocks: list[str] = []
    current: list[str] = []
    current_path: Optional[str] = None

    for line in lines:
        if line.startswith("diff --git "):
            if current:
                if current_path is None or not _should_exclude(current_path, patterns):
                    blocks.append("".join(current))
            current = [line]
            current_path = None
            parts = line.strip().split()
            if len(parts) >= 4:
                a_path = parts[2][2:] if parts[2].startswith("a/") else parts[2]
                b_path = parts[3][2:] if parts[3].startswith("b/") else parts[3]
                current_path = b_path or a_path
        else:
            current.append(line)

    if current:
        if current_path is None or not _should_exclude(current_path, patterns):
            blocks.append("".join(current))

    return "".join(blocks)


def _get_cached_diff(key: str, ttl_seconds: int) -> Optional[str]:
    if key not in _DIFF_CACHE:
        return None
    cached_at, diff = _DIFF_CACHE[key]
    if time.time() - cached_at > ttl_seconds:
        _DIFF_CACHE.pop(key, None)
        return None
    return diff


def _set_cached_diff(key: str, diff: str) -> None:
    _DIFF_CACHE[key] = (time.time(), diff)


def _get_cached_review(key: str, ttl_seconds: int) -> Optional[str]:
    if key not in _REVIEW_CACHE:
        return None
    cached_at, review = _REVIEW_CACHE[key]
    if time.time() - cached_at > ttl_seconds:
        _REVIEW_CACHE.pop(key, None)
        return None
    return review


def _set_cached_review(key: str, review: str) -> None:
    _REVIEW_CACHE[key] = (time.time(), review)


def _review_cache_key(diff: str, chunk_size: int, max_chunks: int) -> str:
    digest = hashlib.sha256(diff.encode("utf-8")).hexdigest()
    return f"review:{digest}:{chunk_size}:{max_chunks}"


def get_latest_commit_diff(repo_path: str):
    temp_dir = None
    repo = None
    try:
        if repo_path.startswith("http"):
            temp_dir = tempfile.mkdtemp()
            repo = Repo.clone_from(repo_path, temp_dir)
            working_path = temp_dir
        else:
            repo = Repo(repo_path)
            working_path = repo_path
        
        latest_commit = repo.head.commit
        if len(list(repo.iter_commits(max_count=2))) > 1:
            previous_commit = list(repo.iter_commits(max_count=2))[1]
            diff = repo.git.diff(previous_commit, latest_commit)
        else:
            diff = repo.git.show(latest_commit)
        return diff
    except Exception as e:
        logger.error("Git Error: %s", str(e))
        return ""
    finally:
        if repo is not None:
            try:
                repo.git.clear_cache()
                repo.close()
            except Exception:
                pass
            del repo
            gc.collect()
        
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, onerror=remove_readonly)




async def review_code_with_ollama(
    code_diff: str,
    chunk_size: int = 5000,
    max_chunks: int = 10,
):
    """Review code diff using the local Ollama model."""
    MAX_CHUNK_SIZE = max(chunk_size, 1000)
    reviews = []
    total_chunks = (len(code_diff) + MAX_CHUNK_SIZE - 1) // MAX_CHUNK_SIZE

    ollama = OllamaService(agent_type="code-review")
    
    try:
        for chunk_idx, i in enumerate(range(0, len(code_diff), MAX_CHUNK_SIZE)):
            if chunk_idx >= max_chunks:
                break
            chunk = code_diff[i:i+MAX_CHUNK_SIZE]
            
            messages = [
                {
                    "role": "system",
                    "content": "You are PRAXIS, the official AI Support Agent, and an expert code reviewer. Provide constructive feedback on code quality, security, performance, and best practices.",
                },
                {
                    "role": "user",
                    "content": f"Review this code diff chunk ({chunk_idx+1}/{total_chunks}):\\n\\n{chunk}",
                },
            ]

            try:
                review_text = await ollama.generate_completion(messages=messages)
                reviews.append(f"Chunk {chunk_idx+1} Review:\\n{review_text}")
            except Exception as e:
                logger.error("Error reviewing chunk %d: %s", chunk_idx+1, e)
                raise
        
        if total_chunks > max_chunks:
            reviews.append(f"\\n[NOTE] Review truncated: Only the first {max_chunks} of {total_chunks} chunks were reviewed for speed. Please reduce your diff size for a full review.")
        return "\\n\\n".join(reviews)
    finally:
        await ollama.close()

# --- API Routes ---

@app.get("/")
async def root():
    return {"message": "Code Review Agent is Online", "bypass_active": bypass_auth}

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "code-review-agent"}

@app.post("/api/v1/webhook/github")
async def github_webhook(request: Request):
    try:
        signature = request.headers.get("X-Hub-Signature-256", "")
        event_type = request.headers.get("X-GitHub-Event", "")
        body = await request.body()

        if event_type == "ping":
            return {"message": "PONG"}

        if event_type not in ["push", "pull_request"]:
            logger.info("Skipping event type: %s", event_type)
            return {"status": "skipped", "message": f"Event type '{event_type}' not reviewed"}

        if not body:
            logger.warning("Empty request body received")
            return {"status": "skipped", "message": "Empty request body"}

        if not verify_github_signature(body, signature):
            logger.warning("Invalid GitHub signature")
            return {"status": "error", "message": "Invalid signature"}

        try:
            payload = json.loads(body.decode("utf-8"))
        except json.JSONDecodeError as e:
            logger.error("JSON decode error: %s", str(e))
            return {"status": "error", "message": f"Invalid JSON: {str(e)}"}
        
        if event_type == "push":
            commits = payload.get("commits", [])
            if not commits:
                return {"status": "skipped", "message": "No commits found"}
            
            has_changes = False
            for commit in commits:
                added = commit.get("added", [])
                modified = commit.get("modified", [])
                if added or modified:
                    has_changes = True
                    break
            
            if not has_changes:
                logger.info("No new files or modifications detected")
                return {"status": "skipped", "message": "No new files or modifications"}

        elif event_type == "pull_request":
            action = payload.get("action")
            if action not in ["opened", "synchronize"]:
                logger.info("Skipping PR action: %s", action)
                return {"status": "skipped", "message": f"PR action '{action}' not reviewed"}

            repo_info = payload.get("repository", {})
            owner = repo_info.get("owner", {}).get("login")
            repo_name = repo_info.get("name")
            pr_number = payload.get("number")
            head_sha = payload.get("pull_request", {}).get("head", {}).get("sha")
            github_token = os.getenv("GITHUB_TOKEN")
            if not all([owner, repo_name, pr_number, github_token]):
                logger.error("Missing owner, repo, PR number, or GitHub token for PR diff fetch.")
                return {"status": "error", "message": "Missing owner, repo, PR number, or GitHub token."}

            logger.info("Fetching PR diff for: %s/%s#%s", owner, repo_name, pr_number)
            github_api = GitHubIntegration(github_token)  # type: ignore
            try:
                diff = await github_api.get_pr_diff(owner, repo_name, pr_number)
            finally:
                await github_api.close()

            if not diff:
                return {"status": "success", "message": "No changes to review."}

            exclude_patterns = _load_exclude_patterns()
            diff = filter_diff_by_paths(diff, exclude_patterns)
            max_chunks = int(os.getenv("REVIEW_MAX_CHUNKS", "6"))
            chunk_size = int(os.getenv("REVIEW_CHUNK_SIZE", "5000"))
            max_diff_chars = int(os.getenv("REVIEW_MAX_DIFF_CHARS", "120000"))
            cache_ttl = int(os.getenv("REVIEW_RESULT_CACHE_TTL_SECONDS", "600"))
            
            if max_diff_chars and len(diff) > max_diff_chars:
                diff = diff[:max_diff_chars] + "\n\n... (Diff truncated) ..."

            review_key = _review_cache_key(diff, chunk_size, max_chunks)
            review = _get_cached_review(review_key, cache_ttl)
            if not review:
                review = await review_code_with_ollama(diff, chunk_size=chunk_size, max_chunks=max_chunks)
                _set_cached_review(review_key, review)
            logger.info("Review generated with local Ollama!")
            
            # Save review to database
            from service import save_code_review_to_db
            db = get_database()
            pr_info = {
                "pr_number": pr_number,
                "repo_owner": owner,
                "repo_name": repo_name,
                "head_sha": head_sha or "unknown"
            }
            # Extract optional fields from body (sent by frontend)
            task_id = payload.get("task_id")
            project_id = payload.get("project_id")
            user_id = payload.get("user_id")
            review_id = await save_code_review_to_db(
                review, pr_info,
                user_id=user_id,
                task_id=task_id,
                project_id=project_id,
                db=db
            )
            
            return {"status": "success", "review": review, "review_id": review_id}

        repo_url = payload.get("repository", {}).get("clone_url")
        logger.info("Reviewing changes for: %s", repo_url)
        diff = get_latest_commit_diff(repo_url)
        if not diff:
            return {"status": "success", "message": "No changes to review."}

        exclude_patterns = _load_exclude_patterns()
        diff = filter_diff_by_paths(diff, exclude_patterns)
        max_chunks = int(os.getenv("REVIEW_MAX_CHUNKS", "6"))
        chunk_size = int(os.getenv("REVIEW_CHUNK_SIZE", "5000"))
        max_diff_chars = int(os.getenv("REVIEW_MAX_DIFF_CHARS", "120000"))
        cache_ttl = int(os.getenv("REVIEW_RESULT_CACHE_TTL_SECONDS", "600"))
        
        if max_diff_chars and len(diff) > max_diff_chars:
            diff = diff[:max_diff_chars] + "\n\n... (Diff truncated) ..."

        review_key = _review_cache_key(diff, chunk_size, max_chunks)
        review = _get_cached_review(review_key, cache_ttl)
        if not review:
            review = await review_code_with_ollama(diff, chunk_size=chunk_size, max_chunks=max_chunks)
            _set_cached_review(review_key, review)
        logger.info("Review generated with local Ollama!")
        return {"status": "success", "review": review}

    except Exception as e:
        logger.error("Error processing webhook: %s", str(e))
        traceback.print_exc()
        # Save a failed review record so the frontend can notify the user
        try:
            raw_body = await request.body()
            if raw_body:
                fail_payload = json.loads(raw_body.decode("utf-8"))
                fail_task_id = fail_payload.get("task_id")
                fail_user_id = fail_payload.get("user_id")
                if fail_task_id:
                    db = get_database()
                    await db.ai_feedback.update_one(
                        {"task_id": fail_task_id, "pull_request_url": fail_payload.get("pull_request_url", "")},
                        {"$set": {
                            "status": "failed",
                            "error": str(e)[:500],
                            "review": "Code review generation failed. Please try again or contact support.",
                            "updated_at": datetime.utcnow(),
                        }},
                        upsert=True,
                    )
                    logger.info("Saved failed review status for task %s", fail_task_id)
        except Exception as inner_e:
            logger.warning("Failed to save failure status: %s", inner_e)
        return {"status": "error", "message": str(e)}


@app.get("/api/v1/review")
async def get_stored_review(
    repo_path: Optional[str] = None,
    task_id: Optional[str] = None,
    current_user: dict = Depends(require_auth)
):
    """
    Get stored code review from database.
    
    Args:
        repo_path: GitHub PR URL or repository path
        task_id: Associated task ID
    
    Returns:
        Stored review from ai_feedback collection or 404 if not found
    """
    try:
        from bson.objectid import ObjectId
        
        db = get_database()
        if db is None:
            raise HTTPException(status_code=503, detail="Database connection not available")
        
        user_id = current_user.get("sub") or current_user.get("user_id")
        if not user_id:
            raise HTTPException(status_code=401, detail="User authentication required")
        
        # Always filter by user first (SECURITY CRITICAL)
        # Exception: when looking up by task_id, allow admin/manager to see
        # trainee reviews by not requiring user_id match
        query = {}
        user_id_filter_applied = False
        
        if task_id:
            task_ids = [task_id]
            try:
                task_ids.append(ObjectId(task_id))
            except (ValueError, InvalidId):
                pass
            query["task_id"] = {"$in": task_ids}
        else:
            # No task_id: require user_id filter for security
            query["user_id"] = user_id
            user_id_filter_applied = True
        
        if repo_path:
            query["pull_request_url"] = repo_path
        
        if not task_id and not repo_path:
            raise HTTPException(status_code=400, detail="Provide task_id or repo_path")
        
        # Fetch the latest stored review using correct Motor syntax
        cursor = db.ai_feedback.find(query).sort([("created_at", -1)]).limit(1)
        docs = await cursor.to_list(length=1)
        review_doc = docs[0] if docs else None
        
        if not review_doc:
            return {"status": "not_found", "review": None, "message": "No stored review found"}
        
        # Properly convert ObjectIds to strings
        review_id_str = str(review_doc.get("_id", ""))
        user_id_str = str(review_doc.get("user_id", ""))
        task_id_str = str(review_doc.get("task_id", "")) if review_doc.get("task_id") else None
        
        return {
            "status": "success",
            "review": review_doc.get("review") or review_doc.get("summary", ""),
            "review_full": {**review_doc, "_id": review_id_str, "user_id": user_id_str, "task_id": task_id_str},
            "review_id": review_id_str
        }
    
    except HTTPException:
        raise
    except (ConnectionError, TimeoutError) as e:
        logger.error("Database connection error: %s", str(e))
        raise HTTPException(status_code=503, detail="Database temporarily unavailable")
    except Exception as e:
        logger.error("Error fetching stored review: %s", str(e))
        traceback.print_exc()
        raise HTTPException(status_code=502, detail="Internal server error")


@app.post("/api/v1/review")
async def review_code(request: ReviewRequest, current_user: dict = Depends(require_auth)):
    """
    Endpoint to review code from a repository. Requires JWT auth.
    First checks database for existing review, then generates if needed.
    
    Args:
        repo_path: Local file path OR GitHub URL
                   - Local: "C:\\path\\to\\repo" or "../planner-agent"
                   - GitHub: "https://github.com/user/repo.git"
                   - PR URL: "https://github.com/user/repo/pull/42"
    """
    try:
        logger.info("Starting code review for: %s", request.repo_path)

        import unicodedata
        def clean_url(url):
            url = unicodedata.normalize('NFKC', url)
            url = ''.join(c for c in url if 32 <= ord(c) <= 126)
            return url.strip()

        repo_path = clean_url(request.repo_path)
        diff = None
        exclude_patterns = _load_exclude_patterns(request.exclude_patterns)
        max_chunks = request.max_chunks or int(os.getenv("REVIEW_MAX_CHUNKS", "6"))
        chunk_size = request.chunk_size or int(os.getenv("REVIEW_CHUNK_SIZE", "5000"))
        max_diff_chars = request.max_diff_chars or int(os.getenv("REVIEW_MAX_DIFF_CHARS", "120000"))
        use_cache = request.use_cache if request.use_cache is not None else os.getenv("REVIEW_USE_CACHE", "true").lower() == "true"
        cache_ttl = int(os.getenv("REVIEW_CACHE_TTL_SECONDS", "600"))
        review_cache_ttl = int(os.getenv("REVIEW_RESULT_CACHE_TTL_SECONDS", "600"))
        
        # Get user ID from current_user
        user_id = current_user.get("sub") or current_user.get("user_id")
        if not user_id:
            raise HTTPException(status_code=401, detail="User authentication required")

        import re
        pr_url_pattern = r"https://github.com/([^/]+)/([^/]+)/pull/(\d+)"
        match = re.match(pr_url_pattern, repo_path)
        
        # Check database for existing review FIRST (for all review types)
        from bson.objectid import ObjectId
        db = get_database()
        existing_review_doc = None
        
        if db is not None:
            try:
                # Build cache query:
                # If task_id is provided in the request, lookup by task_id (string or ObjectId)
                # without restricting by user_id, so admins/managers can retrieve the trainee's review.
                # If task_id is not provided, query is restricted to user_id.
                db_cache_query = {"status": "completed"}
                if request.task_id:
                    task_ids = [request.task_id]
                    try:
                        task_ids.append(ObjectId(request.task_id))
                    except Exception:
                        pass
                    db_cache_query["task_id"] = {"$in": task_ids}
                else:
                    db_cache_query["user_id"] = user_id
                
                if match:
                    db_cache_query["pull_request_url"] = repo_path
                else:
                    # For local repos, use repository_url as identifier
                    db_cache_query["repository_url"] = repo_path
                
                # Use correct Motor async syntax
                cursor = db.ai_feedback.find(db_cache_query).sort([("created_at", -1)]).limit(1)
                docs = await cursor.to_list(length=1)
                existing_review_doc = docs[0] if docs else None
                
                if existing_review_doc and existing_review_doc.get("summary"):
                    logger.info("Found cached review for: %s", repo_path)
                    
                    # Properly convert ObjectId to string
                    review_id_str = str(existing_review_doc.get("_id", ""))
                    
                    # Return with standardized response structure
                    return {
                        "status": "success",
                        "review": existing_review_doc.get("review") or existing_review_doc.get("summary", ""),
                        "repo_path": repo_path,
                        "review_id": review_id_str,
                        "from_cache": True,
                        "cached_at": str(existing_review_doc.get("created_at", ""))
                    }
            except (ConnectionError, TimeoutError) as e:
                # Database temporarily unavailable, proceed with fresh generation
                logger.warning("Database cache check failed: %s", str(e))
                logger.info("Proceeding to generate fresh review...")
            except Exception as e:
                # Log other errors but don't fail
                logger.warning("Error checking database cache: %s", str(e))
                traceback.print_exc()
        
        if match:
            owner, repo, pr_number = match.groups()
            github_token = os.getenv("GITHUB_TOKEN")
            if not github_token:
                return {"status": "error", "message": "Missing GITHUB_TOKEN in environment."}
            cache_key = f"pr:{owner}/{repo}#{pr_number}"
            if use_cache:
                diff = _get_cached_diff(cache_key, cache_ttl)
            if not diff:
                github_api = GitHubIntegration(github_token)
                try:
                    diff = await github_api.get_pr_diff(owner, repo, int(pr_number))
                finally:
                    await github_api.close()
                if use_cache and diff:
                    _set_cached_diff(cache_key, diff)
            if not diff:
                return {"status": "success", "message": "No changes to review."}
        else:
            diff = get_latest_commit_diff(repo_path)
            if not diff:
                return {"status": "success", "message": "No changes to review."}

        diff = filter_diff_by_paths(diff, exclude_patterns)
        if max_diff_chars and len(diff) > max_diff_chars:
            diff = diff[:max_diff_chars] + "\n\n... (Diff truncated) ..."

        review_key = _review_cache_key(diff, chunk_size, max_chunks)
        review = _get_cached_review(review_key, review_cache_ttl) if use_cache else None
        if not review:
            review = await review_code_with_ollama(diff, chunk_size=chunk_size, max_chunks=max_chunks)
            if use_cache:
                _set_cached_review(review_key, review)

        if not review or not str(review).strip():
            raise HTTPException(status_code=502, detail="Code review generation failed (empty response).")

        logger.info("Review generated with local Ollama!")
        
        # Save review to database
        from service import save_code_review_to_db
        db = get_database()
        review_id = None
        
        if match:
            # We have PR info, save it with PR details
            pr_info = {
                "pr_number": int(pr_number),
                "repo_owner": owner,
                "repo_name": repo,
                "head_sha": "unknown"  # Would need additional API call to get this
            }
            review_id = await save_code_review_to_db(review, pr_info, user_id=user_id, task_id=request.task_id, project_id=request.project_id, db=db)
        else:
            # Save with repository path
            pr_info = {
                "pr_number": 0,
                "repo_owner": "unknown",
                "repo_name": request.repo_path,
                "head_sha": "unknown"
            }
            review_id = await save_code_review_to_db(review, pr_info, user_id=user_id, task_id=request.task_id, project_id=request.project_id, db=db)
        
        # Standardized response structure (matches cached response)
        return {
            "status": "success",
            "review": review,
            "repo_path": request.repo_path,
            "review_id": review_id,
            "from_cache": False
        }

    except HTTPException:
        raise

    except Exception as e:
        logger.error("Error during review: %s", str(e))
        traceback.print_exc()
        raise HTTPException(status_code=502, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8004))
    uvicorn.run(app, host="0.0.0.0", port=port)