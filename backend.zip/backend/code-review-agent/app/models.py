from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

class pull_requestInfo(BaseModel):
    repo_owner: str
    repo_name: str
    pr_number: int
    head_sha: str
    base_sha: str

class WebhookPayload(BaseModel):
    action: str
    pull_request: Dict[str, Any]
    repository: Dict[str, Any]

class ReviewRequest(BaseModel):
    diff: str
    pr_info: pull_requestInfo
    language: Optional[str] = None
    focus_areas: Optional[List[str]] = Field(
        default=["code_quality", "security", "performance", "best_practices"]
    )

class ReviewResponse(BaseModel):
    status: str
    review_id: str
    message: str
    timestamp: str

class HealthResponse(BaseModel):
    status: str
    version: str
    timestamp: str

# ==================== CODE COMMENT MODEL ====================
class CodeComment(BaseModel):
    id: Optional[str] = Field(None, alias="_id")
    line: int
    column: Optional[int] = None
    fileName: str
    message: str
    severity: str  # info, warning, error, suggestion
    category: str  # code-quality, performance, security, best-practices, documentation
    suggestion: Optional[str] = None
    example: Optional[str] = None

# ==================== AI FEEDBACK MODEL ====================
class AIFeedbackData(BaseModel):
    """AI-generated code review feedback"""
    id: Optional[str] = Field(None, alias="_id")
    task_id: Optional[str] = None
    user_id: Optional[str] = None
    pull_request_url: Optional[str] = None
    repository_url: Optional[str] = None
    branch_name: Optional[str] = None
    commitHash: Optional[str] = None
    comments: List[CodeComment] = []
    summary: str = ""
    strengths: List[str] = []
    improvements: List[str] = []
    recommendations: List[str] = []
    ai_model: Optional[str] = "deepseek/deepseek-chat"
    processing_time: Optional[float] = 0
    analysisDate: Optional[datetime] = None
    status: str = "completed"  # pending, completed, failed, reviewing
    error: Optional[str] = None
    totalIssues: int = 0
    criticalIssues: int = 0
    warningIssues: int = 0
    infoIssues: int = 0
    isRead: bool = False
    readAt: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        populate_by_name = True
