"""
GitHub API Integration
Handles all GitHub API interactions including fetching diffs and posting comments
"""
import aiohttp
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class GitHubIntegration:
    """
    Handles GitHub API operations with proper session lifecycle management.
    """

    def __init__(self, github_token: str):
        self.token = github_token
        self.base_url = "https://api.github.com"
        self.headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "AI-Code-Review-Agent"
        }
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def close(self):
        if self._session is not None and not self._session.closed:
            await self._session.close()
            self._session = None

    async def get_pr_diff(self, owner: str, repo: str, pr_number: int) -> str:
        """
        Fetch the diff for a pull request
        """
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}"
        session = await self._get_session()
        headers = self.headers.copy()
        headers["Accept"] = "application/vnd.github.v3.diff"

        async with session.get(url, headers=headers) as response:
            if response.status == 200:
                diff = await response.text()
                logger.info(f"Successfully fetched diff for PR #{pr_number}")
                return diff
            else:
                error_text = await response.text()
                logger.error(f"Failed to fetch diff: {response.status} - {error_text}")
                raise Exception(f"Failed to fetch PR diff: {response.status}")

    async def get_pr_files(self, owner: str, repo: str, pr_number: int) -> list:
        """
        Get list of files changed in a PR
        """
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}/files"
        session = await self._get_session()

        async with session.get(url, headers=self.headers) as response:
            if response.status == 200:
                files = await response.json()
                logger.info(f"Fetched {len(files)} files for PR #{pr_number}")
                return files
            else:
                logger.error(f"Failed to fetch files: {response.status}")
                return []

    async def post_review_comment(
        self,
        owner: str,
        repo: str,
        pr_number: int,
        comment: str,
        commit_sha: Optional[str] = None
    ) -> bool:
        """
        Post a review comment on a pull request
        """
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{pr_number}/comments"

        payload = {"body": comment}
        session = await self._get_session()

        async with session.post(url, headers=self.headers, json=payload) as response:
            if response.status == 201:
                logger.info(f"Successfully posted comment to PR #{pr_number}")
                return True
            else:
                error_text = await response.text()
                logger.error(f"Failed to post comment: {response.status} - {error_text}")
                return False

    async def post_review(
        self,
        owner: str,
        repo: str,
        pr_number: int,
        commit_sha: str,
        body: str,
        event: str = "COMMENT"
    ) -> bool:
        """
        Post a full review (not just a comment)
        This allows for approve/request changes actions
        """
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}/reviews"

        payload = {
            "commit_id": commit_sha,
            "body": body,
            "event": event
        }
        session = await self._get_session()

        async with session.post(url, headers=self.headers, json=payload) as response:
            if response.status == 200:
                logger.info(f"Successfully posted review to PR #{pr_number}")
                return True
            else:
                error_text = await response.text()
                logger.error(f"Failed to post review: {response.status} - {error_text}")
                return False

    async def get_pr_info(self, owner: str, repo: str, pr_number: int) -> dict:
        """
        Get pull request information
        """
        url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}"
        session = await self._get_session()

        async with session.get(url, headers=self.headers) as response:
            if response.status == 200:
                pr_data = await response.json()
                logger.info(f"Fetched info for PR #{pr_number}")
                return pr_data
            else:
                logger.error(f"Failed to fetch PR info: {response.status}")
                return {}

    async def run_checks(self, owner: str, repo: str, pr_number: int) -> dict:
        """
        Get status checks for a PR (linting, tests, etc.)
        """
        pr_info = await self.get_pr_info(owner, repo, pr_number)
        if not pr_info:
            return {"success": False, "checks": []}

        head_sha = pr_info.get("head", {}).get("sha")
        if not head_sha:
            return {"success": False, "checks": []}

        url = f"{self.base_url}/repos/{owner}/{repo}/commits/{head_sha}/check-runs"
        session = await self._get_session()

        async with session.get(url, headers=self.headers) as response:
            if response.status == 200:
                data = await response.json()
                check_runs = data.get("check_runs", [])

                all_passed = all(
                    run.get("conclusion") == "success"
                    for run in check_runs
                )

                return {
                    "success": all_passed,
                    "checks": check_runs,
                    "total": len(check_runs),
                    "passed": sum(1 for r in check_runs if r.get("conclusion") == "success"),
                    "failed": sum(1 for r in check_runs if r.get("conclusion") == "failure")
                }
            else:
                logger.error(f"Failed to fetch check runs: {response.status}")
                return {"success": False, "checks": []}

    async def detect_main_language(self, owner: str, repo: str, pr_number: int) -> Optional[str]:
        """
        Detect the primary programming language based on the files in a PR.
        """
        files = await self.get_pr_files(owner, repo, pr_number)
        if not files:
            return None

        extension_counts = {}
        for file in files:
            filename = file.get("filename", "")
            if "." in filename:
                parts = filename.split(".")
                if len(parts) > 1:
                    ext = parts[-1].lower()
                    extension_counts[ext] = extension_counts.get(ext, 0) + 1

        if not extension_counts:
            return None

        language_map = {
            "py": "Python",
            "js": "JavaScript",
            "ts": "TypeScript",
            "tsx": "TypeScript/React",
            "jsx": "JavaScript/React",
            "go": "Go",
            "rs": "Rust",
            "java": "Java",
            "cpp": "C++",
            "c": "C",
            "cs": "C#",
            "rb": "Ruby",
            "php": "PHP",
            "html": "HTML",
            "css": "CSS"
        }

        most_common_ext = max(extension_counts, key=extension_counts.get)
        return language_map.get(most_common_ext)
