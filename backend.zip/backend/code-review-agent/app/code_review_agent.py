import logging
from typing import List, TypedDict, Optional, Any

try:
    from shared.ollama_service import OllamaService
except ImportError:  # when running from within the app directory
    from ollama_service import OllamaService  # type: ignore

# For LangGraph - use Any type if CompiledGraph is not available
try:
    from langgraph.graph import StateGraph, END
    CompiledGraph = Any
except ImportError as e:
    print(f"Error importing langgraph: {e}")
    StateGraph = None
    END = None
    CompiledGraph = Any

# Configure logging
logger = logging.getLogger(__name__)

# --- Define the State for our Graph ---

class AgentState(TypedDict):
    """
    Defines the state of our review agent.
    This state is passed between nodes in the graph.
    """
    diff: str
    focus_areas: Optional[List[str]]  # Updated to be optional
    language: Optional[str]           # Added language field
    raw_review: str                   # The raw text output from the LLM
    review_text: str                  # The final, formatted review text
    error_message: Optional[str]      # To store any errors

# --- Define the Agent Class ---

class CodeReviewAgent:
    """
    Implements the AI Code Review logic using LangGraph.
    """
    
    def __init__(self, model: Optional[str] = None, **kwargs: Any):
        """
        Initializes the agent, the local Ollama client, and the LangGraph workflow.

        Legacy credential keyword arguments are accepted for backward
        compatibility and ignored. All reviews are generated locally by Ollama.
        """
        self.ollama = OllamaService(agent_type="code-review")
        self.model_name = model or self.ollama.ollama_model

        # Build the LangGraph workflow
        self.app = self._build_graph()

    def _build_graph(self) -> Any:
        """
        Builds the LangGraph workflow for code review.
        """
        workflow = StateGraph(AgentState)
        
        # Add the nodes
        workflow.add_node("generate_review", self._generate_review_node)
        workflow.add_node("format_review", self._format_review_node)
        
        # Define the edges
        workflow.set_entry_point("generate_review")
        workflow.add_edge("generate_review", "format_review")
        workflow.add_edge("format_review", END)
        
        # Compile the graph
        return workflow.compile()

    # --- Node Definitions ---

    async def _generate_review_node(self, state: AgentState) -> dict:
        """
        LangGraph node: Calls the LLM to generate the code review.
        """
        logger.info(f"Generating review with model {self.model_name}...")
        diff = state["diff"]
        focus_areas = state.get("focus_areas")
        language = state.get("language")  # Get language from state
        
        if not diff or diff.strip() == "":
            logger.warning("Diff is empty. Skipping review.")
            return {
                "raw_review": "The code diff is empty. No changes to review.",
                "error_message": None
            }

        # Truncate diff if it's too large to prevent API errors
        # 30k chars is a safe-ish bet for most models, approx 7.5k tokens
        max_diff_length = 30000 
        if len(diff) > max_diff_length:
            logger.warning(f"Diff length ({len(diff)}) exceeds max. Truncating.")
            diff = diff[:max_diff_length] + "\n\n... (Diff truncated) ..."
            
        try:
            # System prompt inspired by your workflow file
            system_prompt = """You are PRAXIS, the official AI Support Agent, and a senior software engineer acting as an expert code reviewer. Your goal is to provide a helpful, constructive, and detailed review of the provided code diff.
                
Follow these rules:
1.  **Tone**: Professional, friendly, and collaborative.
2.  **Focus**: Clean code (SOLID, DRY), potential bugs, security vulnerabilities (OWASP), performance bottlenecks, readability, and idiomatic best practices.
3.  **Actionable**: Provide specific, drop-in code suggestions for improvements.
4.  **Positive**: Call out exceptionally well-written code.
5.  **Structure**:
    - Use `### 🚀 Improvements` for refactoring and best practices.
    - Use `### 🐛 Potential Bugs` for logic errors or edge cases.
    - Use `### ⚡ Performance` for efficiency gains.
    - Use `### 🔒 Security` for potential vulnerabilities.
    - Use `### ✅ Good Job` for praise.
6.  **GitHub Flavored Markdown**: Use code snippets (`...`) for short examples and code blocks (```language) for longer fixes.
7.  **Concise but Thorough**: Don't repeat what the code already does; explain *why* it should change.
"""
            
            # Updated User prompt to include language
            language_prompt = f"The code is primarily written in **{language}**." if language else "The code language is not specified, please infer it from the diff."
            focus_prompt = f"Main focus areas: **{', '.join(focus_areas) if focus_areas else 'General Review'}**"
            
            user_prompt = f"""{language_prompt}
{focus_prompt}

Please review the following code diff and provide your feedback.

--- CODE DIFF ---
{diff}
--- END OF DIFF ---
"""
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
            response_text = await self.ollama.generate_completion(
                messages=messages,
                temperature=0.2,
            )

            return {
                "raw_review": response_text,
                "error_message": None
            }
            
        except Exception as e:
            logger.error(f"Error calling local Ollama: {str(e)}")
            return {
                "raw_review": "",
                "error_message": f"Error during AI review: {str(e)}"
            }

    def _format_review_node(self, state: AgentState) -> dict:
        """
        LangGraph node: Formats the raw review into the final comment text.
        """
        logger.info("Formatting review...")
        raw_review = state.get("raw_review", "")
        error_message = state.get("error_message")
        
        if error_message:
            review_text = f"""### ⚠️ AI Code Review Failed
            
An error occurred while trying to generate the review:
```
{error_message}
```
"""
        else:
            # Add a header to the review
            review_text = f"""### 🤖 AI Code Review
            
Hello! I've taken a look at your changes. Here are my thoughts:

---

{raw_review}

---
*This review was generated by an AI assistant. Please review it carefully.*
"""
        
        return {"review_text": review_text}

    # --- Public Method ---

    async def review_code(self, diff: str, focus_areas: Optional[List[str]] = None, language: Optional[str] = None) -> dict:
        """
        Public method to run the code review graph.
        
        Args:
            diff: The code diff string.
            focus_areas: An optional list of areas to focus on.
            language: An optional string specifying the code language.
            
        Returns:
            A dictionary (the final state) which includes 'review_text'.
        """
        logger.info("Starting new code review...")
        
        # Initial state
        inputs = {
            "diff": diff,
            "focus_areas": focus_areas,
            "language": language,
            "raw_review": "",
            "review_text": "",
            "error_message": None
        }
        
        try:
            # Run the graph asynchronously
            # The output of ainvoke is the final state
            final_state = await self.app.ainvoke(inputs)
            
            logger.info("Code review graph completed.")
            return final_state
            
        except Exception as e:
            logger.error(f"Error running review graph: {str(e)}")
            # Return a state dictionary formatted as an error
            return {
                "diff": diff,
                "focus_areas": focus_areas,
                "language": language,
                "raw_review": "",
                "review_text": f"### ⚠️ AI Code Review Failed\n\nA critical error occurred in the review agent:\n```{str(e)}```",
                "error_message": str(e)
            }