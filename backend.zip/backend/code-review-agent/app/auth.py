"""
Auth middleware for Code-Review-Agent.

Supports two authentication flows:
1. Standard JWT tokens (email/password login via support-agent's /auth/login)
2. Frontend-generated tokens for OAuth users (Google/GitHub login)
   - The frontend stores users in MongoDB `users` collection with an `externaluser_id`
   - It passes the externaluser_id (or a JWT with sub=externaluser_id) as the Bearer token
   - Fallback: if JWT fails, we look up the token value directly in the DB
"""
import sys
import os
import logging
from pathlib import Path
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import motor.motor_asyncio
from bson import ObjectId

logger = logging.getLogger(__name__)

# Add shared module to path
shared_path = str(Path(__file__).parent.parent / "shared")
if shared_path not in sys.path:
    sys.path.append(shared_path)

from shared.auth_utils import verify_access_token

security = HTTPBearer()

# MongoDB client (lazy-init, reused across requests)
_db = None

def _get_db():
    """Lazy-init MongoDB connection for token lookups."""
    global _db
    if _db is None:
        mongo_uri = os.getenv("MONGODB_URI")
        db_name = os.getenv("DATABASE_NAME", "praxis-aipm")
        if not mongo_uri:
            return None
        client = motor.motor_asyncio.AsyncIOMotorClient(mongo_uri)
        _db = client[db_name]
    return _db


async def _lookup_user_in_db(token: str) -> dict | None:
    """
    Fallback: look up the token in the `users` collection.
    The frontend stores OAuth users with externaluser_id as their identifier.
    It may pass that value (or a JWT wrapping it) as the Bearer token.
    
    We try three lookups:
      1. externaluser_id == token  (frontend passes raw OAuth ID as token)
      2. _id == ObjectId(token)   (frontend passes MongoDB _id as token)
      3. email == token           (less likely but defensive)
    """
    db = _get_db()
    if db is None:
        return None
    try:
        # 1. externaluser_id match (most common for Google/GitHub OAuth)
        user = await db.users.find_one({"externaluser_id": token})
        if user:
            return {"sub": str(user["_id"]), "externaluser_id": token, "email": user.get("email")}

        # 2. ObjectId _id match
        if ObjectId.is_valid(token):
            user = await db.users.find_one({"_id": ObjectId(token)})
            if user:
                return {"sub": str(user["_id"]), "email": user.get("email")}

        # 3. email match
        user = await db.users.find_one({"email": token})
        if user:
            return {"sub": str(user["_id"]), "email": token}

        # 4. Custom access token match (frontend generated)
        user = await db.users.find_one({"$or": [{"access_token": token}, {"accessToken": token}]})
        if user:
            return {"sub": str(user["_id"]), "email": user.get("email"), "accessToken": token}

    except Exception as e:
        logger.warning(f"DB token lookup failed: {e}")
    return None


async def require_auth(
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> dict:
    """
    FastAPI dependency that authenticates using:
    1. JWT token (standard email/password login)
    2. DB lookup fallback (OAuth / frontend-generated tokens)
    """
    token = credentials.credentials

    # --- Step 1: Try JWT verification ---
    payload = verify_access_token(token)
    if payload:
        return payload

    # --- Step 2: Fallback DB lookup for OAuth users ---
    user = await _lookup_user_in_db(token)
    if user:
        return user

    # --- Neither worked ---
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def optional_auth(
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> dict | None:
    """Optional auth — returns None instead of raising if unauthenticated."""
    try:
        return await require_auth(credentials)
    except HTTPException:
        return None
