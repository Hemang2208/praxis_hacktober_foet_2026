import hmac
import hashlib
import logging
from typing import List, Optional, TYPE_CHECKING
from datetime import datetime
from bson.objectid import ObjectId

# Import for type checking only to avoid circular imports
if TYPE_CHECKING:
    from code_review_agent import CodeReviewAgent
    from github_integration import GitHubIntegration

# Configure logging
logger = logging.getLogger(__name__)


async def save_code_review_to_db(
    review_text: str,
    pr_info: dict,
    user_id: Optional[str] = None,
    task_id: Optional[str] = None,
    project_id: Optional[str] = None,
    db = None
) -> Optional[str]:
    """
    Save the code review to the database and link it to the task.
    
    Args:
        review_text: The generated review text
        pr_info: Dictionary with PR information
        user_id: User ID (optional)
        task_id: Task ID to link the review to (optional)
        project_id: Project ID (optional)
        db: Database connection object
    
    Returns:
        The ID of the saved review, or None if save failed
    """
    if db is None:
        logger.warning("Database connection not available, skipping save")
        return None
    
    try:
        from review_parser import create_ai_feedback_from_review
        
        pr_number = pr_info.get("pr_number")
        repo_owner = pr_info.get("repo_owner")
        repo_name = pr_info.get("repo_name")
        head_sha = pr_info.get("head_sha")
        
        # Create feedback object
        pull_request_url = f"https://github.com/{repo_owner}/{repo_name}/pull/{pr_number}"
        repository_url = f"https://github.com/{repo_owner}/{repo_name}"
        
        feedback = create_ai_feedback_from_review(
            review_text=review_text,
            user_id=user_id,
            task_id=task_id,
            pull_request_url=pull_request_url,
            repository_url=repository_url,
            commit_hash=head_sha,
            ai_model="deepseek/deepseek-chat"
        )
        
        # Convert to dict for MongoDB
        feedback_dict = feedback.dict(by_alias=True, exclude_none=True)
        
        # Store the full review markdown text alongside structured fields
        # so the frontend can render the complete review on reload
        feedback_dict["review"] = review_text
        
        # Convert task_id and user_id to ObjectId if valid to ensure correct types in MongoDB
        if "task_id" in feedback_dict and ObjectId.is_valid(feedback_dict["task_id"]):
            feedback_dict["task_id"] = ObjectId(feedback_dict["task_id"])
        if "user_id" in feedback_dict and ObjectId.is_valid(feedback_dict["user_id"]):
            feedback_dict["user_id"] = ObjectId(feedback_dict["user_id"])
        
        # Use task_id search to prevent duplicate reviews
        if task_id:
            task_ids = [task_id]
            if ObjectId.is_valid(task_id):
                task_ids.append(ObjectId(task_id))
            
            filter_query = {"task_id": {"$in": task_ids}}
            if feedback_dict.get("pull_request_url"):
                filter_query["pull_request_url"] = feedback_dict["pull_request_url"]
            
            existing = await db.ai_feedback.find_one(filter_query)
            if existing:
                await db.ai_feedback.update_one(
                    {"_id": existing["_id"]},
                    {"$set": feedback_dict}
                )
                review_id = str(existing["_id"])
            else:
                result = await db.ai_feedback.insert_one(feedback_dict)
                review_id = str(result.inserted_id)
        else:
            # No task_id — use insert_one (legacy behavior)
            result = await db.ai_feedback.insert_one(feedback_dict)
            review_id = str(result.inserted_id)
        
        logger.info(f"✅ Code review saved to database with ID: {review_id}")
        
        # Link review to task if task_id is provided
        if task_id:
            try:
                db_review_id = ObjectId(review_id) if ObjectId.is_valid(review_id) else review_id
                update_data = {"ai_feedback": db_review_id, "feedback_status": "ready"}
                # Try ObjectId-based update first, fall back to string
                if ObjectId.is_valid(task_id):
                    await db.tasks.update_one(
                        {"_id": ObjectId(task_id)},
                        {"$set": update_data}
                    )
                else:
                    await db.tasks.update_one(
                        {"$or": [{"_id": task_id}, {"task_id": task_id}]},
                        {"$set": update_data}
                    )
                logger.info(f"✅ Task {task_id} linked to review {review_id}")
            except Exception as link_err:
                logger.warning(f"Failed to link review to task {task_id}: {link_err}")
        
        return review_id
        
    except Exception as e:
        logger.error(f"❌ Failed to save code review to database: {str(e)}", exc_info=True)
        return None


async def update_code_review_in_db(
    review_id: str,
    updates: dict,
    db = None
) -> bool:
    """
    Update an existing code review in the database.
    
    Args:
        review_id: The review ID to update
        updates: Dictionary of fields to update
        db: Database connection object
    
    Returns:
        True if update successful, False otherwise
    """
    if db is None:
        logger.warning("Database connection not available, skipping update")
        return False
    
    try:
        updates["updated_at"] = datetime.utcnow()
        
        result = await db.ai_feedback.update_one(
            {"_id": ObjectId(review_id)},
            {"$set": updates}
        )
        
        if result.modified_count > 0:
            logger.info(f"✅ Code review {review_id} updated in database")
            return True
        else:
            logger.warning(f"No document found to update with ID: {review_id}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Failed to update code review: {str(e)}", exc_info=True)
        return False


def verify_github_signature(payload: bytes, signature: str, secret: str) -> bool:
    """
    Verify GitHub webhook signature
    
    Args:
        payload: The raw request body as bytes
        signature: The X-Hub-Signature-256 header from GitHub
        secret: Your webhook secret
        
    Returns:
        bool: True if signature is valid, False otherwise
    """
    if not signature:
        logger.warning("No signature provided")
        return False
    
    if not secret:
        logger.error("Webhook secret not configured")
        return False
   
    try:
        expected_signature = 'sha256=' + hmac.new(
            secret.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()
       
        is_valid = hmac.compare_digest(expected_signature, signature)
        
        if not is_valid:
            logger.warning("Invalid webhook signature")
        
        return is_valid
    except Exception as e:
        logger.error(f"Error verifying signature: {str(e)}")
        return False


async def process_code_review(
    diff: str,
    pr_info: dict,
    focus_areas: Optional[List[str]],
    code_review_agent: 'CodeReviewAgent',
    github_integration: 'GitHubIntegration',
    language: Optional[str] = None
) -> None:
    """
    Process code review in background
    
    Args:
        diff: The code diff string
        pr_info: Dictionary containing PR information with keys:
                 - pr_number: int
                 - repo_owner: str
                 - repo_name: str
                 - head_sha: str
        focus_areas: Optional list of areas to focus on
        code_review_agent: Instance of CodeReviewAgent
        github_integration: Instance of GitHubIntegration
        language: Optional programming language hint
    """
    try:
        # Extract and validate PR info with proper type checking
        pr_number = pr_info.get("pr_number")
        repo_owner = pr_info.get("repo_owner")
        repo_name = pr_info.get("repo_name")
        head_sha = pr_info.get("head_sha")
        
        # Type guard: ensure all required fields are present and are strings/int
        if (not isinstance(pr_number, int) or 
            not isinstance(repo_owner, str) or 
            not isinstance(repo_name, str) or 
            not isinstance(head_sha, str)):
            logger.error(f"Invalid PR information: pr_number={pr_number}, repo_owner={repo_owner}, repo_name={repo_name}, head_sha={head_sha}")
            return
        
        logger.info(f"Starting review for PR #{pr_number}")
        
        # Detect language if not provided
        if not language:
            try:
                detected_lang = await github_integration.detect_main_language(
                    owner=repo_owner,
                    repo=repo_name,
                    pr_number=pr_number
                )
                if detected_lang:
                    language = detected_lang
                    logger.info(f"Auto-detected language: {language}")
            except Exception as lang_err:
                logger.warning(f"Failed to detect language: {str(lang_err)}")
       
        # Run the LangGraph agent
        review_result = await code_review_agent.review_code(
            diff=diff,
            focus_areas=focus_areas,
            language=language
        )
       
        # Post review to GitHub
        # Using post_review instead of post_review_comment for a better UI in GitHub
        success = await github_integration.post_review(
            owner=repo_owner,
            repo=repo_name,
            pr_number=pr_number,
            body=review_result["review_text"],
            commit_sha=head_sha,
            event="COMMENT"
        )
        
        if success:
            logger.info(f"Review completed successfully for PR #{pr_number}")
        else:
            logger.error(f"Failed to post review for PR #{pr_number}")
       
    except Exception as e:
        logger.error(f"Error processing review: {str(e)}", exc_info=True)
        
        # Attempt to post error message to PR
        try:
            # Re-extract with type checking for error handling
            pr_number = pr_info.get("pr_number")
            repo_owner = pr_info.get("repo_owner")
            repo_name = pr_info.get("repo_name")
            head_sha = pr_info.get("head_sha")
            
            # Only post error if we have valid info
            if (isinstance(pr_number, int) and 
                isinstance(repo_owner, str) and 
                isinstance(repo_name, str) and 
                isinstance(head_sha, str)):
                
                error_message = f"""### ⚠️ Code Review Failed

An error occurred while processing the code review:

```
{str(e)}
```

Please check the logs or contact the repository administrator.
"""
                await github_integration.post_review_comment(
                    owner=repo_owner,
                    repo=repo_name,
                    pr_number=pr_number,
                    comment=error_message,
                    commit_sha=head_sha
                )
            else:
                logger.error("Cannot post error message: invalid PR info")
                
        except Exception as post_error:
            logger.error(f"Failed to post error message to PR: {str(post_error)}")