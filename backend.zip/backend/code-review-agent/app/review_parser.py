import re
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from models import AIFeedbackData, CodeComment

logger = logging.getLogger(__name__)


def parse_review_response(review_text: str) -> Dict:
    """
    Parse the AI-generated review text into structured data.
    
    Extracts:
    - Improvements (from '### 🚀 Improvements' section)
    - Bugs (from '### 🐛 Potential Bugs' section)
    - Performance issues (from '### ⚡ Performance' section)
    - Security issues (from '### 🔒 Security' section)
    - Positive feedback (from '### ✅ Good Job' section)
    
    Returns a dictionary with categorized feedback.
    """
    
    if not review_text or not isinstance(review_text, str):
        logger.warning("Empty or invalid review text provided")
        return {
            "improvements": [],
            "bugs": [],
            "performance": [],
            "security": [],
            "strengths": [],
            "all_issues": [],
            "summary": "No review content to parse"
        }
    
    result = {
        "improvements": [],
        "bugs": [],
        "performance": [],
        "security": [],
        "strengths": [],
        "all_issues": [],
        "summary": ""
    }
    
    # Convert to lowercase for case-insensitive matching
    review_lower = review_text.lower()
    
    # Extract improvements section
    improvements_match = re.search(
        r'###\s*🚀\s*improvements?.*?\n(.*?)(?=###|$)',
        review_text,
        re.IGNORECASE | re.DOTALL
    )
    if improvements_match:
        improvements_text = improvements_match.group(1).strip()
        improvements = extract_list_items(improvements_text)
        result["improvements"] = improvements
        result["all_issues"].extend(improvements)
    
    # Extract potential bugs section
    bugs_match = re.search(
        r'###\s*🐛\s*potential bugs?.*?\n(.*?)(?=###|$)',
        review_text,
        re.IGNORECASE | re.DOTALL
    )
    if bugs_match:
        bugs_text = bugs_match.group(1).strip()
        bugs = extract_list_items(bugs_text)
        result["bugs"] = bugs
        result["all_issues"].extend(bugs)
    
    # Extract performance section
    performance_match = re.search(
        r'###\s*⚡\s*performance.*?\n(.*?)(?=###|$)',
        review_text,
        re.IGNORECASE | re.DOTALL
    )
    if performance_match:
        performance_text = performance_match.group(1).strip()
        performance = extract_list_items(performance_text)
        result["performance"] = performance
        result["all_issues"].extend(performance)
    
    # Extract security section
    security_match = re.search(
        r'###\s*🔒\s*security.*?\n(.*?)(?=###|$)',
        review_text,
        re.IGNORECASE | re.DOTALL
    )
    if security_match:
        security_text = security_match.group(1).strip()
        security = extract_list_items(security_text)
        result["security"] = security
        result["all_issues"].extend(security)
    
    # Extract positive feedback / good job section
    strengths_match = re.search(
        r'###\s*✅\s*good job.*?\n(.*?)(?=###|$)',
        review_text,
        re.IGNORECASE | re.DOTALL
    )
    if strengths_match:
        strengths_text = strengths_match.group(1).strip()
        strengths = extract_list_items(strengths_text)
        result["strengths"] = strengths
    
    # Create a summary if no structured sections found
    if not result["all_issues"] and not result["strengths"]:
        # Use first 200 characters as summary
        summary = review_text.strip()[:200]
        result["summary"] = summary
    else:
        # Create summary from the review
        result["summary"] = generate_summary(result)
    
    return result


def extract_list_items(text: str) -> List[str]:
    """
    Extract list items from text.
    Supports:
    - Bullet points (-, *, •)
    - Numbered items (1., 2., etc.)
    """
    items = []
    
    if not text or not text.strip():
        return items
    
    # Split by newlines
    lines = text.split('\n')
    
    for line in lines:
        line = line.strip()
        
        if not line:
            continue
        
        # Check for bullet points
        if line.startswith(('-', '*', '•')):
            item = re.sub(r'^[-*•]\s*', '', line).strip()
            # Clean up code blocks
            item = clean_code_blocks(item)
            if item:
                items.append(item)
        # Check for numbered items
        elif re.match(r'^\d+\.\s+', line):
            item = re.sub(r'^\d+\.\s+', '', line).strip()
            item = clean_code_blocks(item)
            if item:
                items.append(item)
        # If it's not empty and previous line was an item, it might be continuation
        elif items and not line.startswith('#'):
            # Treat as continuation of previous item
            last_item = items[-1]
            items[-1] = f"{last_item} {line}"
    
    # Remove duplicates while preserving order
    seen = set()
    unique_items = []
    for item in items:
        if item not in seen:
            seen.add(item)
            unique_items.append(item)
    
    return unique_items


def clean_code_blocks(text: str) -> str:
    """Remove markdown code block markers from text"""
    # Remove inline code markers
    text = re.sub(r'`([^`]*)`', r'\1', text)
    text = re.sub(r'```(.|\n)*?```', '', text)
    return text.strip()


def generate_summary(parsed_data: Dict) -> str:
    """Generate a summary from the parsed review data"""
    summary_parts = []
    
    if parsed_data.get("strengths"):
        summary_parts.append(f"✅ Strengths: {len(parsed_data['strengths'])} found")
    
    if parsed_data.get("bugs"):
        summary_parts.append(f"🐛 Bugs: {len(parsed_data['bugs'])} found")
    
    if parsed_data.get("security"):
        summary_parts.append(f"🔒 Security: {len(parsed_data['security'])} issues")
    
    if parsed_data.get("performance"):
        summary_parts.append(f"⚡ Performance: {len(parsed_data['performance'])} issues")
    
    if parsed_data.get("improvements"):
        summary_parts.append(f"🚀 Improvements: {len(parsed_data['improvements'])} suggestions")
    
    return " | ".join(summary_parts) if summary_parts else "Review analysis completed"


def create_comments_from_issues(issues: List[str], category: str) -> List[CodeComment]:
    """
    Convert issues to CodeComment objects.
    
    Args:
        issues: List of issue descriptions
        category: Category of issues (code-quality, security, performance, etc.)
    
    Returns:
        List of CodeComment objects
    """
    comments = []
    severity_map = {
        "security": "error",
        "bugs": "error",
        "performance": "warning",
        "improvements": "suggestion",
        "strengths": "info"
    }
    
    severity = severity_map.get(category, "info")
    
    for idx, issue in enumerate(issues, 1):
        comment = CodeComment(
            line=idx,
            fileName="review",
            message=issue,
            severity=severity,
            category=category
        )
        comments.append(comment)
    
    return comments


def create_ai_feedback_from_review(
    review_text: str,
    user_id: Optional[str] = None,
    task_id: Optional[str] = None,
    pull_request_url: Optional[str] = None,
    repository_url: Optional[str] = None,
    branch_name: Optional[str] = None,
    commit_hash: Optional[str] = None,
    ai_model: str = "deepseek/deepseek-chat",
) -> AIFeedbackData:
    """
    Create an AIFeedbackData object from the review text.
    
    Parses the review, counts issues by severity, and creates a complete feedback object.
    """
    
    # Parse the review text
    parsed = parse_review_response(review_text)
    
    # Extract different categories
    bugs = parsed.get("bugs", [])
    security = parsed.get("security", [])
    performance = parsed.get("performance", [])
    improvements = parsed.get("improvements", [])
    strengths = parsed.get("strengths", [])
    
    # Create comments from issues
    comments = []
    comments.extend(create_comments_from_issues(bugs, "code-quality"))
    comments.extend(create_comments_from_issues(security, "security"))
    comments.extend(create_comments_from_issues(performance, "performance"))
    comments.extend(create_comments_from_issues(improvements, "best-practices"))
    comments.extend(create_comments_from_issues(strengths, "documentation"))
    
    # Count issues by severity
    critical_issues = len(security) + len(bugs)
    warning_issues = len(performance)
    info_issues = len(improvements) + len(strengths)
    total_issues = critical_issues + warning_issues + info_issues
    
    now = datetime.utcnow()
    
    # Create the feedback object
    feedback = AIFeedbackData(
        user_id=user_id,
        task_id=task_id,
        pull_request_url=pull_request_url,
        repository_url=repository_url,
        branch_name=branch_name,
        commitHash=commit_hash,
        comments=comments,
        summary=parsed.get("summary", "Code review completed"),
        strengths=strengths,
        improvements=improvements,
        recommendations=create_recommendations(bugs, security, performance),
        ai_model=ai_model,
        processing_time=0,
        analysisDate=now,
        status="completed",
        error=None,
        totalIssues=total_issues,
        criticalIssues=critical_issues,
        warningIssues=warning_issues,
        infoIssues=info_issues,
        isRead=False,
        created_at=now,
        updated_at=now
    )
    
    return feedback


def create_recommendations(bugs: List[str], security: List[str], performance: List[str]) -> List[str]:
    """
    Create actionable recommendations based on the issues found.
    """
    recommendations = []
    
    if security:
        recommendations.append("Address all security vulnerabilities before merging this PR")
    
    if bugs:
        recommendations.append("Review and fix identified bugs in the code")
    
    if performance:
        recommendations.append("Consider optimizing performance bottlenecks")
    
    if not recommendations:
        recommendations.append("Code looks good! Continue with the current development approach")
    
    return recommendations
