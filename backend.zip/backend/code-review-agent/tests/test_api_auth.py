import requests
import time

BASE_URL = "http://localhost:8004"

def test_health_public():
    print("Testing /health endpoint (should be public)...")
    try:
        response = requests.get(f"{BASE_URL}/health")
        print(f"Status: {response.status_code}")
        if response.status_code == 200:
            print("Success: /health is public.")
        else:
            print("Failure: /health is not public.")
    except Exception as e:
        print(f"Error: {e}")

def test_review_protected():
    print("\nTesting /review/sync endpoint (should be protected)...")
    try:
        # Dummy data
        payload = {
            "diff": "test diff",
            "pr_info": {
                "repo_owner": "test",
                "repo_name": "test",
                "pr_number": 1,
                "head_sha": "abc"
            }
        }
        response = requests.post(f"{BASE_URL}/review/sync", json=payload)
        print(f"Status: {response.status_code}")
        if response.status_code == 401:
            print("Success: /review/sync is protected (returned 401).")
        else:
            print(f"Failure: /review/sync should return 401, but returned {response.status_code}.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    print("NOTE: Ensure the FastAPI server is running on port 8004 before running this test.")
    test_health_public()
    test_review_protected()
