import asyncio
import os
from dotenv import load_dotenv
from app.code_review_agent import CodeReviewAgent

# Load environment variables
load_dotenv()

async def test_agent_review():
    agent = CodeReviewAgent()
    
    sample_diff = """
diff --git a/app/main.py b/app/main.py
index e69de29..b78a453 100644
--- a/app/main.py
+++ b/app/main.py
@@ -1,5 +1,10 @@
 def calculate_sum(a, b):
-    return a + b
+    # This is a very simple function
+    # Adding some comments for testing
+    result = a + b
+    print(f"Result is {result}")
+    return result
+
+def potential_bug(items):
+    # BUG: This will fail if items is None
+    return len(items)
"""
    
    print("Testing CodeReviewAgent.review_code...")
    result = await agent.review_code(
        diff=sample_diff,
        focus_areas=["code_quality", "best_practices"],
        language="Python"
    )
    
    print("\n--- REVIEW RESULT ---")
    print(result.get("review_text"))
    print("----------------------\n")
    
    if "review_text" in result and result["review_text"]:
        print("Success: Review generated.")
    else:
        print("Failure: Review text missing.")

if __name__ == "__main__":
    asyncio.run(test_agent_review())
