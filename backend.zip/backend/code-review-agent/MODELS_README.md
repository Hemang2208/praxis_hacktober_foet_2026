# Code Review Agent - Models Documentation

## Overview

The Code Review Agent models handle GitHub pull request integration and code review functionality. The agent analyzes code diffs and provides intelligent code review feedback.

## Table of Contents

- [Core Models](#core-models)
- [Request Models](#request-models)
- [Response Models](#response-models)
- [Health Models](#health-models)
- [API Workflows](#api-workflows)
- [GitHub Integration](#github-integration)

---

## Core Models

### pull_requestInfo

**Purpose**: Contains information about a GitHub pull request

**Fields**:
- `repo_owner` (str): GitHub repository owner/organization name
- `repo_name` (str): Repository name
- `pr_number` (int): Pull request number
- `head_sha` (str): SHA of the head commit (the PR's current state)
- `base_sha` (str): SHA of the base commit (where PR started from)

**Example**:
```python
pr_info = pull_requestInfo(
    repo_owner="myorg",
    repo_name="awesome-project",
    pr_number=42,
    head_sha="abc123def456",
    base_sha="xyz789uvw123"
)
```

**Usage**: This model is used to uniquely identify and reference a specific pull request for review operations.

### WebhookPayload

**Purpose**: Represents a GitHub webhook payload for PR events

**Fields**:
- `action` (str): The action that triggered the webhook
  - "opened" - PR was opened
  - "synchronize" - PR received new commits
  - "reopened" - PR was reopened
  - "edited" - PR was edited
  - "closed" - PR was closed
- `pull_request` (Dict[str, Any]): Complete PR object from GitHub API
  - Includes: title, description, author, timestamps, etc.
- `repository` (Dict[str, Any]): Complete repository object from GitHub API
  - Includes: name, owner, description, URL, etc.

**Example**:
```python
webhook = WebhookPayload(
    action="opened",
    pull_request={
        "number": 42,
        "title": "Add new feature",
        "user": {"login": "developer"},
        "created_at": "2024-01-15T10:30:00Z",
        # ... more fields from GitHub API
    },
    repository={
        "name": "awesome-project",
        "owner": {"login": "myorg"},
        "url": "https://github.com/myorg/awesome-project",
        # ... more fields from GitHub API
    }
)
```

**GitHub Actions Triggering Webhook**:
- PR opened, synchronized, reopened, edited, closed
- Comments added/edited/deleted
- Review requested/submitted

---

## Request Models

### ReviewRequest

**Purpose**: Input model for requesting a code review

**Fields**:
- `diff` (str, required): The code diff to review (unified diff format)
- `pr_info` (pull_requestInfo, required): Pull request information
- `language` (str, optional): Programming language of the code
  - Auto-detect if not provided
  - Examples: "python", "javascript", "java", "go", "rust"
- `focus_areas` (List[str], optional): Specific areas to focus on
  - Default: `["code_quality", "security", "performance", "best_practices"]`
  - Other options: `["testing", "documentation", "maintainability", "readability"]`

**Example**:
```python
review_request = ReviewRequest(
    diff="""--- a/app.py
+++ b/app.py
@@ -1,5 +1,8 @@
 def calculate_total(items):
-    total = 0
-    for item in items:
-        total = total + item
-    return total
+    total = 0
+    for item in items:
+        if item > 0:
+            total += item
+    return total
""",
    pr_info=pull_requestInfo(
        repo_owner="myorg",
        repo_name="awesome-project",
        pr_number=42,
        head_sha="abc123def456",
        base_sha="xyz789uvw123"
    ),
    language="python",
    focus_areas=["code_quality", "performance", "security"]
)
```

**Diff Format**:
Use standard unified diff format:
```
--- a/path/to/file.ext
+++ b/path/to/file.ext
@@ -line_start,line_count +line_start,line_count @@
 context line
-removed line
+added line
 context line
```

**Supported Languages**:
- Python, JavaScript/TypeScript, Java, Go, Rust, C/C++, C#, Ruby, PHP, etc.

---

## Response Models

### ReviewResponse

**Purpose**: Output model containing code review results

**Fields**:
- `status` (str): Status of the review operation
  - "success" - Review completed successfully
  - "processing" - Review is being processed
  - "failed" - Review failed with error
  - "partial" - Partial review due to size/complexity limits
- `review_id` (str): Unique identifier for the review
  - Used to track and reference the review
  - Format: UUID or similar unique identifier
- `message` (str): Review feedback and comments
  - Contains structured or narrative feedback
  - May include code suggestions, improvements, issues
  - Markdown formatted for readability
- `timestamp` (str): ISO 8601 timestamp when review was completed

**Example**:
```python
review_response = ReviewResponse(
    status="success",
    review_id="rev_abc123xyz789",
    message="""## Code Review Results

### Summary
Good overall structure with some suggestions for improvement.

### Issues Found
1. **Security**: Lack of input validation on user input
   - Line 15: Add validation before processing user_input
   
2. **Performance**: Inefficient loop
   - Line 23: Consider using list comprehension or vectorization
   
### Suggestions
- Add error handling for edge cases
- Consider adding type hints for better type safety
- Add docstrings to public methods

### Positive Feedback
✓ Good code organization
✓ Clear variable names
✓ Proper error handling in most cases

### Files Reviewed
- app.py (42 lines)
- utils.py (18 lines)
""",
    timestamp="2024-01-15T10:45:30Z"
)
```

**Message Content**:
The message field is a formatted string containing:
- Summary of findings
- Issues by category (security, performance, maintainability, etc.)
- Specific line numbers and suggestions
- Praise for good practices
- Overall assessment and recommendations

---

## Health Models

### HealthResponse

**Purpose**: Service health check response

**Fields**:
- `status` (str): Overall service status
  - "healthy" - Service is operating normally
  - "degraded" - Service is working but with issues
  - "unhealthy" - Service is down or failing
- `version` (str): Service version number
  - Format: semantic versioning (e.g., "1.2.3")
  - Helps track which version is running
- `timestamp` (str): ISO 8601 timestamp of health check

**Example**:
```python
health = HealthResponse(
    status="healthy",
    version="1.5.2",
    timestamp="2024-01-15T10:50:00Z"
)
```

**Typical Health Check Endpoint**:
```
GET /health
Response: HealthResponse
```

---

## API Workflows

### Code Review Workflow

**Step 1: Trigger Review**
```
Client → POST /review
Body: ReviewRequest
```

**Step 2: Processing**
- Parse diff
- Identify changed files and lines
- Analyze code for issues
- Generate feedback using AI

**Step 3: Response**
```
Server → ReviewResponse
Contains: review_id, feedback, timestamp
```

**Step 4: Store Result**
- Save review to database
- Associate with PR
- Store feedback for history

### GitHub Webhook Workflow

**Step 1: GitHub Webhook Event**
```
GitHub Server → POST /webhook
Body: WebhookPayload (action="opened" or "synchronize")
```

**Step 2: Process Webhook**
- Extract PR info
- Fetch diff from GitHub API
- Create ReviewRequest
- Trigger code review

**Step 3: Post Review**
- Format feedback as GitHub comments
- Post review on PR using GitHub API
- Update PR status

**Step 4: Store History**
- Save webhook event
- Save review result
- Update review count and stats

---

## GitHub Integration

### Webhook Events

**PR Opened**
```json
{
  "action": "opened",
  "pull_request": {
    "number": 42,
    "title": "Implement new feature",
    "user": {"login": "developer"},
    "body": "Description of changes",
    "created_at": "2024-01-15T10:30:00Z"
  },
  "repository": {...}
}
```

**PR Synchronized (new commits)**
```json
{
  "action": "synchronize",
  "pull_request": {...},
  "repository": {...}
}
```

### Webhook Configuration

To receive webhooks, configure in GitHub repository settings:

**Webhook URL**: `https://your-api.com/webhook/github`

**Events to Subscribe**:
- Pull Request Events
  - opened
  - synchronize
  - reopened

**Content Type**: `application/json`

### GitHub API Access

The Code Review Agent needs:
- Authentication: Personal Access Token or OAuth token
- Permissions:
  - `repo` - Access to repository content
  - `pull-requests:read` - Read PR information
  - `pull-requests:write` - Post reviews/comments
- Rate Limits: 60 requests/hour (unauthenticated), 5000/hour (authenticated)

### Posting Reviews to GitHub

Reviews are posted as GitHub PR Reviews with format:
```python
{
  "body": "Overall review feedback",
  "event": "COMMENT",  # or "APPROVE", "REQUEST_CHANGES"
  "comments": [
    {
      "path": "app.py",
      "line": 15,
      "body": "Consider adding input validation here"
    }
  ]
}
```

---

## Code Review Quality

### Review Categories

**Security**
- Authentication/authorization issues
- SQL injection risks
- XSS vulnerabilities
- Cryptographic best practices
- Secrets exposed in code

**Performance**
- Time complexity issues
- Memory leaks
- Inefficient algorithms
- Database query optimization
- Caching opportunities

**Code Quality**
- Naming conventions
- Code duplication
- Type safety
- Error handling
- Complexity metrics

**Best Practices**
- Design patterns
- SOLID principles
- Testing coverage
- Documentation
- Maintainability

---

## Error Handling

**Invalid Diff Format**
- Returns ReviewResponse with status="failed"
- Message includes parsing error details

**Unsupported Language**
- Agent attempts auto-detection
- Falls back to generic review if detection fails
- Returns ReviewResponse with language assumption

**PR Not Found**
- Returns 404 error
- Verify pr_info fields are correct

**Review Size Limits**
- Large diffs may be reviewed partially
- Returns ReviewResponse with status="partial"

**Rate Limiting**
- GitHub API rate limits apply
- Agent implements exponential backoff
- Returns 429 error if rate limit exceeded

---

## Usage Examples

### Direct Code Review Request

```python
# Create review request
request = ReviewRequest(
    diff=code_diff,
    pr_info=pull_requestInfo(
        repo_owner="pytorch",
        repo_name="pytorch",
        pr_number=12345,
        head_sha="abc123",
        base_sha="def456"
    ),
    language="python",
    focus_areas=["security", "performance"]
)

# Send request
response = await review_service.review_code(request)

# Process response
if response.status == "success":
    print(f"Review ID: {response.review_id}")
    print(response.message)
```

### GitHub Webhook Integration

```python
# Endpoint to receive webhooks
@app.post("/webhook/github")
async def handle_webhook(payload: WebhookPayload):
    if payload.action in ["opened", "synchronize"]:
        # Extract PR info
        pr_number = payload.pull_request["number"]
        
        # Fetch full diff from GitHub
        diff = fetch_pr_diff(payload.repository, pr_number)
        
        # Create review request
        request = ReviewRequest(
            diff=diff,
            pr_info=extract_pr_info(payload),
            language=None  # Auto-detect
        )
        
        # Review code
        response = await review_service.review_code(request)
        
        # Post review back to GitHub
        post_review_to_github(
            payload.repository,
            pr_number,
            response.message
        )
```

### Health Check

```python
# Check service health
health = await health_service.check_health()
print(f"Status: {health.status}")
print(f"Version: {health.version}")
```

---

## Database Schema

```
CodeReview
├── id (UUID)
├── review_id (from ReviewResponse)
├── pr_info (pull_requestInfo)
├── request (ReviewRequest)
├── response (ReviewResponse)
├── status (string)
├── created_at (datetime)
└── webhook_payload (WebhookPayload, optional)

ReviewHistory
├── repo_owner (string)
├── repo_name (string)
├── pr_number (int)
├── review_count (int)
├── last_review (datetime)
└── reviews (List[CodeReview])
```

---

## Best Practices

1. **Provide Language**: Help the agent by specifying language if known
2. **Focus Areas**: Use focus_areas to emphasize important review aspects
3. **Diff Quality**: Ensure diffs are in valid unified format
4. **Webhook Validation**: Validate GitHub webhook signatures for security
5. **Retry Logic**: Implement retry logic with exponential backoff
6. **Review Storage**: Store reviews for audit trail and history
7. **Rate Limiting**: Respect GitHub API rate limits with caching

---

## Security Considerations

1. **Webhook Validation**:
   - Verify GitHub webhook signatures using X-Hub-Signature header
   - Never trust unsigned webhooks

2. **Token Security**:
   - Store GitHub tokens in secure environment variables
   - Rotate tokens regularly
   - Use least-privilege scopes

3. **Code Privacy**:
   - Be cautious when reviewing proprietary code
   - Consider on-premise deployment for sensitive codebases
   - Implement access controls

4. **Input Validation**:
   - Validate all input in ReviewRequest
   - Sanitize diff content before processing
   - Check PR info structure

---

## Troubleshooting

**Review not posted to GitHub**:
- Check GitHub token has correct permissions
- Verify webhook configuration is correct
- Check rate limits not exceeded

**Webhook not received**:
- Verify webhook URL is correct in GitHub settings
- Check firewall/network allows inbound connections
- Verify payload format matches expectations

**Inaccurate reviews**:
- Provide language specification
- Use focus_areas to guide review
- Provide more context in PR description

---

## Notes

- All timestamps use ISO 8601 format
- Review IDs are unique identifiers for audit trail
- Reviews are not modified after creation (immutable)
- Diff must be in standard unified diff format
- GitHub API calls are rate-limited and require authentication

