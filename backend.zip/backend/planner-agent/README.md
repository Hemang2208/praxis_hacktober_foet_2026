# Planner Agent

AI project planning agent. Takes a project brief and generates structured plans with tasks, milestones, and timelines.

**Port:** 8002

## What it does

- Generates project plans from natural language briefs
- Breaks plans into tasks with effort estimates and dependencies
- Task refinement — iteratively improves generated tasks based on feedback
- Quality scoring on generated plans

## Structure

This agent uses an `app/` package layout:

```
planner-agent/
├── app/
│   ├── main.py         — FastAPI app
│   ├── models.py       — Pydantic models
│   ├── routes.py       — Route handlers
│   ├── services.py     — LLM + planning logic
│   └── database.py     — MongoDB connection
├── tests/              — Test files
├── Dockerfile
└── requirements.txt
```

## Main endpoints

```
POST /api/v1/projects/{id}/plan          — generate plan for a project
GET  /api/v1/projects/{id}/plan          — get existing plan
PUT  /api/v1/projects/{id}/plan/tasks    — update tasks
POST /api/v1/tasks/{id}/refine           — refine a specific task with AI
```

## Env vars

```
MONGODB_URI=
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5-coder:latest
JWT_SECRET_KEY=
```

## Running locally

```bash
pip install -r app/requirements.txt
uvicorn app.main:app --reload --port 8002
```

## Tests

```bash
cd tests
pytest test_planner_simple.py -v
pytest test_planner_debug.py -v
```

## Docs

- `MODELS_README.md` — model reference
- `IMPLEMENTATION_DETAILS.md` — planning algorithm details
- `QUICK_START_QUALITY.md` — quality scoring guide
