# Planner Agent - Models Documentation

## Overview

The Planner Agent models handle project planning, resource management, task organization, and timeline management. The agent assists in creating comprehensive project plans and organizing team resources.

## Table of Contents

- [Core Project Models](#core-project-models)
- [Resource Models](#resource-models)
- [Planning Component Models](#planning-component-models)
- [Task Models](#task-models)
- [Request/Response Models](#requestresponse-models)
- [Utilities](#utilities)
- [API Workflows](#api-workflows)
- [Database Integration](#database-integration)

---

## Core Project Models

### ProjectCreate

**Purpose**: Input model for creating a new project

**Fields**:
- `title` (str): Project name/title
- `description` (str): Detailed project description
- `deadline` (datetime, optional): Project deadline
- `tags` (List[str]): Project tags for categorization (default: [])
- `document` (str): Project requirements document (SRS, specification, etc.)
- `created_by` (str): User ID of project creator
- `status` (str): Project status (default: "planning")
  - "planning" - In planning phase
  - "active" - In progress
  - "paused" - On hold
  - "completed" - Finished
  - "archived" - Archived
- `tasks` (List[str]): Task IDs associated with project (default: [])
- `progress` (float): Progress percentage 0-100 (default: 0)
- `team` (List[TeamMember]): Team members (default: [])
- `sprints` (List[Sprint]): Project sprints (default: [])
- `timeline` (List[TimelineEvent]): Timeline events (default: [])
- `resources` (List[Resource]): Project resources (default: [])

**Example**:
```python
project_create = ProjectCreate(
    title="E-Commerce Platform",
    description="Build a scalable e-commerce platform",
    deadline=datetime(2024, 12, 31),
    tags=["ecommerce", "backend", "web"],
    document="Software Requirements Specification...",
    created_by="user_123",
    status="planning",
    team=[
        TeamMember(user="dev_001", role="backend-lead"),
        TeamMember(user="dev_002", role="frontend-lead")
    ]
)
```

### ProjectCreateResponse

**Purpose**: Response when project is successfully created

**Fields**:
- `project_id` (str): MongoDB ObjectId as string (assigned by DB)
- `title` (str): Project title (echo)
- `status` (str): Project status (echo)
- `progress` (float): Initial progress (echo)
- `ai_generated_tags` (List[str]): AI-generated additional tags
- `created_at` (datetime): Creation timestamp
- `updated_at` (datetime): Last update timestamp

**Example**:
```python
response = ProjectCreateResponse(
    project_id="507f1f77bcf86cd799439011",
    title="E-Commerce Platform",
    status="planning",
    progress=0.0,
    ai_generated_tags=["scalability", "microservices", "api-design"],
    created_at=datetime.now(),
    updated_at=datetime.now()
)
```

### ProjectResponse

**Purpose**: Complete project model with all details

**Fields**:
- `id` (PyObjectId): MongoDB ObjectId (alias: "_id")
- `title` (str): Project title
- `description` (str): Project description
- `deadline` (datetime, optional): Deadline
- `tags` (List[str]): Project tags
- `document` (str): Requirements document
- `status` (str): Current status
- `tasks` (List[str]): Associated task IDs
- `progress` (float): Progress percentage
- `team` (List[TeamMember]): Team members
- `sprints` (List[Sprint]): Sprint information
- `timeline` (List[TimelineEvent]): Timeline events
- `resources` (List[Resource]): Project resources
- `created_by` (str): Creator identifier
- `created_at` (datetime): Creation timestamp
- `updated_at` (datetime): Last update timestamp

**Special Features**:
- MongoDB ObjectId handling with PyObjectId
- Configurable JSON encoding
- Allows populating by field name or alias (_id)

**Example**:
```python
project = ProjectResponse(
    id=ObjectId("507f1f77bcf86cd799439011"),
    title="E-Commerce Platform",
    description="Build a scalable e-commerce platform",
    # ... all other fields
    created_at=datetime.now(),
    updated_at=datetime.now()
)
```

---

## Resource Models

### Resource

**Purpose**: Represents a team member or resource allocated to the project

**Fields**:
- `profile` (str): User profile type (e.g., "developer", "designer", "manager")
- `skills` (List[str]): List of skills (e.g., ["Python", "Django", "PostgreSQL"])
- `experience` (str): Experience level (e.g., "senior", "mid-level", "junior")
- `description` (str): Brief description of the resource
- `type` (str): Resource type (e.g., "human", "tool", "service")
- `avatar` (str, optional): Avatar/profile image URL
- `username` (str, optional): GitHub/system username
- `name` (str, optional): Full name
- `user` (str, optional): User ID reference

**Example**:
```python
resource = Resource(
    profile="developer",
    skills=["Python", "Django", "PostgreSQL", "Docker"],
    experience="senior",
    description="Full-stack developer with 8+ years experience",
    type="human",
    avatar="https://example.com/avatars/john.jpg",
    username="john_doe",
    name="John Doe",
    user="user_123"
)

# Tool resource
tool = Resource(
    profile="tool",
    skills=["CI/CD", "Automation"],
    experience="n/a",
    description="GitHub Actions for continuous integration",
    type="tool",
    name="GitHub Actions"
)
```

---

## Planning Component Models

### Sprint

**Purpose**: Represents a development sprint

**Fields**:
- `name` (str): Sprint name (e.g., "Sprint 1: Core Features")
- `progress` (float): Progress percentage (0-100)
- `status` (str): Sprint status
  - "planning" - Being planned
  - "active" - Currently running
  - "completed" - Finished
  - "blocked" - Blocked by issues

**Example**:
```python
sprint = Sprint(
    name="Sprint 1: Authentication & User Management",
    progress=45.5,
    status="active"
)
```

### TimelineEvent

**Purpose**: Represents a significant event in the project timeline

**Fields**:
- `title` (str): Event title
- `description` (str): Detailed description
- `type` (str): Event type
  - "milestone" - Major milestone
  - "deadline" - Deadline
  - "release" - Release event
  - "review" - Review/checkpoint
  - "other" - Other events
- `date` (datetime): When the event occurs

**Example**:
```python
event = TimelineEvent(
    title="v1.0 Release",
    description="Release version 1.0 with core features",
    type="release",
    date=datetime(2024, 6, 30)
)

event2 = TimelineEvent(
    title="Alpha Review",
    description="Internal review of alpha version",
    type="review",
    date=datetime(2024, 5, 15)
)
```

### TeamMember

**Purpose**: Represents a team member assigned to the project

**Fields**:
- `user` (str): User ID or identifier
- `role` (str): Role in the project
  - "project-lead" - Project leader
  - "backend-lead" - Backend team lead
  - "frontend-lead" - Frontend team lead
  - "devops-lead" - DevOps lead
  - "backend-dev" - Backend developer
  - "frontend-dev" - Frontend developer
  - "qa" - QA engineer
  - "designer" - UI/UX designer
  - "analyst" - Business analyst
  - "contributor" - General contributor

**Example**:
```python
team_members = [
    TeamMember(user="user_001", role="project-lead"),
    TeamMember(user="user_002", role="backend-lead"),
    TeamMember(user="user_003", role="frontend-lead"),
    TeamMember(user="user_004", role="qa")
]
```

---

## Task Models

### Task

**Purpose**: Individual project task

**Fields**:
- `task_name` (str): Task name
- `description` (str): Task description
- `dependencies` (List[str]): IDs of tasks that must be completed first

**Example**:
```python
task = Task(
    task_name="Design Database Schema",
    description="Design the database schema for user management",
    dependencies=[]
)

dependent_task = Task(
    task_name="Implement User Repository",
    description="Implement database layer for users",
    dependencies=["task_001"]  # Depends on schema design
)
```

### SubTask

**Purpose**: Breakdown of a task into smaller units

**Fields**:
- `name` (str): Subtask name
- `description` (str): Subtask description
- `effort` (str): Effort estimation
  - "1 hour" - Very small
  - "4 hours" - Small
  - "8 hours" - Medium (1 day)
  - "16 hours" - Large (2 days)
  - "32 hours" - Very large (1 week)
- `technical_requirements` (List[str]): Technical skills/tools needed

**Example**:
```python
subtasks = [
    SubTask(
        name="Analyze Requirements",
        description="Analyze and document requirements",
        effort="4 hours",
        technical_requirements=["requirements-analysis"]
    ),
    SubTask(
        name="Design Schema",
        description="Create database schema diagram",
        effort="8 hours",
        technical_requirements=["database-design", "SQL"]
    ),
    SubTask(
        name="Code Implementation",
        description="Implement the schema",
        effort="8 hours",
        technical_requirements=["Python", "SQLAlchemy"]
    )
]
```

### RefinedTask

**Purpose**: Task with detailed subtasks breakdown

**Inherits from**: Task

**Additional Fields**:
- `subtasks` (List[SubTask]): Detailed subtasks

**Example**:
```python
refined_task = RefinedTask(
    task_name="Design Database Schema",
    description="Design the database schema for user management",
    dependencies=[],
    subtasks=[
        SubTask(name="Analyze Requirements", ...),
        SubTask(name="Design Schema", ...),
        SubTask(name="Code Implementation", ...)
    ]
)
```

### Milestone

**Purpose**: Represents a project milestone

**Fields**:
- `name` (str): Milestone name (e.g., "Phase 1 Complete")
- `timeline` (str): Timeline for completion (e.g., "Week 2", "2024-03-31")
- `deliverables` (List[str]): Deliverables for this milestone

**Example**:
```python
milestone = Milestone(
    name="Backend Infrastructure Complete",
    timeline="2024-03-31",
    deliverables=[
        "Database schema implemented",
        "Authentication API complete",
        "User management endpoints working",
        "Logging system deployed"
    ]
)
```

---

## Request/Response Models

### GeneratePlanRequest

**Purpose**: Request for AI to generate a project plan

**Fields**:
- `planning_depth` (str): Depth of planning analysis (default: "medium")
  - "low" - Quick overview, minimal detail
  - "medium" - Balanced detail
  - "high" - Comprehensive, detailed analysis
- `include_risk_analysis` (bool): Whether to include risk analysis (default: False)

**Example**:
```python
request = GeneratePlanRequest(
    planning_depth="high",
    include_risk_analysis=True
)
```

### PlanHighLevelTask

**Purpose**: High-level task in generated plan

**Fields**:
- `task_name` (str): Task name
- `description` (str): Task description
- `dependencies` (List[str]): Task dependencies (default: [])
- `estimated_duration` (str, optional): Estimated time to complete (e.g., "2 weeks")

**Example**:
```python
task = PlanHighLevelTask(
    task_name="Backend Development",
    description="Develop REST API and core backend services",
    dependencies=["Database Design"],
    estimated_duration="4 weeks"
)
```

### PlanMilestone

**Purpose**: Milestone in generated plan

**Fields**:
- `name` (str): Milestone name
- `timeline` (str): Timeline (e.g., "Week 4", "2024-04-30")
- `deliverables` (List[str]): Expected deliverables (default: [])

**Example**:
```python
milestone = PlanMilestone(
    name="MVP Complete",
    timeline="2024-05-31",
    deliverables=[
        "User authentication working",
        "Core features implemented",
        "Performance baseline established",
        "Security audit completed"
    ]
)
```

### ProjectPlanResponse

**Purpose**: AI-generated project plan

**Fields**:
- `project_id` (str): Associated project ID
- `summary` (str): Executive summary of the plan
- `skills_required` (List[str]): Skills needed for the project (default: [])
- `milestones` (List[PlanMilestone]): Project milestones (default: [])
- `high_level_tasks` (List[PlanHighLevelTask]): Main tasks (default: [])
- `risk_factors` (List[str]): Identified risks (default: [])
- `generated_by` (str): AI service that generated the plan
- `generated_at` (datetime): Generation timestamp

**Example**:
```python
plan = ProjectPlanResponse(
    project_id="507f1f77bcf86cd799439011",
    summary="This plan outlines a 16-week development cycle...",
    skills_required=["Python", "React", "PostgreSQL", "Docker", "AWS"],
    milestones=[
        PlanMilestone(name="Phase 1", ...),
        PlanMilestone(name="Phase 2", ...)
    ],
    high_level_tasks=[
        PlanHighLevelTask(name="Design", ...),
        PlanHighLevelTask(name="Development", ...)
    ],
    risk_factors=[
        "Resource availability in Q2",
        "Third-party API reliability",
        "Scope creep risk"
    ],
    generated_by="ollama",
    generated_at=datetime.now()
)
```

### ProjectUpdate

**Purpose**: Partial update to project fields

**Fields**: All ProjectCreate fields are optional for updates

**Example**:
```python
update = ProjectUpdate(
    status="active",
    progress=25.0,
    deadline=datetime(2024, 11, 30)
)
```

---

## Utilities

### PyObjectId

**Purpose**: Custom type for MongoDB ObjectId compatibility with Pydantic

**Features**:
- Validates MongoDB ObjectId format
- JSON serializes to string for API compatibility
- Aliases "_id" field to "id" for convenience
- Provides schema support for OpenAPI

**Usage**:
```python
# In models
id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")

# Access
project_id = str(project.id)  # Convert to string if needed
```

---

## API Workflows

### Project Creation Workflow

**Step 1: Create Project**
```
Client → POST /projects
Body: ProjectCreate
```

**Step 2: Processing**
- Validate input
- Assign ObjectId
- Add timestamps
- Store to database

**Step 3: Response**
```
Server → ProjectCreateResponse
Returns: project_id, timestamps, AI-generated tags
```

### Plan Generation Workflow

**Step 1: Request Plan**
```
Client → POST /projects/{project_id}/plan
Body: GeneratePlanRequest
```

**Step 2: AI Processing**
- Analyze project requirements
- Generate tasks and milestones
- Identify risks (if requested)
- Estimate effort and duration

**Step 3: Response**
```
Server → ProjectPlanResponse
Returns: tasks, milestones, skills, risks
```

### Project Retrieval Workflow

**Step 1: Get Project**
```
Client → GET /projects/{project_id}
```

**Step 2: Database Query**
- Fetch project by ObjectId
- Populate related data

**Step 3: Response**
```
Server → ProjectResponse
Returns: complete project details
```

### Project Update Workflow

**Step 1: Update Project**
```
Client → PATCH /projects/{project_id}
Body: ProjectUpdate
```

**Step 2: Processing**
- Validate changes
- Update only provided fields
- Update timestamp

**Step 3: Response**
```
Server → ProjectResponse
Returns: updated project
```

---

## Database Integration

### MongoDB Collections

```
Projects Collection
├── _id (ObjectId)
├── title (string)
├── description (string)
├── deadline (datetime)
├── tags (array)
├── document (string)
├── status (string)
├── tasks (array of IDs)
├── progress (float)
├── team (array of TeamMemember)
├── sprints (array of Sprint)
├── timeline (array of TimelineEvent)
├── resources (array of Resource)
├── created_by (string/ObjectId)
├── created_at (datetime)
└── updated_at (datetime)

ProjectPlans Collection
├── _id (ObjectId)
├── project_id (ObjectId)
├── summary (string)
├── skills_required (array)
├── milestones (array of PlanMilestone)
├── high_level_tasks (array of PlanHighLevelTask)
├── risk_factors (array)
├── generated_by (string)
└── generated_at (datetime)
```

---

## Relationships

```
Project (1) ──── (N) Task
        (1) ──── (N) Sprint
        (1) ──── (1) ProjectPlan
        (1) ──── (N) TeamMember
        (1) ──── (N) Resource
        (1) ──── (N) TimelineEvent

Task (1) ──── (N) SubTask
     (0..N) ──── (1) Task (dependencies)

Sprint (N) ──── (1) Project
```

---

## Validation Rules

1. **ProjectCreate**:
   - `title`: Non-empty string
   - `description`: Non-empty string
   - `deadline`: Must be in future (if provided)
   - `progress`: Must be 0-100
   - `created_by`: Non-empty string

2. **GeneratePlanRequest**:
   - `planning_depth`: "low", "medium", or "high"
   - `include_risk_analysis`: Boolean

3. **Milestone**:
   - `name`: Non-empty string
   - `timeline`: Valid date or period string
   - `deliverables`: Array of non-empty strings

---

## Usage Examples

### Create a Project

```python
# Create project
project_create = ProjectCreate(
    title="Mobile App",
    description="iOS and Android app",
    deadline=datetime(2024, 12, 31),
    tags=["mobile", "ios", "android"],
    document="Requirements document...",
    created_by="user_123"
)

# Store in database
response = db.projects.insert_one(project_create.dict())
project_id = str(response.inserted_id)
```

### Generate Plan

```python
# Request plan
plan_request = GeneratePlanRequest(
    planning_depth="high",
    include_risk_analysis=True
)

# Generate plan
plan = ai_service.generate_plan(project_id, plan_request)

# Store plan
db.project_plans.insert_one(plan.dict())
```

### Update Project Progress

```python
# Update progress
update = ProjectUpdate(
    progress=50.0,
    status="active"
)

# Apply update
db.projects.update_one(
    {"_id": ObjectId(project_id)},
    {"$set": update.dict(exclude_unset=True)}
)
```

---

## Best Practices

1. **Clear Naming**: Use descriptive names for tasks, sprints, and milestones
2. **Realistic Estimates**: Provide accurate effort estimations
3. **Dependency Management**: Define clear task dependencies
4. **Skill Requirements**: List all required technical skills
5. **Risk Identification**: Include identified risks in planning
6. **Timeline Clarity**: Use clear, consistent timeline formats
7. **Team Roles**: Assign clear roles to team members

---

## Notes

- All timestamps use UTC datetime
- MongoDB ObjectIds are automatically generated on creation
- Project status should follow the defined status values
- Resource types help identify resource availability and allocation
- Sprints should be sequential for better planning clarity

