# Task Quality Engine - Implementation Details

## Architecture Overview

```
Planner Agent (main.py)
├── TaskQualityEngine (task_quality_engine.py)
│   ├── detect_project_niche()
│   ├── estimate_task_complexity()
│   ├── generate_prompt_for_niche()
│   ├── validate_task_quality()
│   └── NicheTaskGenerator
│
├── PlannerAgent (planner.py)
│   ├── generate_project_plan()
│   │   ├── Uses TaskQualityEngine for niche detection
│   │   └── Uses domain-specific prompts
│   ├── refine_project_tasks()
│   │   └── Uses quality subtask prompts
│   └── _generate_smart_subtasks()
│       ├── API/Service pattern
│       ├── Database pattern
│       ├── Frontend pattern
│       ├── Testing pattern
│       └── Generic pattern
│
└── MongoDB
    └── Stores enriched task definitions
```

## Module: Task Quality Engine

### Classes & Enums

#### `ProjectNiche` (Enum)
```python
class ProjectNiche(Enum):
    WEB_DEVELOPMENT = "web_development"
    MOBILE_APP = "mobile_app"
    DATA_SCIENCE = "data_science"
    DEVOPS = "devops"
    BLOCKCHAIN = "blockchain"
    MACHINE_LEARNING = "machine_learning"
    SAAS = "saas"
    E_COMMERCE = "e_commerce"
    FINTECH = "fintech"
    HEALTHCARE = "healthcare"
    IOT = "iot"
    GAME_DEVELOPMENT = "game_development"
    GENERAL = "general"
```

#### `TaskComplexity` (Enum)
```python
class TaskComplexity(Enum):
    TRIVIAL = "trivial"           # < 1 day
    SIMPLE = "simple"             # 1-3 days
    MODERATE = "moderate"         # 3-5 days
    COMPLEX = "complex"           # 1-2 weeks
    VERY_COMPLEX = "very_complex" # 2+ weeks
```

### Key Methods

#### 1. `detect_project_niche(title, description, tags) -> ProjectNiche`

**Algorithm:**
- Tokenize all text (title + description + tags)
- Count keyword matches for each niche
- Return niche with highest match count

**Keyword Mapping:**
```python
niche_keywords = {
    ProjectNiche.WEB_DEVELOPMENT: ["web", "frontend", "backend", "react", ...],
    ProjectNiche.MOBILE_APP: ["mobile", "ios", "android", "flutter", ...],
    ProjectNiche.DATA_SCIENCE: ["data science", "analytics", "insights", ...],
    # ... 9 more niches
}
```

**Example:**
```python
niche = TaskQualityEngine.detect_project_niche(
    "E-commerce Platform",
    "Build online store with React frontend and Node backend",
    ["web", "react", "nodejs", "database"]
)
# Returns: ProjectNiche.WEB_DEVELOPMENT
```

#### 2. `estimate_task_complexity(task_name, description, dependencies, required_skills) -> TaskComplexity`

**Scoring Algorithm:**

```
complexity_score = 0

# Description length (more detailed = more complex)
if len(description) > 200:
    score += 2
elif len(description) > 100:
    score += 1

# Complexity keywords
for word in ["integrate", "architect", "design", "optimize", ...]:
    if word in task_name.lower() + description.lower():
        score += 1

# Dependencies (each adds to complexity)
score += number_of_dependencies

# Required skills (skills increase complexity)
score += required_skills // 2

# Map score to level:
# 0-1: TRIVIAL
# 2-3: SIMPLE
# 4-6: MODERATE
# 7-10: COMPLEX
# 10+: VERY_COMPLEX
```

**Example:**
```python
complexity = TaskQualityEngine.estimate_task_complexity(
    "Implement JWT authentication",
    "Create secure JWT-based auth with refresh tokens and role-based access control",
    dependencies=2,
    required_skills=3
)
# Returns: TaskComplexity.MODERATE
```

#### 3. `generate_prompt_for_niche(niche, project_details) -> str`

**Structure:**
```
[Base Instructions]
- Focus on quality and specificity
- List 10 CRITICAL REQUIREMENTS
- Emphasize no placeholders

[Niche-Specific Guidance]
- Domain best practices
- Technology considerations
- Common pitfalls

[Project Context]
- Title, description
- Team size, deadline
- Tags and constraints

[JSON Structure Requirements]
- Exact format with field definitions
- Examples of good vs bad values

[Quality Rules]
- Specific requirements
- Count requirements
- Validation rules
```

**Niche Specific Content Examples:**

**Web Development:**
```
- Frontend/backend separation
- API design tasks
- Database schema design
- Security (auth, authorization, protection)
- Testing (unit, integration, e2e)
- Performance optimization
- Responsive design
- Cross-browser compatibility
- Deployment & monitoring
```

**Data Science:**
```
- Data collection and preparation
- Exploratory data analysis (EDA)
- Feature engineering
- Model selection and training
- Hyperparameter tuning
- Model evaluation and validation
- Documentation of assumptions
- Dashboards and visualization
```

**DevOps:**
```
- Infrastructure planning
- Containerization
- Orchestration setup
- CI/CD pipeline configuration
- Monitoring and logging
- Security/compliance
- Disaster recovery
- Documentation and runbooks
```

#### 4. `validate_task_quality(task) -> (bool, List[str])`

**Validation Rules:**
```python
def validate_task_quality(task):
    issues = []
    
    # Generic name check
    generic = ["task", "work", "do", "make", "create", "implement"]
    if task_name too short or contains generic words:
        issues.append("Task name too generic")
    
    # Description length
    if len(description) < 50:
        issues.append("Description too brief")
    
    # Acceptance criteria
    if not criteria or len(criteria) < 2:
        issues.append("Need at least 2 criteria")
    
    # Deliverables
    if not deliverables:
        issues.append("Missing deliverables")
    
    # Time estimate
    if not estimated_duration:
        issues.append("Missing time estimate")
    
    # Technical requirements
    if not technical_requirements:
        issues.append("Missing technical requirements")
    
    return len(issues) == 0, issues
```

## Integration Points

### 1. In `generate_project_plan()`

**Before Enhancement:**
```python
prompt_template = generic_template
```

**After Enhancement:**
```python
# Detect niche
project_niche = TaskQualityEngine.detect_project_niche(
    context.get("title"),
    context.get("description"),
    context.get("tags")
)

# Use domain-specific prompt
prompt_template = TaskQualityEngine.generate_prompt_for_niche(
    project_niche,
    context
)
```

### 2. In `refine_project_tasks()`

**Enhanced Prompt:**
```python
refine_prompt = ChatPromptTemplate.from_messages([
    ("system", quality_focused_instructions),
    ("user", structured_task_breakdown_request)
])
```

**Quality Focus:**
- Specific subtask names
- Clear acceptance criteria
- Hour-level estimates
- Testing approach
- Deliverables per subtask

### 3. In `_generate_fallback_refined_tasks()`

**Smart Pattern Selection:**
```python
# Detect task type
if "api" in task_name.lower():
    subtasks = generate_api_subtasks(task_name)
elif "database" in task_name.lower():
    subtasks = generate_database_subtasks(task_name)
elif "ui" in task_name.lower():
    subtasks = generate_ui_subtasks(task_name)
elif "test" in task_name.lower():
    subtasks = generate_testing_subtasks(task_name)
else:
    subtasks = generate_generic_subtasks(task_name)

# Adjust for complexity
if complexity == TaskComplexity.VERY_COMPLEX:
    for st in subtasks:
        st["estimated_hours"] *= 1.5
```

## Prompt Engineering Details

### Base Instructions (Used for All Niches)
```
You are an expert project manager specializing in [NICHE].
Your task is to generate ONLY valid JSON with NO additional text.

CRITICAL REQUIREMENTS FOR HIGH-QUALITY TASKS:
1. Each task must be SPECIFIC and ACTIONABLE
2. Each task must have clear ACCEPTANCE CRITERIA
3. Each task must have TECHNICAL REQUIREMENTS
4. Each task must specify DEPENDENCIES
5. Each task must have realistic TIME ESTIMATES
6. Tasks oriented toward [NICHE] best practices
7. NO placeholder tasks
8. Tasks decomposed to appropriate granularity (3-5 days each)
9. Include RISK FACTORS per task
10. Define clear DELIVERABLES for each task
```

### JSON Structure Template

**For Main Plan:**
```json
{
    "tasks": [
        {
            "id": "task_1",
            "name": "SPECIFIC task name",
            "description": "Detailed description",
            "acceptance_criteria": ["Criterion 1", "Criterion 2"],
            "technical_requirements": ["Tech 1", "Tech 2"],
            "dependencies": ["task_x"],
            "estimated_duration": "5 days",
            "effort_level": "Medium",
            "complexity": "moderate",
            "deliverables": ["Output 1", "Output 2"],
            "risk_factors": ["Risk 1"],
            "success_metrics": ["Metric 1"]
        }
    ]
}
```

**For Subtasks:**
```json
{
    "parent_task_name": "Parent",
    "subtasks": [
        {
            "name": "Specific subtask",
            "description": "Detailed description",
            "acceptance_criteria": ["Criterion 1"],
            "estimated_hours": 12,
            "order": 1,
            "technical_requirements": ["Req 1"],
            "testing_approach": "How tested",
            "deliverables": ["Output 1"]
        }
    ]
}
```

## Extending the System

### Adding a New Niche

1. **Add to Enum:**
```python
class ProjectNiche(Enum):
    # ... existing
    MY_NEW_NICHE = "my_new_niche"
```

2. **Add Keywords:**
```python
niche_keywords = {
    # ... existing
    ProjectNiche.MY_NEW_NICHE: [
        "keyword1", "keyword2", "keyword3",
        # Add 5-10 keywords specific to niche
    ]
}
```

3. **Add Niche-Specific Guidance:**
```python
niche_prompts = {
    # ... existing
    ProjectNiche.MY_NEW_NICHE: """
For MY_NEW_NICHE projects:
- Best practice 1
- Best practice 2
- Technology consideration 1
- Common task types
- Integration points
- Testing strategies
"""
}
```

4. **Add Template (Optional):**
```python
NICHE_TEMPLATES = {
    # ... existing
    ProjectNiche.MY_NEW_NICHE: {
        "phases": ["Phase 1", "Phase 2", ...],
        "key_tasks": ["Task 1", "Task 2", ...]
    }
}
```

5. **Add Smart Subtask Pattern (Optional):**
```python
def _generate_smart_subtasks(self, task_name, task_desc, complexity):
    # ... existing patterns
    elif any(word in task_lower for word in ["my_niche_keyword"]):
        subtasks = [
            {
                "name": "...",
                "description": "...",
                # subtask structure
            }
        ]
```

## Performance Considerations

### Token Usage Impact
- **Main prompt:** +200-300 tokens (niche-specific guidance)
- **Subtask prompt:** +150-200 tokens (structured format)
- **Total impact:** +30-40% vs generic prompts

### Latency Impact
- **Niche detection:** <50ms
- **Complexity estimation:** <50ms
- **Prompt generation:** <100ms
- **Total overhead:** <200ms (negligible)

### Storage Impact
- **Per-task additions:** +200-400 bytes
- **Per-plan average:** +2-4 KB
- **Negligible impact** on MongoDB

## Testing the Implementation

### Unit Test Example:
```python
def test_detect_web_development_niche():
    niche = TaskQualityEngine.detect_project_niche(
        "E-commerce Website",
        "Build React frontend with Node backend",
        ["web", "react", "nodejs"]
    )
    assert niche == ProjectNiche.WEB_DEVELOPMENT

def test_estimate_complex_task():
    complexity = TaskQualityEngine.estimate_task_complexity(
        "Design microservices architecture",
        "Design scalable microservices with service discovery...",
        dependencies=3,
        required_skills=5
    )
    assert complexity == TaskComplexity.COMPLEX

def test_task_quality_validation():
    is_valid, issues = TaskQualityEngine.validate_task_quality({
        "name": "Implement user authentication",
        "description": "Create JWT-based auth system with refresh tokens"
        # ... rest of task
    })
    assert is_valid == True
```

## Troubleshooting

### Issue: Wrong Niche Detected
**Solution:** Add more keywords or adjust keyword matching

### Issue: Tasks Still Generic
**Solution:** Improve project description in request

### Issue: Subtasks Too Long
**Solution:** Reduce estimated hours scale (currently 4-20 hours)

### Issue: Missing Technical Requirements
**Solution:** Ensure prompt includes these in template

## Future Enhancements

1. **Machine Learning-based Niche Detection**
   - Train on real project data
   - Higher accuracy than keyword matching

2. **Historical Task Learning**
   - Learn from past projects
   - Suggest similar tasks

3. **Team Skill Mapping**
   - Match tasks to team capabilities
   - Suggest training needs

4. **Risk Assessment Engine**
   - ML-based risk prediction
   - Mitigation suggestions

5. **Budget Estimation**
   - Cost per task based on complexity
   - Resource allocation

6. **Sprint Planning Integration**
   - Automatic sprint breaking
   - Velocity-based scheduling

---

**Version:** 2.0
**Last Updated:** March 2025
**Status:** Production Ready ✅
