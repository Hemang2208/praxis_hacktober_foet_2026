"""
Simple test script to verify PlannerAgent fixes
Run this to test if the planner agent works correctly
"""

import sys
import os
import asyncio
import logging
from datetime import datetime

# Add the app directory to Python path
app_dir = os.path.join(os.path.dirname(__file__), 'app')
sys.path.insert(0, app_dir)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def test_basic_planner():
    """Test basic planner functionality without MongoDB."""
    try:
        logger.info("🧪 Testing basic PlannerAgent functionality...")
        
        # Check if environment variables are set
        from dotenv import load_dotenv
        load_dotenv()
        
        model = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:latest")
        if not model:
            logger.error("❌ OLLAMA_MODEL not configured")
            logger.info("Please create a .env file with your Ollama configuration")
            logger.info("Example: OLLAMA_MODEL=qwen2.5-coder:latest")
            return False
        
        logger.info(f"✅ Ollama model configured: {model}")
        
        # Import and test planner
        from core.planner import PlannerAgent
        
        # Create planner instance
        planner = PlannerAgent()
        logger.info("✅ PlannerAgent initialized successfully")
        
        # Create a mock planner that doesn't use MongoDB
        class TestPlanner(PlannerAgent):
            async def _store_project_plan(self, project_id: str, plan: dict):
                logger.info(f"✅ Mock storage: Plan for project {project_id} would be stored")
                logger.info(f"Plan has keys: {list(plan.keys())}")
                return True
        
        test_planner = TestPlanner()
        
        # Test data
        test_project = {
            "_id": "test_123",
            "title": "Test Web Application",
            "description": "A sample web application for testing the planner",
            "status": "planning",
            "team": ["developer1", "designer1"],
            "progress": 0,
            "tags": ["web", "test", "react"],
            "deadline": "2025-12-31"
        }
        
        logger.info("🚀 Generating project plan...")
        result = await test_planner.generate_project_plan(test_project)
        
        if "error" in result:
            logger.error(f"❌ Plan generation failed: {result['error']}")
            logger.error(f"Message: {result.get('message', 'No message')}")
            return False
        
        # Validate the result
        required_keys = ["summary", "key_features_deliverables", "major_milestones", "high_level_tasks"]
        missing_keys = [key for key in required_keys if key not in result]
        
        if missing_keys:
            logger.error(f"❌ Missing required keys in result: {missing_keys}")
            return False
        
        logger.info("✅ Project plan generated successfully!")
        logger.info(f"Summary: {result['summary'][:100]}...")
        logger.info(f"Features count: {len(result['key_features_deliverables'])}")
        logger.info(f"Milestones count: {len(result['major_milestones'])}")
        logger.info(f"Tasks count: {len(result['high_level_tasks'])}")
        
        return True
        
    except ImportError as e:
        logger.error(f"❌ Import error: {e}")
        logger.info("Make sure all dependencies are installed:")
        logger.info("pip install -r app/requirements.txt")
        return False
    except Exception as e:
        logger.error(f"❌ Test failed: {e}")
        return False

async def main():
    """Run the test."""
    logger.info("🎯 Starting PlannerAgent test...")
    
    success = await test_basic_planner()
    
    if success:
        logger.info("\n🎉 SUCCESS! The planner agent is working correctly.")
        logger.info("\nNext steps:")
        logger.info("1. Make sure MongoDB is running for full functionality")
        logger.info("2. Check your environment variables are properly configured")
        logger.info("3. Install any missing dependencies")
    else:
        logger.info("\n❌ FAILED! Check the error messages above.")
        logger.info("\nTroubleshooting:")
        logger.info("1. Install dependencies: pip install -r app/requirements.txt")
        logger.info("2. Ensure Ollama is running and OLLAMA_MODEL is set in .env")
        logger.info("3. Ensure the configured Ollama model is installed")

if __name__ == "__main__":
    asyncio.run(main())