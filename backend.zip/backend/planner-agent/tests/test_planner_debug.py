import asyncio
import os
import sys
from datetime import datetime
import logging
from dotenv import load_dotenv

# Add the app directory to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from core.planner import PlannerAgent
from core.mongodb import MongoDB

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def test_planner():
    """Test the planner agent functionality."""
    
    # Load environment variables
    load_dotenv()
    
    # Check the configured local Ollama model
    model = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:latest")
    if not model:
        logger.error("OLLAMA_MODEL not configured")
        logger.info("Please configure OLLAMA_MODEL in a .env file or environment variable")
        return False
    
    logger.info(f"Ollama model configured: {model}")
    
    try:
        # Initialize the planner agent
        logger.info("Initializing PlannerAgent...")
        planner = PlannerAgent()
        logger.info("PlannerAgent initialized successfully")
        
        # Test with minimal project details
        test_project = {
            "_id": "test_project_123",
            "title": "Test Project",
            "description": "A simple test project to verify the planner agent functionality",
            "status": "planning",
            "team": ["dev1", "dev2"],
            "progress": 0,
            "tags": ["test", "backend"],
            "deadline": "2025-12-01"
        }
        
        logger.info("Testing project plan generation...")
        
        # Try to generate a plan without MongoDB first
        try:
            # Test just the LLM part
            context = {
                "title": test_project.get("title", "Untitled Project"),
                "description": test_project.get("description", ""),
                "status": test_project.get("status", "planning"),
                "team_size": len(test_project.get("team", [])),
                "progress": test_project.get("progress", 0),
                "tags": ", ".join(test_project.get("tags", [])),
                "deadline": test_project.get("deadline", "Not specified")
            }
            
            # Just test the LLM chain without MongoDB storage
            from langchain_core.prompts import ChatPromptTemplate
            prompt_template = """You are PRAXIS, the official AI Support Agent, and a project planning assistant. You MUST respond with ONLY valid JSON - no other text before or after.

Project Details:
Title: {title}
Description: {description}
Status: {status}
Team Size: {team_size} members
Current Progress: {progress}%
Tags: {tags}
Deadline: {deadline}

Generate a project plan in this EXACT JSON structure:
{{
    "summary": "A comprehensive overview of the project",
    "key_features_deliverables": [
        "Feature 1",
        "Feature 2",
        "Feature 3"
    ],
    "major_milestones": [
        {{
            "name": "Milestone 1",
            "timeline": "Week 1-2"
        }}
    ],
    "high_level_tasks": [
        {{
            "task_name": "Task 1",
            "description": "Task description",
            "dependencies": [],
            "estimated_duration": "2 days"
        }}
    ]
}}

IMPORTANT:
1. Respond ONLY with valid JSON
2. Include 3-5 key features
3. Include 4-6 milestones
4. Include 5-8 tasks
5. NO placeholders - use real content based on the project details
6. NO text before or after the JSON
7. Ensure all JSON syntax is valid
"""
            
            plan_prompt = ChatPromptTemplate.from_template(prompt_template)
            chain = plan_prompt | planner.llm | planner.output_parser
            
            logger.info("Testing LLM chain...")
            response = await chain.ainvoke(context)
            logger.info(f"LLM Response received: {response}")
            
            # Try to parse the JSON
            import json
            try:
                plan_json = json.loads(response.strip())
                logger.info("✅ JSON parsing successful!")
                logger.info(f"Plan summary: {plan_json.get('summary', 'N/A')}")
                return True
            except json.JSONDecodeError as e:
                logger.error(f"❌ JSON parsing failed: {e}")
                logger.error(f"Raw response: {response}")
                return False
                
        except Exception as e:
            logger.error(f"❌ LLM chain test failed: {e}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Failed to initialize PlannerAgent: {e}")
        return False

async def test_with_mock_storage():
    """Test the full planner functionality with mocked storage."""
    try:
        # Mock the MongoDB storage method
        class MockPlannerAgent(PlannerAgent):
            async def _store_project_plan(self, project_id: str, plan: dict):
                logger.info(f"Mock storage: Would store plan for project {project_id}")
                logger.info(f"Plan keys: {list(plan.keys())}")
                return True
        
        planner = MockPlannerAgent()
        
        test_project = {
            "_id": "test_project_456",
            "title": "Mock Storage Test",
            "description": "Testing with mocked storage",
            "status": "planning",
            "team": ["dev1"],
            "progress": 0,
            "tags": ["test"],
            "deadline": "2025-12-01"
        }
        
        logger.info("Testing with mocked storage...")
        result = await planner.generate_project_plan(test_project)
        
        if "error" in result:
            logger.error(f"❌ Plan generation failed: {result['error']}")
            return False
        else:
            logger.info("✅ Plan generation successful with mocked storage!")
            return True
            
    except Exception as e:
        logger.error(f"❌ Mock storage test failed: {e}")
        return False

async def main():
    """Run all tests."""
    logger.info("🚀 Starting PlannerAgent debug tests...")
    
    # Test 1: Basic LLM functionality
    logger.info("\n📝 Test 1: Basic LLM functionality")
    test1_result = await test_planner()
    
    # Test 2: Full functionality with mocked storage
    logger.info("\n💾 Test 2: Full functionality with mocked storage")
    test2_result = await test_with_mock_storage()
    
    # Summary
    logger.info("\n📊 Test Results Summary:")
    logger.info(f"Basic LLM Test: {'✅ PASSED' if test1_result else '❌ FAILED'}")
    logger.info(f"Mocked Storage Test: {'✅ PASSED' if test2_result else '❌ FAILED'}")
    
    if test1_result and test2_result:
        logger.info("\n🎉 All tests passed! The planner should work correctly.")
        logger.info("If you're still getting errors, check:")
        logger.info("1. MongoDB connection (ensure MongoDB is running)")
        logger.info("2. Environment variables are properly loaded")
        logger.info("3. All dependencies are installed")
    else:
        logger.info("\n⚠️ Some tests failed. Check the logs above for details.")

if __name__ == "__main__":
    asyncio.run(main())