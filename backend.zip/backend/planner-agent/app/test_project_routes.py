import pytest
from fastapi.testclient import TestClient
from datetime import datetime, timedelta
from app.main import app
from app.core.mongodb import MongoDB
from bson import ObjectId
import asyncio

client = TestClient(app)

# Sample project data for testing
SAMPLE_PROJECT = {
    "title": "Test Project",
    "description": "A test project",
    "document": "Test document content",
    "status": "planning",
    "user": "test_user_123",
    "tags": ["test", "api"],
    "tasks": [],
    "progress": 0,
    "team": [],
    "sprints": [],
    "timeline": [],
    "resources": []
}

@pytest.fixture(autouse=True)
def setup_teardown():
    """Setup and teardown for each test."""
    # This would normally initialize your test database
    yield
    # Cleanup after each test


class TestProjectUpdate:
    """Test cases for PATCH /api/projects/{project_id}"""
    
    def test_update_single_field_title(self):
        """Test updating only the title field."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "title": "Updated Project Title"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == "Updated Project Title"
    
    def test_update_multiple_fields(self):
        """Test updating multiple valid fields at once."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "title": "New Title",
                "description": "New description",
                "status": "in-progress",
                "progress": 50.5
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == "New Title"
        assert data["description"] == "New description"
        assert data["status"] == "in-progress"
        assert data["progress"] == 50.5
    
    def test_update_with_deadline(self):
        """Test updating deadline field."""
        deadline = (datetime.now() + timedelta(days=30)).isoformat()
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "deadline": deadline
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert "deadline" in data
    
    def test_update_with_tags(self):
        """Test updating tags list."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "tags": ["urgent", "backend", "feature"]
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["tags"] == ["urgent", "backend", "feature"]
    
    def test_update_with_team_members(self):
        """Test updating team members."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "team": [
                    {
                        "name": "John Doe",
                        "avatar": "https://example.com/avatar1.jpg"
                    },
                    {
                        "name": "Jane Smith",
                        "avatar": "https://example.com/avatar2.jpg"
                    }
                ]
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data["team"]) == 2
        assert data["team"][0]["name"] == "John Doe"
    
    def test_update_with_sprints(self):
        """Test updating sprints."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "sprints": [
                    {
                        "name": "Sprint 1",
                        "progress": 100,
                        "status": "completed"
                    },
                    {
                        "name": "Sprint 2",
                        "progress": 50,
                        "status": "in-progress"
                    }
                ]
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data["sprints"]) == 2
    
    def test_update_with_timeline_events(self):
        """Test updating timeline events."""
        event_date = datetime.now().isoformat()
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "timeline": [
                    {
                        "title": "Project Kickoff",
                        "description": "Initial project kickoff meeting",
                        "type": "milestone",
                        "date": event_date
                    }
                ]
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data["timeline"]) == 1
    
    def test_update_with_resources(self):
        """Test updating resources."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "resources": [
                    {
                        "profile": "senior_developer",
                        "skills": ["Python", "FastAPI", "MongoDB"],
                        "experience": "10 years",
                        "description": "Full-stack developer",
                        "type": "engineer",
                        "username": "john_dev"
                    }
                ]
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert len(data["resources"]) == 1
    
    def test_update_with_unknown_fields_only(self):
        """Test PATCH with only unknown fields (should return current project with warning)."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "additionalProp1": "some value",
                "unknown_field": "another value"
            }
        )
        # Should now return 200 instead of 400
        assert response.status_code == 200
        data = response.json()
        # Should contain the existing project data
        assert "_id" in data
    
    def test_update_with_mixed_valid_and_unknown_fields(self):
        """Test PATCH with both valid and unknown fields (unknown should be ignored)."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "title": "Updated Title",
                "description": "Updated Description",
                "additionalProp1": "ignored",
                "customField": "also ignored"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["title"] == "Updated Title"
        assert data["description"] == "Updated Description"
        # Unknown fields should not be in response
        assert "additionalProp1" not in data
        assert "customField" not in data
    
    def test_update_invalid_project_id_format(self):
        """Test PATCH with invalid ObjectId format."""
        response = client.patch(
            "/api/projects/not_a_valid_id",
            json={"title": "New Title"}
        )
        assert response.status_code == 400
        assert "Invalid project ID" in response.json()["detail"]
    
    def test_update_nonexistent_project(self):
        """Test PATCH on non-existent project ID."""
        # Using a valid ObjectId format but for non-existent project
        valid_fake_id = str(ObjectId())
        response = client.patch(
            f"/api/projects/{valid_fake_id}",
            json={"title": "New Title"}
        )
        assert response.status_code == 404
        assert "Project not found" in response.json()["detail"]
    
    def test_update_empty_request_body(self):
        """Test PATCH with empty request body."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={}
        )
        # Should return 200 with current project (no changes)
        assert response.status_code == 200
        data = response.json()
        assert "_id" in data
    
    def test_update_progress_to_100(self):
        """Test updating progress to completion."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "progress": 100,
                "status": "completed"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["progress"] == 100
        assert data["status"] == "completed"
    
    def test_update_status_transitions(self):
        """Test various status transitions."""
        statuses = ["planning", "in-progress", "on-hold", "completed"]
        
        for status in statuses:
            response = client.patch(
                "/api/projects/685e7198fcb93bc195b76ecf",
                json={"status": status}
            )
            assert response.status_code == 200
            assert response.json()["status"] == status
    
    def test_update_clear_tags(self):
        """Test clearing tags by passing empty list."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={
                "tags": []
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["tags"] == []
    
    def test_response_contains_objectid_as_string(self):
        """Test that ObjectId in response is returned as string, not object."""
        response = client.patch(
            "/api/projects/685e7198fcb93bc195b76ecf",
            json={"title": "Test"}
        )
        assert response.status_code == 200
        data = response.json()
        # _id should be a string
        assert isinstance(data["_id"], str)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
