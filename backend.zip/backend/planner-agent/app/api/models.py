from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import List, Optional, Dict, Any, Annotated, Literal
from datetime import datetime
from bson import ObjectId
import json

# For Pydantic v2, we don't need a custom PyObjectId class
# Just use str type with validation

class Resource(BaseModel):
    profile: str
    skills: List[str]
    experience: str
    description: str
    type: str
    avatar: Optional[str] = None
    username: Optional[str] = None
    name: Optional[str] = None
    user: Optional[str] = None
    
    model_config = ConfigDict(
        json_encoders={ObjectId: str},
        ser_json_timedelta='float'
    )

class Sprint(BaseModel):
    name: str
    progress: float
    status: str

class TimelineEvent(BaseModel):
    title: str
    description: str
    type: str
    date: datetime

class TeamMember(BaseModel):
    user: str
    role: str
    
    model_config = ConfigDict(
        json_encoders={ObjectId: str}
    )


class FrontendTeamMember(BaseModel):
    """Optional frontend-oriented team member fields.

    Stored for backward compatibility with existing UI that reads `team_members`.
    Backend source-of-truth remains `team`.
    """

    name: Optional[str] = None
    avatar: Optional[str] = None
    image_url: Optional[str] = None
    profile_picture: Optional[str] = None
    email: Optional[str] = None
    role: Optional[str] = None
    user: Optional[str] = None
    username: Optional[str] = None

    model_config = ConfigDict(
        extra='ignore',
        json_encoders={ObjectId: str}
    )

class ProjectCreate(BaseModel):
    title: str
    description: str
    deadline: Optional[datetime] = None
    tags: List[str] = Field(default_factory=list)
    document: str
    created_by: str = Field(description="User identifier who created the project")
    companyId: Optional[str] = Field(default=None, description="Company identifier that owns the project")
    user: Optional[str] = Field(default=None, description="User identifier (alias for created_by)")
    status: str = Field(default="planning")
    tasks: List[str] = Field(default_factory=list)
    progress: float = Field(default=0)
    team: List[TeamMember] = Field(default_factory=list)
    sprints: List[Sprint] = Field(default_factory=list)
    timeline: List[TimelineEvent] = Field(default_factory=list)
    resources: List[Resource] = Field(default_factory=list)

class Milestone(BaseModel):
    name: str
    timeline: str
    deliverables: List[str] = Field(default_factory=list)

class Task(BaseModel):
    task_name: str
    description: str
    dependencies: List[str]
    due_date: Optional[str] = None

class SubTask(BaseModel):
    name: str
    description: str
    effort: str
    technical_requirements: List[str]
    due_date: Optional[str] = None

class RefinedTask(Task):
    sub_tasks: List[SubTask]

class ProjectUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    deadline: Optional[datetime] = None
    tags: Optional[List[str]] = None
    document: Optional[str] = None
    companyId: Optional[str] = None
    status: Optional[str] = None
    tasks: Optional[List[str]] = None
    progress: Optional[float] = None
    team: Optional[List[TeamMember]] = None
    team_members: Optional[List[FrontendTeamMember]] = None
    sprints: Optional[List[Sprint]] = None
    timeline: Optional[List[TimelineEvent]] = None
    resources: Optional[List[Resource]] = None
    github_repository: Optional[str] = None
    
    model_config = ConfigDict(
        extra='ignore',
        json_encoders={ObjectId: str}
    )

class GeneratePlanRequest(BaseModel):
    planning_depth: str = Field(default="medium", description="Planning depth: high | medium | low")
    include_risk_analysis: bool = Field(default=False, description="Whether to include risk analysis")

class PlanHighLevelTask(BaseModel):
    task_name: str
    description: str
    dependencies: List[str] = Field(default_factory=list)
    estimated_duration: Optional[str] = None
    due_date: Optional[str] = Field(default=None, description="The expected due date for this task in YYYY-MM-DD format")

class PlanMilestone(BaseModel):
    name: str
    timeline: str
    deliverables: List[str] = Field(default_factory=list)

class ProjectPlanResponse(BaseModel):
    project_id: str
    summary: str
    skills_required: List[str] = Field(default_factory=list)
    milestones: List[PlanMilestone] = Field(default_factory=list)
    high_level_tasks: List[PlanHighLevelTask] = Field(default_factory=list)
    risk_factors: List[str] = Field(default_factory=list)
    generated_by: str = Field(description="AI service that generated the plan")
    generated_at: datetime


# Standardized Response Wrappers
class AIOperationResponse(BaseModel):
    """Standardized wrapper for all AI operations (plan generation, task refinement)"""
    ai_used: bool = Field(description="True if AI generated, False if fallback")
    source: Literal["ollama", "ollama_fallback", "deterministic_fallback"] = Field(
        description="Which source generated this response"
    )
    model: Optional[str] = Field(description="Which model was used (if applicable)")
    data: Dict[str, Any] = Field(description="Actual response data")
    generated_at: datetime
    execution_time_ms: Optional[int] = Field(default=None, description="Total execution time")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional metadata (retry_count, llm_error, etc.)"
    )

    model_config = ConfigDict(json_encoders={ObjectId: str})


class PlanGenerationResponse(AIOperationResponse):
    """Standardized response for plan generation with plan-specific data"""
    pass


class TaskRefinementResponse(AIOperationResponse):
    """Standardized response for task refinement with refinement-specific data"""
    pass