from fastapi import APIRouter, HTTPException, Depends, Body, Request
from typing import Dict, Any, List, Optional
from pydantic import ValidationError
from core.planner import PlannerAgent
from core.mongodb import MongoDB
from api.models import ProjectCreate, ProjectUpdate, GeneratePlanRequest, ProjectPlanResponse
import os
import logging
import re
from bson import ObjectId
from bson.errors import InvalidId
from datetime import datetime
from jose import JWTError, jwt


from bson import ObjectId
from bson.errors import InvalidId

def convert_objectids(data: Any) -> Any:
    """
    Recursively traverses a dict or list to convert all ObjectId instances to strings.
    """
    if isinstance(data, dict):
        return {key: convert_objectids(value) for key, value in data.items()}
    if isinstance(data, list):
        return [convert_objectids(item) for item in data]
    if isinstance(data, ObjectId):
        return str(data)
    return data

def normalize_project(project: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize project data to match frontend expectations.
    Maps backend field names to frontend field names.
    - Converts all ObjectIds to strings
    - Maps created_by → user
    - Maps created_at → created_at, updated_at → updated_at
    - Ensures all frontend-expected fields exist
    """
    converted = convert_objectids(project)
    
    # Ensure user field is set (map from created_by if needed)
    if "created_by" in converted and "user" not in converted:
        converted["user"] = converted["created_by"]
    if "companyId" not in converted and "company_id" in converted:
        converted["companyId"] = converted["company_id"]
    
    # Map datetime fields to camelCase for frontend compatibility
    if "created_at" in converted and "created_at" not in converted:
        converted["created_at"] = converted["created_at"]
    if "updated_at" in converted and "updated_at" not in converted:
        converted["updated_at"] = converted["updated_at"]
    if "githubRepository" in converted and "github_repository" not in converted:
        converted["github_repository"] = converted["githubRepository"]
    
    return converted

async def _generate_ai_tags(title: str, description: str, document: str) -> List[str]:
    """Generate AI tags for a project using the local Ollama model."""

    def keyword_fallback() -> List[str]:
        keywords = set()
        for word in f"{title} {description}".lower().split():
            cleaned = word.strip('.,!?;:()[]{}\'"')
            if len(cleaned) > 4:
                keywords.add(cleaned)
        return sorted(keywords)[:5]

    try:
        planner = PlannerAgent.get_instance()
        tags = await planner.ollama.generate_json_completion(
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are PRAXIS, the official AI Support Agent. "
                        "Return ONLY a JSON array of 3-5 short, relevant project tags."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Project title: {title}\n"
                        f"Description: {description[:500]}\n"
                        f"Document excerpt: {document[:500]}"
                    ),
                },
            ],
            temperature=0.2,
            max_tokens=200,
        )
        if isinstance(tags, dict):
            tags = tags.get("tags") or tags.get("keywords") or []
        if isinstance(tags, list):
            cleaned_tags = [str(tag).strip() for tag in tags if str(tag).strip()]
            if cleaned_tags:
                return cleaned_tags[:5]
    except Exception as e:
        logger.warning(f"Error generating AI tags: {e}")

    return keyword_fallback()


logger = logging.getLogger(__name__)

# Lazy-load JWT_SECRET so the module can be imported without the env var set.
# A clear error is raised on first JWT operation if it's missing.
_JWT_SECRET: Optional[str] = None

def _get_jwt_secret() -> str:
    global _JWT_SECRET
    if _JWT_SECRET is None:
        key = os.getenv("JWT_SECRET_KEY") or os.getenv("JWT_SECRET")
        if not key:
            raise ValueError(
                "JWT_SECRET_KEY environment variable is not set. "
                "Set it in your .env file or export it before starting the service."
            )
        _JWT_SECRET = key
    return _JWT_SECRET

JWT_ALGORITHM = "HS256"

COMPANY_PROJECT_WRITE_ROLES = {"owner", "admin"}
COMPANY_SUBROLES = {"owner", "admin", "manager", "trainee"}
LEGACY_SUBROLE_MAP = {"super" + "admin": "admin"}
LEGACY_SUBROLE_MAP.update(
    {
        "super_owner": "owner",
        "super-owner": "owner",
        "super owner": "owner",
        "superowner": "owner",
    }
)


def verify_session_token(token: str) -> Optional[Dict[str, Any]]:
    try:
        payload = jwt.decode(token, _get_jwt_secret(), algorithms=[JWT_ALGORITHM])
        return payload if isinstance(payload, dict) else None
    except JWTError:
        return None


def normalize_company_subrole(value: Any) -> str:
    raw = str(value or "").strip().lower()
    if raw in COMPANY_SUBROLES:
        return raw
    return LEGACY_SUBROLE_MAP.get(raw, "trainee")


async def get_authenticated_payload(request: Request) -> Dict[str, Any]:
    token = request.cookies.get("aipm_token")
    token_source = "cookie"
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.lower().startswith("bearer "):
            token = auth_header[7:].strip()
            token_source = "Authorization header"

    if not token:
        # Some upstream proxies forward auth tokens using custom headers.
        forwarded = (
            request.headers.get("x-access-token")
            or request.headers.get("x-auth-token")
            or request.headers.get("x-jwt-token")
            or ""
        )
        token = forwarded.strip() or None
        if token:
            token_source = "custom header"

    if not token:
        logger.warning(
            "Auth: no token found in cookie, Authorization header, or custom headers. "
            "Cookie keys: %s, Auth header present: %s, Custom headers present: %s",
            list(request.cookies.keys()),
            bool(request.headers.get("Authorization")),
            bool(
                request.headers.get("x-access-token")
                or request.headers.get("x-auth-token")
                or request.headers.get("x-jwt-token")
            ),
        )
        raise HTTPException(status_code=401, detail="Unauthorized")

    payload = verify_session_token(token)
    if payload is None:
        logger.warning(
            "Auth: token from %s failed verification (token prefix: %s...)",
            token_source,
            token[:20] if len(token) > 20 else token,
        )
        raise HTTPException(status_code=401, detail="Unauthorized")

    # Accept both standard 'sub' claim and legacy 'id' claim for compatibility.
    # The support-agent creates JWTs with 'sub'; Next.js session fallback JWTs use 'id'.
    user_id = payload.get("id") or payload.get("sub")
    if not user_id:
        logger.warning(
            "Auth: token from %s has no 'id' or 'sub' claim (keys: %s)",
            token_source,
            list(payload.keys()),
        )
        raise HTTPException(status_code=401, detail="Unauthorized")

    # Ensure 'id' is populated for downstream consumers that expect it.
    if "id" not in payload and "sub" in payload:
        payload["id"] = payload["sub"]

    logger.debug("Auth: token verified from %s for user id=%s", token_source, user_id)
    return payload


async def get_user_role(user_id: str) -> Optional[str]:
    if MongoDB.db is None:
        raise HTTPException(status_code=500, detail="Database connection not initialized")

    if not ObjectId.is_valid(user_id):
        return None

    user = await MongoDB.db.users.find_one(
        {"_id": ObjectId(user_id)},
        {"role": 1},
    )
    if not user:
        return None

    role = user.get("role")
    return str(role).strip().lower() if role else None


async def get_company_member_role(company_id: str, email: Optional[str]) -> Optional[str]:
    if MongoDB.db is None:
        raise HTTPException(status_code=500, detail="Database connection not initialized")

    if not email or not ObjectId.is_valid(company_id):
        return None

    company = await MongoDB.db.users.find_one({"_id": ObjectId(company_id)})
    if not company or str(company.get("role") or "").strip().lower() != "company":
        return None

    members = company.get("members") or []
    normalized_email = str(email).strip().lower()
    for member in members:
        if (
            str(member.get("email") or "").strip().lower() == normalized_email
            and str(member.get("status") or "").strip().lower() == "active"
        ):
            return normalize_company_subrole(member.get("subrole"))

    return None


async def get_active_company_membership(
    email: Optional[str], preferred_company_id: Optional[str] = None
) -> Optional[Dict[str, str]]:
    if MongoDB.db is None:
        raise HTTPException(status_code=500, detail="Database connection not initialized")

    if not email:
        return None

    normalized_email = str(email).strip().lower()
    escaped_email = re.escape(normalized_email)

    query: Dict[str, Any] = {
        "role": "company",
        "members": {
            "$elemMatch": {
                "email": {"$regex": f"^{escaped_email}$", "$options": "i"},
                "status": "active",
            }
        },
    }

    if preferred_company_id and ObjectId.is_valid(preferred_company_id):
        query["_id"] = ObjectId(preferred_company_id)

    company = await MongoDB.db.users.find_one(
        query,
        {"_id": 1, "members": 1},
    )

    if not company:
        return None

    members = company.get("members") or []
    member_role = None
    for member in members:
        if (
            str(member.get("email") or "").strip().lower() == normalized_email
            and str(member.get("status") or "").strip().lower() == "active"
        ):
            member_role = normalize_company_subrole(member.get("subrole"))
            break

    if not member_role:
        return None

    return {
        "company_id": str(company["_id"]),
        "member_role": member_role,
    }


def get_project_owner_identifier(project: Dict[str, Any]) -> Optional[str]:
    owner_value = (
        project.get("companyId")
        or project.get("company_id")
        or project.get("created_by")
        or project.get("user")
    )
    if owner_value is None:
        return None

    owner_id = str(owner_value).strip()
    return owner_id or None


async def resolve_project_ownership(project: Dict[str, Any]) -> Dict[str, Optional[str]]:
    owner_id = get_project_owner_identifier(project)
    if not owner_id:
        return {"owner_id": None, "owner_role": None}

    if project.get("companyId") or project.get("company_id"):
        return {"owner_id": owner_id, "owner_role": "company"}

    owner_role = await get_user_role(owner_id)
    return {"owner_id": owner_id, "owner_role": owner_role}


async def assert_project_write_access(request: Request, project: Dict[str, Any]) -> Dict[str, Any]:
    payload = await get_authenticated_payload(request)
    ownership = await resolve_project_ownership(project)
    owner_id = ownership.get("owner_id")
    owner_role = ownership.get("owner_role")

    if not owner_id:
        return payload

    if owner_role == "company":
        member_role = await get_company_member_role(owner_id, payload.get("email"))
        if member_role not in COMPANY_PROJECT_WRITE_ROLES:
            raise HTTPException(status_code=403, detail="Forbidden")

        return payload

    if str(payload.get("id")) != owner_id:
        raise HTTPException(status_code=403, detail="Forbidden")

    return payload

router = APIRouter()

@router.post("/projects", response_model=Dict[str, Any])
async def create_project(project: ProjectCreate, request: Request) -> Dict[str, Any]:
    """Create a new project and return complete project data."""
    try:
        logger.info(f"Creating new project: {project.title}")
        payload = await get_authenticated_payload(request)
        # Convert the Pydantic model to dict
        project_data = project.dict(exclude_unset=True)

        creator_id = str(project_data.get("created_by") or project_data.get("user") or "").strip()
        if not creator_id:
            raise HTTPException(status_code=400, detail="Creator information is required")

        if str(payload.get("id")) != creator_id:
            raise HTTPException(status_code=403, detail="Forbidden")
        
        # If 'user' field is provided but not 'created_by', use it
        if "user" in project_data and project_data["user"]:
            if "created_by" not in project_data or not project_data["created_by"]:
                project_data["created_by"] = project_data["user"]

        company_id = str(project_data.get("companyId") or "").strip() or None
        creator_role = await get_user_role(creator_id)
        membership_context = await get_active_company_membership(
            payload.get("email"),
            company_id,
        ) if company_id else None

        # If no explicit companyId is provided but creator is an active company member,
        # attach ownership to that company workspace.
        if not membership_context and creator_role != "company":
            membership_context = await get_active_company_membership(payload.get("email"))

        company_owned = creator_role == "company" or membership_context is not None

        if company_owned:
            if membership_context:
                company_owner_id = membership_context["company_id"]
                member_role = membership_context["member_role"]
            else:
                company_owner_id = creator_id
                member_role = await get_company_member_role(
                    company_owner_id,
                    payload.get("email"),
                )

            if member_role not in COMPANY_PROJECT_WRITE_ROLES:
                raise HTTPException(status_code=403, detail="Forbidden")

            project_data["companyId"] = company_owner_id
            project_data["user"] = company_owner_id
            # Keep actual creator for auditing while companyId remains source of ownership.
            project_data["created_by"] = creator_id
        else:
            project_data["companyId"] = None
            project_data["user"] = creator_id
            project_data["created_by"] = creator_id
        
        # Generate AI tags based on description and document
        ai_tags = await _generate_ai_tags(project.title, project.description, project.document)
        project_data["ai_generated_tags"] = ai_tags
        
        # Explicitly initialize github_repository as None to avoid showing 'View Repository'
        project_data["github_repository"] = None
        
        # Create the project
        created_project = await MongoDB.create_project(project_data)
        logger.info(f"Successfully created project with ID: {created_project['_id']}")
        
        # Normalize and return the COMPLETE project
        normalized = normalize_project(created_project)
        
        # Ensure _id and project_id are both set
        if "_id" in normalized:
            normalized["project_id"] = normalized["_id"]
        
        logger.debug(f"Returning complete normalized project with {len(normalized)} fields")
        return normalized
    except HTTPException as http_exc:
        if http_exc.status_code == 401:
            logger.warning(
                "create_project 401: request from %s, auth header present: %s, cookie keys: %s",
                request.client.host if request.client else "unknown",
                bool(request.headers.get("Authorization")),
                list(request.cookies.keys()),
            )
        raise
    except Exception as e:
        logger.error(f"Error creating project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/projects", response_model=List[Dict[str, Any]])
async def list_projects(include_deleted: bool = False):
    """List all projects from the database."""
    try:
        logger.info("Attempting to fetch projects from database")
        if MongoDB.db is None :
            logger.error("MongoDB connection not initialized")
            raise HTTPException(status_code=500, detail="Database connection not initialized")
        
        projects = []
        logger.info("Starting database query...")
        query = {} if include_deleted else {"status": {"$ne": "deleted"}}
        async for project in MongoDB.db.projects.find(query):
            logger.debug(f"Found project with ID: {project.get('_id')}")
            
            # Normalize project: convert ObjectIds and map fields for frontend
            normalized_project = normalize_project(project)
            
            # Check if project has a plan using the converted string ID
            has_plan = await MongoDB.db.project_plans.find_one({
                "project_id": normalized_project["_id"] 
            }) is not None
            
            # Add plan status to project
            normalized_project["has_plan"] = has_plan
            projects.append(normalized_project)
        
        logger.info(f"Found {len(projects)} projects in database")
        logger.debug(f"First project sample (if any): {projects[0] if projects else 'no projects'}")
        return projects
    except Exception as e:
        logger.error(f"Error listing projects: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/projects/{project_id}", response_model=Dict[str, Any])
async def get_project(project_id: str, include_deleted: bool = False) -> Dict[str, Any]:
    """Get a specific project by its ID."""
    try:
        logger.info(f"Fetching project with ID: {project_id}")
        
        # Check if the database is connected
        if MongoDB.db is None:
            logger.error("MongoDB connection not initialized")
            raise HTTPException(status_code=500, detail="Database connection not initialized")
        
        # Convert string ID to MongoDB ObjectId
        try:
            obj_id = ObjectId(project_id)
        except InvalidId:
            logger.error(f"Invalid ObjectId format: {project_id}")
            raise HTTPException(status_code=400, detail="Invalid project ID format")

        # Get project from MongoDB
        project = await MongoDB.db.projects.find_one({"_id": obj_id})

        if not project or (not include_deleted and project.get("status") == "deleted"):
            logger.error(f"Project not found with ID: {project_id}")
            raise HTTPException(status_code=404, detail="Project not found")

        # Normalize project: convert ObjectIds and map fields for frontend
        converted_project = normalize_project(project)
        
        # Check if project has a plan
        has_plan = await MongoDB.db.project_plans.find_one({
            "project_id": converted_project["_id"]
        }) is not None
        
        # Add plan status to project
        converted_project["has_plan"] = has_plan

        # Synchronize team/team_members: Filter out deleted user accounts
        team = converted_project.get("team", [])
        team_members = converted_project.get("team_members", [])
        
        if team or team_members:
            # Extract user IDs from both lists to check for existence
            user_id_strs = set()
            for t in team:
                if t.get("user"): user_id_strs.add(str(t["user"]))
            for tm in team_members:
                if tm.get("user"): user_id_strs.add(str(tm["user"]))
            
            # Identify valid ObjectIds for database lookup
            valid_object_ids = []
            for uid_str in user_id_strs:
                if len(uid_str) == 24: # Basic check for ObjectId string length
                    try:
                        valid_object_ids.append(ObjectId(uid_str))
                    except:
                        pass
            
            if valid_object_ids:
                # Find all existing users in the users collection
                existing_users_cursor = MongoDB.db.users.find(
                    {"_id": {"$in": valid_object_ids}},
                    {"_id": 1}
                )
                existing_users = await existing_users_cursor.to_list(length=None)
                existing_user_ids = {str(u["_id"]) for u in existing_users}
                
                # Filter team list
                if team:
                    converted_project["team"] = [
                        t for t in team 
                        if not t.get("user") or str(t["user"]) in existing_user_ids or len(str(t["user"])) != 24
                    ]
                
                # Filter team_members snapshot list
                if team_members:
                    converted_project["team_members"] = [
                        tm for tm in team_members 
                        if not tm.get("user") or str(tm["user"]) in existing_user_ids or len(str(tm["user"])) != 24
                    ]

        logger.info(f"Successfully retrieved and synchronized project: {project_id}")
        return converted_project

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/projects/{project_id}/description", response_model=Dict[str, Any])
async def get_project_description(project_id: str) -> Dict[str, Any]:
    """Get the description of a specific project by its ID."""
    try:
        # --- FIX: Check if the database is connected ---
        if MongoDB.db is None:
            logger.error("MongoDB connection not initialized")
            raise HTTPException(status_code=500, detail="Database connection not initialized")
        
        # Convert string ID to MongoDB ObjectId
        try:
            obj_id = ObjectId(project_id)
        except InvalidId:
            logger.error(f"Invalid ObjectId format: {project_id}")
            raise HTTPException(status_code=400, detail="Invalid project ID format")

        # Get project from MongoDB
        project = await MongoDB.db.projects.find_one(
            {"_id": obj_id},
            {"description": 1, "title": 1}  # Only retrieve description and title fields
        )

        if not project:
            logger.error(f"Project not found with ID: {project_id}")
            raise HTTPException(status_code=404, detail="Project not found")

        return {
            "id": str(project["_id"]),
            "title": project.get("title", "Untitled Project"),
            "description": project.get("description", "No description available")
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving project description: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
# @router.get("/projects", response_model=List[Dict[str, Any]])
# async def list_projects():
#     """List all projects from the database."""
#     try:
#         logger.info("Attempting to fetch projects from database")
#         if  MongoDB.db is None :
#             logger.error("MongoDB connection not initialized")
#             raise HTTPException(status_code=500, detail="Database connection not initialized")
#         # Fetch all projects from MongoDB
#         projects = []
#         logger.info("Starting database query...")
#         async for project in MongoDB.db.projects.find():
#             logger.debug(f"Found project with ID: {project.get('_id')}")
#             # Convert ObjectId to string
#             project_id = str(project["_id"])
#             project["_id"] = project_id
            
#             # Check if project has a plan using the ObjectId
#             has_plan = await MongoDB.db.project_plans.find_one({
#                 "project_id": project_id
#             }) is not None
            
#             # Add plan status to project
#             project["has_plan"] = has_plan
#             projects.append(project)
        
#         logger.info(f"Found {len(projects)} projects in database")
#         return projects
#     except Exception as e:
#         logger.error(f"Error listing projects: {str(e)}")
#         raise HTTPException(status_code=500, detail=str(e))

async def get_planner_agent() -> PlannerAgent:
    """Dependency to get PlannerAgent singleton instance."""
    try:
        return PlannerAgent.get_instance()
    except ValueError as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail="Failed to initialize the local Ollama planner configuration"
        )

@router.post("/projects/{project_id}/plan", response_model=Dict[str, Any])
async def generate_plan_for_existing_project(
    project_id: str,
    request: Request,
    plan_request: GeneratePlanRequest = Body(default_factory=GeneratePlanRequest),
    planner: PlannerAgent = Depends(get_planner_agent),
) -> Dict[str, Any]:
    """Generate a project plan for an existing project in the database."""
    try:
        if MongoDB.db is None:
            logger.error("MongoDB connection not initialized")
            raise HTTPException(status_code=500, detail="Database connection not initialized")
        # Convert string ID to MongoDB ObjectId
        try:
            obj_id = ObjectId(project_id)
        except InvalidId:
            logger.error(f"Invalid ObjectId format: {project_id}")
            raise HTTPException(status_code=400, detail="Invalid project ID format")

        # Get existing plan if it exists
        existing_plan = await MongoDB.db.project_plans.find_one({"project_id": project_id})
        if existing_plan:
            logger.info(f"Found existing plan for project: {project_id}")
            # Convert _id to str instead of deleting
            if "_id" in existing_plan:
                existing_plan["_id"] = str(existing_plan["_id"])
            return convert_objectids(existing_plan)

        # Get project data if it exists
        project = await MongoDB.db.projects.find_one({"_id": obj_id})
        if project:
            await assert_project_write_access(request, project)
        
        # Create a minimal project context even if no data is found
        project_context = {
            "_id": project_id,
            "title": project.get("title", "Untitled Project"),
            "description": project.get("description", "Project details not available"),
            "status": project.get("status", "planning"),
            "tags": project.get("tags", []),
            "team": project.get("team", []),
            "deadline": project.get("deadline", None),
            "resources": project.get("resources", []),
            "progress": project.get("progress", 0),
            "planning_depth": plan_request.planning_depth,
            "include_risk_analysis": plan_request.include_risk_analysis
        } if project else {
            "_id": project_id,
            "title": "Untitled Project",
            "description": "Project details to be determined",
            "status": "planning",
            "tags": [],
            "team": [],
            "progress": 0,
            "planning_depth": plan_request.planning_depth,
            "include_risk_analysis": plan_request.include_risk_analysis
        }

        # Generate new plan using whatever context we have
        plan = await planner.generate_project_plan(project_context)
        
        if "error" in plan:
            error_type = plan.get("error")
            error_message = plan.get("message", "Failed to generate plan")
            
            # Handle rate limit errors specifically
            if error_type == "rate_limit_exceeded":
                logger.warning(f"Rate limit exceeded for project {project_id}")
                raise HTTPException(
                    status_code=429, 
                    detail={
                        "error": "rate_limit_exceeded",
                        "message": error_message,
                        "retry_after": plan.get("retry_after", "60 seconds")
                    }
                )
            else:
                logger.error(f"Plan generation error: {error_type}")
                raise HTTPException(status_code=500, detail=error_message)
        
        # Check if this is a fallback plan and log appropriately
        if plan.get("generated_by") == "fallback_generator":
            logger.info(f"Using fallback plan for project {project_id} due to API limitations")
        
        # Basic validation of plan structure
        if not isinstance(plan, dict):
            raise HTTPException(status_code=500, detail="Invalid plan format generated")
        
        # Ensure minimum plan structure with spec-compliant fields
        plan = {
            "project_id": project_id,
            "summary": plan.get("summary", "Project summary to be determined"),
            "skills_required": plan.get("skills_required", []),
            "milestones": plan.get("major_milestones", []),
            "high_level_tasks": plan.get("high_level_tasks", []),
            "risk_factors": plan.get("risk_factors", []) if plan_request.include_risk_analysis else [],
            "generated_by": plan.get("generated_by", "ollama"),
            "generated_at": datetime.utcnow()
        }
        
        # Store the plan
        await MongoDB.store_project_plan(project_id, plan)
        logger.info(f"Successfully generated and stored plan for project: {project_id}")
        
        return convert_objectids(plan)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating plan for project {project_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))



@router.post("/refine-tasks/{project_id}", response_model=Dict[str, Any])
async def refine_project_tasks(
    project_id: str,
    request: Request,
    planner: PlannerAgent = Depends(get_planner_agent),
) -> Dict[str, Any]:
    """Refine the tasks in an existing project plan."""
    try:
        logger.info(f"Looking up project plan with ID: {project_id}")
        
        if MongoDB.db is None:
            logger.error("MongoDB connection not initialized")
            raise HTTPException(status_code=500, detail="Database connection not initialized")
        
        try:
            obj_id = ObjectId(project_id)
        except InvalidId:
            logger.error(f"Invalid ObjectId format: {project_id}")
            raise HTTPException(status_code=400, detail="Invalid project ID format")

        # First check if the project exists
        project = await MongoDB.db.projects.find_one({"_id": obj_id})
        if not project:
            raise HTTPException(
                status_code=404,
                detail=f"No project found with ID: {project_id}. Please create a project first."
            )

        await assert_project_write_access(request, project)
        
        # Get the existing plan from MongoDB
        existing_plan = await MongoDB.db.project_plans.find_one({"project_id": project_id})
        
        # Get high-level tasks to refine
        if existing_plan and "high_level_tasks" in existing_plan:
            tasks_to_refine = existing_plan["high_level_tasks"]
        else:
            tasks_to_refine = [
                {
                    "task_name": "Project Setup",
                    "description": f"Initial setup for {project.get('title', 'the project')}",
                    "dependencies": []
                }
            ]
        
        # Refine the tasks
        refined_plan = await planner.refine_project_tasks(project_id, tasks_to_refine)
        
        if "error" in refined_plan and "refined_tasks" not in refined_plan:
            error_message = refined_plan.get('message', 'Failed to refine tasks')
            logger.error(f"Complete task refinement failure: {error_message}")
            raise HTTPException(status_code=500, detail=error_message)
        
        # Check if this was a fallback result
        if refined_plan.get("status") == "fallback":
            logger.warning(f"Task refinement used fallback for project {project_id}")

        # --- FIX: MERGE AND SAVE TO DATABASE ---
        # 1. If existing_plan exists, we merge the new tasks into it so we don't lose other fields (like summary)
        # 2. If it doesn't exist, we use the refined_plan as is.
        if existing_plan:
            # Assuming refined_plan returns a dict with "high_level_tasks" or "refined_tasks"
            # Adjust the key below based on exactly what your PlannerAgent returns
            updated_tasks = refined_plan.get("refined_tasks") or refined_plan.get("high_level_tasks")
            
            if updated_tasks:
                existing_plan["high_level_tasks"] = updated_tasks
                # Store the updated existing plan
                await MongoDB.store_project_plan(project_id, existing_plan)
                logger.info(f"Successfully updated and saved plan for project: {project_id}")
                return convert_objectids(existing_plan)
            else:
                # If structure is different, just save the refined_plan directly
                await MongoDB.store_project_plan(project_id, refined_plan)
        else:
            # No existing plan, save the new one
            await MongoDB.store_project_plan(project_id, refined_plan)
        # --- END OF FIX ---

        logger.info(f"Successfully refined and saved tasks for project: {project_id}")
        return convert_objectids(refined_plan)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error refining tasks for project {project_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.patch("/projects/{project_id}", response_model=Dict[str, Any])
async def update_project_details(
    project_id: str,
    request: Request,
    update: Dict[str, Any] = Body(...),
) -> Dict[str, Any]:
    """Update details of an existing project."""
    try:
        if MongoDB.db is None:
            raise HTTPException(status_code=500, detail="Database connection not initialized")

        current_project = await MongoDB.db.projects.find_one({"_id": ObjectId(project_id)})
        if not current_project:
            raise HTTPException(status_code=404, detail="Project not found")

        payload = await assert_project_write_access(request, current_project)

        # For PATCH, accept partial updates and avoid strict nested validation
        allowed_fields = set(ProjectUpdate.__fields__.keys())
        update_data = {k: v for k, v in update.items() if k in allowed_fields}

        ignored = [k for k in update.keys() if k not in allowed_fields]
        if ignored:
            logger.warning(f"Ignoring unknown update fields for project {project_id}: {ignored}")

        if not update_data:
            logger.warning(f"No valid update fields provided for project {project_id}")
            # Return the current project without changes
            return normalize_project(current_project)

        if isinstance(update_data.get("team_members"), list):
            incoming_members = [
                member
                for member in update_data.get("team_members", [])
                if isinstance(member, dict)
            ]

            seen_member_keys = set()
            for member in incoming_members:
                member_user = str(member.get("user") or "").strip().lower()
                member_email = str(member.get("email") or "").strip().lower()
                member_key = f"user:{member_user}" if member_user else (f"email:{member_email}" if member_email else "")
                if not member_key:
                    continue
                if member_key in seen_member_keys:
                    raise HTTPException(
                        status_code=409,
                        detail="Duplicate member entries are not allowed.",
                    )
                seen_member_keys.add(member_key)

            ownership = await resolve_project_ownership(current_project)
            owner_id = ownership.get("owner_id")
            owner_role = ownership.get("owner_role")

            is_admin_or_owner = False
            if owner_role == "company" and owner_id:
                member_role = await get_company_member_role(owner_id, payload.get("email"))
                is_admin_or_owner = member_role in COMPANY_PROJECT_WRITE_ROLES

            if is_admin_or_owner:
                existing_members = current_project.get("team_members") or []

                def _member_key(raw: Dict[str, Any]) -> str:
                    member_user = str(raw.get("user") or "").strip().lower()
                    member_email = str(raw.get("email") or "").strip().lower()
                    if member_user:
                        return f"user:{member_user}"
                    if member_email:
                        return f"email:{member_email}"
                    return ""

                existing_keys = {
                    _member_key(member)
                    for member in existing_members
                    if isinstance(member, dict)
                }

                incoming_keys = {
                    _member_key(member)
                    for member in incoming_members
                }

                newly_added_keys = {key for key in incoming_keys if key and key not in existing_keys}
                current_user_id_key = f"user:{str(payload.get('id') or '').strip().lower()}"
                current_user_email = str(payload.get("email") or "").strip().lower()
                current_user_email_key = f"email:{current_user_email}" if current_user_email else ""

                if current_user_id_key in newly_added_keys or (
                    current_user_email_key and current_user_email_key in newly_added_keys
                ):
                    raise HTTPException(
                        status_code=409,
                        detail="Admin/Owner already has implicit project access and cannot be added as a team member.",
                    )

        logger.info(f"Updating project {project_id} with data: {list(update_data.keys())}")

        # Let MongoDB.update_project perform necessary conversions (e.g., ObjectId for tasks/user)
        updated_project = await MongoDB.update_project(project_id, update_data)

        if not updated_project:
            raise HTTPException(status_code=404, detail="Project not found")

        # Normalize the project to ensure proper field mapping
        return normalize_project(updated_project)

    except InvalidId:
        logger.error(f"Invalid ObjectId format: {project_id}")
        raise HTTPException(status_code=400, detail="Invalid project ID format")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating project {project_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/projects/{project_id}", response_model=Dict[str, Any])
async def delete_project(project_id: str, request: Request) -> Dict[str, Any]:
    """Soft delete a project by setting its status to 'deleted'."""
    try:
        logger.info(f"Attempting to soft delete project: {project_id}")

        if MongoDB.db is None:
            raise HTTPException(status_code=500, detail="Database connection not initialized")

        current_project = await MongoDB.db.projects.find_one({"_id": ObjectId(project_id)})
        if not current_project:
            raise HTTPException(status_code=404, detail="Project not found")

        await assert_project_write_access(request, current_project)

        deleted_project = await MongoDB.soft_delete_project(project_id)

        if not deleted_project:
            raise HTTPException(status_code=404, detail="Project not found")

        logger.info(f"Successfully soft-deleted project: {project_id}")
        
        # Convert all ObjectIds to strings recursively
        return convert_objectids(deleted_project)

    except InvalidId:
        logger.error(f"Invalid ObjectId format: {project_id}")
        raise HTTPException(status_code=400, detail="Invalid project ID format")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error soft-deleting project {project_id}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))