from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import router
from core.mongodb import MongoDB
import os
import logging
from dotenv import load_dotenv
import uvicorn
from datetime import datetime
from pathlib import Path


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Load .env from the root directory (docker-compose mounts it at /app/.env)
env_path = Path('/app/.env') if os.path.exists('/app/.env') else Path('../../.env')
load_dotenv(dotenv_path=env_path)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for the FastAPI application.
    Handles startup (DB connection) and shutdown (DB close) events.
    """
    # --- STARTUP LOGIC ---
    try:
        mongo_url = os.getenv("MONGODB_URI")
        db_name = os.getenv("DATABASE_NAME", "praxis-aipm")

        logger.info("Starting application lifespan...")

        if not mongo_url:
            logger.warning("⚠️ MONGODB_URI not found in environment variables. Running without database.")
        else:
            logger.info(f"Attempting to connect to database: {db_name}")
            try:
                # Call the connection method
                await MongoDB.connect_to_mongo(mongo_url=mongo_url, db_name=db_name)
                
                # Crucial Check: Verify the DB object was actually assigned
                if MongoDB.db is not None:
                    logger.info("✅ MongoDB connection established and verified.")
                else:
                    logger.error("❌ MongoDB.connect_to_mongo completed, but MongoDB.db is still None.")
            
            except Exception as e:
                logger.error(f"❌ Critical error connecting to MongoDB: {e}")
                # We yield anyway so the API stays online (returning 500s for DB routes instead of crashing)

    except Exception as e:
        logger.error(f"Unexpected error during application startup: {e}")

    # Yield control back to the application (Server starts handling requests now)
    yield

    # --- SHUTDOWN LOGIC ---
    logger.info("Shutting down application...")

    # Close PlannerAgent resources (aiohttp sessions, etc.)
    try:
        from core.planner import PlannerAgent
        if PlannerAgent._instance is not None:
            await PlannerAgent._instance.close()
            logger.info("✅ PlannerAgent resources released.")
    except Exception as e:
        logger.warning(f"Error closing PlannerAgent: {e}")

    try:
        # Only try to close if the client exists
        if hasattr(MongoDB, 'client') and MongoDB.client:
            await MongoDB.close_mongo_connection()
            logger.info("✅ MongoDB connection closed.")
        else:
            logger.info("No active MongoDB connection to close.")
    except Exception as e:
        logger.warning(f"Error closing MongoDB connection: {e}")
    
    logger.info("Application shutdown complete.")

# Initialize the app with this lifespan
app = FastAPI(lifespan=lifespan)

app = FastAPI(
    title="Project Planner API",
    lifespan=lifespan,
    description="A Project Planning API using a local Ollama model and MongoDB with AI-powered project planning capabilities",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware (configure as needed for your frontend)
def _get_allowed_origins():
    """Read CORS origins from the environment and always allow local development."""
    configured = os.getenv("ALLOWED_ORIGINS", "")
    origins = [origin.strip() for origin in configured.split(",") if origin.strip()]
    for local in ("http://localhost:3000", "http://localhost:8000", "http://localhost"):
        if local not in origins:
            origins.append(local)
    return origins


app.add_middleware(
    CORSMiddleware,
    allow_origins=_get_allowed_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Root endpoint that provides API information and documentation links."""
    return {
        "message": "Welcome to Project Planner API",
        "version": "1.0.0",
        "documentation": {
            "swagger_ui": "/docs",
            "redoc": "/redoc"
        },
        "available_endpoints": {
            "projects": {
                "create": "POST /api/projects - Create a new project",
                "list": "GET /api/projects - List all projects (use ?include_deleted=true to include deleted)",
                "get_description": "GET /api/projects/{project_id}/description - Get project description",
                "update": "PATCH /api/projects/{project_id} - Update project (partial update supported)",
                "delete": "DELETE /api/projects/{project_id} - Soft delete a project"
            },
            "planning": {
                "generate_plan": "GET /api/projects/{project_id}/plan - Generate AI-powered project plan",
                "refine_tasks": "POST /api/refine-tasks/{project_id} - Refine tasks with AI assistance"
            }
        },
        "features": {
            "ai_powered": "Uses a local Ollama model for intelligent project planning and task breakdown",
            "soft_delete": "Projects are soft-deleted (marked as deleted, not permanently removed)",
            "partial_updates": "PATCH endpoint supports partial updates - only send fields you want to change",
            "plan_generation": "Automatic project plan generation with milestones, tasks, and deliverables",
            "task_refinement": "Break down high-level tasks into detailed sub_tasks with effort estimates"
        },
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint to verify API and database connectivity."""
    try:
        # Check MongoDB connection
        # --- FIX: Check .client instead of .db ---
        if MongoDB.client is not None:
            await MongoDB.client.admin.command('ping')
            db_status = "connected"
        else:
            db_status = "disconnected"
        
        return {
            "status": "healthy" if db_status == "connected" else "unhealthy",
            "database": db_status,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "database": "error",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

# Include API routes
app.include_router(router, prefix="/api/v1", tags=["Projects"])

def main():
    """Run the application with uvicorn server."""
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    reload = os.getenv("RELOAD", "true").lower() == "true"
    
    logger.info(f"Starting server on {host}:{port}")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info"
    )

if __name__ == "__main__":
    main()


# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(
#         "main:app",
#         host="0.0.0.0",
#         port=int(os.getenv("PORT", 8002)),
#         reload=True
#     )