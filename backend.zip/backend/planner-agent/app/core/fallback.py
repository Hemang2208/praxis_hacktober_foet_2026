"""
Rate limit handler and fallback plan generator
"""

from typing import Dict, Any, List, Tuple
import logging

logger = logging.getLogger(__name__)


class FallbackPlanGenerator:
    """Generate detailed fallback plans when primary AI provider is unavailable"""

    BASE_FEATURES = [
        "Project governance and kickoff documentation",
        "Architecture and implementation blueprint",
        "Core capability implementation",
        "Testing, quality, and release readiness",
        "Production deployment and handover"
    ]

    TAG_FEATURE_MAP = {
        "web": [
            "Responsive web interface with accessibility standards",
            "Design system and reusable UI component library",
            "Cross-browser compatibility validation"
        ],
        "api": [
            "Versioned API contract and endpoint documentation",
            "Authentication, authorization, and rate limiting",
            "Request/response validation and error handling"
        ],
        "database": [
            "Logical and physical data model design",
            "Database migration and rollback strategy",
            "Backup, restore, and data integrity controls"
        ],
        "mobile": [
            "Mobile-first experience and performance optimization",
            "Offline handling and sync strategy",
            "Device and OS compatibility matrix"
        ],
        "ai": [
            "Prompt/inference workflow design",
            "Model output evaluation criteria",
            "Fallback and guardrail policy for unreliable responses"
        ],
        "ecommerce": [
            "Catalog, cart, and checkout workflow",
            "Order lifecycle and fulfillment tracking",
            "Payment and transaction audit support"
        ]
    }

    TAG_SKILL_MAP = {
        "web": ["Frontend development", "UI/UX design", "Accessibility engineering"],
        "api": ["API design", "Backend development", "Service integration"],
        "database": ["Database design", "SQL", "Data migration"],
        "mobile": ["Mobile engineering", "Performance tuning"],
        "devops": ["CI/CD", "Infrastructure as code", "Monitoring"],
        "ai": ["Prompt engineering", "Model integration", "Evaluation design"],
        "ecommerce": ["Payment integration", "Order management domain"],
        "security": ["Threat modeling", "Application security"],
    }

    @staticmethod
    def generate_fallback_plan(project_details: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a detailed fallback project plan based on available project metadata"""

        # Handle missing project details
        if not project_details:
            logger.error("generate_fallback_plan called with None or empty project_details")
            return {"error": "Invalid project details"}

        project_id = project_details.get("_id") or project_details.get("project_id", "unknown")
        title = project_details.get("title", "Untitled Project")
        description = (project_details.get("description", "") or "").strip()
        raw_tags = project_details.get("tags", []) or []
        tags = [str(tag).strip().lower() for tag in raw_tags if str(tag).strip()]
        team = project_details.get("team", []) or []
        team_size = len(team)
        deadline = project_details.get("deadline")

        project_type = FallbackPlanGenerator._infer_project_type(tags, description)
        target_duration_weeks = FallbackPlanGenerator._estimate_duration_weeks(team_size, tags)
        scope_statement = FallbackPlanGenerator._build_scope_statement(title, description, project_type)

        features = FallbackPlanGenerator._generate_features(tags)
        skills = FallbackPlanGenerator._generate_skills(tags)
        milestones = FallbackPlanGenerator._generate_milestones(target_duration_weeks, deadline)
        risk_register, risk_factors = FallbackPlanGenerator._generate_risk_register(tags, team_size)
        high_level_tasks = FallbackPlanGenerator._generate_tasks(tags, target_duration_weeks)

        plan = {
            "project_id": str(project_id),
            "summary": (
                f"{title} is planned as a {project_type} initiative. {scope_statement} "
                f"The plan assumes a delivery team of {team_size} contributors with an estimated "
                f"execution window of approximately {target_duration_weeks} weeks. "
                "Fallback planning emphasizes predictable delivery, incremental validation, and "
                "clear handoff criteria for each phase."
            ),
            "project_context": {
                "project_title": title,
                "project_type": project_type,
                "team_size": team_size,
                "deadline": deadline,
                "tags": tags,
                "assumptions": [
                    "Core stakeholders can provide weekly feedback during implementation.",
                    "Team members are available for planned ceremonies and review checkpoints.",
                    "Infrastructure and tooling access can be provisioned during setup week."
                ],
                "constraints": [
                    "Plan generated from fallback logic without live model reasoning.",
                    "Task estimates are indicative and should be refined with historical velocity.",
                    "Requirements may evolve and must be managed with change control."
                ]
            },
            "key_features_deliverables": features,
            "skills_required": skills,
            "major_milestones": milestones,
            "risk_factors": risk_factors,
            "risk_register": risk_register,
            "high_level_tasks": high_level_tasks,
            "governance_plan": {
                "cadence": "Weekly planning and status reviews, daily standups, milestone retrospectives",
                "status_reporting": "Weekly progress report with blockers, risks, and completion confidence",
                "decision_framework": "Escalate unresolved blockers older than 2 business days",
                "change_control": "Any scope change must include impact on timeline, effort, and quality"
            },
            "quality_strategy": {
                "test_pyramid": [
                    "Unit testing for business logic and utility layers",
                    "Integration testing for system boundaries and persistence",
                    "End-to-end validation for critical user journeys"
                ],
                "quality_gates": [
                    "Code review approval before merge",
                    "Automated lint/type/test checks green",
                    "No unresolved severity-high defects in release scope"
                ],
                "definition_of_done": [
                    "Acceptance criteria met and verified",
                    "Documentation updated",
                    "Monitoring/alerting and rollback approach defined"
                ]
            },
            "communication_plan": {
                "stakeholder_updates": "Weekly summary + milestone demos",
                "engineering_sync": "Daily standup + twice-weekly technical sync",
                "risk_review": "Dedicated weekly risk and dependency review",
                "artifact_repository": "Maintain all specs, notes, and decisions in shared project workspace"
            }
        }

        logger.info(f"Generated fallback plan for project: {title}")
        return plan

    @staticmethod
    def _infer_project_type(tags: List[str], description: str) -> str:
        if "ecommerce" in tags:
            return "digital commerce platform"
        if "mobile" in tags:
            return "mobile product"
        if "api" in tags and "web" in tags:
            return "full-stack platform"
        if "api" in tags:
            return "service/API platform"
        if "web" in tags:
            return "web application"
        if "ai" in tags:
            return "AI-enabled application"
        if "data" in tags or "database" in tags:
            return "data-centric solution"
        if description:
            return "software delivery initiative"
        return "general software project"

    @staticmethod
    def _estimate_duration_weeks(team_size: int, tags: List[str]) -> int:
        base = 10
        complexity_boost = min(len(tags), 5)
        if team_size <= 2:
            capacity_adjustment = 2
        elif team_size <= 5:
            capacity_adjustment = 1
        elif team_size <= 8:
            capacity_adjustment = 0
        else:
            capacity_adjustment = -1
        return max(8, base + complexity_boost + capacity_adjustment)

    @staticmethod
    def _build_scope_statement(title: str, description: str, project_type: str) -> str:
        if description:
            return (
                f"The objective is to deliver {title} as a {project_type} with the following intent: "
                f"{description}"
            )
        return (
            f"The objective is to deliver {title} as a {project_type} with clear requirements, "
            "implementation priorities, and measurable rollout outcomes"
        )

    @staticmethod
    def _generate_features(tags: List[str]) -> List[str]:
        features = list(FallbackPlanGenerator.BASE_FEATURES)
        for tag in tags:
            features.extend(FallbackPlanGenerator.TAG_FEATURE_MAP.get(tag, []))
        return list(dict.fromkeys(features))

    @staticmethod
    def _generate_skills(tags: List[str]) -> List[str]:
        skills = [
            "Project management",
            "Requirements analysis",
            "Software development",
            "System design",
            "Testing and QA",
            "Technical documentation"
        ]
        for tag in tags:
            skills.extend(FallbackPlanGenerator.TAG_SKILL_MAP.get(tag, []))
        return list(dict.fromkeys(skills))

    @staticmethod
    def _generate_milestones(target_duration_weeks: int, deadline: Any) -> List[Dict[str, Any]]:
        design_end = max(2, target_duration_weeks // 4)
        build_end = max(design_end + 2, (target_duration_weeks * 3) // 4)
        test_end = max(build_end + 1, target_duration_weeks - 1)

        return [
            {
                "name": "Initiation and Discovery",
                "timeline": "Week 1",
                "deliverables": [
                    "Project charter and success metrics",
                    "Stakeholder map and communication matrix",
                    "Initial risk and dependency register"
                ]
            },
            {
                "name": "Architecture and Planning",
                "timeline": f"Week 2-{design_end}",
                "deliverables": [
                    "Solution architecture and module boundaries",
                    "Data model and integration contracts",
                    "Implementation backlog with priority tiers"
                ]
            },
            {
                "name": "Build and Integration",
                "timeline": f"Week {design_end + 1}-{build_end}",
                "deliverables": [
                    "Core feature implementation",
                    "Integration with external/internal dependencies",
                    "Incremental demos and feedback log"
                ]
            },
            {
                "name": "Validation and Hardening",
                "timeline": f"Week {build_end + 1}-{test_end}",
                "deliverables": [
                    "Test evidence and defect triage outcomes",
                    "Performance and reliability checks",
                    "Release readiness sign-off"
                ]
            },
            {
                "name": "Release and Handover",
                "timeline": f"Week {test_end + 1}-{target_duration_weeks}",
                "deliverables": [
                    "Production deployment and validation checklist",
                    "Operational runbook and support transition",
                    f"Post-launch review{' before ' + str(deadline) if deadline else ''}"
                ]
            }
        ]

    @staticmethod
    def _generate_risk_register(tags: List[str], team_size: int) -> Tuple[List[Dict[str, str]], List[str]]:
        risks = [
            {
                "risk": "Requirements ambiguity causing rework",
                "impact": "High",
                "probability": "Medium",
                "mitigation": "Run structured requirement reviews and acceptance criteria workshops"
            },
            {
                "risk": "Delivery slippage due to underestimation",
                "impact": "High",
                "probability": "Medium",
                "mitigation": "Apply milestone buffers and weekly re-estimation"
            },
            {
                "risk": "Dependency delays from external systems",
                "impact": "Medium",
                "probability": "Medium",
                "mitigation": "Track dependency owners and prepare fallback integration mocks"
            },
            {
                "risk": "Quality regression under timeline pressure",
                "impact": "High",
                "probability": "Medium",
                "mitigation": "Enforce quality gates and defect thresholds before release"
            }
        ]

        if "api" in tags:
            risks.append({
                "risk": "Contract mismatch between services",
                "impact": "Medium",
                "probability": "Medium",
                "mitigation": "Adopt contract-first design and integration tests"
            })

        if "database" in tags:
            risks.append({
                "risk": "Schema changes impacting existing data",
                "impact": "High",
                "probability": "Low",
                "mitigation": "Use migration testing, backups, and rollback checkpoints"
            })

        if team_size <= 2:
            risks.append({
                "risk": "Limited delivery bandwidth",
                "impact": "Medium",
                "probability": "High",
                "mitigation": "Narrow MVP scope and sequence non-critical items post-release"
            })

        risk_factors = [item["risk"] for item in risks]
        return risks, risk_factors

    @staticmethod
    def _generate_tasks(tags: List[str], target_duration_weeks: int) -> List[Dict[str, Any]]:
        task_templates: List[Dict[str, Any]] = [
            {
                "task_name": "Project Setup and Governance",
                "description": "Establish repository standards, branching model, environments, and governance rituals.",
                "dependencies": [],
                "estimated_duration": "3 days"
            },
            {
                "task_name": "Requirements and Scope Baseline",
                "description": "Define user stories, acceptance criteria, non-functional requirements, and release scope.",
                "dependencies": ["Project Setup and Governance"],
                "estimated_duration": "4 days"
            },
            {
                "task_name": "Architecture and Data/Service Design",
                "description": "Document solution architecture, module responsibilities, data flows, and interface contracts.",
                "dependencies": ["Requirements and Scope Baseline"],
                "estimated_duration": "1 week"
            },
            {
                "task_name": "Core Feature Implementation",
                "description": "Build prioritized functional capabilities in iterative increments with code reviews.",
                "dependencies": ["Architecture and Data/Service Design"],
                "estimated_duration": f"{max(3, target_duration_weeks // 2)} weeks"
            },
            {
                "task_name": "Integration and System Validation",
                "description": "Integrate components and validate cross-cutting behavior across key workflows.",
                "dependencies": ["Core Feature Implementation"],
                "estimated_duration": "1-2 weeks"
            },
            {
                "task_name": "Quality Assurance and Hardening",
                "description": "Execute test strategy, resolve defects, and complete release readiness checklist.",
                "dependencies": ["Integration and System Validation"],
                "estimated_duration": "1 week"
            },
            {
                "task_name": "Release, Monitoring, and Handover",
                "description": "Deploy to production, validate observability, and transition to support operations.",
                "dependencies": ["Quality Assurance and Hardening"],
                "estimated_duration": "3-4 days"
            }
        ]

        if "web" in tags:
            task_templates.insert(
                4,
                {
                    "task_name": "Frontend Experience Implementation",
                    "description": "Implement user journeys, accessibility checks, and responsive behavior with design consistency.",
                    "dependencies": ["Core Feature Implementation"],
                    "estimated_duration": "1-2 weeks"
                }
            )

        if "api" in tags:
            task_templates.insert(
                4,
                {
                    "task_name": "API Contract and Security Hardening",
                    "description": "Finalize API schema validation, auth controls, and reliability/error-management behavior.",
                    "dependencies": ["Core Feature Implementation"],
                    "estimated_duration": "1 week"
                }
            )

        if "database" in tags:
            task_templates.insert(
                4,
                {
                    "task_name": "Database Optimization and Migration Validation",
                    "description": "Validate migrations, indexing, query performance, and data recovery procedures.",
                    "dependencies": ["Core Feature Implementation"],
                    "estimated_duration": "4-6 days"
                }
            )

        for task in task_templates:
            task["due_date"] = "TBD (Dependent on project kickoff)"

        return task_templates

def check_ollama_status():
    """Check whether the local Ollama integration is configured."""
    return True

class RateLimitHandler:
    """Handle rate limiting scenarios"""
    
    @staticmethod
    def get_retry_delay(attempt: int) -> int:
        """Calculate retry delay based on attempt number"""
        base_delay = 60  # 1 minute base delay
        return min(base_delay * (2 ** attempt), 300)  # Max 5 minutes
    
    @staticmethod
    def should_use_fallback(error_count: int) -> bool:
        """Determine if we should use fallback plan"""
        return error_count >= 3