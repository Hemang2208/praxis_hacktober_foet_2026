from typing import Dict, Any, Optional, List
import json
from datetime import datetime
from core.mongodb import MongoDB
from core.fallback import FallbackPlanGenerator
from core.task_quality_engine import TaskQualityEngine, ProjectNiche
from shared.ollama_service import OllamaService
import logging
import asyncio
import os
from dotenv import load_dotenv
import time
from enum import Enum

load_dotenv()

LLM_TIMEOUT_SECONDS = float(os.getenv("PLANNER_LLM_TIMEOUT_SECONDS", "600"))

logger = logging.getLogger(__name__)


  # Tentatively retrying after timeout


class TaskEnricher:
    """Enrich task data with intelligent defaults and validation"""

    @staticmethod
    def enrich_task_name(name: str, description: str) -> str:
        """Generate meaningful task name from description if name is missing or generic"""
        if not name or name.strip().lower() in ["unnamed task", "task", ""]:
            # Extract meaningful keywords from description
            if not description:
                return "Task Implementation"

            # Get first meaningful phrase from description
            words = description.split()[:5]
            first_phrase = " ".join(words).rstrip(".")

            # Capitalize and clean up
            if first_phrase:
                return first_phrase[:50] if len(first_phrase) > 50 else first_phrase
            return "Task Implementation"

        return name.strip()

    @staticmethod
    def validate_and_enrich(task: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and enrich task data"""
        if not isinstance(task, dict):
            return None

        # Extract fields with defaults
        task_name = task.get("task_name") or task.get("name") or ""
        description = task.get("description") or ""
        dependencies = task.get("dependencies") or []

        # Enrich task name
        enriched_name = TaskEnricher.enrich_task_name(task_name, description)

        # Validate dependencies is a list
        if not isinstance(dependencies, list):
            dependencies = []

        # Return enriched task (snake_case only)
        enriched_task = {
            "task_name": enriched_name,
            "description": description,
            "dependencies": dependencies,
            "due_date": task.get("due_date"),
            "estimated_duration": task.get("estimated_duration"),
        }

        # Keep any other fields that were in the original task
        for key, value in task.items():
            if key not in enriched_task:
                enriched_task[key] = value

        return enriched_task

    @staticmethod
    def enrich_tasks_list(tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Enrich a list of tasks"""
        if not tasks:
            return []

        enriched_tasks = []
        for task in tasks:
            enriched = TaskEnricher.validate_and_enrich(task)
            if enriched:
                enriched_tasks.append(enriched)

        return enriched_tasks


class PlannerAgent:
    _instance: Optional["PlannerAgent"] = None

    def __init__(self):
        """Initialize the PlannerAgent with the local Ollama service."""
        self.llm_available = True
        self.mongodb = MongoDB()
        self.ollama = OllamaService(agent_type="planner")
        logger.info(f"PlannerAgent initialized. LLM available: {self.llm_available}.")

    @classmethod
    def get_instance(cls) -> "PlannerAgent":
        """Return a shared singleton instance (created on first call)."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    async def close(self):
        """Release HTTP sessions and resources."""
        await self.ollama.close()

    def _validate_llm_ready(self) -> bool:
        if not self.llm_available:
            logger.debug("Local Ollama is unavailable, will use fallback")
            return False
        return True

    async def _generate_plan_internal(self, context: Dict[str, Any], project_details: Dict[str, Any]) -> Dict[str, Any]:
        """Internal plan generation logic wrapped with timeout"""
        project_niche = TaskQualityEngine.detect_project_niche(
            context.get("title", ""),
            context.get("description", ""),
            context.get("tags", []).split(", ") if isinstance(context.get("tags", ""), str) else context.get("tags", [])
        )
        logger.info(f"Detected project niche: {project_niche.value}")

        prompt_template = TaskQualityEngine.generate_prompt_for_niche(project_niche, context)

        messages = [
            {
                "role": "system",
                "content": "You are PRAXIS, the official AI Support Agent, and a senior project manager creating detailed, actionable project plans. Output ONLY valid JSON with NO additional text."
            },
            {
                "role": "user",
                "content": prompt_template
            }
        ]

        logger.info(f"Generating {project_niche.value} project plan with high-quality tasks...")
        plan_json = await self.ollama.generate_json_completion(messages=messages)

        # Normalize and auto-populate missing required fields to prevent validation failures
        if not isinstance(plan_json, dict):
            plan_json = {}

        if "tasks" in plan_json and "high_level_tasks" not in plan_json:
            plan_json["high_level_tasks"] = plan_json.pop("tasks")
            logger.info("Mapped 'tasks' to 'high_level_tasks' in plan_json")

        tags_str = context.get("tags", "")
        if isinstance(tags_str, str):
            tags = [t.strip().lower() for t in tags_str.split(",") if t.strip()]
        else:
            tags = []

        if "summary" not in plan_json or not plan_json["summary"]:
            title = context.get("title", "Untitled Project")
            description = context.get("description", "")
            project_type = FallbackPlanGenerator._infer_project_type(tags, description)
            team_size = context.get("team_size", 0)
            plan_json["summary"] = (
                f"{title} is planned as a {project_type} initiative. "
                f"The plan assumes a delivery team of {team_size} contributors. "
                "AI-assisted planning emphasizes specific deliverables, structured phases, and clear quality gates."
            )
            logger.info("Auto-generated missing summary in plan_json")

        if "key_features_deliverables" not in plan_json or not plan_json["key_features_deliverables"]:
            tasks_list = plan_json.get("high_level_tasks", [])
            features = []
            if isinstance(tasks_list, list):
                for task in tasks_list:
                    if isinstance(task, dict):
                        name = task.get("name") or task.get("task_name")
                        if name:
                            features.append(name)
            if not features:
                features = FallbackPlanGenerator._generate_features(tags)
            plan_json["key_features_deliverables"] = features
            logger.info("Auto-generated missing key_features_deliverables in plan_json")

        if "major_milestones" not in plan_json or not plan_json["major_milestones"]:
            team_size = context.get("team_size", 0)
            target_duration_weeks = FallbackPlanGenerator._estimate_duration_weeks(team_size, tags)
            plan_json["major_milestones"] = FallbackPlanGenerator._generate_milestones(target_duration_weeks, context.get("deadline"))
            logger.info("Auto-generated missing major_milestones in plan_json")

        required_fields = [
            "summary",
            "key_features_deliverables",
            "major_milestones",
            "high_level_tasks"
        ]
        missing_fields = [field for field in required_fields if field not in plan_json]
        if missing_fields:
            raise ValueError(f"Missing required fields in plan: {', '.join(missing_fields)}")

        return plan_json

    async def generate_project_plan(self, project_details: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a detailed project plan."""
        start_time = time.time()
        project_id = str(project_details.get("_id", "unknown"))

        try:
            logger.info(json.dumps({
                "event": "plan_generation_started",
                "project_id": project_id,
                "llm_available": self.llm_available
            }))

            # Extract project details with defaults
            context = {
                "title": project_details.get("title", "Untitled Project"),
                "description": project_details.get("description", ""),
                "status": project_details.get("status", "planning"),
                "team_size": len(project_details.get("team", [])),
                "progress": project_details.get("progress", 0),
                "tags": ", ".join(project_details.get("tags", [])),
                "deadline": project_details.get("deadline", "Not specified"),
                "planning_depth": project_details.get("planning_depth", "medium"),
                "include_risk_analysis": project_details.get("include_risk_analysis", False)
            }

            logger.info(f"Project context: {context}")

            # If LLM/API key isn't configured, use fallback generator immediately
            if not self.llm_available:
                logger.warning("Local Ollama unavailable — using fallback plan generator")
                try:
                    fallback_plan = FallbackPlanGenerator.generate_fallback_plan(project_details)

                    # Attempt to store fallback plan (non-blocking)
                    try:
                        await self._store_project_plan(project_id, fallback_plan)
                        logger.info(f"Stored fallback plan for project {project_id}")
                    except Exception as storage_error:
                        logger.warning(f"Failed to store fallback plan: {storage_error}")

                    execution_time = int((time.time() - start_time) * 1000)
                    return {
                        **fallback_plan,
                        "ai_used": False,
                        "source": "deterministic_fallback",
                        "generated_at": datetime.utcnow().isoformat(),
                        "execution_time_ms": execution_time,
                        "fallback_level": 1,
                        "reason_for_fallback": "Local Ollama unavailable"
                    }
                except Exception as e:
                    logger.error(f"Fallback plan generation failed: {e}")
                    execution_time = int((time.time() - start_time) * 1000)
                    return {
                        "error": "fallback_generation_failed",
                        "message": str(e),
                        "ai_used": False,
                        "execution_time_ms": execution_time
                    }

            # Try to generate plan with a bounded timeout
            try:
                plan_json = await asyncio.wait_for(
                    self._generate_plan_internal(context, project_details),
                    timeout=LLM_TIMEOUT_SECONDS
                )

                # Store the plan in MongoDB (non-blocking)
                try:
                    await self._store_project_plan(project_id, plan_json)
                    logger.info(f"Successfully generated and stored plan for project {project_id}")
                except Exception as storage_error:
                    logger.warning(f"Failed to store plan in MongoDB: {storage_error}")

                execution_time = int((time.time() - start_time) * 1000)
                return {
                    **plan_json,
                    "ai_used": True,
                    "source": "ollama",
                    "model": "ollama_service",
                    "fallback_level": 0,
                    "generated_at": datetime.utcnow().isoformat(),
                    "execution_time_ms": execution_time
                }

            except asyncio.TimeoutError:
                logger.error("Plan generation timed out after %s seconds", LLM_TIMEOUT_SECONDS)
                logger.info("Falling back to deterministic plan generation due to timeout...")

                # Use fallback plan generator
                try:
                    fallback_plan = FallbackPlanGenerator.generate_fallback_plan(project_details)

                    # Try to store the fallback plan
                    try:
                        await self._store_project_plan(project_id, fallback_plan)
                        logger.info(f"Successfully generated and stored fallback plan for project {project_id}")
                    except Exception as storage_error:
                        logger.warning(f"Failed to store fallback plan: {storage_error}")

                    execution_time = int((time.time() - start_time) * 1000)
                    return {
                        **fallback_plan,
                        "ai_used": False,
                        "source": "deterministic_fallback",
                        "generated_at": datetime.utcnow().isoformat(),
                        "execution_time_ms": execution_time,
                        "fallback_level": 1,
                        "reason_for_fallback": f"API timeout ({LLM_TIMEOUT_SECONDS:g} seconds)"
                    }

                except Exception as fallback_error:
                    logger.error(f"Fallback plan generation also failed: {fallback_error}")
                    execution_time = int((time.time() - start_time) * 1000)
                    return {
                        "error": "timeout_and_fallback_failed",
                        "message": "Plan generation timed out and fallback generation failed.",
                        "ai_used": False,
                        "execution_time_ms": execution_time
                    }

            except Exception as api_error:
                logger.error(f"API error during plan generation: {api_error}")
                # Generate fallback plan
                try:
                    fallback_plan = FallbackPlanGenerator.generate_fallback_plan(project_details)

                    # Try to store the fallback plan
                    try:
                        await self._store_project_plan(project_id, fallback_plan)
                    except Exception as storage_error:
                        logger.warning(f"Failed to store fallback plan: {storage_error}")

                    execution_time = int((time.time() - start_time) * 1000)
                    return {
                        **fallback_plan,
                        "ai_used": False,
                        "source": "deterministic_fallback",
                        "generated_at": datetime.utcnow().isoformat(),
                        "execution_time_ms": execution_time,
                        "fallback_level": 1,
                        "reason_for_fallback": f"API error: {str(api_error)}"
                    }

                except Exception as fallback_error:
                    logger.error(f"Fallback plan generation also failed: {fallback_error}")
                    execution_time = int((time.time() - start_time) * 1000)
                    return {
                        "error": "plan_generation_failed",
                        "message": "Plan generation failed and fallback also failed.",
                        "ai_used": False,
                        "execution_time_ms": execution_time
                    }

        except Exception as e:
            logger.error(f"Unexpected error in plan generation: {str(e)}")
            execution_time = int((time.time() - start_time) * 1000)
            return {
                "error": "unexpected_error",
                "message": "An unexpected error occurred during plan generation.",
                "ai_used": False,
                "execution_time_ms": execution_time
            }

    async def _refine_tasks_internal(self, enriched_tasks: List[Dict[str, Any]], tasks_str: str) -> List[Dict[str, Any]]:
        """Internal task refinement logic wrapped with timeout"""
        system_prompt = """You are PRAXIS, the official AI Support Agent, and a senior technical project manager specializing in task decomposition.
Your output MUST be ONLY valid JSON with NO additional text before or after.

QUALITY REQUIREMENTS:
1. Each subtask must be SPECIFIC and highly actionable
2. Each subtask needs clear acceptance criteria
3. Include technical implementation details
4. Subtasks must have realistic time estimates (in hours)
5. NO generic sub_tasks - all must be specific to the project
6. Subtasks should be 1-3 days of work each
7. Include testing approach for each subtask
8. Focus on making tasks so clear that anyone can implement them"""

        user_prompt = f"""Given these high-level tasks, break each into detailed, high-quality sub_tasks:

{tasks_str}

For each parent task, create 3-5 specific sub_tasks following these rules:
1. Each subtask must have a specific, descriptive name
2. Include detailed description of exactly what needs to be done
3. Define 2-3 clear acceptance criteria per subtask
4. Estimate hours realistically (typically 4-16 hours per subtask)
5. Specify technical requirements and dependencies
6. Describe how the subtask will be tested
7. List specific deliverables
8. Number the sub_tasks in logical order
9. Preserve the original task due date and add realistic subtask due dates in YYYY-MM-DD format

Return ONLY this exact JSON structure with NO text before or after.
The top-level JSON value MUST be an array containing one entry for EVERY input task.
Do NOT return a single object, and do NOT omit any input task:
[
    {{
        "task_name": "name from original task",
        "description": "description from original task",
        "dependencies": ["dependencies from original task"],
        "due_date": "YYYY-MM-DD",
        "sub_tasks": [
            {{
                "name": "SPECIFIC subtask name (not generic)",
                "description": "Detailed description of exactly what needs to be done",
                "acceptance_criteria": [
                    "Specific criterion 1",
                    "Specific criterion 2",
                    "Specific criterion 3"
                ],
                "estimated_hours": 12,
                "order": 1,
                "technical_requirements": ["Specific tech requirement 1", "Specific requirement 2"],
                "testing_approach": "How this will be tested and verified",
                "deliverables": ["Specific deliverable 1", "Specific deliverable 2"],
                "due_date": "YYYY-MM-DD"
            }}
        ]
    }}
]

CRITICAL RULES:
- NO placeholder values
- Each subtask name must be specific
- Each acceptance criterion must be measurable and specific
- Hours must be realistic for the complexity
- All JSON must be valid"""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        logger.info(f"Sending tasks to refine: {len(enriched_tasks)} tasks")
        refined_tasks = await self.ollama.generate_json_completion(messages=messages)
        logger.info(
            "Refined tasks response type=%s keys=%s",
            type(refined_tasks).__name__,
            list(refined_tasks.keys())[:10] if isinstance(refined_tasks, dict) else "n/a",
        )

        if isinstance(refined_tasks, dict):
            if "task_name" in refined_tasks or (
                "title" in refined_tasks and "sub_tasks" in refined_tasks
            ):
                refined_tasks = [refined_tasks]
                logger.info("Wrapped a single refined task object in a list")
            else:
                for key in ("refined_tasks", "tasks", "high_level_tasks", "data", "items", "results"):
                    candidate = refined_tasks.get(key)
                    if isinstance(candidate, list):
                        refined_tasks = candidate
                        logger.info(f"Unwrapped refined tasks from '{key}'")
                        break
                else:
                    list_values = [value for value in refined_tasks.values() if isinstance(value, list)]
                    if len(list_values) == 1:
                        refined_tasks = list_values[0]
                        logger.info("Unwrapped refined tasks from single list value")

        if not isinstance(refined_tasks, list):
            raise ValueError("Refined tasks must be a list")

        if len(refined_tasks) < len(enriched_tasks):
            missing = enriched_tasks[len(refined_tasks):]
            logger.warning(
                "Model refined %s of %s tasks; generating fallback details for the remaining %s",
                len(refined_tasks),
                len(enriched_tasks),
                len(missing),
            )
            refined_tasks.extend(self._generate_fallback_refined_tasks(missing))

        for task in refined_tasks:
            if not isinstance(task, dict) or "task_name" not in task:
                raise ValueError("Each refined task must be a dict with 'task_name'")

        logger.info(json.dumps({
            "event": "tasks_refined",
            "refined_count": len(refined_tasks),
            "ai_used": True
        }))

        return refined_tasks

    async def refine_project_tasks(self, project_id: str, tasks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Refine high-level tasks into detailed sub_tasks."""
        start_time = time.time()

        try:
            logger.info(json.dumps({
                "event": "task_refinement_started",
                "project_id": project_id,
                "task_count": len(tasks) if tasks else 0,
                "llm_available": self.llm_available
            }))

            # MongoDB connection check (non-blocking)
            project_plan = None
            if MongoDB.db is not None:
                try:
                    project_plan = await MongoDB.db.project_plans.find_one({"project_id": project_id})
                    if not project_plan:
                        logger.info(f"No existing plan found for project {project_id}")
                        project_plan = {
                            "project_id": project_id,
                            "high_level_tasks": tasks,
                            "created_at": datetime.utcnow(),
                            "updated_at": datetime.utcnow()
                        }
                except Exception as db_error:
                    logger.warning(f"MongoDB error: {db_error}")
                    project_plan = None

            # Validate input tasks
            if not tasks or not isinstance(tasks, list):
                logger.error(f"Invalid tasks input: {tasks}")
                execution_time = int((time.time() - start_time) * 1000)
                return {
                    "error": "invalid_input",
                    "message": "Tasks must be a non-empty list",
                    "ai_used": False,
                    "execution_time_ms": execution_time
                }

            # ENRICH TASKS
            enriched_tasks = TaskEnricher.enrich_tasks_list(tasks)
            logger.info(json.dumps({
                "event": "tasks_enriched",
                "project_id": project_id,
                "original_count": len(tasks),
                "enriched_count": len(enriched_tasks)
            }))

            tasks_str = json.dumps(enriched_tasks, indent=2)

            # Check if LLM is available
            if not self._validate_llm_ready():
                logger.info("LLM not available, using fallback task refinement")
                fallback_refined = self._generate_fallback_refined_tasks(enriched_tasks)
                execution_time = int((time.time() - start_time) * 1000)

                # Try to store fallback result
                if project_plan and MongoDB.db is not None:
                    try:
                        project_plan["high_level_tasks"] = fallback_refined
                        project_plan["updated_at"] = datetime.utcnow()
                        await self._store_project_plan(project_id, project_plan)
                    except Exception as storage_error:
                        logger.warning(f"Failed to store fallback refined tasks: {storage_error}")

                return {
                    "project_id": project_id,
                    "refined_tasks": fallback_refined,
                    "original_tasks": tasks,
                    "status": "fallback",
                    "ai_used": False,
                    "source": "deterministic_fallback",
                    "generated_at": datetime.utcnow().isoformat(),
                    "execution_time_ms": execution_time,
                    "fallback_level": 1,
                    "reason_for_fallback": "LLM not available"
                }

            # Try to refine tasks with a bounded timeout
            try:
                refined_tasks = await asyncio.wait_for(
                    self._refine_tasks_internal(enriched_tasks, tasks_str),
                    timeout=LLM_TIMEOUT_SECONDS
                )

                # Try to store the updated plan (non-blocking)
                if project_plan and MongoDB.db is not None:
                    try:
                        project_plan["high_level_tasks"] = refined_tasks
                        project_plan["updated_at"] = datetime.utcnow()
                        await self._store_project_plan(project_id, project_plan)
                        logger.info("Successfully stored refined tasks to database")
                    except Exception as storage_error:
                        logger.warning(f"Failed to store refined tasks: {storage_error}")

                execution_time = int((time.time() - start_time) * 1000)
                return {
                    "project_id": project_id,
                    "refined_tasks": refined_tasks,
                    "original_tasks": tasks,
                    "status": "success",
                    "ai_used": True,
                    "source": "ollama",
                    "model": "ollama_service",
                    "fallback_level": 0,
                    "generated_at": datetime.utcnow().isoformat(),
                    "execution_time_ms": execution_time
                }

            except asyncio.TimeoutError:
                logger.error("Task refinement timed out after %s seconds", LLM_TIMEOUT_SECONDS)
                logger.info("Falling back to fallback task refinement due to timeout...")

                # Fallback: Generate basic sub_tasks
                fallback_refined = self._generate_fallback_refined_tasks(enriched_tasks)

                # Try to store fallback result
                if project_plan and MongoDB.db is not None:
                    try:
                        project_plan["high_level_tasks"] = fallback_refined
                        project_plan["updated_at"] = datetime.utcnow()
                        await self._store_project_plan(project_id, project_plan)
                    except Exception as storage_error:
                        logger.warning(f"Failed to store fallback refined tasks: {storage_error}")

                execution_time = int((time.time() - start_time) * 1000)
                return {
                    "project_id": project_id,
                    "refined_tasks": fallback_refined,
                    "original_tasks": tasks,
                    "status": "fallback",
                    "ai_used": False,
                    "source": "deterministic_fallback",
                    "generated_at": datetime.utcnow().isoformat(),
                    "execution_time_ms": execution_time,
                    "fallback_level": 1,
                    "reason_for_fallback": f"timeout ({LLM_TIMEOUT_SECONDS:g} seconds)"
                }

            except Exception as api_error:
                logger.error(f"API error during task refinement: {api_error}")
                # Generate fallback refined tasks
                fallback_refined = self._generate_fallback_refined_tasks(enriched_tasks)
                execution_time = int((time.time() - start_time) * 1000)

                return {
                    "project_id": project_id,
                    "refined_tasks": fallback_refined,
                    "original_tasks": tasks,
                    "status": "fallback",
                    "ai_used": False,
                    "source": "deterministic_fallback",
                    "generated_at": datetime.utcnow().isoformat(),
                    "execution_time_ms": execution_time,
                    "fallback_level": 1,
                    "reason_for_fallback": f"API error: {str(api_error)}"
                }

        except Exception as e:
            logger.error(f"Error refining project tasks: {e}")
            execution_time = int((time.time() - start_time) * 1000)

            # Generate fallback refined tasks as last resort
            try:
                logger.info("Attempting fallback task refinement...")
                fallback_refined = self._generate_fallback_refined_tasks(tasks)

                return {
                    "project_id": project_id,
                    "refined_tasks": fallback_refined,
                    "original_tasks": tasks,
                    "status": "fallback",
                    "ai_used": False,
                    "source": "deterministic_fallback",
                    "generated_at": datetime.utcnow().isoformat(),
                    "execution_time_ms": execution_time,
                    "fallback_level": 1,
                    "reason_for_fallback": f"System error: {str(e)}"
                }
            except Exception as fallback_error:
                logger.error(f"Fallback task refinement also failed: {fallback_error}")
                return {
                    "error": str(e),
                    "message": "Failed to refine project tasks.",
                    "fallback_error": str(fallback_error),
                    "ai_used": False,
                    "execution_time_ms": execution_time
                }

    def _generate_fallback_refined_tasks(self, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate high-quality fallback refined tasks when API is unavailable."""
        logger.info("Generating high-quality fallback refined tasks...")

        refined_tasks = []

        for task in tasks:
            # Support both camelCase and snake_case input
            task_name = task.get("task_name") or task.get("task_name", "Unnamed Task")
            task_desc = task.get("description", "No description provided")
            task_deps = task.get("dependencies", [])
            task_duration = task.get("estimated_duration") or task.get("estimated_duration", "TBD")

            # Estimate complexity based on task characteristics
            complexity = TaskQualityEngine.estimate_task_complexity(
                task_name,
                task_desc,
                len(task_deps),
                3
            )

            logger.info(f"Task '{task_name}' estimated complexity: {complexity.value}")

            # Generate specific, high-quality sub_tasks based on complexity and task type
            sub_tasks = self._generate_smart_subtasks(task_name, task_desc, complexity)

            refined_task = {
                "task_name": task_name,
                "description": task_desc,
                "dependencies": task_deps,
                "estimated_duration": task_duration,
                "complexity": complexity.value,
                "sub_tasks": sub_tasks
            }

            refined_tasks.append(refined_task)

        logger.info(f"Generated {len(refined_tasks)} refined tasks with {sum(len(t.get('sub_tasks', [])) for t in refined_tasks)} sub_tasks")
        return refined_tasks

    def _generate_smart_subtasks(self, task_name: str, task_desc: str, complexity) -> List[Dict[str, Any]]:
        """Generate smart, specific sub_tasks based on task type and complexity"""

        sub_tasks = []
        task_lower = task_name.lower() + " " + task_desc.lower()

        # Determine task type and generate specific sub_tasks
        if any(word in task_lower for word in ["api", "endpoint", "rest", "service"]):
            sub_tasks = [
                {
                    "name": f"Design API contract for {task_name}",
                    "description": f"Create detailed API specification with endpoints, request/response schemas, error codes, and authentication requirements for {task_name}",
                    "acceptance_criteria": [
                        "OpenAPI/Swagger specification complete",
                        "All endpoints documented",
                        "Request/response schemas defined"
                    ],
                    "estimated_hours": 6,
                    "order": 1,
                    "technical_requirements": ["OpenAPI specification", "API design tools"],
                    "testing_approach": "Review specification against business requirements"
                },
                {
                    "name": f"Implement {task_name} backend handlers",
                    "description": f"Implement the actual API handlers, business logic, and database operations for {task_name}",
                    "acceptance_criteria": [
                        "All endpoints implemented and functional",
                        "Business logic correctly implemented",
                        "Error handling implemented"
                    ],
                    "estimated_hours": 16,
                    "order": 2,
                    "technical_requirements": ["Backend framework", "Database"],
                    "testing_approach": "Unit tests for each endpoint"
                },
                {
                    "name": f"Write tests for {task_name}",
                    "description": f"Create comprehensive unit tests, integration tests, and API tests for {task_name}",
                    "acceptance_criteria": [
                        "Unit test coverage > 80%",
                        "All endpoints tested",
                        "Edge cases covered"
                    ],
                    "estimated_hours": 10,
                    "order": 3,
                    "technical_requirements": ["Testing framework", "Mock data"],
                    "testing_approach": "Run full test suite"
                },
                {
                    "name": f"Document and deploy {task_name}",
                    "description": f"Create documentation, deploy to staging, and prepare for production release of {task_name}",
                    "acceptance_criteria": [
                        "API documentation complete",
                        "Deployed to staging environment",
                        "Performance tests passed"
                    ],
                    "estimated_hours": 6,
                    "order": 4,
                    "technical_requirements": ["Deployment tools", "Documentation tools"],
                    "testing_approach": "Smoke tests on staging"
                }
            ]

        elif any(word in task_lower for word in ["database", "schema", "migration", "model"]):
            sub_tasks = [
                {
                    "name": f"Design data schema for {task_name}",
                    "description": f"Create database schema, define relationships, and plan migration strategy for {task_name}",
                    "acceptance_criteria": [
                        "Schema design complete",
                        "All relationships defined",
                        "Migration strategy documented"
                    ],
                    "estimated_hours": 8,
                    "order": 1,
                    "technical_requirements": ["Database design tool", "SQL knowledge"],
                    "testing_approach": "Schema review and validation"
                },
                {
                    "name": f"Implement data models and ORM for {task_name}",
                    "description": f"Create ORM models, relationships, and validation for {task_name}",
                    "acceptance_criteria": [
                        "All models implemented",
                        "Relationships working correctly",
                        "Validation rules implemented"
                    ],
                    "estimated_hours": 12,
                    "order": 2,
                    "technical_requirements": ["ORM framework", "Database"],
                    "testing_approach": "Model tests"
                },
                {
                    "name": f"Create and test migrations for {task_name}",
                    "description": f"Write, test, and document database migrations for {task_name}",
                    "acceptance_criteria": [
                        "Migrations written",
                        "Rollback tested",
                        "Documented for production"
                    ],
                    "estimated_hours": 8,
                    "order": 3,
                    "technical_requirements": ["Migration tools"],
                    "testing_approach": "Test migration up and down"
                }
            ]

        elif any(word in task_lower for word in ["ui", "frontend", "component", "page", "interface"]):
            sub_tasks = [
                {
                    "name": f"Create mockups for {task_name}",
                    "description": f"Design wireframes and high-fidelity mockups for {task_name}",
                    "acceptance_criteria": [
                        "Wireframes created",
                        "Visual design finalized",
                        "Responsive design considered"
                    ],
                    "estimated_hours": 8,
                    "order": 1,
                    "technical_requirements": ["Design tools", "Design system"],
                    "testing_approach": "Design review"
                },
                {
                    "name": f"Implement components for {task_name}",
                    "description": f"Develop reusable UI components for {task_name}",
                    "acceptance_criteria": [
                        "All components implemented",
                        "Props/interfaces defined",
                        "Accessibility compliant"
                    ],
                    "estimated_hours": 14,
                    "order": 2,
                    "technical_requirements": ["Frontend framework", "CSS"],
                    "testing_approach": "Component testing and visual regression"
                },
                {
                    "name": f"Test and optimize {task_name}",
                    "description": f"Write tests, optimize performance, and improve accessibility for {task_name}",
                    "acceptance_criteria": [
                        "Test coverage > 80%",
                        "Performance optimized",
                        "Accessibility audit passed"
                    ],
                    "estimated_hours": 10,
                    "order": 3,
                    "technical_requirements": ["Testing framework", "Accessibility tools"],
                    "testing_approach": "Automated and manual testing"
                }
            ]

        elif any(word in task_lower for word in ["test", "testing", "qa", "quality"]):
            sub_tasks = [
                {
                    "name": f"Create test plan for {task_name}",
                    "description": f"Define test strategy, test cases, and acceptance criteria for {task_name}",
                    "acceptance_criteria": [
                        "Test plan documented",
                        "Test cases enumerated",
                        "Acceptance criteria clear"
                    ],
                    "estimated_hours": 6,
                    "order": 1,
                    "technical_requirements": ["Testing methodology", "Test case tools"],
                    "testing_approach": "Test plan review"
                },
                {
                    "name": f"Implement automated tests for {task_name}",
                    "description": f"Write unit, integration, and end-to-end tests for {task_name}",
                    "acceptance_criteria": [
                        "Test coverage > 80%",
                        "All tests passing",
                        "CI/CD integrated"
                    ],
                    "estimated_hours": 14,
                    "order": 2,
                    "technical_requirements": ["Testing framework", "CI/CD tools"],
                    "testing_approach": "Test execution and reporting"
                },
                {
                    "name": f"Perform manual testing and bug fixing for {task_name}",
                    "description": f"Execute manual test cases and fix discovered issues for {task_name}",
                    "acceptance_criteria": [
                        "All test cases executed",
                        "Critical bugs fixed",
                        "Regression testing passed"
                    ],
                    "estimated_hours": 12,
                    "order": 3,
                    "technical_requirements": ["Testing tools", "Bug tracking"],
                    "testing_approach": "QA sign-off"
                }
            ]

        else:
            # Generic smart sub_tasks
            sub_tasks = [
                {
                    "name": f"Research and planning for {task_name}",
                    "description": f"Research requirements, dependencies, and technical approach for implementing {task_name}. Document findings and create implementation plan.",
                    "acceptance_criteria": [
                        "Requirements analysis complete",
                        "Technical approach documented",
                        "Risks identified"
                    ],
                    "estimated_hours": 6,
                    "order": 1,
                    "technical_requirements": ["Analysis tools", "Documentation"],
                    "testing_approach": "Plan review"
                },
                {
                    "name": f"Development/Implementation of {task_name}",
                    "description": f"Implement the core functionality for {task_name} based on the planned approach",
                    "acceptance_criteria": [
                        "Feature implemented",
                        "Code follows standards",
                        "Documentation added"
                    ],
                    "estimated_hours": 16,
                    "order": 2,
                    "technical_requirements": ["Development environment"],
                    "testing_approach": "Code review"
                },
                {
                    "name": f"Testing and validation of {task_name}",
                    "description": f"Test the {task_name} implementation to ensure it meets requirements and handles edge cases",
                    "acceptance_criteria": [
                        "Functional tests passed",
                        "Edge cases tested",
                        "Defects fixed"
                    ],
                    "estimated_hours": 8,
                    "order": 3,
                    "technical_requirements": ["Testing tools"],
                    "testing_approach": "QA testing"
                }
            ]

        # Adjust hours based on complexity
        if complexity.value == "very_complex":
            for st in sub_tasks:
                st["estimated_hours"] = int(st["estimated_hours"] * 1.5)

        return sub_tasks

    async def _store_project_plan(self, project_id: str, plan: Dict[str, Any]) -> None:
        """Store the project plan in MongoDB."""
        try:
            # Check if the database is connected
            if MongoDB.db is None:
                logger.error("MongoDB connection not initialized in _store_project_plan")
                raise ValueError("Database connection not initialized")

            # Add timestamp information
            now = datetime.utcnow()
            plan_with_metadata = {
                "project_id": project_id,
                "created_at": now,
                "updated_at": now,
                **plan
            }

            # Store with upsert to handle both create and update cases
            result = await MongoDB.db.project_plans.update_one(
                {"project_id": project_id},
                {"$set": plan_with_metadata},
                upsert=True
            )

            if result.upserted_id:
                logger.info(f"Created new project plan for project ID: {project_id}")
            elif result.modified_count > 0:
                logger.info(f"Updated existing project plan for project ID: {project_id}")
            else:
                logger.warning(f"No changes made to project plan for project ID: {project_id}")

        except Exception as e:
            logger.error(f"Error storing project plan: {e}")
            raise

    async def _update_project_plan(self, project_id: str, plan: Dict[str, Any]) -> None:
        """Update the project plan in MongoDB."""
        try:
            # Check if the database is connected
            if MongoDB.db is None:
                logger.error("MongoDB connection not initialized in _update_project_plan")
                raise ValueError("Database connection not initialized")

            # Add the project_id to the plan document
            plan_with_id = {
                "project_id": project_id,
                **plan
            }
            result = await MongoDB.db.project_plans.update_one(
                {"project_id": project_id},
                {"$set": plan_with_id}
            )
            if result.modified_count == 0 and result.matched_count == 0:
                logger.error(f"No project plan found with ID: {project_id}")
                raise ValueError(f"Project plan not found with ID: {project_id}")
            logger.info(f"Updated project plan for project ID: {project_id}")
        except Exception as e:
            logger.error(f"Error updating project plan: {e}")
            raise
