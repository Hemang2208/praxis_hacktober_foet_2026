"""
Enhanced Task Quality Engine for PRAXIS Planner
Focuses on creating high-quality, niche-specific, detailed tasks with clear acceptance criteria
"""

import json
import logging
from typing import Dict, List, Any, Optional
from enum import Enum
import re

logger = logging.getLogger(__name__)


class ProjectNiche(Enum):
    """Supported project niches/domains"""
    WEB_DEVELOPMENT = "web_development"
    MOBILE_APP = "mobile_app"
    DATA_SCIENCE = "data_science"
    DEVOPS = "devops"
    BLOCKCHAIN = "blockchain"
    MACHINE_LEARNING = "machine_learning"
    SAAS = "saas"
    E_COMMERCE = "e_commerce"
    FINTECH = "fintech"
    HEALTHCARE = "healthcare"
    IOT = "iot"
    GAME_DEVELOPMENT = "game_development"
    GENERAL = "general"


class TaskComplexity(Enum):
    """Task complexity levels"""
    TRIVIAL = "trivial"  # < 1 day
    SIMPLE = "simple"  # 1-3 days
    MODERATE = "moderate"  # 3-5 days
    COMPLEX = "complex"  # 1-2 weeks
    VERY_COMPLEX = "very_complex"  # 2+ weeks


class TaskQualityEngine:
    """Generate and refine high-quality tasks for specific project niches"""
    
    @staticmethod
    def detect_project_niche(title: str, description: str, tags: List[str]) -> ProjectNiche:
        """Detect project niche based on title, description, and tags"""
        text = f"{title} {description} {' '.join(tags)}".lower()
        
        niche_keywords = {
            ProjectNiche.WEB_DEVELOPMENT: ["web", "frontend", "backend", "react", "vue", "angular", "node", "html", "css"],
            ProjectNiche.MOBILE_APP: ["mobile", "ios", "android", "flutter", "react native", "app", "native"],
            ProjectNiche.DATA_SCIENCE: ["data science", "analytics", "insights", "ml", "machine learning", "data pipeline"],
            ProjectNiche.DEVOPS: ["devops", "ci/cd", "docker", "kubernetes", "infrastructure", "deployment", "cloud"],
            ProjectNiche.BLOCKCHAIN: ["blockchain", "crypto", "web3", "smart contract", "ethereum", "solidity"],
            ProjectNiche.MACHINE_LEARNING: ["machine learning", "deep learning", "neural", "model", "training", "prediction"],
            ProjectNiche.SAAS: ["saas", "subscription", "multi-tenant", "billing", "user management"],
            ProjectNiche.E_COMMERCE: ["ecommerce", "store", "shopping", "marketplace", "inventory", "payment"],
            ProjectNiche.FINTECH: ["fintech", "finance", "payment", "banking", "transaction", "ledger"],
            ProjectNiche.HEALTHCARE: ["healthcare", "medical", "patient", "hospital", "health", "clinical"],
            ProjectNiche.IOT: ["iot", "sensor", "embedded", "hardware", "edge", "device"],
            ProjectNiche.GAME_DEVELOPMENT: ["game", "unity", "unreal", "game dev", "gameplay", "graphics"],
        }
        
        max_matches = 0
        detected_niche = ProjectNiche.GENERAL
        
        for niche, keywords in niche_keywords.items():
            matches = sum(1 for keyword in keywords if keyword in text)
            if matches > max_matches:
                max_matches = matches
                detected_niche = niche
        
        return detected_niche
    
    @staticmethod
    def estimate_task_complexity(
        task_name: str,
        description: str,
        dependencies: int,
        required_skills: int
    ) -> TaskComplexity:
        """Estimate task complexity based on various factors"""
        complexity_score = 0
        
        # Check description length (more detailed = often more complex)
        if len(description) > 200:
            complexity_score += 2
        elif len(description) > 100:
            complexity_score += 1
        
        # Check for complexity keywords
        complex_keywords = ["integrate", "architect", "design", "optimize", "refactor", "debug", "analyze", "scale"]
        for word in complex_keywords:
            if word in task_name.lower() + description.lower():
                complexity_score += 1
        
        # Dependencies increase complexity
        complexity_score += dependencies
        
        # Required skills increase complexity
        complexity_score += required_skills // 2
        
        # Map score to complexity level
        if complexity_score <= 1:
            return TaskComplexity.TRIVIAL
        elif complexity_score <= 3:
            return TaskComplexity.SIMPLE
        elif complexity_score <= 6:
            return TaskComplexity.MODERATE
        elif complexity_score <= 10:
            return TaskComplexity.COMPLEX
        else:
            return TaskComplexity.VERY_COMPLEX
    
    @staticmethod
    def generate_prompt_for_niche(
        niche: ProjectNiche,
        project_details: Dict[str, Any]
    ) -> str:
        """Generate a specialized prompt based on project niche"""
        
        base_instructions = """You are PRAXIS, the official AI Support Agent, and a world-class project manager specializing in {niche} who creates highly detailed, specific, and actionable project plans.

YOUR PRIMARY OBJECTIVE: Generate ONLY valid JSON with absolutely NO additional text before, after, or between.

🚫 ANTI-PATTERNS TO AVOID:
- Generic task names: ❌ "Build backend", "Create UI" ✅ "Implement JWT authentication with refresh tokens", "Design responsive product card component"
- Vague descriptions: ❌ "Do testing" ✅ "Write unit tests for payment processing logic with 95%+ code coverage"
- Weak acceptance criteria: ❌ "It works" ✅ "All API endpoints return correct status codes", "Response time < 200ms", "Zero unhandled exceptions in logs"
- No dependencies: ❌ All tasks independent ✅ Database schema → Data migrations → API endpoints → Frontend integration
- Unrealistic estimates: ❌ "1 week" for complex feature ✅ "3 days for component, 2 days for integration tests"
- Missing deliverables: ❌ No outputs defined ✅ "Docker image pushed to registry", "API documentation in Swagger", "Code review approved"
- Placeholder text: ❌ "Tech 1", "Risk 1" ✅ "PostgreSQL with indexed queries", "API rate limiting under attack"

✅ STANDARDS FOR EXCELLENT TASKS:
1. SPECIFICITY: Task names must contain the WHAT and sometimes the HOW
   - Example: "Implement login form with OAuth2 Google integration and email validation"
   
2. ACCEPTANCE CRITERIA (2-4 specific, measurable criteria):
   - "User successfully logs in with Google account"
   - "Form validates email format with regex and shows error message"
   - "Session token persists for 7 days or user logs out"
   - "Password reset works via email within 5 minutes"
   
3. DELIVERABLES (concrete outputs):
   - "Code committed with passing tests on main branch"
   - "API endpoint documented in Swagger/OpenAPI"
   - "User documentation with screenshots in Confluence"
   
4. TECHNICAL REQUIREMENTS (specific tools, frameworks, standards):
   - NOT: "Backend framework" → YES: "Python FastAPI with async/await"
   - NOT: "Database" → YES: "PostgreSQL 14+ with RLS (Row Level Security)"
   
5. REALISTIC ESTIMATES based on complexity:
   - Simple (1-2 days): Minor feature, straightforward code
   - Moderate (3-5 days): Feature with integration, some testing
   - Complex (5-10 days): Multiple systems, heavy testing, learning curve
   
6. DEPENDENCIES (proper DAG structure - no circular dependencies):
   - List task_ids that MUST complete before this task starts
   - Example: ["task_1_design", "task_2_database_setup"] means both must complete first
   
7. RISK FACTORS (specific, realistic risks):
   - NOT: "Might be complicated" → YES: "Third-party OAuth API rate limits (100 req/minute)"
   - NOT: "Team might not know" → YES: "Team inexperienced with WebSocket implementation"

8. GRANULARITY: Each task should take 2-5 days for a full-stack developer
   - Too big: "Build entire authentication system" (2+ weeks)
   - Just right: "Implement JWT token generation and validation" (3-4 days)
   - Too small: "Add password field to login form" (4 hours)

9. TASK ORGANIZATION: Group related tasks into logical phases/milestones
   - Foundation Phase: Infrastructure, database, core setup
   - Core Feature Phase: Main functionality development
   - Integration Phase: Connecting components together
   - Testing & Polish Phase: QA, performance optimization
   - Launch Phase: Deployment, monitoring, documentation

10. PARALLEL vs SEQUENTIAL:
   - Many tasks CAN run in parallel (different team members)
   - Dependencies show sequencing constraints
   - Aim for 3-5 days of critical path per phase"""
        
        niche_prompts = {
            ProjectNiche.WEB_DEVELOPMENT: """
█ WEB DEVELOPMENT REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Architecture & Setup (Days 0-3)
   - Design REST API with clear endpoint contracts
   - Database schema design with migrations
   - Authentication/authorization strategy (JWT, OAuth, sessions)
   - Environment setup (Docker, CI/CD pipelines)

2️⃣  Backend Development (Days 3-10)
   - API endpoint implementation (CRUD operations minimum)
   - Database connection and ORM setup
   - Authentication middleware
   - Error handling and validation layer
   - API documentation (OpenAPI/Swagger)

3️⃣  Frontend Development (Days 8-15, parallel with backend)
   - Component architecture and design system
   - Form handling with validation
   - State management setup
   - API integration
   - Responsive design (mobile-first)

4️⃣  Testing & Integration (Days 13-18)
   - Unit tests (backend API routes, frontend components)
   - Integration tests (API + Database)
   - E2E tests (critical user flows)
   - Performance testing
   - Security testing (SQL injection, XSS, CSRF)

5️⃣  Optimization & Deployment (Days 18-21)
   - Performance optimization (caching, CDN, lazy loading)
   - Security hardening (HTTPS, headers, rate limiting)
   - Monitoring setup (error tracking, logging, metrics)
   - Load testing
   - Production deployment

SPECIFIC CONCERNS:
- Include explicit database migration tasks
- Separate frontend and backend concerns clearly
- Include cross-browser/cross-device testing
- Add accessibility (WCAG) compliance tasks
- Include performance benchmarking baselines
""",
            ProjectNiche.MOBILE_APP: """
█ MOBILE APP REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Design & Prototyping (Days 0-5)
   - Wireframes for all screens
   - Design system and component library
   - Platform guidelines review (iOS HIG, Material Design)
   - Figma/design tool setup

2️⃣  Project Setup (Days 5-8)
   - IDE setup (Xcode for iOS, Android Studio for Android)
   - Dependency management (CocoaPods, Gradle, pub)
   - CI/CD pipeline for builds
   - Testing framework setup

3️⃣  Core Features (Days 8-20, parallel iOS/Android)
   - App navigation structure
   - Authentication (local & remote)
   - API integration layer
   - Offline storage (SQLite, Realm, Hive)
   - Push notifications setup

4️⃣  Testing (Days 18-25)
   - Unit tests per module
   - UI tests with real devices
   - Performance testing (memory, battery, network)
   - Crash reporting setup
   - Beta testing on TestFlight/Firebase

5️⃣  Launch Prep (Days 25-30)
   - App Store/Google Play submission
   - Screenshots and store listing
   - Release notes and change log
   - Post-launch monitoring

SPECIFIC CONCERNS:
- Explicitly separate iOS and Android tasks if multi-platform
- Include device compatibility testing (various OS versions)
- Add battery and data usage optimization tasks
- Include offline functionality testing
- Add app store submission with specific requirements per platform
""",
            ProjectNiche.DATA_SCIENCE: """
█ DATA SCIENCE REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Problem Definition & Data Gathering (Days 0-5)
   - Define success metrics and evaluation criteria
   - Data source identification and contracts
   - Data collection and labeling strategy
   - Exploratory data analysis (EDA)

2️⃣  Data Preparation (Days 5-12)
   - Data cleaning and validation
   - Handling missing values and outliers
   - Feature engineering (explicit features, not black box)
   - Train/test/validation split

3️⃣  Model Development (Days 12-25)
   - Baseline model establishment
   - Multiple model comparison (explicit models, not "try different ones")
   - Hyperparameter tuning with cross-validation
   - Feature importance analysis
   - Error analysis and bias detection

4️⃣  Validation & Testing (Days 24-30)
   - Test set evaluation against success metrics
   - Comparison against baseline
   - Statistical significance testing
   - Fairness and bias assessment

5️⃣  Deployment & Monitoring (Days 28-35)
   - Model serialization and versioning
   - Prediction API development
   - A/B testing setup
   - Model monitoring and retraining pipeline
   - Documentation of model assumptions

SPECIFIC CONCERNS:
- Explicitly name ML algorithms (Random Forest, XGBoost, Neural Network, etc.)
- Include feature importance and interpretability tasks
- Add bias and fairness assessment tasks
- Include explicit baseline comparison
- Document assumptions and limitations
- Add model deprecation/retraining strategy
""",
            ProjectNiche.DEVOPS: """
█ DEVOPS REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Infrastructure Planning (Days 0-5)
   - Infrastructure as Code tool selection (Terraform, CloudFormation, Bicep)
   - Architecture design (VPC, subnets, security groups)
   - Disaster recovery strategy
   - Capacity planning

2️⃣  Core Infrastructure (Days 5-15)
   - VPC and network setup
   - Database setup with backups
   - Message queue setup
   - Container registry setup
   - Logging and monitoring infrastructure

3️⃣  CI/CD Pipeline (Days 15-25)
   - Source control hooks
   - Build automation (Docker image creation)
   - Test automation in pipeline
   - Deployment automation (staging → production)
   - Rollback strategy

4️⃣  Monitoring & Observability (Days 24-30)
   - Metrics collection (CPU, memory, disk)
   - Log aggregation and analysis
   - Alerting rules and escalation
   - Dashboards for incident response
   - Synthetic monitoring (uptime checks)

5️⃣  Security & Compliance (Days 28-35)
   - Secret management (API keys, DB credentials)
   - Network security hardening
   - Compliance scanning (SIEM, vulnerability scanning)
   - Incident response playbooks
   - Security training documentation

SPECIFIC CONCERNS:
- Explicitly specify cloud provider (AWS, Azure, GCP)
- Include infrastructure cost optimization tasks
- Add disaster recovery drills
- Include security scanning automation
- Add service scalability and auto-scaling setup
""",
            ProjectNiche.MACHINE_LEARNING: """
█ MACHINE LEARNING REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Problem Definition (Days 0-3)
   - Define learning objective (classification, regression, clustering)
   - Define success metrics (accuracy, F1, RMSE, etc.)
   - Baseline establishment
   - Data strategy

2️⃣  Data Preparation (Days 3-10)
   - Data collection and labeling
   - Data cleaning and preprocessing
   - Feature engineering (explicit features)
   - Data augmentation if needed

3️⃣  Model Development (Days 10-25)
   - Architecture design (specific: CNN, RNN, Transformer, etc.)
   - Model implementation from scratch or fine-tuning
   - Training loop with validation
   - Hyperparameter optimization

4️⃣  Evaluation & Improvement (Days 24-30)
   - Test set evaluation
   - Error analysis and mistake review
   - Comparison against baseline and state-of-art
   - Fairness and bias assessment

5️⃣  Production Deployment (Days 30-40)
   - Model quantization/compression for faster inference
   - API server setup (TensorFlow Serving, FastAPI, etc.)
   - Inference pipeline optimization
   - A/B testing framework
   - Model monitoring and retraining automation
   - Model versioning system

SPECIFIC CONCERNS:
- Explicitly name ML frameworks (PyTorch, TensorFlow, JAX, etc.)
- Include GPU/TPU requirements explicitly
- Add inference optimization tasks
- Include model interpretability analysis
- Add fairness and bias mitigation tasks
- Document model assumptions and limitations
""",
            ProjectNiche.SAAS: """
█ SAAS REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Foundation & Multi-tenancy (Days 0-10)
   - Multi-tenancy architecture (database per tenant, shared DB with row-level security, etc.)
   - Authentication and authorization system
   - Tenant isolation strategy
   - API rate limiting and throttling

2️⃣  Core Features (Days 10-25)
   - Multi-tenant logging and audit trails
   - Subscription/billing system integration
   - Team and permission management
   - Data backup and recovery per tenant

3️⃣  Advanced Features (Days 24-35)
   - SSO/SAML integration
   - Custom branding/whitelabeling
   - Analytics and usage reporting
   - Webhook system for integrations
   - Export functionality

4️⃣  Reliability & Scale (Days 33-40)
   - Load testing at scale
   - Database partitioning and sharding strategy
   - Caching layer (Redis)
   - Asynchronous job processing
   - High availability setup

5️⃣  Operations & Compliance (Days 38-45)
   - Data residency compliance
   - SOC 2/GDPR compliance
   - Security hardening
   - Monitoring and incident response
   - Customer onboarding automation

SPECIFIC CONCERNS:
- Explicitly specify multi-tenancy approach
- Include data isolation verification tasks
- Add compliance checklist (GDPR, HIPAA if needed)
- Include scalability stress testing
- Add customer upgrade/downgrade workflows
""",
            ProjectNiche.E_COMMERCE: """
█ E-COMMERCE REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Product Catalog (Days 0-8)
   - Product data model design
   - Inventory management system
   - Product search implementation with filtering
   - Product recommendation engine

2️⃣  Shopping Experience (Days 8-18)
   - Shopping cart with persistence
   - Checkout flow (address, shipping method, payment)
   - Order processing and confirmation
   - Email notifications (order, tracking, delivery)

3️⃣  Payment & Fulfillment (Days 16-25)
   - Payment gateway integration (Stripe, PayPal, etc.)
   - PCI compliance and security
   - Order fulfillment workflow
   - Returns and refunds processing
   - Shipping integration (APIs for cost calculation)

4️⃣  Customer Engagement (Days 23-35)
   - User accounts and order history
   - Review and rating system
   - Wishlist functionality
   - Email marketing/promotions
   - Customer service tickets

5️⃣  Analytics & Optimization (Days 33-40)
   - Analytics tracking (Google Analytics, custom)
   - Conversion funnel analysis
   - A/B testing framework
   - Performance optimization (page speed, search)
   - Fraud detection system

SPECIFIC CONCERNS:
- Explicitly name payment gateways
- Include PCI DSS compliance verification
- Add inventory sync and low-stock alerts
- Include multi-currency support requirements
- Add tax calculation for different jurisdictions
- Include abandoned cart recovery
""",
            ProjectNiche.BLOCKCHAIN: """
█ BLOCKCHAIN REQUIREMENTS:
PHASES TO INCLUDE:
1️⃣  Smart Contract Design (Days 0-10)
   - Solidity contract design and architecture
   - Function specification and state management
   - Security audit checklist (reentrancy, overflow, etc.)
   - Testnet deployment and testing

2️⃣  Security & Testing (Days 10-20)
   - Unit tests with Hardhat/Truffle
   - Integration tests on testnet
   - External security audit
   - Bug bounty program setup

3️⃣  Wallet & Integration (Days 20-30)
   - Wallet integration (MetaMask, etc.)
   - Transaction signing and verification
   - Gas optimization
   - Multi-sig wallet setup if needed

4️⃣  Frontend Interaction (Days 28-40)
   - Web3.js/ethers.js integration
   - Contract interaction UI
   - Transaction status tracking
   - Error handling and user guidance

5️⃣  Deployment & Monitoring (Days 38-50)
   - Mainnet deployment strategy
   - Contract verification on block explorer
   - Monitoring and alerting for contract events
   - Post-launch updates and governance

SPECIFIC CONCERNS:
- Explicitly name blockchain (Ethereum, Polygon, etc.)
- Include gas optimization analysis
- Add formal verification tasks if high-value contracts
- Include slashing/penalty mechanism design if applicable
- Add upgrade/proxy pattern if contract updates expected
- Include governance mechanism design
""",
            ProjectNiche.GENERAL: """
█ GENERAL PROJECT REQUIREMENTS:
Apply these principles universally:
- All tasks must be specific and measurable
- Document dependencies clearly
- Include testing at each phase
- Plan for 10-20% contingency time
- Include documentation tasks explicitly
- Organize by phases even if not explicitly defined
- Consider team skill levels in estimates
"""
        }
        
        project_title = project_details.get("title", "Project")
        project_desc = project_details.get("description", "")[:300]
        team_size = len(project_details.get("team", []))
        deadline = project_details.get("deadline", "Not specified")
        
        niche_specific = niche_prompts.get(niche, "")
        
        full_prompt = f"""{base_instructions.format(niche=niche.value)}

{niche_specific}

═══════════════════════════════════════════════════════════════════════════════
📋 PROJECT DETAILS FOR PLANNING:
═══════════════════════════════════════════════════════════════════════════════
Title: {project_title}
Description: {project_desc}
Team Size: {team_size} members
Deadline: {deadline}

ESTIMATE GUIDE BASED ON TEAM SIZE:
- 1 developer: Add 20-30% buffer to all estimates, sequential work only
- 2-3 developers: Standard estimates, some parallelization
- 4-6 developers: Can parallelize 40-50% of tasks
- 7+ developers: Can parallelize 60-70% of tasks, plan coordination overhead

═══════════════════════════════════════════════════════════════════════════════
📝 TASK GENERATION CHECKLIST:
═══════════════════════════════════════════════════════════════════════════════

✅ DO:
  ✓ Create 8-12 tasks covering the full project lifecycle
  ✓ Use specific, domain-appropriate task names with 5-10 words
  ✓ Include 2-4 measurable acceptance criteria per task
  ✓ Name specific technologies/frameworks, not generic placeholders
  ✓ Define realistic dependencies that form a valid DAG (no cycles)
  ✓ Estimate based on task complexity, not just hours
  ✓ Include at least one task for testing/QA per feature area
  ✓ Include deployment/launch tasks at the end
  ✓ Assign realistic due dates that respect the project deadline
  ✓ Include risk factors specific to each task (library issues, API changes, team gaps)
  ✓ Plan for contingency - tasks should not exceed 10 days unless they're major phases
  ✓ Include deliverables that can be reviewed/verified

❌ DON'T:
  ✗ Use generic names: "Build API", "Create UI", "Do testing"
  ✗ Create tasks longer than 10 days (too coarse-grained)
  ✗ Mix unrelated concerns (API + Database + Frontend = 3 tasks)
  ✗ Leave dependencies empty if there are true dependencies
  ✗ Use placeholder values like "Tech 1", "Risk 1", "Deliverable 1"
  ✗ Create circular dependencies (Task A depends on B, B depends on A)
  ✗ Underestimate testing and integration work
  ✗ Skip documentation and deployment tasks
  ✗ Ignore team skill gaps and learning curve
  ✗ Plan all tasks as sequential (enable parallelization where possible)

═══════════════════════════════════════════════════════════════════════════════
📐 JSON FIELD SPECIFICATIONS & EXAMPLES:
═══════════════════════════════════════════════════════════════════════════════

FIELD: "id"
DESCRIPTION: Unique identifier for the task (used for dependencies)
REQUIRED: YES
FORMAT: "task_1", "task_2", etc. (sequential numbering)
EXAMPLE: "id": "task_1"

FIELD: "name" 
DESCRIPTION: Specific, actionable task name (5-10 words, concrete not generic)
REQUIRED: YES
BAD EXAMPLES: "Build backend", "Create UI", "Testing", "API work"
GOOD EXAMPLES: "Implement JWT token validation with refresh token rotation", "Build responsive product card component with lazy loading"
FORMAT: String, max 80 chars

FIELD: "description"
DESCRIPTION: Detailed explanation of work required (2-3 sentences)
REQUIRED: YES
SHOULD INCLUDE: What needs to be done, why it matters, any context
EXAMPLE: "Implement email verification system that sends a confirmation link via AWS SES. Link must expire after 24 hours and include rate limiting (max 5 attempts per hour). This is critical for user security and compliance requirements."
FORMAT: String, 100-300 chars

FIELD: "acceptance_criteria"
DESCRIPTION: 2-4 specific, measurable criteria defining "done"
REQUIRED: YES
FORMAT: Array of strings, each starting with action verb
GOOD EXAMPLE: [
  "User receives verification email within 30 seconds of signup",
  "Link includes secure token and expires after 24 hours",
  "UI shows error message for invalid/expired tokens",
  "Rate limiting blocks after 5 failed attempts with 15-minute cooldown"
]

FIELD: "technical_requirements"
DESCRIPTION: Specific tools, frameworks, libraries, standards (NOT generic)
REQUIRED: YES
MUST BE SPECIFIC: Name the exact technology
BAD: ["Backend framework", "Database"]
GOOD: ["Python FastAPI 0.95+", "PostgreSQL 14 with RLS", "AWS SES for email"]
FORMAT: Array of strings with specific versions/details

FIELD: "dependencies"
DESCRIPTION: Array of task IDs that must COMPLETE before this task starts
REQUIRED: YES (can be empty array [] if no dependencies)
MEANS: Task A depends on Task B → Task B must be done first
EXAMPLE: ["task_3", "task_5"] = This task needs task_3 AND task_5 done first
FORMAT: Array of task IDs or empty array []

FIELD: "estimated_duration"
DESCRIPTION: How long the task will take (person-days or person-hours)
REQUIRED: YES
GOOD FORMATS: "2 days", "3-4 days", "1 week", "40 hours"
HOW TO ESTIMATE:
  - Simple/routine: 1 day
  - Moderate/some complexity: 2-4 days
  - Complex/multiple systems: 5-10 days
  - Very large/learning curve: 10+ days (but consider breaking into smaller tasks)
FORMAT: String describing duration

FIELD: "due_date"
DESCRIPTION: Target completion date (MUST be before project deadline)
REQUIRED: YES
FORMAT: "YYYY-MM-DD" (ISO 8601 format)
CALCULATION: Start date + duration + buffer for dependencies
EXAMPLE: "2025-02-15"

FIELD: "effort_level"
REQUIRED: YES
FORMAT: One of: "Low" (1 day), "Medium" (2-5 days), "High" (5-10 days)

FIELD: "complexity"
REQUIRED: YES
FORMAT: One of: "trivial", "simple", "moderate", "complex", "very_complex"
GUIDE:
  - trivial: Single function, <100 lines code
  - simple: Single component/feature, straightforward logic
  - moderate: Contains integration, multiple components, some testing
  - complex: Multiple systems, heavy testing, architectural decisions
  - very_complex: Significant learning curve, major architectural work

FIELD: "deliverables"
DESCRIPTION: Concrete outputs that can be verified (NOT vague)
REQUIRED: YES
BAD: ["Code", "Feature", "Tests"]
GOOD: ["API endpoints documented in Swagger", "Docker image pushed to ECR", "GitHub PR merged with 2+ approvals"]
FORMAT: Array of specific, verifiable deliverables (2-3 minimum)

FIELD: "risk_factors"
DESCRIPTION: Specific risks that could impact THIS task
REQUIRED: YES
MUST BE SPECIFIC: Identify actual risks, not generic risks
BAD: ["Might be hard", "Team knowledge", "Technical complexity"]
GOOD: ["Third-party notification service has 99.9% SLA (0.1% downtime risk)", "Team lacks Kubernetes experience (learning curve: +2 days)", "Payment API rate limits (100 req/min) may impact load tests"]
FORMAT: Array of specific, identified risks

FIELD: "success_metrics"
DESCRIPTION: Quantifiable measures of task success
REQUIRED: YES
EXAMPLES: ["Email delivery within 30 seconds", "Zero unhandled exceptions in logs", "Response time < 200ms at 100 req/s"]
FORMAT: Array of measurable metrics

═══════════════════════════════════════════════════════════════════════════════
🎯 VALIDATION RULES (Your final output must satisfy ALL):
═══════════════════════════════════════════════════════════════════════════════
1. ✓ Total tasks: 8-12 (not fewer, not more)
2. ✓ Each task ID is unique and sequential (task_1, task_2, ... task_N)
3. ✓ Each task has task name (no placeholders, specific to project)
4. ✓ Each task has 2-4 acceptance criteria (measurable, not generic)
5. ✓ Each task has 2+ technical requirements (specific tools/libs, not "framework")
6. ✓ Each task has realistic duration (2-10 days, not 1 day, not 20 days)
7. ✓ Dependencies form valid DAG (no cycles: A→B→C→A is invalid)
8. ✓ All due_dates are properly formatted (YYYY-MM-DD) and before project deadline
9. ✓ Each task has 2+ deliverables (specific outputs, not generic)
10. ✓ Each task has 1+ risk factors (specific technical risks identified)
11. ✓ All effort_level values are one of: "Low", "Medium", "High"
12. ✓ All complexity values are one of: "trivial", "simple", "moderate", "complex", "very_complex"
13. ✓ NO placeholder text anywhere (no "Task X", "Tech 1", "Risk 1")
14. ✓ Task names are 5-10 words and domain-specific
15. ✓ First 2-3 tasks should be setup/foundation with no/few dependencies
16. ✓ Last task should relate to testing, deployment, or launch
17. ✓ Descriptions are detailed (100+ characters, not vague)

═══════════════════════════════════════════════════════════════════════════════
📤 RETURN FORMAT (CRITICAL: JSON ONLY, NO OTHER TEXT):
═══════════════════════════════════════════════════════════════════════════════
Return ONLY valid JSON with NO markdown, NO explanations, NO text outside JSON:

{{
    "tasks": [
        {{
            "id": "task_1",
            "name": "Specific, detailed task name (5-10 words)",
            "description": "Detailed description with context and purpose (100-300 chars)",
            "acceptance_criteria": [
                "Measurable criterion 1",
                "Measurable criterion 2", 
                "Measurable criterion 3"
            ],
            "technical_requirements": [
                "Specific framework with version: Node.js 18+, Express 4.18+",
                "Database: PostgreSQL 14 with UUID extension",
                "Tool/Standard: Docker, JWT-based authentication"
            ],
            "dependencies": ["task_X", "task_Y"],
            "estimated_duration": "3-4 days",
            "due_date": "YYYY-MM-DD",
            "effort_level": "Medium",
            "complexity": "moderate",
            "deliverables": [
                "GitHub PR merged with passing CI/CD",
                "API documentation in OpenAPI format",
                "Code with 80%+ test coverage"
            ],
            "risk_factors": [
                "Third-party service API may have breaking changes",
                "Team lacks experience with chosen framework (+1-2 days learning)"
            ],
            "success_metrics": [
                "API responds within 200ms at 100 req/s",
                "Zero unhandled exceptions in staging logs"
            ]
        }}
        // ... more tasks (8-12 total)
    ]
}}

Remember: ONLY JSON output. No text before, after, or between JSON content.
Quality over quantity: Specific, detailed tasks are better than vague, generic ones.
"""
        return full_prompt
    
    @staticmethod
    def generate_quality_subtask_prompt(task_data: Dict[str, Any]) -> str:
        """Generate a prompt for breaking down a task into high-quality sub_tasks"""
        
        return f"""You are PRAXIS, the official AI Support Agent, and an expert technical project manager breaking down complex tasks into manageable, specific sub-tasks.

═══════════════════════════════════════════════════════════════════════════════
📋 PARENT TASK TO DECOMPOSE:
═══════════════════════════════════════════════════════════════════════════════
Name: {task_data.get('name', '')}
Description: {task_data.get('description', '')}
Duration: {task_data.get('estimated_duration', '')}
Acceptance Criteria: {json.dumps(task_data.get('acceptance_criteria', []))}
Technical Requirements: {json.dumps(task_data.get('technical_requirements', []))}

═══════════════════════════════════════════════════════════════════════════════
⚙️  SUBTASK DECOMPOSITION RULES:
═══════════════════════════════════════════════════════════════════════════════

✅ EXCELLENT SUBTASKS:
- Each subtask is 1-3 days of work (8-24 hours)
- Subtasks are sequential or have clear ordering
- Each subtask has specific deliverable (code, test, doc)
- Subtasks flow logically: Setup → Implementation → Testing → Documentation
- Dependencies are clear between subtasks
- Each subtask can be completed independently by one developer
- Task names are specific: "Write password reset API endpoint" not "Implementation"

❌ POOR SUBTASKS:
- Too vague: "Work on feature", "Testing", "Code review"
- Too broad: Combines multiple concerns (API + Database + Frontend)
- Too small: "Add this variable", "Change this method name"
- Unclear dependencies: Hard to tell what must happen first

═══════════════════════════════════════════════════════════════════════════════
📏 DETAILED SUBTASK BREAKDOWN CHECKLIST:
═══════════════════════════════════════════════════════════════════════════════

For a parent task taking 5 days, plan 4-5 subtasks of 1-2 days each:

1️⃣  SETUP SUBTASK (Day 0-0.5)
   - Set up development environment
   - Create project files/folders
   - Install dependencies
   - Create test structure

2️⃣  CORE IMPLEMENTATION (Days 0.5-3)
   - Break into multiple implementation subtasks by feature/component
   - Each subtask: single responsibility, focused scope
   - Examples: "Implement password hashing with bcrypt", "Add database schema migrations"

3️⃣  INTEGRATION SUBTASK (Days 3-4)
   - Connect components together
   - Wire up API endpoints
   - Connect to database
   - Handle errors

4️⃣  TESTING SUBTASK (Days 4-4.5)
   - Unit tests for individual components
   - Integration tests across components
   - Edge case testing

5️⃣  DOCUMENTATION SUBTASK (Days 4.5-5)
   - Code comments and docstrings
   - API documentation
   - README updates
   - Deployment instructions

═══════════════════════════════════════════════════════════════════════════════
📝 SUBTASK FIELD SPECIFICATIONS:
═══════════════════════════════════════════════════════════════════════════════

FIELD: "name"
TYPE: String
DESCRIPTION: Specific subtask name (3-7 words)
GOOD: "Implement JWT token generation with expiry", "Write unit tests for encoder"
BAD: "Code", "Testing", "Implementation"

FIELD: "description"  
TYPE: String
DESCRIPTION: Detailed explanation (100-200 chars)
SHOULD INCLUDE: What will be built, why, acceptance criteria summary

FIELD: "acceptance_criteria"
TYPE: Array of strings
DESCRIPTION: 2-3 specific, measurable criteria for this subtask
GOOD: [
  "Function generates valid JWT token with 1-hour expiry",
  "Token includes user ID and permission scopes",
  "Token can be decoded and verified"
]

FIELD: "estimated_hours"
TYPE: Number
VALID RANGE: 4-24 hours (1-3 days)
GUIDE:
  - 4 hours: Simple, straightforward task
  - 8 hours: Moderate task with testing
  - 12 hours: Complex task, multiple parts
  - 16-24 hours: Very complex OR includes testing

FIELD: "order"
TYPE: Number
DESCRIPTION: Sequential position (1, 2, 3, ...)
MEANS: Tasks with lower order numbers should be completed first
MUST BE SEQUENTIAL: [1, 2, 3, 4, 5] not [1, 3, 5]

FIELD: "technical_requirements"
TYPE: Array of strings
DESCRIPTION: Specific technologies/tools needed for this subtask
GOOD: ["bcrypt library for hashing", "JWT library: PyJWT", "PostgreSQL client"]
BAD: ["Security library", "Database"]

FIELD: "depends_on_subtask"
TYPE: null or Number
DESCRIPTION: Order number of subtask that must complete first
EXAMPLE: 2 means this subtask depends on subtask with order: 2
NOTE: Use null if no dependency (can be done in parallel with others)

FIELD: "testing_approach"
TYPE: String
DESCRIPTION: How will this subtask be tested/verified?
GOOD: "Unit tests with 95%+ coverage, mock database calls"
GOOD: "Manual testing with test user account, verify email received"
GOOD: "Integration test connecting API → Database → External service"

FIELD: "deliverables"
TYPE: Array of strings (2-3 items)
DESCRIPTION: Concrete outputs/files that will be created
GOOD: ["JWT generation function with docstring", "Unit test file with 15+ test cases"]
BAD: ["Code", "Tests"]

═══════════════════════════════════════════════════════════════════════════════
✅ VALIDATION (ALL must be satisfied):
═══════════════════════════════════════════════════════════════════════════════
1. ✓ 3-5 subtasks total (not 1, not 10)
2. ✓ Each subtask is 4-24 hours (1-3 days)
3. ✓ "order" field is sequential: 1, 2, 3, 4, 5
4. ✓ Total hours roughly equals parent task duration
5. ✓ Subtask names are specific (5+ words, actionable)
6. ✓ Each subtask has 2-3 acceptance criteria
7. ✓ Dependencies are valid (subtask depends on lower order number only)
8. ✓ No circular dependencies
9. ✓ Each subtask has specific testing_approach
10. ✓ Each subtask has 2-3 concrete deliverables
11. ✓ First subtask has "depends_on_subtask": null
12. ✓ Technical requirements are specific (not generic)

═══════════════════════════════════════════════════════════════════════════════
📤 RETURN FORMAT (JSON ONLY, NO OTHER TEXT):
═══════════════════════════════════════════════════════════════════════════════
Return ONLY this exact JSON with NO text before, after, or mixed in:

{{
    "parent_task_name": "{task_data.get('name', '')}",
    "parent_task_duration": "{task_data.get('estimated_duration', '')}",
    "sub_tasks": [
        {{
            "name": "Specific subtask name (3-7 words)",
            "description": "Detailed explanation of what will be done",
            "acceptance_criteria": [
                "Specific acceptance criterion 1",
                "Specific acceptance criterion 2",
                "Specific acceptance criterion 3"
            ],
            "estimated_hours": 12,
            "order": 1,
            "technical_requirements": [
                "Specific framework/library with version",
                "Tool needed",
                "Standard/pattern to follow"
            ],
            "depends_on_subtask": null,
            "testing_approach": "How this subtask will be tested/verified",
            "deliverables": [
                "Specific deliverable 1 (file, function, PR, etc.)",
                "Specific deliverable 2",
                "Specific deliverable 3"
            ]
        }}
        // ... 3-5 total subtasks
    ]
}}

CRITICAL RULES:
- ONLY JSON output. No markdown, no explanations, no text outside JSON.
- Quality over quantity: Specific subtasks are better than vague ones.
- Each subtask must contribute directly to the parent task's acceptance criteria.
- Subtasks should flow in logical order (setup → implementation → testing → docs).
"""
    
    @staticmethod
    
    @staticmethod
    def validate_task_quality(task: Dict[str, Any]) -> tuple[bool, List[str]]:
        """Validate task quality and return issues found"""
        issues = []
        
        # Check for specific, non-generic names
        generic_words = ["task", "work", "do", "make", "create", "implement", "fix", "update", "change"]
        if any(word in task.get("name", "").lower() for word in generic_words):
            # Allow these if they're more specific
            if len(task.get("name", "")) < 10:
                issues.append(f"Task name too generic: '{task.get('name')}'")
        
        # Check description length
        if len(task.get("description", "")) < 50:
            issues.append("Description too brief - provide more context")
        
        # Check acceptance criteria
        criteria = task.get("acceptance_criteria", [])
        if not criteria or len(criteria) < 2:
            issues.append("Need at least 2 acceptance criteria")
        
        # Check for deliverables
        if not task.get("deliverables"):
            issues.append("Missing deliverables")
        
        # Check for time estimate
        if not task.get("estimated_duration"):
            issues.append("Missing time estimate")
        
        # Check for technical requirements
        if not task.get("technical_requirements"):
            issues.append("Missing technical requirements")
        
        return len(issues) == 0, issues


class NicheTaskGenerator:
    """Generate niche-specific task templates and examples"""
    
    NICHE_TEMPLATES = {
        ProjectNiche.WEB_DEVELOPMENT: {
            "phases": [
                "Project Setup & Architecture",
                "Backend API Development",
                "Database Design & Migration",
                "Frontend Development",
                "Integration & Testing",
                "Performance Optimization",
                "Security Hardening",
                "Deployment & DevOps"
            ],
            "key_tasks": [
                "Design REST API endpoints with OpenAPI/Swagger documentation",
                "Implement user authentication with JWT/OAuth2",
                "Create responsive UI components with accessibility compliance",
                "Set up CI/CD pipeline with automated testing",
                "Implement database migrations and versioning",
                "Set up monitoring and error tracking"
            ]
        },
        ProjectNiche.MOBILE_APP: {
            "phases": [
                "Design & Prototyping",
                "Project Setup",
                "Core Features Development",
                "UI/UX Implementation",
                "Testing on Devices",
                "Performance Optimization",
                "App Store Submission",
                "Post-Launch Support"
            ],
            "key_tasks": [
                "Create low-fidelity wireframes and high-fidelity mockups",
                "Implement native platform-specific features",
                "Set up local and remote data persistence",
                "Implement push notifications and deep linking",
                "Create app store submission materials",
                "Set up crash reporting and analytics"
            ]
        },
        ProjectNiche.DATA_SCIENCE: {
            "phases": [
                "Problem Definition & Data Collection",
                "Exploratory Data Analysis",
                "Data Cleaning & Preprocessing",
                "Feature Engineering",
                "Model Development",
                "Model Evaluation & Validation",
                "Visualization & Reporting",
                "Deployment & Monitoring"
            ],
            "key_tasks": [
                "Collect and document data sources",
                "Perform statistical analysis and visualization",
                "Handle missing values and outliers",
                "Engineer domain-specific features",
                "Build and compare baseline models",
                "Create interactive dashboards and reports"
            ]
        }
    }
    
    @staticmethod
    def get_niche_template(niche: ProjectNiche) -> Optional[Dict[str, Any]]:
        """Get template for a specific niche"""
        return NicheTaskGenerator.NICHE_TEMPLATES.get(niche)
    
    @staticmethod
    def suggest_tasks_for_niche(niche: ProjectNiche, context: Dict[str, Any]) -> List[str]:
        """Suggest high-quality tasks based on niche and context"""
        template = NicheTaskGenerator.get_niche_template(niche)
        if not template:
            return []
        
        suggestions = []
        for phase in template.get("phases", []):
            suggestions.append(f"[Phase] {phase}")
        
        for task in template.get("key_tasks", []):
            suggestions.append(f"- {task}")
        
        return suggestions
