# github_controller.py
from typing import List, Dict, Optional, Any
from motor.motor_asyncio import AsyncIOMotorDatabase

from database import get_database
from services.github_service import github_service
from utils import convert_objectid, get_current_time

class GitHubController:
    def __init__(self):
        self.db: Optional[AsyncIOMotorDatabase] = None

    def get_db(self) -> AsyncIOMotorDatabase:
        """
        Retrieves the database connection.
        Uses a local variable to satisfy strict type checkers (Pylance).
        """
        if self.db is not None:
            return self.db
            
        # Fetch fresh connection
        db_connection = get_database()
        
        # Strict check: If connection failed, raise exception immediately
        if db_connection is None:
            raise Exception("Database connection not available")
            
        self.db = db_connection
        return self.db

    async def sync_commits(self, project_id: str, username: str, repo: str) -> Dict[str, Any]:
        """Sync GitHub commits for a project"""
        db = self.get_db()
        
        # Validate repository exists
        is_valid = await github_service.validate_repo(username, repo)
        if not is_valid:
            raise ValueError("Repository not found or not accessible")
        
        # Get last sync timestamp for THIS repository.
        # If we use the latest commit across the whole project, syncing a different repo
        # that only has older commits will incorrectly fetch 0 commits.
        last_commit = await db.github_commits.find_one(
            {
                "project_id": project_id,
                "username": username,
                "repo": repo,
            },
            sort=[("timestamp", -1)],
        )
        
        since = None
        if last_commit:
            since = last_commit.get("timestamp")
        
        # Fetch new commits
        commits = await github_service.fetch_commits(username, repo, since)
        
        # Safety check: ensure commits is a list (in case service returns None)
        if commits is None:
            commits = []
        
        # Save commits to database
        saved_commits = 0
        for commit_data in commits:
            commit_doc = {
                **commit_data,
                "project_id": project_id,
                "username": username,
                "repo": repo,
                "synced_at": get_current_time()
            }
            
            # Check if commit already exists
            existing = await db.github_commits.find_one(
                {
                    "commitSha": commit_data.get("commitSha") or commit_data.get("commit_sha"),
                    "project_id": project_id,
                    "username": username,
                    "repo": repo,
                }
            )
            
            if not existing:
                await db.github_commits.insert_one(commit_doc)
                saved_commits += 1
        
        # Return MUST be outside the loop
        return {
            "message": f"Synced {saved_commits} new commits",
            "total_fetched": len(commits),
            "saved_commits": saved_commits
        }

    async def sync_selected_commits(
        self,
        project_id: str,
        username: str,
        repo: str,
        shas: List[str],
    ) -> Dict[str, Any]:
        """Sync only the specified commit SHAs for a repository."""
        db = self.get_db()

        # Validate repository exists
        is_valid = await github_service.validate_repo(username, repo)
        if not is_valid:
            raise ValueError("Repository not found or not accessible")

        # Normalize and de-duplicate SHAs
        normalized: List[str] = []
        seen = set()
        for s in shas or []:
            if not isinstance(s, str):
                continue
            sha = s.strip()
            if not sha:
                continue
            if sha in seen:
                continue
            seen.add(sha)
            normalized.append(sha)

        if len(normalized) == 0:
            raise ValueError("No commit SHAs provided")

        # Guardrail against accidental large payloads
        if len(normalized) > 50:
            raise ValueError("Too many commits selected (max 50)")

        requested = len(normalized)
        fetched = 0
        saved_commits = 0
        not_found = 0

        for sha in normalized:
            commit_data = await github_service.fetch_commit_by_sha(username, repo, sha)
            if not commit_data:
                not_found += 1
                continue
            fetched += 1

            commit_doc = {
                **commit_data,
                "project_id": project_id,
                "username": username,
                "repo": repo,
                "synced_at": get_current_time(),
            }

            existing = await db.github_commits.find_one(
                {
                    "commit_sha": commit_doc.get("commit_sha"),
                    "project_id": project_id,
                    "username": username,
                    "repo": repo,
                }
            )

            if not existing:
                await db.github_commits.insert_one(commit_doc)
                saved_commits += 1

        # Return MUST be outside the loop
        base_message = f"Synced {saved_commits} selected commits"
        if not_found:
            base_message = f"{base_message} ({not_found} not found)"

        return {
            "message": base_message,
            "requested": requested,
            "total_fetched": fetched,
            "saved_commits": saved_commits,
            "not_found": not_found,
        }
    
    async def get_project_commits(self, project_id: str, limit: int = 50) -> List[Dict]:
        """Get GitHub commits for a project"""
        db = self.get_db()
        cursor = db.github_commits.find({"project_id": project_id}).sort("timestamp", -1).limit(limit)
        commits = await cursor.to_list(length=limit)
        return convert_objectid(commits)
    
    async def get_recent_commits(self, project_id: str, limit: int = 10) -> List[Dict]:
        """Get recent commits for dashboard"""
        return await self.get_project_commits(project_id, limit)
    
    async def get_commit_stats(self, project_id: str) -> Dict[str, int]:
        """Get commit statistics for a project"""
        
        # Get all commits (limit increased for stats)
        commits = await self.get_project_commits(project_id, 1000)
        
        if not commits:
            return {
                "totalCommits": 0,
                "totalAdditions": 0,
                "totalDeletions": 0,
                "uniqueAuthors": 0,
                "filesChanged": 0
            }
        
        total_commits = len(commits)
        # Use safe .get() calls for all fields
        total_additions = sum([c.get("additions", 0) for c in commits])
        total_deletions = sum([c.get("deletions", 0) for c in commits])
        unique_authors = len(set([c.get("author", "unknown") for c in commits]))
        
        # Complex list comprehension to count unique files
        all_files = []
        for c in commits:
            files = c.get("filesChanged", [])
            if isinstance(files, list):
                all_files.extend(files)
                
        files_changed = len(set(all_files))
        
        return {
            "totalCommits": total_commits,
            "totalAdditions": total_additions,
            "totalDeletions": total_deletions,
            "uniqueAuthors": unique_authors,
            "filesChanged": files_changed
        }

# Create controller instance
github_controller = GitHubController()