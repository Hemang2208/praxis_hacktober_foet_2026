#!/usr/bin/env python3
"""
Test script for the new Generate Related Tasks API endpoint.

This script tests the new API that generates multiple related tasks 
based on a reference task.

Usage:
    python test_related_tasks.py
"""

import asyncio
import aiohttp
import json
from datetime import datetime

# Configuration
BASE_URL = "http://localhost:8003/api/v1"
PROJECT_ID = "test-project-123"  # Update with actual project ID
TASK_ID = "test-task-789"  # Update with actual task ID from your database

async def create_sample_task(session):
    """Create a sample task for testing"""
    print("\n1️⃣  Creating a sample task...")
    
    task_data = {
        "title": "API Endpoint Design",
        "description": "Design comprehensive RESTful API endpoints with proper documentation and error handling",
        "priority": "high",
        "estimated_hours": 8,
        "tags": ["backend", "api"],
        "dependencies": []
    }
    
    url = f"{BASE_URL}/projects/{PROJECT_ID}/tasks"
    
    try:
        async with session.post(url, json=task_data) as response:
            if response.status == 200:
                result = await response.json()
                task_id = result.get("task", {}).get("_id") or result.get("task", {}).get("id")
                print(f"✅ Sample task created: {task_id}")
                return task_id
            else:
                print(f"❌ Failed to create task: {response.status}")
                print(await response.text())
                return None
    except Exception as e:
        print(f"❌ Error creating task: {e}")
        return None


async def test_generate_related_tasks(session, task_id):
    """Test generating related tasks"""
    print(f"\n2️⃣  Testing Generate Related Tasks API...")
    
    # Test with different counts
    test_counts = [2, 4, 6]
    
    for count in test_counts:
        print(f"\n   Testing with count={count}...")
        url = f"{BASE_URL}/projects/{PROJECT_ID}/tasks/{task_id}/generate-related-tasks?count={count}"
        
        try:
            async with session.post(url) as response:
                if response.status == 200:
                    result = await response.json()
                    tasks = result.get("tasks", [])
                    print(f"   ✅ Successfully generated {len(tasks)} related tasks")
                    
                    # Display generated tasks
                    for i, task in enumerate(tasks, 1):
                        print(f"\n      Task {i}:")
                        print(f"        Title: {task.get('title')}")
                        print(f"        Description: {task.get('description')[:100]}...")
                        print(f"        Priority: {task.get('priority')}")
                        print(f"        Estimated Hours: {task.get('estimated_hours')}")
                        print(f"        Dependencies: {task.get('dependencies')}")
                else:
                    error_detail = await response.text()
                    print(f"   ❌ Error (status {response.status}): {error_detail}")
        except Exception as e:
            print(f"   ❌ Exception: {e}")


async def run_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("Testing Generate Related Tasks API")
    print("="*60)
    
    async with aiohttp.ClientSession() as session:
        # Try to use existing task or create a new one
        task_id = TASK_ID
        
        # First, try to get an existing task from the project
        print(f"\nChecking for existing tasks in project {PROJECT_ID}...")
        try:
            async with session.get(f"{BASE_URL}/projects/{PROJECT_ID}/tasks") as response:
                if response.status == 200:
                    tasks = await response.json()
                    if isinstance(tasks, dict):
                        tasks = tasks.get("tasks", [])
                    if tasks and len(tasks) > 0:
                        task_id = tasks[0].get("_id") or tasks[0].get("id")
                        print(f"✅ Found existing task: {task_id}")
                    else:
                        print("No existing tasks found, will create one...")
                        task_id = await create_sample_task(session)
                        if not task_id:
                            print("\n❌ Could not create sample task, aborting test.")
                            return
        except Exception as e:
            print(f"Could not fetch existing tasks, will create one...")
            task_id = await create_sample_task(session)
            if not task_id:
                print("\n❌ Could not create sample task, aborting test.")
                return
        
        # Run the actual test
        if task_id:
            await test_generate_related_tasks(session, task_id)
    
    print("\n" + "="*60)
    print("Test Complete!")
    print("="*60 + "\n")


async def test_api_integration():
    """Test the actual API endpoint"""
    print("\n🔍 Testing API endpoint directly...")
    
    async with aiohttp.ClientSession() as session:
        # Test 1: Create a test project and task
        print("\n1️⃣  Setting up test data...")
        
        # Fetch or create a test task
        test_task_id = "test-task-" + str(int(datetime.now().timestamp()))
        test_project_id = "test-project-" + str(int(datetime.now().timestamp()))
        
        # Try with a sample task
        sample_task = {
            "title": "Design Database Schema",
            "description": "Create comprehensive database schema with proper normalization, indexing strategy, and migration scripts",
            "priority": "high",
            "estimated_hours": 12,
            "tags": ["database", "backend"],
            "dependencies": []
        }
        
        # Create task
        async with session.post(
            f"{BASE_URL}/projects/{test_project_id}/tasks",
            json=sample_task
        ) as response:
            if response.status == 200:
                result = await response.json()
                actual_task_id = result.get("task", {}).get("_id") or result.get("task", {}).get("id")
                if actual_task_id:
                    print(f"✅ Created test task: {actual_task_id}")
                    
                    # Test generate related tasks
                    print(f"\n2️⃣  Testing generate related tasks with count=4...")
                    async with session.post(
                        f"{BASE_URL}/projects/{test_project_id}/tasks/{actual_task_id}/generate-related-tasks?count=4"
                    ) as gen_response:
                        if gen_response.status == 200:
                            gen_result = await gen_response.json()
                            print(f"✅ Successfully generated tasks:")
                            print(json.dumps(gen_result, indent=2, default=str))
                        else:
                            print(f"❌ Error generating tasks: {gen_response.status}")
                            print(await gen_response.text())
                else:
                    print(f"❌ Could not parse task ID from response")
            else:
                print(f"❌ Failed to create test task: {response.status}")


if __name__ == "__main__":
    print("Starting Generate Related Tasks API tests...")
    
    try:
        # Run the full test suite
        asyncio.run(run_tests())
        
        # Also run direct integration test
        print("\n🔄 Running direct API integration test...")
        asyncio.run(test_api_integration())
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Tests interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
