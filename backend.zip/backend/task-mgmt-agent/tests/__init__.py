# tests init
