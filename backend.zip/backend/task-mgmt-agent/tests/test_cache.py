import pytest
import pytest_asyncio
import asyncio
from unittest.mock import AsyncMock, patch, MagicMock

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from shared.cache_utils import cache_manager, NULL_SENTINEL
from shared.lock import acquire_lock

@pytest_asyncio.fixture
async def mock_redis():
    mock = AsyncMock()
    # Mocking standard get/set behavior
    mock_store = {}
    
    async def mock_setex(key, ttl, value):
        mock_store[key] = value
        return True
        
    async def mock_get(key):
        return mock_store.get(key)
        
    async def mock_execute_command(*args):
        # Handle bloom filter logic
        if args[0] == "BF.EXISTS":
            return 1 if args[2] in mock_store.get(args[1], set()) else 0
        if args[0] == "BF.ADD":
            if args[1] not in mock_store:
                mock_store[args[1]] = set()
            mock_store[args[1]].add(args[2])
            return 1
            
    # Handle distributed lock
    async def mock_set(*args, **kwargs):
        if kwargs.get("nx"):
            key = args[0]
            if key not in mock_store:
                mock_store[key] = args[1]
                return True
            return False
        return True
        
    async def mock_eval(*args):
        # Release lock logic
        key = args[2]
        val = args[3]
        if mock_store.get(key) == val:
            del mock_store[key]
            return 1
        return 0

    mock.setex = mock_setex
    mock.get = mock_get
    mock.execute_command = mock_execute_command
    mock.set = mock_set
    mock.eval = mock_eval
    
    cache_manager.redis = mock
    cache_manager.bloom_enabled = True
    
    yield mock
    
    cache_manager.redis = None


@pytest.mark.asyncio
async def test_bloom_filter_cache_penetration(mock_redis):
    """Test that a non-existent key fails the bloom filter check and returns False."""
    key = "test_key_does_not_exist"
    exists = await cache_manager.check_bloom(key)
    assert exists is False
    
    # After adding it, it should return True
    await cache_manager.bloom_add(key)
    exists = await cache_manager.check_bloom(key)
    assert exists is True


@pytest.mark.asyncio
async def test_null_caching(mock_redis):
    """Test that setting a NULL_SENTINEL works and is retrieved correctly."""
    key = "test_null_key"
    await cache_manager.set_cached(key, NULL_SENTINEL, ttl=60)
    
    data, is_stale = await cache_manager.get_cached(key)
    assert data == NULL_SENTINEL
    assert is_stale is False


@pytest.mark.asyncio
async def test_distributed_lock(mock_redis):
    """Test distributed locking mechanism prevents thundering herd."""
    lock_name = "test_lock"
    
    # First lock succeeds
    lock1 = await acquire_lock(cache_manager.redis, lock_name, timeout_ms=5000)
    assert await lock1.acquire() is True
    
    # Second lock fails
    lock2 = await acquire_lock(cache_manager.redis, lock_name, timeout_ms=5000)
    assert await lock2.acquire() is False
    
    # Releasing first lock allows second to succeed
    await lock1.release()
    assert await lock2.acquire() is True
    await lock2.release()


@pytest.mark.asyncio
async def test_soft_expiration(mock_redis):
    """Test that soft expiration flags stale data correctly."""
    key = "test_soft_key"
    value = {"data": "important"}
    
    # Set with 0 soft_ttl so it expires immediately for testing
    await cache_manager.set_cached(key, value, ttl=60, soft_ttl=0)
    
    # Wait a tiny bit to ensure time passes
    await asyncio.sleep(0.01)
    
    data, is_stale = await cache_manager.get_cached(key)
    assert data == value
    assert is_stale is True # It should be marked as stale
