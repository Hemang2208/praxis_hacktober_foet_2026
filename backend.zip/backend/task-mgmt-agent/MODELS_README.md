# Task Management Agent - Models Documentation

## Overview

The Task Management Agent models handle project task tracking, progress management, GitHub integration, and team collaboration. The agent provides comprehensive task lifecycle management with GitHub commit tracking.

## Table of Contents

- [Core Task Models](#core-task-models)
- [Request Models](#request-models)
- [Progress Tracking Models](#progress-tracking-models)
- [GitHub Integration Models](#github-integration-models)
- [Dashboard Models](#dashboard-models)
- [API Workflows](#api-workflows)
- [Status & Priority Values](#status--priority-values)

---

## Core Task Models

### SubTask

**Purpose**: Represents a smaller unit of work within a task

**Fields**:
- `title` (str): Subtask title
- `description` (str): Detailed description of what needs to be done
- `estimated_hours` (int): Estimated hours to complete (default: 1)
  - Use realistic estimates for planning
  - Can be adjusted based on progress
- `status` (str): Current status (default: "pending")
  - "pending" - Not started
  - "in_progress" - Currently being worked on
  - "completed" - Finished
  - "blocked" - Blocked by dependencies

**Example**:
```python
subtasks = [
    SubTask(
        title="Set up database connection",
        description="Create and test database connection pool",
        estimated_hours=2,
        status="completed"
    ),
    SubTask(
        title="Implement user repository",
        description="Create CRUD operations for users",
        estimated_hours=4,
        status="in_progress"
    ),
    SubTask(
        title="Write unit tests",
        description="Write comprehensive unit tests",
        estimated_hours=3,
        status="pending"
    )
]
```

### Task

**Purpose**: Main project task with all tracking information

**Fields**:
- `id` (str, optional): Task ID (assigned by database)
- `project_id` (str): Associated project ID (required)
- `title` (str): Task title (required)
- `description` (str): Detailed task description (required)
- `status` (str): Task status
  - "pending" - Not started
  - "in_progress" - Currently being worked on
  - "completed" - Finished
  - "blocked" - Blocked by dependencies or issues
- `priority` (str): Priority level
  - "low" - Low priority, can be deferred
  - "medium" - Normal priority
  - "high" - High priority, should be addressed soon
- `estimated_hours` (int): Total estimated hours (default: 1)
- `actual_hours` (int): Actual hours spent (default: 0)
- `dependencies` (List[str]): IDs of tasks that must complete first (default: [])
  - Empty list means no dependencies
  - Used to build task dependency graph
- `sub_tasks` (List[SubTask]): Breakdown of this task (default: [])
- `assigned_to` (str, optional): User ID of assignee
- `created_at` (datetime, optional): Creation timestamp
- `updated_at` (datetime, optional): Last update timestamp
- `due_date` (datetime, optional): Task deadline

**Example**:
```python
task = Task(
    project_id="proj_123",
    title="Implement User Authentication",
    description="Add JWT-based authentication system",
    status="in_progress",
    priority="high",
    estimated_hours=16,
    actual_hours=8,
    dependencies=[],
    sub_tasks=subtasks,
    assigned_to="user_001",
    due_date=datetime(2024, 2, 15)
)
```

**Relationships**:
- Each Task has optional SubTasks
- Tasks can depend on other Tasks via dependency IDs
- Tasks belong to a Project via project_id

### TaskCreate

**Purpose**: Request model for creating a new task

**Fields**:
- `title` (str): Task title (required)
- `description` (str): Task description (required)
- `priority` (str): Priority (default: "medium")
- `estimated_hours` (int): Estimated hours (default: 1)
- `dependencies` (List[str]): Task dependencies (default: [])
- `sub_tasks` (List[SubTask]): Initial subtasks (default: [])
- `assigned_to` (str, optional): Initial assignee
- `due_date` (datetime, optional): Task deadline

**Example**:
```python
create_request = TaskCreate(
    title="Code Review & Testing",
    description="Review code and execute test suite",
    priority="high",
    estimated_hours=4,
    dependencies=["task_001"],  # Depends on implementation
    sub_tasks=[
        SubTask(title="Run unit tests", estimated_hours=1),
        SubTask(title="Run integration tests", estimated_hours=2),
        SubTask(title="Peer code review", estimated_hours=1)
    ],
    assigned_to="user_002",
    due_date=datetime(2024, 2, 10)
)
```

---

## Request Models

### Workflow Models

All request models are standardized Pydantic models with proper validation:

```python
# Example of creating tasks in batch
tasks_to_create = [
    TaskCreate(title="Design Phase", priority="high"),
    TaskCreate(title="Development Phase", priority="high"),
    TaskCreate(title="Testing Phase", priority="medium")
]

# Send to API
responses = [create_task(project_id, t) for t in tasks_to_create]
```

---

## Progress Tracking Models

### ProgressUpdate

**Purpose**: Record progress updates for a task

**Fields**:
- `task_id` (str): Task being updated (required)
- `status` (str): New status (required)
  - "pending" - Move back to pending
  - "in_progress" - Start/continue work
  - "completed" - Mark as complete
  - "blocked" - Mark as blocked
- `hours_worked` (int): Hours worked in this update (default: 0)
  - Added to task's actual_hours
  - Use to track incremental progress
- `notes` (str, optional): Update notes/comments
  - Can include blockers, next steps, etc.

**Example**:
```python
update = ProgressUpdate(
    task_id="task_001",
    status="in_progress",
    hours_worked=2,
    notes="Started implementation, database design complete"
)

# Later...
update2 = ProgressUpdate(
    task_id="task_001",
    status="in_progress",
    hours_worked=3,
    notes="Core logic implemented, debugging integration issues"
)

# Completion
update3 = ProgressUpdate(
    task_id="task_001",
    status="completed",
    hours_worked=1,
    notes="Task complete, all tests passing"
)
```

**Usage Pattern**:
- Send update when starting work
- Send periodic updates during work
- Send final update when complete
- Cumulative: actual_hours increases with each update

---

## GitHub Integration Models

### GitHubCommit

**Purpose**: Track commits associated with a task

**Fields**:
- `commit_sha` (str): Full commit SHA hash
- `message` (str): Commit message
- `author` (str): Committer name/email
- `timestamp` (datetime): When commit was made
- `files_changed` (List[str]): Files modified (default: [])
  - Full file paths relative to repo root
- `additions` (int): Lines added (default: 0)
- `deletions` (int): Lines deleted (default: 0)

**Example**:
```python
commits = [
    GitHubCommit(
        commit_sha="abc123def456789",
        message="feat: implement user authentication",
        author="alice@example.com",
        timestamp=datetime(2024, 1, 15, 10, 30),
        files_changed=["app/auth.py", "app/models.py", "tests/test_auth.py"],
        additions=250,
        deletions=45
    ),
    GitHubCommit(
        commit_sha="def456ghi789abc",
        message="fix: handle edge case in token validation",
        author="alice@example.com",
        timestamp=datetime(2024, 1, 15, 14, 20),
        files_changed=["app/auth.py"],
        additions=15,
        deletions=8
    )
]
```

**GitHub Integration**:
- Fetch commits associated with task
- Parse commit messages for task references
- Track development activity
- Measure code impact (lines changed)

---

## Task Assignment Models

### TaskAssignment

**Purpose**: Handle task assignment to single or multiple users

**Fields**:
- `task_id` (str): Task to assign (required)
- `user_id` (str): Single user assignment (for backward compatibility)
- `user_ids` (List[str], optional): Multiple user assignment (new feature)
- `notes` (str, optional): Assignment notes
  - Can include instructions, context, etc.

**Example**:
```python
# Single user assignment (legacy)
assignment = TaskAssignment(
    task_id="task_001",
    user_id="user_001",
    notes="You have this task - please ping me with questions"
)

# Multiple users (new)
assignment_multi = TaskAssignment(
    task_id="task_002",
    user_ids=["user_001", "user_002"],
    notes="Pair programming task - collaborate together"
)

# Update without assignment
unassign = TaskAssignment(
    task_id="task_003",
    user_id="",
    notes="This task is now unassigned, open for anyone"
)
```

**Features**:
- Supports both single and multiple assignments
- Can include contextual notes
- Maintains assignment history

---

## Dashboard Models

### ProjectDashboard

**Purpose**: Complete project overview for dashboard display

**Fields**:
- `project_id` (str): Project being displayed
- `statistics` (Dict): Project statistics
  - Keys might include: "total_tasks", "completed_tasks", "in_progress_tasks",
    "blocked_tasks", "completion_rate", "average_velocity", etc.
  - Values are flexible (int, float, str) for different metrics
- `tasks` (List[Task]): All tasks for the project
- `recent_commits` (List[Dict]): Recent GitHub commits
  - Each dict contains commit information from GitHubCommit
  - Limited to most recent commits for dashboard
- `recent_progress` (List[Dict]): Recent progress updates
  - Each dict contains progress update information
  - Shows activity timeline

**Example**:
```python
dashboard = ProjectDashboard(
    project_id="proj_123",
    statistics={
        "total_tasks": 25,
        "completed_tasks": 12,
        "in_progress_tasks": 10,
        "blocked_tasks": 3,
        "completion_rate": 48.0,
        "average_velocity": 3.5,  # tasks/week
        "total_hours_estimated": 200,
        "total_hours_actual": 95
    },
    tasks=[task1, task2, task3, ...],
    recent_commits=[
        {
            "commit_sha": "abc123",
            "message": "feat: implement authentication",
            "author": "alice@example.com",
            "timestamp": "2024-01-15T14:20:00",
            "additions": 250,
            "deletions": 45
        },
        # More commits...
    ],
    recent_progress=[
        {
            "task_id": "task_001",
            "status": "in_progress",
            "hours_worked": 3,
            "timestamp": "2024-01-15T16:00:00",
            "notes": "Core implementation complete"
        },
        # More updates...
    ]
)
```

**Dashboard Use Cases**:
- Project overview display
- Progress tracking
- Team activity feed
- Velocity/burndown charts
- Resource allocation view

---

## API Workflows

### Task Creation Workflow

**Step 1: Create Task**
```
Client → POST /projects/{project_id}/tasks
Body: TaskCreate
```

**Step 2: Processing**
- Validate project exists
- Validate dependencies exist
- Create task record
- Assign ID and timestamps

**Step 3: Response**
```
Server → Task
Returns: complete task with ID
```

### Progress Update Workflow

**Step 1: Update Progress**
```
Client → PATCH /tasks/{task_id}/progress
Body: ProgressUpdate
```

**Step 2: Processing**
- Validate task exists
- Update status
- Add hours to actual_hours
- Record update timestamp

**Step 3: Response**
```
Server → Task
Returns: updated task
```

### Task Assignment Workflow

**Step 1: Assign Task**
```
Client → POST /tasks/{task_id}/assign
Body: TaskAssignment
```

**Step 2: Processing**
- Validate task exists
- Update assignment
- Record change
- Notify assignee (optional)

**Step 3: Response**
```
Server → Task
Returns: updated task with new assignment
```

### Dashboard Workflow

**Step 1: Request Dashboard**
```
Client → GET /projects/{project_id}/dashboard
```

**Step 2: Processing**
- Fetch project
- Get all tasks
- Calculate statistics
- Fetch recent commits
- Fetch recent updates
- Aggregate data

**Step 3: Response**
```
Server → ProjectDashboard
Returns: complete dashboard data
```

### GitHub Sync Workflow

**Step 1: Webhook from GitHub**
```
GitHub → POST /webhook/github
Payload: push event with commits
```

**Step 2: Processing**
- Parse commits
- Match to tasks via commit messages
- Create GitHubCommit records
- Update task associations

**Step 3: Storage**
- Store commits in database
- Update task commit lists
- Update dashboard data

---

## Status & Priority Values

### Valid Statuses

| Status | Description | Transitions |
|--------|-------------|-------------|
| `pending` | Not started | → in_progress, blocked |
| `in_progress` | Currently being worked | → completed, blocked, pending |
| `completed` | Finished and done | → (none - final state) |
| `blocked` | Blocked by issue/dependency | → pending, in_progress |

### Valid Priorities

| Priority | Description | Typical Use |
|----------|-------------|-------------|
| `low` | Low priority | Nice to have, can defer |
| `medium` | Normal priority | Regular work |
| `high` | High priority | Should do soon |

---

## Database Integration

### MongoDB Collections

```
Projects Collection
├── _id (ObjectId)
├── title (string)
├── description (string)
└── ... (project fields)

Tasks Collection
├── _id (ObjectId)
├── project_id (ObjectId) - index
├── title (string)
├── description (string)
├── status (string) - index
├── priority (string)
├── estimated_hours (int)
├── actual_hours (int)
├── dependencies (array of ObjectId)
├── sub_tasks (array of SubTask)
├── assigned_to (ObjectId)
├── created_at (datetime) - index
├── updated_at (datetime)
└── due_date (datetime)

ProgressUpdates Collection
├── _id (ObjectId)
├── task_id (ObjectId) - index
├── status (string)
├── hours_worked (int)
├── notes (string)
└── timestamp (datetime)

GitHubCommits Collection
├── _id (ObjectId)
├── commit_sha (string) - unique index
├── message (string)
├── author (string)
├── timestamp (datetime)
├── files_changed (array)
├── additions (int)
├── deletions (int)
└── task_id (ObjectId) - index (optional)
```

### Index Recommendations

```python
# Efficient queries
db.tasks.create_index([("project_id", 1), ("status", 1)])
db.tasks.create_index([("assigned_to", 1), ("status", 1)])
db.tasks.create_index([("due_date", 1)])
db.progress_updates.create_index([("task_id", 1), ("timestamp", -1)])
db.github_commits.create_index([("task_id", 1), ("timestamp", -1)])
```

---

## Task Dependency Management

### Dependency Resolution

```python
def get_task_dependencies(task_id, all_tasks):
    """Resolve all dependencies for a task"""
    dependencies = []
    task = find_task(task_id)
    
    for dep_id in task.dependencies:
        dependencies.append(find_task(dep_id))
    
    return dependencies

def can_start_task(task_id):
    """Check if task can be started"""
    task = find_task(task_id)
    dependencies = get_task_dependencies(task_id)
    
    # Can start if all dependencies are completed
    return all(dep.status == "completed" for dep in dependencies)

def get_critical_path(project_id):
    """Get critical path for project"""
    tasks = get_all_tasks(project_id)
    # Find longest dependency chain
    return calculate_longest_path(tasks)
```

### Circular Dependency Prevention

- Validate no cycles when adding dependencies
- Check transitive dependencies
- Prevent self-dependencies

---

## Effort Tracking

### Metrics

```python
# Task-level metrics
task.estimated_hours   # Original estimate
task.actual_hours      # Real time spent
velocity = actual / estimated  # Where 1.0 = on track

# Project-level metrics
total_estimated = sum(task.estimated_hours for all tasks)
total_actual = sum(task.actual_hours for all tasks)
project_velocity = total_actual / total_estimated

# Progress metrics
completed = count(tasks with status="completed")
completion_rate = completed / total_tasks * 100
average_task_duration = total_actual / completed

# Burndown
remaining_hours = sum(task.estimated_hours - task.actual_hours)
```

---

## Best Practices

1. **Task Naming**: Use clear, action-oriented titles
2. **Estimates**: Provide realistic hour estimates
3. **Dependencies**: Define clear task dependencies
4. **Subtasks**: Break large tasks into smaller units
5. **Updates**: Track progress regularly with updates
6. **Status**: Keep status current
7. **Assignment**: Assign tasks to capable team members
8. **Notes**: Include context in progress notes

---

## Common Queries

```python
# Get all pending tasks
pending_tasks = [t for t in tasks if t.status == "pending"]

# Get tasks by assignee
user_tasks = [t for t in tasks if t.assigned_to == user_id]

# Get high-priority, in-progress work
urgent_work = [t for t in tasks 
               if t.priority == "high" and t.status == "in_progress"]

# Get overdue tasks
overdue = [t for t in tasks 
           if t.due_date and t.due_date < datetime.now() 
           and t.status != "completed"]

# Get blocked tasks
blocked = [t for t in tasks if t.status == "blocked"]

# Get task with blockers
def has_blockers(task):
    return any(t.status != "completed" 
               for t in get_dependencies(task))
```

---

## Error Handling

**Common Errors**:
- `400 Bad Request`: Invalid status or priority value
- `404 Not Found`: Task or project not found
- `409 Conflict`: Circular dependency detected
- `422 Unprocessable Entity`: Missing required fields
- `424 Failed Dependency`: Cannot transition due to blocked dependencies

---

## Notes

- All timestamps use UTC datetime
- Task IDs are MongoDB ObjectIds (as strings in API)
- Status transitions are restricted (not all combinations allowed)
- Actual_hours is cumulative, increases with progress updates
- Dependencies must reference existing tasks
- Subtask statuses update manually (not auto-calculated from tasks)

