# task_service.py
from datetime import datetime, timezone, timedelta
import logging
import math
from typing import List, Dict, Optional, Any
import uuid
import sys
import os
import asyncio
import random
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

# Add parent directory to sys.path to import shared
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from shared.cache_utils import cache_manager, NULL_SENTINEL
from shared.lock import acquire_lock

from database import get_database
from models import Task, TaskCreate, ProgressUpdate, TaskAssignment
from utils import convert_objectid, get_current_time, calculate_completion_percentage
from services.llm_service import generate_tasks_with_llm, generate_related_tasks_with_llm

logger = logging.getLogger(__name__)

class TaskService:
    # No __init__ method is needed, as the database object is injected via dependencies.

    async def invalidate_task_cache(self, task_id: str):
        """Invalidate cache keys for a specific task"""
        if not task_id:
            return
        try:
            if cache_manager.redis:
                await cache_manager.redis.delete(f"task:{task_id}:True", f"task:{task_id}:False")
                logger.info(f"Invalidated cache for task {task_id}")
        except Exception as e:
            logger.warning(f"Failed to invalidate task cache for {task_id}: {e}")

    def _parse_due_date_value(self, value: Any) -> Optional[datetime]:
        """Best-effort parse for due date values coming from LLM or clients."""
        if value is None:
            return None
        if isinstance(value, datetime):
            dt = value
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt

        if isinstance(value, str):
            s = value.strip()
            if not s:
                return None
            # Accept common ISO variants, including Z.
            s_norm = s.replace("Z", "+00:00")
            try:
                dt = datetime.fromisoformat(s_norm)
            except Exception:
                # Accept simple date-only strings.
                try:
                    dt = datetime.strptime(s, "%Y-%m-%d")
                except Exception:
                    return None
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt

        return None

    def _extract_due_date(self, task_data: Dict[str, Any]) -> Optional[datetime]:
        if not isinstance(task_data, dict):
            return None

        # Common shapes (snake_case and camelCase)
        for key in ("due_date", "due_date", "deadline", "due", "target_date"):
            dt = self._parse_due_date_value(task_data.get(key))
            if dt:
                return dt
        return None
    
    async def create_project_plan(self, db: AsyncIOMotorDatabase, project_id: str, plan_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create or update a project plan in the database.
        
        Args:
            db: Database connection
            project_id: The ID string of the project
            plan_data: The plan content
        """
        if not project_id:
            raise ValueError("Invalid project_id provided")

        # 1. Get Project Details (to auto-fill summary if missing)
        try:
            project = await db.projects.find_one({"_id": ObjectId(project_id)})
        except Exception:
            # Handle case where project_id might not be a valid ObjectId string
            project = None

        if not project:
            # Continue anyway if strictly creating a plan, but warn or use defaults
            summary = plan_data.get("summary", "Project Plan")
            tech_stack = plan_data.get("tech_stack", [])
        else:
            # Auto-fill summary from DB project details if not in input
            summary = plan_data.get("summary")
            if not summary:
                summary = f"Project: {project.get('title', 'Untitled')}. {project.get('description', '')}"
            
            # Auto-fill tech stack from project tags
            tech_stack = plan_data.get("tech_stack", project.get("tags", []))

        # 2. Prepare the Plan Document
        # FIX: We use **plan_data to include ALL fields provided by the input (like 'objectives', 'requirements')
        # This prevents "empty strings" if the input schema differs from our expected schema.
        plan_doc = {
            **plan_data,  # <-- CRITICAL FIX: Merge all input fields first
            "project_id": project_id,
            "summary": summary,
            "tech_stack": tech_stack,
            "created_at": get_current_time(),
            "updated_at": get_current_time()
        }

        # 3. Ensure critical fields exist (mapping aliases if needed)
        # If input has 'objectives' but we want 'high_level_tasks', we can alias them here, or just keep both.
        if "high_level_tasks" not in plan_doc:
            plan_doc["high_level_tasks"] = plan_data.get("tasks", [])
            
        if "key_features_deliverables" not in plan_doc:
            plan_doc["key_features_deliverables"] = plan_data.get("features", [])

        # 4. Save to database (Upsert)
        await db.project_plans.update_one(
            {"project_id": project_id},
            {"$set": plan_doc},
            upsert=True
        )
        
        # 5. Return the saved document
        saved_plan = await db.project_plans.find_one({"project_id": project_id})
        return convert_objectid(saved_plan) if saved_plan else plan_doc

    async def get_project_plan(self, db: AsyncIOMotorDatabase, project_id: str) -> Optional[Dict]:
        """Fetch project plan from database"""
        try:
            project_plan = await db.project_plans.find_one({"project_id": project_id})
            return convert_objectid(project_plan) if project_plan else None
        except Exception as e:
            print(f"Error fetching project plan: {e}")
            return None
    
    async def create_task(self, db: AsyncIOMotorDatabase, project_id: str, task_data: TaskCreate) -> Dict:
        """Create a single task for a project (overwrites any existing assignment if provided)"""
        try:
            # Validate project exists
            project = await db.projects.find_one({"_id": ObjectId(project_id)})
            if not project:
                raise ValueError(f"Project {project_id} not found")
            
            # Handle possible camelCase fields from frontend
            incoming_data = task_data.dict()
            # Support sub_tasks alias
            subtasks_input = incoming_data.get('sub_tasks') or incoming_data.get('sub_tasks') or []
            # Ensure each subtask dict conforms to SubTask model (allow extra fields)
            normalized_subtasks = [sub if isinstance(sub, dict) else sub.dict() for sub in subtasks_input]
            # Handle due date aliases
            due_date_val = incoming_data.get('due_date') or incoming_data.get('due_date')
            
            normalized_status = self._normalize_task_status(getattr(task_data, "status", "todo"))
            task_doc = {
                "project_id": project_id,
                "title": task_data.title,
                "description": task_data.description,
                "priority": task_data.priority,
                "estimated_hours": task_data.estimated_hours,
                "actual_hours": 0,
                "dependencies": task_data.dependencies,
                "sub_tasks": normalized_subtasks,
                "status": normalized_status,
                "is_deleted": False,
                "created_at": get_current_time(),
                "updated_at": get_current_time()
            }
            
            if due_date_val:
                task_doc["due_date"] = due_date_val
            # Preserve any extra fields passed by the client (future‑proofing)
            # EXCLUDING keys we've already handled/canonicalized to avoid duplication
            for k, v in incoming_data.items():
                if k not in task_doc and k not in ("_id", "id", "sub_tasks", "sub_tasks", "due_date"):
                    task_doc[k] = v
            
            # Handle assignment - overwrite any existing assignment
            if task_data.assigned_to:
                # Validate user is a member of the project
                is_member = await self.check_user_project_membership(db, task_data.assigned_to, project_id)
                if not is_member:
                    raise ValueError(f"User {task_data.assigned_to} is not a member of project {project_id}")
                
                task_doc["assigned_to"] = task_data.assigned_to
                
                # Log the assignment
                assignment = TaskAssignment(
                    task_id="",  # Will be set after task creation
                    user_id=task_data.assigned_to,
                    notes="Assigned during task creation"
                )
            
            # Insert the task
            result = await db.tasks.insert_one(task_doc)
            task_doc["id"] = str(result.inserted_id)

            # Keep project document in sync (legacy field used by some UIs):
            # store task ObjectId references without removing on delete.
            try:
                await db.projects.update_one(
                    {"_id": ObjectId(project_id)},
                    {
                        "$addToSet": {"tasks": result.inserted_id},
                        "$set": {"updated_at": get_current_time()},
                    },
                )
            except Exception as e:
                # Non-blocking: task creation should succeed even if project update fails
                print(f"Warning: failed to update project.tasks for project {project_id}: {e}")
            
            # Log assignment if it was provided
            if task_data.assigned_to:
                assignment.task_id = task_doc["id"]
                await self._log_task_assignment(db, task_doc["id"], assignment)
            
            return convert_objectid(task_doc)
            
        except Exception as e:
            print(f"Error creating task: {e}")
            raise

    async def add_subtask(self, db: AsyncIOMotorDatabase, task_id: str, subtask_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Append a subtask to an existing task without overwriting the whole list."""
        try:
            if not ObjectId.is_valid(task_id):
                return None

            task = await db.tasks.find_one({"_id": ObjectId(task_id)})
            if not task:
                return None

            raw = dict(subtask_data or {})
            title = str(raw.get("title", "")).strip()
            if not title:
                raise ValueError("Subtask title is required")

            description = raw.get("description", "")
            if description is None:
                description = ""
            if not isinstance(description, str):
                description = str(description)

            completed_in = raw.get("completed")
            status_in = raw.get("status")
            if completed_in is not None:
                completed = bool(completed_in)
                status = "completed" if completed else "pending"
            else:
                status = str(status_in or "pending").strip().lower()
                completed = status in ("completed", "done", "complete")
                if completed:
                    status = "completed"
                elif status in ("pending", "todo", "to-do"):
                    status = "pending"

            sub_id = raw.get("id")
            if not sub_id or not str(sub_id).strip():
                sub_id = f"st-{uuid.uuid4().hex}"

            estimated_hours = raw.get("estimated_hours", 1)
            try:
                estimated_hours = int(estimated_hours)
            except Exception:
                estimated_hours = 1
            if estimated_hours <= 0:
                estimated_hours = 1

            created_at = raw.get("created_at")
            if created_at is None:
                created_at = get_current_time()

            subtask_doc: Dict[str, Any] = {
                "id": str(sub_id),
                "title": title,
                "description": description,
                "estimated_hours": estimated_hours,
                "status": status,
                "completed": completed,
                "created_at": created_at,
            }

            # Preserve any extra keys passed by clients (future-proofing)
            for k, v in raw.items():
                if k not in subtask_doc and k not in ("_id",):
                    subtask_doc[k] = v

            await db.tasks.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$push": {"sub_tasks": subtask_doc},
                    "$set": {"updated_at": get_current_time()},
                },
            )
            await self.invalidate_task_cache(task_id)

            return await self.get_task_by_id(db, task_id)
        except ValueError:
            raise
        except Exception as e:
            print(f"Error adding subtask: {e}")
            return None

    async def list_task_notes(
        self,
        db: AsyncIOMotorDatabase,
        task_id: str,
        include_deleted: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Return notes for a task and a computed count."""
        try:
            if not ObjectId.is_valid(task_id):
                return None

            task = await db.tasks.find_one({"_id": ObjectId(task_id)})
            if not task:
                return None

            notes = task.get("notes", [])
            if not isinstance(notes, list):
                notes = []

            def is_deleted(n: Any) -> bool:
                if not isinstance(n, dict):
                    return False
                return bool(n.get("is_deleted") or n.get("is_deleted") or n.get("deleted"))

            active_notes = notes if include_deleted else [n for n in notes if not is_deleted(n)]

            # Stable sort by created time (best-effort)
            def created_ms(n: Any) -> int:
                if not isinstance(n, dict):
                    return 0
                v = n.get("created_at") or n.get("created_at") or n.get("created")
                try:
                    if isinstance(v, datetime):
                        return int(v.timestamp() * 1000)
                    return int(datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp() * 1000)
                except Exception:
                    return 0

            active_notes.sort(key=created_ms)

            return {
                "task_id": task_id,
                "count": len(active_notes),
                "notes": convert_objectid(active_notes),
            }
        except Exception as e:
            print(f"Error listing notes: {e}")
            return None

    async def add_task_note(
        self,
        db: AsyncIOMotorDatabase,
        task_id: str,
        content: str,
        parent_id: Optional[str] = None,
        author: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Append a note to a task."""
        try:
            if not ObjectId.is_valid(task_id):
                return None

            if not content or not str(content).strip():
                raise ValueError("Note content is required")

            task = await db.tasks.find_one({"_id": ObjectId(task_id)})
            if not task:
                return None

            note_id = f"note-{uuid.uuid4().hex}"
            note_doc: Dict[str, Any] = {
                "id": note_id,
                "content": str(content).strip(),
                "created_at": get_current_time(),
                "parent_id": str(parent_id) if parent_id else None,
                "is_deleted": False,
                "author": author or {"id": "unknown", "name": "Unknown", "avatar": ""},
            }

            await db.tasks.update_one(
                {"_id": ObjectId(task_id)},
                {
                    "$push": {"notes": note_doc},
                    "$set": {"updated_at": get_current_time()},
                },
            )
            await self.invalidate_task_cache(task_id)

            return convert_objectid(note_doc)
        except ValueError:
            raise
        except Exception as e:
            print(f"Error adding note: {e}")
            return None

    async def update_task_note(
        self,
        db: AsyncIOMotorDatabase,
        task_id: str,
        note_id: str,
        content: str,
    ) -> Optional[Dict[str, Any]]:
        """Update a note's content."""
        try:
            if not ObjectId.is_valid(task_id):
                return None
            if not note_id:
                raise ValueError("Note ID is required")
            if not content or not str(content).strip():
                raise ValueError("Note content is required")

            result = await db.tasks.update_one(
                {"_id": ObjectId(task_id), "notes.id": str(note_id)},
                {
                    "$set": {
                        "notes.$.content": str(content).strip(),
                        "notes.$.updated_at": get_current_time(),
                        "notes.$.is_edited": True,
                        "updated_at": get_current_time(),
                    }
                },
            )
            await self.invalidate_task_cache(task_id)

            if result.matched_count <= 0:
                return None

            task = await db.tasks.find_one({"_id": ObjectId(task_id)})
            if not task:
                return None
            notes = task.get("notes", [])
            if isinstance(notes, list):
                for n in notes:
                    if isinstance(n, dict) and str(n.get("id")) == str(note_id):
                        return convert_objectid(n)
            return None
        except ValueError:
            raise
        except Exception as e:
            print(f"Error updating note: {e}")
            return None

    async def delete_task_note(
        self,
        db: AsyncIOMotorDatabase,
        task_id: str,
        note_id: str,
    ) -> bool:
        """Soft delete a note."""
        try:
            if not ObjectId.is_valid(task_id):
                return False
            if not note_id:
                raise ValueError("Note ID is required")

            result = await db.tasks.update_one(
                {"_id": ObjectId(task_id), "notes.id": str(note_id)},
                {
                    "$set": {
                        "notes.$.is_deleted": True,
                        "updated_at": get_current_time(),
                    }
                },
            )
            await self.invalidate_task_cache(task_id)

            return result.matched_count > 0
        except ValueError:
            raise
        except Exception as e:
            print(f"Error deleting note: {e}")
            return False
    
    async def generate_tasks(self, db: AsyncIOMotorDatabase, project_id: str) -> List[Dict]:
        """Generate tasks for a project using LLM.

        IMPORTANT: This returns a preview only (no DB writes). Persist tasks via
        POST /projects/{project_id}/tasks after user confirmation.
        """
        # 1. Fetch the plan
        project_plan = await self.get_project_plan(db, project_id)
        
        # 2. Check if plan exists
        if not project_plan:
            raise ValueError(f"Project plan not found for project {project_id}. Please create a plan first.")
        
        # 3. Generate tasks via LLM
        generated_tasks = await generate_tasks_with_llm(project_plan)

        # Keep the preview within the desired range (12-18 tasks)
        if isinstance(generated_tasks, list) and len(generated_tasks) > 18:
            generated_tasks = generated_tasks[:18]
        
        preview_tasks = []

        # Default schedule: start tomorrow (UTC midnight) and space tasks based on estimated hours.
        base_date = get_current_time().astimezone(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        schedule_cursor = base_date + timedelta(days=1)
        hours_per_day = 4
        for task_data in generated_tasks:
            # Handle various key names the LLM might return
            title = task_data.get("title") or task_data.get("task_name") or "Untitled Task"

            raw_desc = (
                task_data.get("description")
                or task_data.get("details")
                or task_data.get("body")
                or ""
            )
            if not isinstance(raw_desc, str):
                raw_desc = str(raw_desc)
            description = raw_desc.strip()
            if not description or description.lower() == str(title).strip().lower():
                description = (
                    f"Deliver {title} by defining scope, listing acceptance criteria, and "
                    "breaking the work into concrete implementation steps. Identify dependencies, "
                    "specify the technologies to use, and outline validation checks and test cases. "
                    "Document configuration changes, edge cases, and rollout notes so the task can "
                    "be implemented, reviewed, and integrated without ambiguity."
                )

            # Preserve original keys (like task_name/estimated_duration) while
            # also providing canonical keys used by the frontend.
            preview = dict(task_data)
            preview.update({
                "project_id": project_id,
                "title": title,
                "description": description,
                "priority": task_data.get("priority", "medium"),
                "estimated_hours": task_data.get("estimated_hours", task_data.get("estimated_hours", 1)),
                "dependencies": task_data.get("dependencies", []),
                "sub_tasks": [],
                "status": self._normalize_task_status(task_data.get("status", "todo")),
            })

            # Prefer any due date produced upstream; otherwise auto-fill.
            due_dt = self._extract_due_date(task_data)
            if due_dt is None:
                due_dt = schedule_cursor

            # Make sure next task due dates are monotonically increasing.
            if due_dt < schedule_cursor:
                due_dt = schedule_cursor

            # Increment schedule based on estimated effort.
            est = preview.get("estimated_hours", 1)
            try:
                est_f = float(est)
            except Exception:
                est_f = 1.0
            days_for_task = max(1, int(math.ceil(est_f / float(hours_per_day))))
            schedule_cursor = due_dt + timedelta(days=days_for_task)

            preview["due_date"] = due_dt

            preview_tasks.append(convert_objectid(preview))

        return preview_tasks

    async def generate_related_tasks(
        self, 
        db: AsyncIOMotorDatabase, 
        project_id: str, 
        task_id: str,
        count: int = 4
    ) -> List[Dict]:
        """Generate related tasks based on a reference task and save them as separate new tasks in the database.
        
        Args:
            db: Database connection
            project_id: The project ID
            task_id: The reference task ID to base generation on
            count: Number of related tasks to generate (1-8, default: 4)
            
        Returns:
            List of newly created tasks with their database IDs
        """
        
        # 1. Fetch the reference task and validate project exists
        try:
            task_obj_id = ObjectId(task_id) if ObjectId.is_valid(task_id) else task_id
        except Exception:
            task_obj_id = task_id
            
        reference_task = await db.tasks.find_one({"_id": task_obj_id})
        
        if not reference_task:
            raise ValueError(f"Reference task {task_id} not found")
        
        # Validate project exists
        project = await db.projects.find_one({"_id": ObjectId(project_id)})
        if not project:
            raise ValueError(f"Project {project_id} not found")
        
        # 2. Limit and validate count
        count = max(1, min(int(count), 8))
        
        # 3. Generate related tasks via LLM
        generated_tasks = await generate_related_tasks_with_llm(reference_task, count)
        
        created_tasks = []
        
        # Default schedule: start from reference task's due date offset
        base_date = reference_task.get("due_date")
        if not base_date:
            base_date = get_current_time().astimezone(timezone.utc).replace(
                hour=0, minute=0, second=0, microsecond=0
            )
        
        schedule_cursor = base_date + timedelta(days=1) if isinstance(base_date, datetime) else get_current_time() + timedelta(days=1)
        hours_per_day = 4
        
        for task_data in generated_tasks:
            # Handle various key names the LLM might return
            title = task_data.get("title") or task_data.get("task_name") or "Untitled Task"
            
            raw_desc = (
                task_data.get("description")
                or task_data.get("details")
                or task_data.get("body")
                or ""
            )
            if not isinstance(raw_desc, str):
                raw_desc = str(raw_desc)
            description = raw_desc.strip()
            
            if not description or description.lower() == str(title).strip().lower():
                description = (
                    f"Complete this related task as part of the broader {reference_task.get('title', 'project')} "
                    "work. Define the scope, acceptance criteria, and implementation steps. Identify any dependencies, "
                    "specify the technologies to use, and outline validation checks. Document configuration changes, "
                    "edge cases, and integration points for seamless project delivery."
                )
            
            # Prefer any due date from LLM; otherwise auto-fill
            due_dt = self._extract_due_date(task_data)
            if due_dt is None:
                due_dt = schedule_cursor
            
            # Make sure next task due dates are monotonically increasing
            if due_dt < schedule_cursor:
                due_dt = schedule_cursor
            
            # Increment schedule based on estimated effort
            est_hours = task_data.get("estimated_hours", task_data.get("estimated_duration", 1))
            try:
                est_f = float(est_hours)
            except Exception:
                est_f = 1.0
            days_for_task = max(1, int(math.ceil(est_f / float(hours_per_day))))
            schedule_cursor = due_dt + timedelta(days=days_for_task)
            
            # 4. Create task document for database insertion
            normalized_status = self._normalize_task_status(task_data.get("status", "todo"))
            dependencies = task_data.get("dependencies", [reference_task.get("title", task_id)])
            if not isinstance(dependencies, list):
                dependencies = [dependencies]
            
            task_doc = {
                "project_id": project_id,
                "title": title,
                "description": description,
                "priority": task_data.get("priority", "medium"),
                "estimated_hours": int(est_f) if est_f else 1,
                "actual_hours": 0,
                "dependencies": dependencies,
                "sub_tasks": [],
                "status": normalized_status,
                "due_date": due_dt,
                "is_deleted": False,
                "created_at": get_current_time(),
                "updated_at": get_current_time(),
            }
            
            # Preserve any extra fields from LLM response (future-proofing)
            for k, v in task_data.items():
                if k not in task_doc and k not in ("_id", "id"):
                    task_doc[k] = v
            
            # 5. Insert the task into database
            try:
                result = await db.tasks.insert_one(task_doc)
                task_doc["_id"] = result.inserted_id
                task_doc["id"] = str(result.inserted_id)
                
                # 6. Keep project document in sync by adding task reference
                try:
                    await db.projects.update_one(
                        {"_id": ObjectId(project_id)},
                        {
                            "$addToSet": {"tasks": result.inserted_id},
                            "$set": {"updated_at": get_current_time()},
                        },
                    )
                except Exception as e:
                    # Non-blocking: task creation should succeed even if project update fails
                    logger.warning(f"Failed to update project.tasks for project {project_id}: {e}")
                
                created_tasks.append(convert_objectid(task_doc))
            except Exception as e:
                logger.error(f"Error inserting generated task '{title}' for project {project_id}: {e}")
                # Continue with next task instead of failing the whole operation
                continue
        
        return created_tasks
    
    async def get_project_tasks(
        self,
        db: AsyncIOMotorDatabase,
        project_id: str,
        include_deleted: bool = False,
        include_notes: bool = True,
    ) -> List[Dict]:
        """Get all tasks for a project"""
        project_obj_id: Optional[ObjectId] = None
        if ObjectId.is_valid(project_id):
            project_obj_id = ObjectId(project_id)

        # Tasks can reference projects using multiple schema variants:
        # - python agent: project_id: str
        # - next/mongoose: project_id: ObjectId | str, project: ObjectId | str
        query: Dict[str, Any] = {
            "$or": [
                {"project_id": project_id},
                {"project": project_id},
            ]
        }
        if project_obj_id:
            query["$or"].extend(
                [
                    {"project_id": project_obj_id},
                    {"project": project_obj_id},
                ]
            )

        if not include_deleted:
            query["is_deleted"] = {"$ne": True}
            query["status"] = {"$ne": "deleted"}
        
        # Optimize performance: Strictly include only the fields needed by the frontend board/lists.
        projection = {
            "_id": 1,
            "project_id": 1,
            "project": 1,
            "title": 1,
            "description": 1,
            "status": 1,
            "priority": 1,
            "due_date": 1,
            "assigned_to": 1,
            "tags": 1,
            "sub_tasks": 1,
            "time_tracking": 1,
            "created_at": 1,
            "updated_at": 1,
            "linked_pr_id": 1,
            "linked_pull_request": 1,
            "notes.is_deleted": 1,
            "notes.deleted": 1,
            "attachments._id": 1,
        }
        cursor = db.tasks.find(query, projection)
        tasks = await cursor.to_list(length=None)

        # Add computed note counts for UI cards without fetching notes bodies.
        for t in tasks:
            try:
                notes = t.get("notes", [])
                if not isinstance(notes, list):
                    notes = []

                def is_deleted(n: Any) -> bool:
                    if not isinstance(n, dict):
                        return False
                    return bool(n.get("is_deleted") or n.get("is_deleted") or n.get("deleted"))

                active_notes_count = sum(1 for n in notes if not is_deleted(n))

                # Provide both snake_case and snake_case for frontend compatibility.
                t["notes_count"] = active_notes_count
                t["notes_count"] = active_notes_count
                # Kanban card reads `comments_count`; treat notes as comments for now.
                t["comments_count"] = active_notes_count
                t["comments_count"] = active_notes_count

                if not include_notes:
                    # Avoid sending large discussion threads in list views.
                    t.pop("notes", None)
            except Exception:
                # Non-fatal; list tasks should still return.
                pass

        # Best-effort: keep legacy project.tasks index in sync with active tasks.
        # This helps admins/users inspecting the project document see the same count
        # the UI shows (tasks are stored in the tasks collection).
        if not include_deleted and ObjectId.is_valid(project_id):
            try:
                await db.projects.update_one(
                    {"_id": ObjectId(project_id)},
                    {
                        "$set": {
                            "tasks": [t.get("_id") for t in tasks if t.get("_id")],
                            "updated_at": get_current_time(),
                        }
                    },
                )
            except Exception as e:
                print(f"Warning: failed to sync project.tasks for project {project_id}: {e}")

        return convert_objectid(tasks)
    
    async def update_task(self, db: AsyncIOMotorDatabase, task_id: str, update_data: Dict) -> Optional[Dict]:
        """Update a task with partial data"""
        try:
            # Validate database connection
            if db is None:
                print(f"Error updating task: Database connection is not available")
                return None

            # Normalize status strings coming from UI clients (e.g. "in-progress", "todo")
            if "status" in update_data and isinstance(update_data.get("status"), str):
                update_data["status"] = self._normalize_task_status(update_data["status"])
                if update_data["status"] == "completed":
                    update_data["completed_at"] = get_current_time()
                else:
                    update_data["completed_at"] = None

            # Normalize sub_tasks field if present
            if "sub_tasks" in update_data:
                sub_tasks = update_data.get("sub_tasks", [])
                if sub_tasks:
                    update_data["sub_tasks"] = sub_tasks

            # Normalize due_date - remove it and re-add if it exists
            if "due_date" in update_data:
                due_date = update_data.pop("due_date")
                if due_date:
                    update_data["due_date"] = due_date

            # Don't update immutable fields
            for field in ["_id", "id", "project_id", "created_at"]:
                update_data.pop(field, None)
                
            update_data["updated_at"] = get_current_time()
            
            # Build query - try ObjectId first, fall back to string
            query = {}
            if ObjectId.is_valid(task_id):
                query["_id"] = ObjectId(task_id)
            else:
                query = {
                    "$or": [
                        {"_id": task_id},
                        {"id": task_id},
                        {"task_id": task_id},
                    ]
                }
            
            result = await db.tasks.update_one(
                query,
                {"$set": update_data}
            )
            await self.invalidate_task_cache(task_id)
            
            if result.matched_count > 0:
                updated_task = await self.get_task_by_id(db, task_id)
                # If status changed, recalculate project progress/status
                if updated_task and "status" in update_data:
                    project_id = self._extract_project_id_from_task(updated_task)
                    if project_id:
                        await self.recalculate_project_progress_and_status(db, project_id)
                return updated_task
            else:
                print(f"Error updating task: Task not found with ID {task_id}")
            return None
        except Exception as e:
            print(f"Error updating task: {str(e)}")
            import traceback
            traceback.print_exc()
            return None

    async def soft_delete_task(self, db: AsyncIOMotorDatabase, task_id: str) -> bool:
        """Soft delete a task by marking is_deleted and status."""
        try:
            query = {}
            if ObjectId.is_valid(task_id):
                query["_id"] = ObjectId(task_id)
            else:
                query = {"$or": [{"_id": task_id}, {"id": task_id}, {"task_id": task_id}]}
            result = await db.tasks.update_one(
                query,
                {
                    "$set": {
                        "is_deleted": True,
                        "status": "deleted",
                        "updated_at": get_current_time(),
                    }
                }
            )
            await self.invalidate_task_cache(task_id)
            if result.matched_count <= 0:
                return False

            # Recompute project progress/status after deletion (deleted tasks are excluded)
            try:
                deleted_task = await self.get_task_by_id(db, task_id, include_deleted=True)
                project_id = self._extract_project_id_from_task(deleted_task or {})
                if project_id:
                    await self.recalculate_project_progress_and_status(db, project_id)
            except Exception as e:
                print(f"Warning: failed to recalculate project progress after delete: {e}")

            return True
        except Exception as e:
            print(f"Error soft deleting task: {e}")
            return False
    
    async def update_task_progress(self, db: AsyncIOMotorDatabase, task_id: str, progress: ProgressUpdate) -> Optional[Dict[str, Any]]:
        """Update task status/hours and propagate progress to the parent project.

        Returns a dict with project updates on success, otherwise None.
        """
        try:
            # Build query - try ObjectId first, fall back to string-based lookup
            task_query = {}
            if ObjectId.is_valid(task_id):
                task_query["_id"] = ObjectId(task_id)
            else:
                task_query = {"$or": [{"_id": task_id}, {"id": task_id}, {"task_id": task_id}]}
            task = await db.tasks.find_one(task_query)
            if not task:
                return None

            normalized_status = self._normalize_task_status(progress.status)

            update_data: Dict[str, Any] = {
                "status": normalized_status,
                "updated_at": get_current_time(),
            }

            if normalized_status == "completed":
                update_data["completed_at"] = get_current_time()
            else:
                update_data["completed_at"] = None

            if progress.hours_worked and progress.hours_worked > 0:
                current_hours = task.get("actual_hours", 0)
                update_data["actual_hours"] = current_hours + progress.hours_worked

            result = await db.tasks.update_one(
                task_query,
                {"$set": update_data},
            )
            await self.invalidate_task_cache(task_id)

            if result.matched_count <= 0:
                return None

            # Always log progress update (status change, hours, notes)
            await self._log_progress(db, task_id, progress)

            project_id = self._extract_project_id_from_task(task)
            if project_id:
                project_update = await self.recalculate_project_progress_and_status(db, project_id)
            else:
                project_update = None

            return {
                "task_id": task_id,
                "task_status": normalized_status,
                "project": project_update,
            }
        except Exception:
            return None

    def _normalize_task_status(self, status: str) -> str:
        """Normalize various client status strings to the UI-canonical set.

        Canonical values: todo | in-progress | submitted | completed | blocked
        """
        value = (status or "").strip().lower()
        mapping = {
            "pending": "todo",
            "todo": "todo",
            "to-do": "todo",
            "to do": "todo",
            "inprogress": "in-progress",
            "in_progress": "in-progress",
            "in progress": "in-progress",
            "in-progress": "in-progress",
            "submitted": "submitted",
            "review": "submitted",
            "under-review": "submitted",
            "completed": "completed",
            "complete": "completed",
            "done": "completed",
            "blocked": "blocked",
        }
        return mapping.get(value, value or "todo")

    def _extract_project_id_from_task(self, task: Dict[str, Any]) -> Optional[str]:
        """Extract a project id from a task document across multiple schema variants."""
        if not task:
            return None

        candidate = (
            task.get("project_id")
            or task.get("project_id")
            or task.get("project")
        )

        if candidate is None:
            return None

        # Motor/Mongo can return raw ObjectId
        if isinstance(candidate, ObjectId):
            return str(candidate)

        # Sometimes stored as string
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()

        return None

    async def recalculate_project_progress_and_status(self, db: AsyncIOMotorDatabase, project_id: str) -> Optional[Dict[str, Any]]:
        """Recompute and persist the project's progress % and planning status based on its tasks."""
        try:
            project_obj_id: Optional[ObjectId] = None
            if ObjectId.is_valid(project_id):
                project_obj_id = ObjectId(project_id)

            # Ensure project exists (projects are stored with _id = ObjectId)
            if not project_obj_id:
                return None

            project = await db.projects.find_one({"_id": project_obj_id})
            if not project:
                return None

            # Fetch tasks for the project across multiple schema variants:
            # - python agent: project_id: str
            # - next/mongoose: project_id: ObjectId, project: ObjectId
            task_query: Dict[str, Any] = {
                "$or": [
                    {"project_id": project_id},
                    {"project_id": project_obj_id},
                    {"project_id": project_id},
                    {"project": project_obj_id},
                    {"project": project_id},
                ],
                "is_deleted": {"$ne": True},
                "status": {"$ne": "deleted"},
            }
            cursor = db.tasks.find(task_query)
            raw_tasks = await cursor.to_list(length=None)

            tasks = convert_objectid(raw_tasks)
            normalized_statuses = [self._normalize_task_status(t.get("status", "")) for t in tasks]

            total = len(tasks)
            completed = sum(1 for s in normalized_statuses if s == "completed")
            submitted = sum(1 for s in normalized_statuses if s == "submitted")

            completion_percentage = calculate_completion_percentage(completed, total)

            # Derive project status from task state
            if total == 0:
                derived_status = "planning"
            elif completed >= total:
                derived_status = "completed"
            else:
                any_started = any(s in {"in-progress", "submitted", "blocked", "completed"} for s in normalized_statuses)
                derived_status = "in-progress" if any_started else "planning"

            update_doc = {
                "progress": completion_percentage,
                "status": derived_status,
                "updated_at": get_current_time(),
            }

            await db.projects.update_one(
                {"_id": project_obj_id},
                {"$set": update_doc},
            )

            return {
                "project_id": project_id,
                "progress": completion_percentage,
                "status": derived_status,
                "total_tasks": total,
                "completed_tasks": completed,
                "submitted_tasks": submitted,
            }
        except Exception:
            return None
    
    async def _log_progress(self, db: AsyncIOMotorDatabase, task_id: str, progress: ProgressUpdate):
        """Log progress update to tracking collection"""
        progress_log = {
            "task_id": task_id,
            "status": progress.status,
            "hours_worked": progress.hours_worked,
            "notes": progress.notes,
            "timestamp": get_current_time()
        }
        await db.progress_tracking.insert_one(progress_log)
    
    async def get_task_by_id(self, db: AsyncIOMotorDatabase, task_id: str, include_deleted: bool = False) -> Optional[Dict]:
        """Get single task by ID with caching and DB fallback"""
        cache_key = f"task:{task_id}:{include_deleted}"

        # 1. Bloom Filter Check (fail-open if unavailable)
        try:
            if not await cache_manager.check_bloom(f"task:{task_id}"):
                logger.debug(f"Bloom filter miss for task {task_id}, falling through to DB")
        except Exception:
            pass

        # 2. Check Cache
        try:
            cached_task, is_stale = await cache_manager.get_cached(cache_key)
            if cached_task == NULL_SENTINEL:
                return None
            if cached_task and not is_stale:
                return cached_task
        except Exception as e:
            logger.debug(f"Cache check failed for task {task_id}: {e}")
            cached_task = None

        # 3. Direct DB lookup (always works, cache/lock are optimizations)
        try:
            task = None
            if ObjectId.is_valid(task_id):
                task = await db.tasks.find_one({"_id": ObjectId(task_id)})
            else:
                # Try string-based lookup for non-ObjectId IDs
                task = await db.tasks.find_one({"_id": task_id}) or \
                       await db.tasks.find_one({"id": task_id}) or \
                       await db.tasks.find_one({"task_id": task_id})

            if not task:
                # Cache the miss to avoid repeated DB hits
                try:
                    await cache_manager.set_cached(cache_key, NULL_SENTINEL, ttl=60)
                except Exception:
                    pass
                return None

            if not include_deleted:
                if task.get("is_deleted") or task.get("status") == "deleted":
                    try:
                        await cache_manager.set_cached(cache_key, NULL_SENTINEL, ttl=60)
                    except Exception:
                        pass
                    return None

            converted = convert_objectid(task)

            # Best-effort cache update
            try:
                lock = await acquire_lock(cache_manager.redis, f"lock:task:{task_id}", timeout_ms=2000)
                if await lock.acquire():
                    try:
                        await cache_manager.set_cached(cache_key, converted, ttl=3600, soft_ttl=600)
                        await cache_manager.bloom_add(f"task:{task_id}")
                    finally:
                        await lock.release()
            except Exception:
                pass

            return converted
        except Exception as e:
            logger.error(f"Error fetching task from DB: {e}")
            return None

    async def get_all_tasks(self, db: AsyncIOMotorDatabase, include_deleted: bool = False) -> List[Dict]:
        """Get all tasks"""
        filter_query = (
            {}
            if include_deleted
            else {"is_deleted": {"$ne": True}, "status": {"$ne": "deleted"}}
        )
        # Optimize performance: Strictly include only the fields needed by the frontend board/lists.
        projection = {
            "_id": 1,
            "project_id": 1,
            "project": 1,
            "title": 1,
            "description": 1,
            "status": 1,
            "priority": 1,
            "due_date": 1,
            "assigned_to": 1,
            "tags": 1,
            "sub_tasks": 1,
            "time_tracking": 1,
            "created_at": 1,
            "updated_at": 1,
            "linked_pr_id": 1,
            "linked_pull_request": 1,
            "notes.is_deleted": 1,
            "notes.deleted": 1,
            "attachments._id": 1,
        }
        cursor = db.tasks.find(filter_query, projection)
        raw_tasks = await cursor.to_list(length=None)
        return convert_objectid(raw_tasks)
    
    async def get_project_statistics(self, db: AsyncIOMotorDatabase, project_id: str) -> Dict:
        """Get project statistics"""
        tasks = await self.get_project_tasks(db, project_id)

        normalized_statuses = [self._normalize_task_status(t.get("status", "")) for t in tasks]

        total_tasks = len(tasks)
        completed_tasks = sum(1 for s in normalized_statuses if s == "completed")
        submitted_tasks = sum(1 for s in normalized_statuses if s == "submitted")
        in_progress_tasks = sum(1 for s in normalized_statuses if s == "in-progress")
        pending_tasks = sum(1 for s in normalized_statuses if s == "todo")
        blocked_tasks = sum(1 for s in normalized_statuses if s == "blocked")
        
        total_estimated_hours = sum([(t.get("estimated_hours") or 0) for t in tasks])
        total_actual_hours = sum([(t.get("actual_hours") or 0) for t in tasks])
        
        completion_percentage = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        return {
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "submitted_tasks": submitted_tasks,
            "in_progress_tasks": in_progress_tasks,
            "pending_tasks": pending_tasks,
            "blocked_tasks": blocked_tasks,
            "completion_percentage": round(completion_percentage, 2),
            "total_estimated_hours": total_estimated_hours,
            "total_actual_hours": total_actual_hours
        }
    
    async def check_user_project_membership(self, db: AsyncIOMotorDatabase, user_id: str, project_id: str) -> bool:
        """Check if user is a member of the project"""
        try:
            # Check if project exists and user is a member
            project = await db.projects.find_one({"_id": ObjectId(project_id)})
            if not project:
                return False
            
            # Check if user is the project owner
            if str(project.get("user", "")) == user_id:
                return True
            
            # Check if user is in team members
            team_members = project.get("team_members", [])
            for member in team_members:
                if str(member.get("user", "")) == user_id:
                    return True
            
            # Check if user is in resources
            resources = project.get("resources", [])
            for resource in resources:
                if str(resource.get("user", "")) == user_id:
                    return True
            
            return False
        except Exception as e:
            print(f"Error checking user project membership: {e}")
            return False
    
    async def assign_user_to_task(self, db: AsyncIOMotorDatabase, task_id: str, assignment: TaskAssignment) -> bool:
        """Assign a user to a task (replaces any existing assignment)"""
        try:
            # First get the task to verify it exists and get project_id
            task = await self.get_task_by_id(db, task_id)
            if not task:
                raise ValueError("Task not found")
            
            # Handle different possible field names for project ID
            project_id = task.get("project_id") or task.get("project_id") or task.get("project")
            if not project_id:
                raise ValueError("Task does not have a project_id field")
                
            is_member = await self.check_user_project_membership(db, assignment.user_id, project_id)
            if not is_member:
                raise ValueError("User is not a member of this project")
            
            # Update the task with assigned user
            update_data = {
                "assigned_to": assignment.user_id,
                "updated_at": get_current_time()
            }
            
            query = {}
            if ObjectId.is_valid(task_id):
                query["_id"] = ObjectId(task_id)
            else:
                query = {"$or": [{"_id": task_id}, {"id": task_id}, {"task_id": task_id}]}
            result = await db.tasks.update_one(
                query,
                {"$set": update_data}
            )
            await self.invalidate_task_cache(task_id)
            
            if result.matched_count > 0:
                await self._log_task_assignment(db, task_id, assignment)
                return True
            
            return False
        except Exception as e:
            print(f"Error assigning user to task: {e}")
            raise
    
    async def _log_task_assignment(self, db: AsyncIOMotorDatabase, task_id: str, assignment: TaskAssignment):
        """Log task assignment to tracking collection"""
        assignment_log = {
            "task_id": task_id,
            "user_id": assignment.user_id,
            "notes": assignment.notes,
            "assigned_at": get_current_time()
        }
        await db.task_assignments.insert_one(assignment_log)
    
    async def get_project_members(self, db: AsyncIOMotorDatabase, project_id: str) -> List[Dict]:
        """Get all members of a project"""
        try:
            project = await db.projects.find_one({"_id": ObjectId(project_id)})
            if not project:
                return []
            
            members = []
            
            # Add team members
            team_members = project.get("team_members", [])
            for member in team_members:
                user_id = member.get("user")
                if user_id:
                    members.append({
                        **member,
                        "role": member.get("role", "Team Member"),
                        "type": "team_member"
                    })
            
            # Add project owner
            project_owner_id = str(project.get("user", ""))
            # Compare using stringified ids to avoid mismatches between ObjectId and str
            if project_owner_id and not any(str(m.get("user", "")) == project_owner_id for m in members):
                 members.append({
                    "name": "Project Owner",
                    "role": "Project Owner",
                    "user": project_owner_id,
                    "type": "owner"
                })

            # Convert any ObjectId or datetime values in members to JSON-friendly types
            return convert_objectid(members)
            
        except Exception as e:
            print(f"Error fetching project members: {e}")
            return []
    
    async def get_assigned_tasks(self, db: AsyncIOMotorDatabase, user_id: str) -> List[Dict]:
        """Get all tasks assigned to a specific user"""
        try:
            cursor = db.tasks.find(
                {
                    "assigned_to": user_id,
                    "is_deleted": {"$ne": True},
                    "status": {"$ne": "deleted"},
                }
            )
            tasks = await cursor.to_list(length=None)
            return convert_objectid(tasks)
        except Exception as e:
            print(f"Error fetching assigned tasks: {e}")
            return []

    async def fix_project_members(self, db: AsyncIOMotorDatabase, project_id: str) -> Dict:
        """Fix project members by ensuring they have proper user IDs"""
        try:
            project = await db.projects.find_one({"_id": ObjectId(project_id)})
            if not project:
                return {"error": "Project not found"}

            return {"status": "checked", "project_id": project_id}

        except Exception as e:
            return {"error": str(e)}

    async def breakdown_task(self, db: AsyncIOMotorDatabase, task_id: str) -> Dict:
        """Generate detailed sub-tasks for a specific task.
        
        Takes only the task ID from the frontend (user just points/clicks),
        fetches the task from DB, and generates detailed breakdown.
        """
        try:
            # Fetch the task from database
            task = await self.get_task_by_id(db, task_id, include_deleted=False)
            if not task:
                raise ValueError(f"Task not found with ID: {task_id}")
            
            # Get project plan for context (optional)
            project_id = task.get("project_id") or task.get("project")
            project_plan = None
            if project_id:
                project_plan = await self.get_project_plan(db, str(project_id))
            
            # Call the breakdown function from llm_service
            from services.llm_service import breakdown_task_details
            breakdown = await breakdown_task_details(task, project_plan if project_plan is not None else {})

            # Persist generated sub_tasks into the task document
            raw_subtasks = breakdown.get("sub_tasks", [])
            if not isinstance(raw_subtasks, list):
                raw_subtasks = []

            existing = task.get("sub_tasks", [])
            if not isinstance(existing, list):
                existing = []

            def normalize_key(st: Dict[str, Any]) -> str:
                title = str(st.get("title", "")).strip().lower()
                desc = str(st.get("description", "")).strip().lower()
                return f"{title}::{desc}"

            existing_keys = {normalize_key(st) for st in existing if isinstance(st, dict)}
            new_subtasks: List[Dict[str, Any]] = []

            for st in raw_subtasks:
                if not isinstance(st, dict):
                    continue
                title = str(st.get("title", "Untitled")).strip()
                if not title:
                    title = "Untitled"
                description = st.get("description", "")
                if description is None:
                    description = ""
                if not isinstance(description, str):
                    description = str(description)

                key = normalize_key({"title": title, "description": description})
                if key in existing_keys:
                    continue
                existing_keys.add(key)

                estimated_hours = st.get("estimated_hours", 1)
                try:
                    estimated_hours = int(estimated_hours)
                except Exception:
                    estimated_hours = 1
                if estimated_hours <= 0:
                    estimated_hours = 1

                sub_id = f"st-{uuid.uuid4().hex}"
                new_subtasks.append({
                    "id": sub_id,
                    "title": title,
                    "description": description,
                    "estimated_hours": estimated_hours,
                    "status": "pending",
                    "completed": False,
                    "created_at": get_current_time(),
                    "ai_generated": True,
                })

            if new_subtasks:
                await db.tasks.update_one(
                    {"_id": ObjectId(task_id)},
                    {
                        "$push": {"sub_tasks": {"$each": new_subtasks}},
                        "$set": {"updated_at": get_current_time()},
                    },
                )
            await self.invalidate_task_cache(task_id)

            updated_task = await self.get_task_by_id(db, task_id, include_deleted=False)

            return {
                "breakdown": breakdown,
                "task": updated_task,
                "added_count": len(new_subtasks),
            }
        
        except ValueError as e:
            raise ValueError(str(e))
        except Exception as e:
            logger.error(f"Error breaking down task {task_id}: {e}")
            raise

# Create a single instance of the service
task_service = TaskService()