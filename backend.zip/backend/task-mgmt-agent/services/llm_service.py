# llm_service.py
import aiohttp
import json
from typing import List, Dict
import os
from dotenv import load_dotenv
import logging
import ast
import asyncio
from shared.ollama_service import OllamaService

load_dotenv()

logger = logging.getLogger(__name__)

client = OllamaService(agent_type="task-mgmt")

async def generate_tasks_with_llm(project_plan: Dict) -> List[Dict]:
    """Generate detailed, niche-specific tasks using the local Ollama model based on project plan"""
    
    # Detect project type/niche from project data
    project_niche = _detect_project_niche(project_plan)
    
    # Build comprehensive, niche-specific prompt
    system_prompt = _build_system_prompt(project_niche, project_plan)
    user_prompt = _build_user_prompt(project_plan, project_niche)
    
    logger.info(f"Generating tasks for niche: {project_niche}")
    
    try:
        tasks_data = await client.generate_json_completion(
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user", 
                    "content": user_prompt
                }
            ],
            temperature=0.4,
            max_tokens=3500
        )
        if isinstance(tasks_data, dict):
            tasks_data = tasks_data.get("tasks") or tasks_data.get("task") or [tasks_data]
        if not isinstance(tasks_data, list):
            tasks_data = [tasks_data]
        return [task for task in tasks_data if isinstance(task, dict)]
        
    except Exception as e:
        logger.warning(f"Error generating tasks with LLM: {e}")
        # Fallback: Generate detailed context-aware tasks
        return generate_fallback_tasks(project_plan)


def _detect_project_niche(project_plan: Dict) -> str:
    """Detect project niche/type from project data"""
    summary = (project_plan.get('summary', '') or '').lower()
    features = ' '.join([str(f).lower() for f in project_plan.get('key_features_deliverables', [])])
    combined = (summary + ' ' + features).lower()
    
    niche_keywords = {
        'web_development': ['web app', 'web application', 'frontend', 'react', 'vue', 'angular', 'typescript', 'html', 'css', 'responsive'],
        'api_service': ['api', 'rest', 'graphql', 'endpoint', 'microservice', 'service layer', 'backend service'],
        'mobile_development': ['mobile', 'ios', 'android', 'react native', 'flutter', 'app', 'cross-platform'],
        'database_system': ['database', 'db', 'mongodb', 'postgresql', 'mysql', 'redis', 'sql', 'schema'],
        'devops_infra': ['devops', 'deployment', 'kubernetes', 'docker', 'ci/cd', 'infrastructure', 'cloud'],
        'machine_learning': ['machine learning', 'ml', 'ai', 'nlp', 'deep learning', 'model', 'tensorflow', 'pytorch'],
        'blockchain': ['blockchain', 'smart contract', 'ethereum', 'web3', 'crypto', 'dapp'],
        'data_science': ['data science', 'analytics', 'big data', 'data pipeline', 'data processing'],
    }
    
    for niche, keywords in niche_keywords.items():
        if any(kw in combined for kw in keywords):
            return niche
    
    return 'general'


def _build_system_prompt(niche: str, project_plan: Dict) -> str:
    """Build niche-specific system prompt with detailed guidance"""
    
    niche_guidance = {
        'web_development': """
You are PRAXIS, the official AI Support Agent, and an expert web development project manager.

CRITICAL TASK GENERATION RULES FOR WEB DEVELOPMENT:
1. SEPARATE Frontend and Backend tasks clearly
2. Include API contract definition tasks BEFORE implementation
3. Include responsive design testing for multiple screen sizes
4. Emphasize database connectivity and ORM setup
5. Include deployment strategy (staging, production, CDN)
6. Cover authentication/authorization early in planning
7. Include SEO and performance optimization tasks

TYPICAL WEB PROJECT PHASES:
- Setup & Infrastructure (Project init, tool configuration)
- API Design & Specification (OpenAPI/Swagger)
- Backend Development (Core logic, database)
- Frontend Architecture (Components, state management)
- Frontend Implementation (Pages, features)
- Integration Testing (Full system testing)
- Security & Optimization
- Deployment & Monitoring

TASK SPECIFICITY: Tasks must be specific to web stack (not generic)
- NOT: "Build backend" → YES: "Implement Express.js API endpoints with Prisma ORM"
- NOT: "Create UI" → YES: "Build React components with TypeScript and Tailwind CSS"
""",
        'api_service': """
You are PRAXIS, the official AI Support Agent, and an expert API and microservice architect.

CRITICAL TASK GENERATION RULES FOR API SERVICES:
1. API Design must come BEFORE any implementation
2. Include comprehensive endpoint specification (OpenAPI/Swagger)
3. Define request/response schemas with validation rules
4. Include authentication/authorization design
5. Emphasize error handling and HTTP status codes
6. Include rate limiting and throttling strategies
7. Design versioning strategy upfront
8. Include API documentation generation
9. Include load testing and performance benchmarking
10. Design backwards compatibility strategy

TYPICAL API PROJECT PHASES:
- Requirements & API Specification
- API Contract Definition (Endpoints, schemas)
- Authentication & Security Design
- Core Implementation
- Error Handling & Validation
- API Documentation
- Load Testing & Performance
- Monitoring & Logging

TASK SPECIFICITY: Must define exact endpoints, not generic API tasks
- NOT: "Implement API" → YES: "Implement GET /projects/:id endpoint with Pagination"
- NOT: "Add authentication" → YES: "Implement JWT bearer token authentication with 24h expiry"
""",
        'mobile_development': """
You are PRAXIS, the official AI Support Agent, and an expert mobile app development project manager.

CRITICAL TASK GENERATION RULES FOR MOBILE:
1. EXPLICIT platform-specific tasks (iOS/Android or choose cross-platform)
2. Include design system setup with mobile constraints
3. Define offline-first architecture EARLY
4. Include device permissions and native feature integration
5. Emphasize testing on real devices (not just emulators)
6. Include app store submission tasks
7. Plan for different screen sizes and orientations
8. Include battery optimization and data usage optimization
9. Design error recovery and retry logic for network issues
10. Include progressive disclosure and mobile UX patterns

TYPICAL MOBILE PROJECT PHASES:
- Design & UX (Mobile-specific)
- Development Environment Setup
- Core App Architecture
- Screen Implementation
- Native Feature Integration
- Offline Data Storage
- Testing on Real Devices
- Battery & Performance Optimization
- App Store Submission

TASK SPECIFICITY: Must be platform and feature specific
- NOT: "Develop app" → YES: "Implement native maps integration using MapKit (iOS) and Google Maps API (Android)"
- NOT: "Add features" → YES: "Implement camera capture with photo editing using native camera APIs"
""",
        'database_system': """
You are PRAXIS, the official AI Support Agent, and an expert database architect and DBA.

CRITICAL TASK GENERATION RULES FOR DATABASE:
1. Data modeling comes BEFORE schema creation
2. Include performance considerations early (indexing, normalization vs denormalization)
3. Define backup and disaster recovery strategy
4. Include migration strategy and versioning
5. Design for scalability (partitioning, replication)
6. Include monitoring and query optimization
7. Plan for data integrity constraints
8. Include testing for data consistency and ACID properties
9. Design security and encryption strategy
10. Include capacity planning and growth projections

TYPICAL DATABASE PROJECT PHASES:
- Data Requirements & Modeling
- Database Technology Selection
- Schema Design & Normalization
- Indexing & Query Optimization
- Migration & Versioning Strategy
- Backup & Recovery Setup
- Monitoring & Performance Tuning
- Security & Encryption

TASK SPECIFICITY: Must be schema and query specific
- NOT: "Setup database" → YES: "Design and create PostgreSQL schema with proper normalization (3NF) for user accounts, authentication tokens, and audit logs"
- NOT: "Add indexes" → YES: "Create composite indexes on (user_id, created_at) and (status, updated_at) for optimized query performance"
""",
        'devops_infra': """
You are PRAXIS, the official AI Support Agent, and an expert DevOps engineer and infrastructure architect.

CRITICAL TASK GENERATION RULES FOR DEVOPS:
1. Infrastructure as Code (IaC) is mandatory (Terraform/CloudFormation)
2. CI/CD pipeline design comes early
3. Define environment strategy (dev, staging, prod)
4. Include monitoring, logging, and alerting setup
5. Plan containerization strategy (Docker)
6. Include orchestration (Kubernetes, Docker Swarm)
7. Define security hardening and compliance
8. Include disaster recovery and high availability
9. Design secrets management
10. Include cost optimization strategies

TYPICAL DEVOPS PROJECT PHASES:
- Cloud Architecture Design
- Infrastructure as Code Development
- CI/CD Pipeline Setup
- Container & Orchestration Setup
- Monitoring & Logging
- Security & Compliance
- Backup & Disaster Recovery
- Cost Optimization

TASK SPECIFICITY: Must specify cloud provider, tools, and configuration
- NOT: "Setup infrastructure" → YES: "Create AWS VPC with public/private subnets, security groups, NAT gateways, and configure auto-scaling groups"
- NOT: "Create CI/CD" → YES: "Set up GitHub Actions CI/CD with automated testing, Docker image building, and ECS deployment with rollback strategy"
""",
        'machine_learning': """
You are PRAXIS, the official AI Support Agent, and an expert machine learning engineer and data scientist.

CRITICAL TASK GENERATION RULES FOR ML:
1. Problem definition and metrics come BEFORE any modeling
2. Data collection and preprocessing is often 80% of the work
3. Include exploratory data analysis (EDA)
4. Define baseline model requirements
5. Include hyperparameter tuning and cross-validation
6. Define model evaluation and testing strategy
7. Include model explainability and interpretability analysis
8. Design inference pipeline and deployment
9. Include model monitoring and retraining strategy
10. Plan for data drift detection

TYPICAL ML PROJECT PHASES:
- Problem Definition & Metrics
- Data Collection & Preparation
- Exploratory Data Analysis (EDA)
- Feature Engineering
- Model Selection & Learning
- Model Evaluation & Tuning
- Model Deployment
- Monitoring & Retraining

TASK SPECIFICITY: Must specify algorithms, frameworks, and metrics
- NOT: "Build model" → YES: "Build XGBoost classifier with hyperparameter optimization (grid search on max_depth, learning_rate) and 5-fold cross-validation with F1 macro scoring"
- NOT: "Deploy model" → YES: "Deploy trained model using FastAPI with ONNX format, implement input validation, output post-processing, and model versioning with fallback to previous model"
""",
        'blockchain': """
You are PRAXIS, the official AI Support Agent, and an expert blockchain architect and smart contract developer.

CRITICAL TASK GENERATION RULES FOR BLOCKCHAIN:
1. Smart contract design and security review comes EARLY
2. Include formal verification for critical contracts
3. Define gas optimization strategy
4. Include testnet deployment and testing before mainnet
5. Design wallet integration carefully
6. Include security audit (internal and external)
7. Plan for upgrade mechanisms (proxy patterns)
8. Include compliance and legal considerations
9. Design monitoring for transaction failures
10. Include fallback and emergency pause mechanisms

TYPICAL BLOCKCHAIN PROJECT PHASES:
- Requirements & Smart Contract Design
- Contract Development & Testing
- Security & Formal Verification
- Testnet Deployment & Testing
- Wallet & UI Integration
- Mainnet Deployment Strategy
- Monitoring & Governance

TASK SPECIFICITY: Must specify blockchain, language, and patterns
- NOT: "Create smart contract" → YES: "Implement ERC-20 token contract in Solidity with proxy pattern (UUPS), initialize owner role, implement mint/burn functions with access control, and prepare for formal verification"
- NOT: "Launch on blockchain" → YES: "Deploy to Ethereum mainnet via CREATE2 factory, verify contract on Etherscan, set up monitoring for transaction failures, implement upgrade proxy, and test emergency withdrawal function"
""",
    }
    
    base_prompt = """You are PRAXIS, the official AI Support Agent, and a world-class project management expert specializing in detailed, niche-specific task generation.

📋 YOUR TASK: Generate a comprehensive, detailed breakdown of project work with specific, actionable tasks and subtasks.

🎯 CORE PRINCIPLES:
1. SPECIFICITY: Tasks must be concrete, not generic (name technologies, frameworks, exact deliverables)
2. ACTIONABILITY: Each task should be implementable by a team member independently
3. COMPLETENESS: Cover entire lifecycle from design through deployment
4. DOMAIN-SPECIFIC: Apply niche-specific best practices and patterns
5. REALISTIC ESTIMATES: Base durations on actual complexity, not arbitrary numbers
6. DEPENDENCIES: Map prerequisites correctly (no circular dependencies)
7. GRANULARITY: Each task should take 3-15 days (not too big, not too small)
8. TITLE BREVITY: Titles must be short (4-8 words, <=60 characters)
9. DESCRIPTION DEPTH: Descriptions must be 100-160 words and not repeat the title

🚫 ANTI-PATTERNS TO AVOID:
- Generic tasks like "Implement feature", "Build component", "Handle error"
- Vague descriptions without specific technologies or deliverables
- Missing security, testing, or deployment tasks
- Unrealistic time estimates
- Unclear task dependencies
- Combining multiple concerns in single task

📊 TASK BREAKDOWN STRUCTURE:
Each task MUST have:
- Short, specific title (4-8 words, <=60 characters)
- Comprehensive description (100-160 words with scope + acceptance criteria; do not repeat the title)
- Realistic estimated_hours (4-120 hours, depends on complexity)
- Priority level (critical/high/medium/low based on dependencies)
- Clear dependencies (list prerequisite task titles)
- Domain-specific technical requirements
"""
    
    niche_specific = niche_guidance.get(niche, "Apply general software engineering best practices.")
    
    return base_prompt + "\n" + niche_specific + """

📝 JSON OUTPUT FORMAT (MUST BE VALID):
[
    {
        "title": "Specific task title with exact deliverable",
        "description": "Comprehensive task description (100+ words) explaining scope, approach, acceptance criteria, and deliverables",
        "estimated_hours": 24,
        "priority": "high",
        "dependencies": ["previous_task_title"],
    }
]

⚠️ CRITICAL REQUIREMENTS:
- Generate 12-18 detailed, specific tasks
- Each task description: 100-160 words with specific details
- Titles must be short (4-8 words, <=60 characters) and not match the description
- All JSON keys and string values must use double quotes
- No markdown code blocks - pure JSON only
- Task titles must name specific technologies and deliverables
- Total project hours should be realistic for the scope"""


def _build_user_prompt(project_plan: Dict, niche: str) -> str:
    """Build detailed user prompt with project information"""
    
    summary = project_plan.get('summary', 'Project')
    features = project_plan.get('key_features_deliverables', [])
    milestones = project_plan.get('major_milestones', [])
    high_level = project_plan.get('high_level_tasks', [])
    skills = project_plan.get('skills_required', [])
    
    features_str = '\n'.join([f"  - {f}" for f in features[:10]]) if features else "  (None provided)"
    milestones_str = '\n'.join([f"  - {m}" for m in milestones[:5]]) if milestones else "  (None provided)"
    tasks_str = '\n'.join([f"  - {t}" for t in high_level[:10]]) if high_level else "  (None provided)"
    skills_str = ', '.join(skills[:8]) if skills else "General development"
    
    return f"""Generate a detailed 12-18 task project breakdown for this project:

PROJECT SUMMARY:
{summary}

PROJECT TYPE: {niche.replace('_', ' ').title()}

KEY FEATURES & DELIVERABLES:
{features_str}

MAJOR MILESTONES:
{milestones_str}

HIGH-LEVEL TASKS:
{tasks_str}

REQUIRED SKILLS:
{skills_str}

REQUIREMENTS FOR TASK GENERATION:
1. Generate 12-18 niche-specific, actionable tasks
2. Each task must be detailed with 100-160 word description
3. Titles must be 4-8 words, <=60 characters, and not repeated in the description
4. Cover entire project lifecycle (design → deployment)
5. Map dependencies correctly between tasks
6. Use specific technologies and frameworks mentioned in the project
7. Estimate hours realistically based on complexity (3-15 days per task)
8. Set priorities based on dependencies and importance
9. Include security, testing, and deployment tasks
10. Make tasks specific to this project, not generic

NICHE GUIDANCE:
Apply {niche.replace('_', ' ')} best practices and patterns.

OUTPUT:
Return ONLY valid JSON array of tasks. No markdown, no explanations, no text outside JSON.
Start with [ and end with ].
Each task must have: title (4-8 words), description (100-160 words), estimated_hours, priority, dependencies."""

def generate_fallback_tasks(project_plan: Dict) -> List[Dict]:
    """Generate comprehensive context-aware fallback tasks when LLM fails"""
    fallback_tasks = []
    high_level_tasks = project_plan.get('high_level_tasks', [])
    key_features = project_plan.get('key_features_deliverables', [])
    milestones = project_plan.get('major_milestones', [])
    summary = project_plan.get('summary', '')

    # Extract project context
    features_lower = [f.lower() if isinstance(f, str) else str(f).lower() for f in key_features]
    project_context = _extract_project_context(summary, features_lower, str(key_features))

    # Parse high-level tasks
    parsed_tasks = []
    for i, task in enumerate(high_level_tasks):
        parsed_task = _parse_task(task, i)
        if parsed_task:
            parsed_tasks.append(parsed_task)

    # If no high-level tasks, generate structural tasks
    if not parsed_tasks:
        parsed_tasks = _generate_structural_tasks(project_context)

    # Generate comprehensive tasks with context-specific sub_tasks
    for i, task_data in enumerate(parsed_tasks):
        task_name = task_data['name']
        task_description = task_data['description']
        task_duration = task_data['duration']

        priority = _determine_priority(task_name, features_lower, i, len(parsed_tasks))
        task_type = _classify_task_type(task_name, project_context)

        # Generate task-specific sub_tasks based on classification
        sub_tasks = _generate_context_aware_subtasks(
            task_name,
            task_duration,
            priority,
            task_type,
            project_context
        )

        fallback_tasks.append({
            "title": task_name,
            "description": task_description,
            "priority": priority,
            "estimated_hours": task_duration,
            "dependencies": task_data.get('dependencies', []),
            "sub_tasks": sub_tasks
        })

    return fallback_tasks


def _parse_task(task, index):
    """Parse task from string or dict format"""
    if isinstance(task, str) and "{" in task and "}" in task and ("task_name" in task or "title" in task):
        try:
            parsed = ast.literal_eval(task)
            if isinstance(parsed, dict):
                task = parsed
        except Exception:
            pass

    if isinstance(task, dict):
        task_name = (
            task.get("task_name")
            or task.get("title")
            or task.get("name")
            or f"Task {index+1}"
        )
        task_description = task.get("description") or f"Complete: {task_name}"
        task_duration = task.get("estimated_duration") or task.get("estimated_hours") or 10

        if isinstance(task_duration, str):
            try:
                task_duration = int(task_duration)
            except ValueError:
                task_duration = 10

        deps = task.get("dependencies") or []
        if not isinstance(deps, list):
            deps = []

        return {
            'name': str(task_name),
            'description': str(task_description),
            'duration': max(8, task_duration),
            'dependencies': deps
        }
    else:
        return {
            'name': str(task),
            'description': f"Complete: {task}",
            'duration': 10,
            'dependencies': []
        }


def _extract_project_context(summary, features, all_features):
    """Extract project context and domain from description and features"""
    context = {
        'is_api': False,
        'is_db': False,
        'is_mobile': False,
        'is_web': False,
        'is_ml': False,
        'is_cloud': False,
        'has_auth': False,
        'is_backend': False,
        'is_frontend': False,
        'domain': 'general'
    }

    combined_text = (summary + ' ' + ' '.join(features) + ' ' + all_features).lower()

    if any(w in combined_text for w in ['api', 'rest', 'graphql', 'endpoint']):
        context['is_api'] = True
    if any(w in combined_text for w in ['database', 'db', 'mongodb', 'sql', 'postgres']):
        context['is_db'] = True
    if any(w in combined_text for w in ['mobile', 'ios', 'android', 'react native']):
        context['is_mobile'] = True
    if any(w in combined_text for w in ['web', 'frontend', 'react', 'vue', 'angular']):
        context['is_web'] = True
    if any(w in combined_text for w in ['ml', 'machine learning', 'ai', 'nlp']):
        context['is_ml'] = True
    if any(w in combined_text for w in ['cloud', 'aws', 'gcp', 'azure', 'deployment']):
        context['is_cloud'] = True
    if any(w in combined_text for w in ['auth', 'authentication', 'login', 'security']):
        context['has_auth'] = True
    if any(w in combined_text for w in ['backend', 'server', 'api', 'service']):
        context['is_backend'] = True
    if any(w in combined_text for w in ['frontend', 'ui', 'ux', 'client', 'web']):
        context['is_frontend'] = True

    return context


def _generate_structural_tasks(context):
    """Generate comprehensive structural tasks based on project type"""
    tasks = []

    # Foundation tasks
    tasks.append({
        'name': 'Project Setup & Infrastructure',
        'description': 'Initialize project structure, configure tools, and set up development infrastructure',
        'duration': 12,
        'dependencies': []
    })

    if context['is_backend'] or context['is_api']:
        tasks.append({
            'name': 'Backend Architecture Design',
            'description': 'Design backend architecture, define data models, and plan API structure',
            'duration': 14,
            'dependencies': ['Project Setup & Infrastructure']
        })
        tasks.append({
            'name': 'Core API Implementation',
            'description': 'Implement core API endpoints and business logic',
            'duration': 20,
            'dependencies': ['Backend Architecture Design']
        })

    if context['is_db']:
        tasks.append({
            'name': 'Database Design & Setup',
            'description': 'Design database schema, create migrations, and optimize queries',
            'duration': 16,
            'dependencies': ['Project Setup & Infrastructure']
        })

    if context['is_frontend'] or context['is_web']:
        tasks.append({
            'name': 'Frontend Architecture & Components',
            'description': 'Design UI/UX, create component library, and establish design system',
            'duration': 16,
            'dependencies': ['Project Setup & Infrastructure']
        })
        tasks.append({
            'name': 'Frontend Implementation',
            'description': 'Build frontend pages, integrate APIs, and implement features',
            'duration': 20,
            'dependencies': ['Frontend Architecture & Components']
        })

    if context['has_auth']:
        tasks.append({
            'name': 'Authentication & Security',
            'description': 'Implement authentication, authorization, and security controls',
            'duration': 14,
            'dependencies': ['Project Setup & Infrastructure']
        })

    if context['is_mobile']:
        tasks.append({
            'name': 'Mobile App Development',
            'description': 'Develop mobile application with platform-specific optimizations',
            'duration': 24,
            'dependencies': ['Project Setup & Infrastructure']
        })

    # Testing & Quality
    tasks.append({
        'name': 'Testing & Quality Assurance',
        'description': 'Write tests, perform QA, and ensure code quality',
        'duration': 16,
        'dependencies': []
    })

    # Documentation & Deployment
    tasks.append({
        'name': 'Documentation & Knowledge Transfer',
        'description': 'Create comprehensive documentation and guides',
        'duration': 10,
        'dependencies': []
    })

    tasks.append({
        'name': 'Deployment & Production Setup',
        'description': 'Deploy application and set up production environment',
        'duration': 12,
        'dependencies': []
    })

    return tasks


def _classify_task_type(task_name, context):
    """Classify task into specific type for generating appropriate sub_tasks"""
    task_lower = task_name.lower()

    if 'api' in task_lower or 'endpoint' in task_lower:
        return 'api_development'
    elif 'database' in task_lower or 'schema' in task_lower:
        return 'database_design'
    elif 'frontend' in task_lower or 'ui' in task_lower or 'component' in task_lower:
        return 'frontend_development'
    elif 'mobile' in task_lower:
        return 'mobile_development'
    elif 'auth' in task_lower or 'security' in task_lower:
        return 'authentication_security'
    elif 'testing' in task_lower or 'qa' in task_lower:
        return 'testing_qa'
    elif 'deployment' in task_lower or 'production' in task_lower:
        return 'deployment'
    elif 'documentation' in task_lower:
        return 'documentation'
    elif 'setup' in task_lower or 'infrastructure' in task_lower or 'architecture' in task_lower:
        return 'infrastructure_setup'
    else:
        return 'general_development'


def _generate_context_aware_subtasks(task_name, estimated_hours, priority, task_type, context):
    """Generate context-specific sub_tasks based on task type"""

    subtasks_map = {
        'api_development': _generate_api_subtasks,
        'database_design': _generate_database_subtasks,
        'frontend_development': _generate_frontend_subtasks,
        'mobile_development': _generate_mobile_subtasks,
        'authentication_security': _generate_auth_subtasks,
        'testing_qa': _generate_testing_subtasks,
        'deployment': _generate_deployment_subtasks,
        'documentation': _generate_documentation_subtasks,
        'infrastructure_setup': _generate_infrastructure_subtasks,
        'general_development': _generate_general_subtasks
    }

    generator = subtasks_map.get(task_type, _generate_general_subtasks)
    return generator(task_name, estimated_hours, priority)


def _divide_hours(total_hours, priority):
    """Divide hours based on priority"""
    if priority == 'high':
        return {
            'planning': total_hours * 0.15,
            'design': total_hours * 0.15,
            'implementation': total_hours * 0.50,
            'testing': total_hours * 0.15,
            'review': total_hours * 0.05
        }
    elif priority == 'low':
        return {
            'planning': total_hours * 0.10,
            'design': total_hours * 0.08,
            'implementation': total_hours * 0.65,
            'testing': total_hours * 0.12,
            'review': total_hours * 0.05
        }
    else:
        return {
            'planning': total_hours * 0.13,
            'design': total_hours * 0.12,
            'implementation': total_hours * 0.55,
            'testing': total_hours * 0.15,
            'review': total_hours * 0.05
        }


def _generate_api_subtasks(task_name, hours, priority):
    """Generate API-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    # Planning & Requirements
    sub_tasks.extend([
        {"title": "1.1 Gather API Requirements", "description": f"Document API endpoints, request/response formats, status codes, rate limits for {task_name}. Define authentication/authorization requirements.", "estimated_hours": max(0.5, h['planning'] * 0.4)},
        {"title": "1.2 Research Standards & Patterns", "description": "Research REST/GraphQL best practices, API versioning strategies, and design patterns. Review existing similar APIs.", "estimated_hours": max(0.5, h['planning'] * 0.35)},
        {"title": "1.3 Create API Specification Document", "description": f"Create OpenAPI/Swagger specification with detailed endpoint definitions, request/response schemas, error codes, and examples for {task_name}.", "estimated_hours": max(0.5, h['planning'] * 0.25)},
    ])

    # Design & Architecture
    sub_tasks.extend([
        {"title": "2.1 Design API Endpoints Architecture", "description": "Design endpoint structure, URL patterns, HTTP methods, resource hierarchy, and endpoint organization strategy.", "estimated_hours": max(0.75, h['design'] * 0.35)},
        {"title": "2.2 Define Request/Response Contracts", "description": "Define data schemas, validation rules, error response formats, pagination strategy, and versioning approach for all endpoints.", "estimated_hours": max(0.75, h['design'] * 0.35)},
        {"title": "2.3 Plan Security & Authentication", "description": "Design authentication flows (JWT/OAuth2), authorization strategy, rate limiting, and security headers for the API.", "estimated_hours": max(0.75, h['design'] * 0.3)},
    ])

    # Implementation
    sub_tasks.extend([
        {"title": "3.1 Set Up API Framework & Dependencies", "description": f"Configure API framework (FastAPI/Express/Django), set up middleware, routing, and dependency injection for {task_name}.", "estimated_hours": max(1, h['implementation'] * 0.12)},
        {"title": "3.2 Implement Core Endpoints - Part A", "description": f"Implement primary GET/POST endpoints for {task_name}. Set up request parsing, validation, and response formatting.", "estimated_hours": max(1.5, h['implementation'] * 0.35)},
        {"title": "3.3 Implement Core Endpoints - Part B", "description": f"Implement PUT/PATCH/DELETE endpoints and secondary endpoints for {task_name}. Add proper HTTP status codes and error handling.", "estimated_hours": max(1.5, h['implementation'] * 0.35)},
        {"title": "3.4 Add Authentication & Authorization", "description": "Implement authentication mechanisms, protect endpoints, add authorization checks, and validate user permissions.", "estimated_hours": max(1, h['implementation'] * 0.12)},
        {"title": "3.5 Implement Rate Limiting & Caching", "description": "Add rate limiting, request caching, response caching, and performance optimization strategies.", "estimated_hours": max(1, h['implementation'] * 0.06)},
    ])

    # Testing
    sub_tasks.extend([
        {"title": "4.1 Write Unit Tests for Endpoints", "description": "Write unit tests for all API endpoints, covering success/failure scenarios, edge cases, and validation rules.", "estimated_hours": max(1, h['testing'] * 0.35)},
        {"title": "4.2 Integration Testing", "description": "Test API integrations with database, external services, and upstream/downstream systems. Verify data consistency.", "estimated_hours": max(1, h['testing'] * 0.35)},
        {"title": "4.3 Performance & Load Testing", "description": "Perform load testing, stress testing, and benchmark API response times under various conditions.", "estimated_hours": max(0.75, h['testing'] * 0.2)},
        {"title": "4.4 Security Testing & Fixes", "description": "Conduct security audit, test for vulnerabilities (injection, auth bypass, etc.), and fix identified issues.", "estimated_hours": max(0.75, h['testing'] * 0.1)},
    ])

    # Review & Documentation
    sub_tasks.extend([
        {"title": "5.1 Code Review & Optimization", "description": "Submit API for peer review, address feedback, optimize code, and improve maintainability.", "estimated_hours": max(0.75, h['review'])},
        {"title": "5.2 Generate API Documentation", "description": f"Create interactive API documentation using Swagger/Postman, provide usage examples, and SDK documentation for {task_name}.", "estimated_hours": max(0.5, h['review'] * 0.5)},
    ])

    return sub_tasks[:16]  # Return top 16 unique sub_tasks


def _generate_database_subtasks(task_name, hours, priority):
    """Generate database-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    # Planning & Requirements
    sub_tasks.extend([
        {"title": "1.1 Gather Data Requirements", "description": f"Collect data requirements, business rules, transaction patterns, and expected data volume for {task_name}.", "estimated_hours": max(0.5, h['planning'] * 0.4)},
        {"title": "1.2 Research Database Technology", "description": "Research database options (SQL vs NoSQL), compare technologies, and select optimal database for requirements.", "estimated_hours": max(0.5, h['planning'] * 0.35)},
        {"title": "1.3 Create Data Model Specification", "description": f"Document all entities, relationships, attributes, and constraints needed for {task_name} data model.", "estimated_hours": max(0.5, h['planning'] * 0.25)},
    ])

    # Design & Architecture
    sub_tasks.extend([
        {"title": "2.1 Design Database Schema", "description": "Design tables, columns, data types, constraints, primary keys, and foreign keys. Create ER diagrams.", "estimated_hours": max(0.75, h['design'] * 0.35)},
        {"title": "2.2 Plan Indexing Strategy", "description": "Design indexes for frequently queried columns, analyze query patterns, and plan composite indexes for performance.", "estimated_hours": max(0.75, h['design'] * 0.3)},
        {"title": "2.3 Design Data Integrity & Backup", "description": "Plan data validation rules, define backup strategy, recovery procedures, and disaster recovery plan.", "estimated_hours": max(0.75, h['design'] * 0.35)},
    ])

    # Implementation
    sub_tasks.extend([
        {"title": "3.1 Set Up Database Environment", "description": f"Configure database instance, set up connection pools, and initialize database server for {task_name}.", "estimated_hours": max(1, h['implementation'] * 0.1)},
        {"title": "3.2 Create Database Schema", "description": "Execute DDL scripts, create tables, define columns, constraints, and relationships in the database.", "estimated_hours": max(1.5, h['implementation'] * 0.3)},
        {"title": "3.3 Create Indexes & Optimize", "description": "Create indexes on key columns, optimize query performance, and verify index usage.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "3.4 Create Migration Scripts", "description": "Write database migration scripts for version control, schema changes, and rollback procedures.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "3.5 Set Up Seed Data", "description": "Create seed data scripts, populate test data, and set up fixtures for development and testing environments.", "estimated_hours": max(0.75, h['implementation'] * 0.15)},
        {"title": "3.6 Configure Monitoring & Logging", "description": "Set up database monitoring, query logging, slow query logs, and performance metrics collection.", "estimated_hours": max(0.75, h['implementation'] * 0.15)},
    ])

    # Testing
    sub_tasks.extend([
        {"title": "4.1 Test Schema Integrity", "description": "Write tests to verify schema definition, constraints, relationships, and data type validations.", "estimated_hours": max(0.75, h['testing'] * 0.3)},
        {"title": "4.2 Test Query Performance", "description": "Test query execution plans, measure response times, identify slow queries, and optimize N+1 problems.", "estimated_hours": max(0.75, h['testing'] * 0.35)},
        {"title": "4.3 Test Data Consistency", "description": "Test ACID properties, transaction handling, concurrent access, and data consistency under load.", "estimated_hours": max(0.75, h['testing'] * 0.25)},
        {"title": "4.4 Test Backup & Recovery", "description": "Test backup procedures, verify restore capabilities, and validate disaster recovery procedures.", "estimated_hours": max(0.75, h['testing'] * 0.1)},
    ])

    # Review & Documentation
    sub_tasks.extend([
        {"title": "5.1 Code Review & Optimization", "description": "Review schema design, optimize table structures, and improve database performance.", "estimated_hours": max(0.75, h['review'])},
        {"title": "5.2 Create Database Documentation", "description": f"Document schema, create data dictionary, provide connection guidelines, and migration procedures for {task_name}.", "estimated_hours": max(0.5, h['review'] * 0.5)},
    ])

    return sub_tasks[:16]


def _generate_frontend_subtasks(task_name, hours, priority):
    """Generate frontend-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    # Planning & Analysis
    sub_tasks.extend([
        {"title": "1.1 Gather UI/UX Requirements", "description": f"Collect user requirements, define user stories, wireframes, and design specifications for {task_name}.", "estimated_hours": max(0.5, h['planning'] * 0.4)},
        {"title": "1.2 Create Design System & Components", "description": "Define design system, branding guidelines, color schemes, typography, and reusable component library.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.3 Plan Responsive Design", "description": "Plan responsive breakpoints, mobile-first approach, accessibility requirements, and browser compatibility.", "estimated_hours": max(0.5, h['planning'] * 0.25)},
    ])

    # Design & Architecture
    sub_tasks.extend([
        {"title": "2.1 Design UI Mockups", "description": f"Create high-fidelity mockups, wireframes, and user flows for {task_name}. Design interactive prototypes.", "estimated_hours": max(0.75, h['design'] * 0.4)},
        {"title": "2.2 Establish Frontend Architecture", "description": "Plan component hierarchy, state management strategy, routing structure, and architectural patterns.", "estimated_hours": max(0.75, h['design'] * 0.35)},
        {"title": "2.3 Plan API Integration Strategy", "description": "Design API client structure, error handling, loading states, caching strategy, and data fetching approach.", "estimated_hours": max(0.75, h['design'] * 0.25)},
    ])

    # Implementation
    sub_tasks.extend([
        {"title": "3.1 Set Up Project & Build Tools", "description": f"Initialize frontend project, configure build tools, webpack/vite, and development environment for {task_name}.", "estimated_hours": max(1, h['implementation'] * 0.1)},
        {"title": "3.2 Build Reusable Components", "description": "Create base components (buttons, inputs, cards, etc.), ensure consistency, and establish component patterns.", "estimated_hours": max(1.5, h['implementation'] * 0.25)},
        {"title": "3.3 Implement Pages & Routes", "description": f"Implement page layouts, routing, navigation, and page-specific components for {task_name}.", "estimated_hours": max(1.5, h['implementation'] * 0.3)},
        {"title": "3.4 Integrate APIs & Data", "description": "Connect to backend APIs, implement data fetching, error handling, and loading state management.", "estimated_hours": max(1, h['implementation'] * 0.2)},
        {"title": "3.5 Add User Interactions & Forms", "description": "Implement form validation, user input handling, animations, and interactive elements.", "estimated_hours": max(1, h['implementation'] * 0.15)},
    ])

    # Testing & Responsive Design
    sub_tasks.extend([
        {"title": "4.1 Test Responsive Design", "description": "Test on various devices, screen sizes, and browsers. Verify responsive layout and touch interactions.",  "estimated_hours": max(1, h['testing'] * 0.25)},
        {"title": "4.2 Test Component Functionality", "description": "Write component tests, test user interactions, form validation, and state updates.", "estimated_hours": max(1, h['testing'] * 0.3)},
        {"title": "4.3 Test Accessibility (A11y)", "description": "Verify WCAG compliance, test keyboard navigation, screen reader compatibility, and accessibility.",  "estimated_hours": max(0.75, h['testing'] * 0.25)},
        {"title": "4.4 Test Cross-Browser Compatibility", "description": "Test on Chrome, Firefox, Safari, Edge browsers and verify consistent behavior across browsers.", "estimated_hours": max(0.75, h['testing'] * 0.2)},
    ])

    # Optimization & Documentation
    sub_tasks.extend([
        {"title": "5.1 Performance & Code Review", "description": "Optimize bundle size, implement lazy loading, optimize images, and improve performance metrics.", "estimated_hours": max(0.75, h['review'] * 0.7)},
        {"title": "5.2 Create Component Documentation", "description": f"Document component usage, create Storybook stories, and provide developer guidelines for {task_name}.", "estimated_hours": max(0.5, h['review'] * 0.3)},
    ])

    return sub_tasks[:16]


def _generate_mobile_subtasks(task_name, hours, priority):
    """Generate mobile-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    sub_tasks.extend([
        {"title": "1.1 Gather Mobile Requirements", "description": f"Collect mobile app requirements, target platforms (iOS/Android), device specifications for {task_name}.", "estimated_hours": max(0.5, h['planning'] * 0.4)},
        {"title": "1.2 Design Mobile UX", "description": "Design mobile UI, define interaction patterns, navigation model, and mobile-specific constraints.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.3 Plan Platform Strategy", "description": "Decide native vs cross-platform approach, select framework (React Native, Flutter), and platform-specific requirements.", "estimated_hours": max(0.5, h['planning'] * 0.25)},
        {"title": "2.1 Set Up Mobile Development Environment", "description": f"Install SDKs, configure emulators, set up development environment for {task_name} mobile app.", "estimated_hours": max(1, h['design'])},
        {"title": "3.1 Implement Mobile App Structure", "description": f"Create project structure, set up navigation, state management for {task_name} mobile application.", "estimated_hours": max(2, h['implementation'] * 0.2)},
        {"title": "3.2 Build Mobile Screens & Navigation", "description": f"Implement app screens, navigation flows, and mobile UI components for {task_name}.", "estimated_hours": max(2, h['implementation'] * 0.3)},
        {"title": "3.3 Integrate Backend APIs", "description": "Connect to backend APIs, handle offline mode, implement data synchronization, and network resilience.", "estimated_hours": max(1.5, h['implementation'] * 0.25)},
        {"title": "3.4 Implement Native Features", "description": "Integrate device features (camera, location, push notifications, storage) for mobile app.", "estimated_hours": max(1.5, h['implementation'] * 0.2)},
        {"title": "3.5 Handle Device Permissions", "description": "Implement permission handling, explain permissions to users, and gracefully handle permission denials.", "estimated_hours": max(1, h['implementation'] * 0.05)},
        {"title": "4.1 Test on Real Devices", "description": "Test mobile app on real iOS and Android devices, verify features and performance.", "estimated_hours": max(1.5, h['testing'] * 0.4)},
        {"title": "4.2 Test Battery & Data Usage", "description": "Profile battery consumption, monitor data usage, optimize for low-end devices.", "estimated_hours": max(1, h['testing'] * 0.3)},
        {"title": "4.3 Test App Performance", "description": "Test app startup time, screen transitions, memory usage, and overall responsiveness.", "estimated_hours": max(1, h['testing'] * 0.3)},
        {"title": "5.1 Optimize App Size & Performance", "description": "Reduce app bundle size, optimize assets, implement code splitting, and improve startup time.", "estimated_hours": max(1, h['review'])},
        {"title": "5.2 Create App Documentation", "description": f"Document app architecture, setup instructions, release procedures for {task_name} mobile app.", "estimated_hours": max(0.75, h['review'] * 0.5)},
    ])

    return sub_tasks[:16]


def _generate_auth_subtasks(task_name, hours, priority):
    """Generate authentication & security-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    sub_tasks.extend([
        {"title": "1.1 Define Security Requirements", "description": f"Document authentication requirements, security policies, compliance needs for {task_name}.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.2 Perform Threat Modeling", "description": "Identify threats, attack vectors, vulnerabilities, and security risks for the application.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.3 Select Authentication Method", "description": "Choose authentication method (JWT, OAuth2, Session-based), define token strategy and session management.", "estimated_hours": max(0.75, h['planning'] * 0.3)},
        {"title": "2.1 Design Security Architecture", "description": f"Design authentication flows, authorization model, role-based access control for {task_name}.", "estimated_hours": max(1, h['design'] * 0.4)},
        {"title": "2.2 Plan Encryption & Hashing", "description": "Plan password hashing strategy, data encryption approach, and key management procedures.", "estimated_hours": max(0.75, h['design'] * 0.3)},
        {"title": "2.3 Design Rate Limiting & Account Security", "description": "Design rate limiting, account lockout policies, password rules, and 2FA/MFA strategy.", "estimated_hours": max(0.75, h['design'] * 0.3)},
        {"title": "3.1 Implement Authentication System", "description": f"Build login/signup/logout functionality, token generation, session management for {task_name}.", "estimated_hours": max(2, h['implementation'] * 0.3)},
        {"title": "3.2 Implement Authorization & RBAC", "description": "Implement role-based access control, permission checks, and resource authorization middleware.", "estimated_hours": max(2, h['implementation'] * 0.25)},
        {"title": "3.3 Implement Password Security", "description": "Implement password hashing, validation rules, password reset flows, and account recovery.", "estimated_hours": max(1.5, h['implementation'] * 0.2)},
        {"title": "3.4 Add Multi-Factor Authentication", "description": "Implement 2FA/MFA using TOTP, SMS, or push notifications for enhanced security.", "estimated_hours": max(1.5, h['implementation'] * 0.15)},
        {"title": "3.5 Implement Security Headers & HTTPS", "description": "Configure security headers (CSP, HSTS, XFO), enforce HTTPS, and set secure cookies.", "estimated_hours": max(1, h['implementation'] * 0.1)},
        {"title": "4.1 Security Testing & Vulnerability Scan", "description": "Perform penetration testing, vulnerability scanning, and fix identified security issues.", "estimated_hours": max(1.5, h['testing'] * 0.4)},
        {"title": "4.2 Test Authentication Flows", "description": "Test login, logout, token refresh, session expiry, and edge cases in authentication.", "estimated_hours": max(1.5, h['testing'] * 0.35)},
        {"title": "4.3 Test Authorization & RBAC", "description": "Test role-based access control, permission enforcement, and authorization edge cases.", "estimated_hours": max(1, h['testing'] * 0.25)},
        {"title": "5.1 Security Audit & Review", "description": "Conduct security code review, verify OWASP compliance, identify remaining vulnerabilities.", "estimated_hours": max(1, h['review'])},
    ])

    return sub_tasks[:16]


def _generate_testing_subtasks(task_name, hours, priority):
    """Generate testing & QA-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    sub_tasks.extend([
        {"title": "1.1 Define Testing Strategy", "description": f"Create test plan, define test cases, testing scope, and quality metrics for {task_name}.", "estimated_hours": max(1, h['planning'] * 0.4)},
        {"title": "1.2 Analyze Test Coverage Needs", "description": "Identify areas requiring unit, integration, e2e testing and define code coverage targets.", "estimated_hours": max(0.75, h['planning'] * 0.3)},
        {"title": "1.3 Set Up Testing Infrastructure", "description": "Configure test frameworks, test runners, CI/CD pipeline, and testing environment.", "estimated_hours": max(0.75, h['planning'] * 0.3)},
        {"title": "2.1 Design Test Cases", "description": f"Design comprehensive test cases covering happy path, edge cases, error scenarios for {task_name}.", "estimated_hours": max(1, h['design'] * 0.5)},
        {"title": "2.2 Plan Performance Testing", "description": "Define performance benchmarks, load testing strategy, stress testing approach, and acceptance criteria.", "estimated_hours": max(0.75, h['design'] * 0.3)},
        {"title": "2.3 Plan Security Testing", "description": "Define security test cases, penetration testing approach, vulnerability scanning strategy.", "estimated_hours": max(0.75, h['design'] * 0.2)},
        {"title": "3.1 Write Unit Tests", "description": f"Create unit tests for all functions/modules achieving 80%+ code coverage for {task_name}.", "estimated_hours": max(2, h['implementation'] * 0.35)},
        {"title": "3.2 Write Integration Tests", "description": "Write integration tests for component interactions, API contracts, and system integrations.", "estimated_hours": max(1.5, h['implementation'] * 0.25)},
        {"title": "3.3 Write End-to-End Tests", "description": f"Write e2e tests for user workflows, critical paths, and feature scenarios for {task_name}.", "estimated_hours": max(1.5, h['implementation'] * 0.25)},
        {"title": "3.4 Create Automated Test Suite", "description": "Set up test automation, continuous testing in CI/CD pipeline, and test result reporting.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "4.1 Execute Test Cases", "description": "Execute all test cases, document results, and log defects/issues found.", "estimated_hours": max(1.5, h['testing'] * 0.3)},
        {"title": "4.2 Performance & Load Testing", "description": "Execute load tests, stress tests, measure performance metrics, and identify bottlenecks.", "estimated_hours": max(1.5, h['testing'] * 0.3)},
        {"title": "4.3 Security Testing", "description": "Execute security tests, penetration testing, vulnerability scanning, and verify security controls.", "estimated_hours": max(1.5, h['testing'] * 0.2)},
        {"title": "4.4 Bug Triage & Retesting", "description": "Triage reported bugs, prioritize issues, verify fixes, and conduct regression testing.", "estimated_hours": max(1, h['testing'] * 0.2)},
        {"title": "5.1 Generate Test Reports", "description": f"Generate comprehensive test reports with coverage metrics, defect status, and quality metrics for {task_name}.", "estimated_hours": max(0.75, h['review'])},
    ])

    return sub_tasks[:16]


def _generate_deployment_subtasks(task_name, hours, priority):
    """Generate deployment-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    sub_tasks.extend([
        {"title": "1.1 Plan Deployment Strategy", "description": f"Document deployment approach, release plan, rollout strategy for {task_name}.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.2 Prepare Release Checklist", "description": "Create pre-deployment checklist, verification steps, and rollback procedures.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.3 Define Production Configuration", "description": "Document production environment configuration, secrets management, and environmental variables.", "estimated_hours": max(0.75, h['planning'] * 0.3)},
        {"title": "2.1 Set Up Infrastructure", "description": f"Provision cloud resources, configure servers, databases, load balancers for {task_name} production.", "estimated_hours": max(1, h['design'] * 0.4)},
        {"title": "2.2 Configure CI/CD Pipeline", "description": "Set up deployment pipeline, automated testing, build processes, and deployment automation.", "estimated_hours": max(1, h['design'] * 0.35)},
        {"title": "2.3 Plan Monitoring & Logging", "description": "Design monitoring strategy, logging architecture, alerting rules, and dashboards for production.", "estimated_hours": max(0.75, h['design'] * 0.25)},
        {"title": "3.1 Build & Package Application", "description": f"Create production build, optimize artifacts, generate deployment packages for {task_name}.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "3.2 Containerize Application", "description": "Create Docker images, build containers, push to registries, and verify container functionality.", "estimated_hours": max(1.5, h['implementation'] * 0.25)},
        {"title": "3.3 Set Up Database & Data Migration", "description": "Set up production database, run migrations, seed data, and verify data integrity.", "estimated_hours": max(1.5, h['implementation'] * 0.25)},
        {"title": "3.4 Configure Load Balancing & Scaling", "description": "Configure load balancers, auto-scaling policies, health checks, and failover mechanisms.", "estimated_hours": max(1.5, h['implementation'] * 0.2)},
        {"title": "3.5 Set Up Monitoring & Logging", "description": "Configure application monitoring, logging aggregation, error tracking, and performance monitoring tools.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "4.1 Conduct Pre-Deployment Testing", "description": "Run pre-deployment tests in staging environment, verify all systems, and validate readiness.", "estimated_hours": max(1, h['testing'] * 0.3)},
        {"title": "4.2 Execute Deployment", "description": f"Deploy to production environment, execute deployment scripts, and verify successful deployment of {task_name}.", "estimated_hours": max(1.5, h['testing'] * 0.35)},
        {"title": "4.3 Conduct Post-Deployment Tests", "description": "Test production application, verify functionality, check performance, and validate user workflows.", "estimated_hours": max(1.5, h['testing'] * 0.25)},
        {"title": "4.4 Monitor & Troubleshoot Deployment", "description": "Monitor production metrics, troubleshoot issues, execute hotfixes if needed.", "estimated_hours": max(1, h['testing'] * 0.1)},
        {"title": "5.1 Document Deployment Procedures", "description": f"Create deployment runbooks, document procedures, troubleshooting guides for {task_name} production.", "estimated_hours": max(0.75, h['review'])},
    ])

    return sub_tasks[:16]


def _generate_documentation_subtasks(task_name, hours, priority):
    """Generate documentation-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    sub_tasks.extend([
        {"title": "1.1 Gather Documentation Requirements", "description": f"Identify documentation needs, audience, and content required for {task_name}.", "estimated_hours": max(0.5, h['planning'] * 0.4)},
        {"title": "1.2 Plan Documentation Structure", "description": "Outline documentation structure, define sections, and plan content organization.", "estimated_hours": max(0.5, h['planning'] * 0.35)},
        {"title": "1.3 Set Up Documentation Tools", "description": "Set up documentation platform (Confluence, Docs, GitBook), configure templates and style guidelines.", "estimated_hours": max(0.5, h['planning'] * 0.25)},
        {"title": "2.1 Create Technical Architecture Doc", "description": f"Document system architecture, design decisions, technology choices for {task_name}.", "estimated_hours": max(1, h['design'] * 0.3)},
        {"title": "2.2 Create API/Interface Documentation", "description": "Document APIs, functions, classes, methods with parameters, return values, and examples.", "estimated_hours": max(1, h['design'] * 0.35)},
        {"title": "2.3 Plan User Guide & Tutorials", "description": "Outline user guide, tutorials, getting started guides, and frequently asked questions.", "estimated_hours": max(0.75, h['design'] * 0.35)},
        {"title": "3.1 Write Technical Documentation", "description": f"Write comprehensive technical docs, architecture diagrams, system design for {task_name}.", "estimated_hours": max(1.5, h['implementation'] * 0.35)},
        {"title": "3.2 Write API Documentation", "description": f"Create detailed API docs with endpoint descriptions, examples, error codes for {task_name}.", "estimated_hours": max(1.5, h['implementation'] * 0.3)},
        {"title": "3.3 Write Developer Setup Guides", "description": "Create installation guides, configuration instructions, and development environment setup documentation.", "estimated_hours": max(1, h['implementation'] * 0.18)},
        {"title": "3.4 Create User Guides & Tutorials", "description": "Write user guides, step-by-step tutorials, best practices, and usage examples.", "estimated_hours": max(1, h['implementation'] * 0.12)},
        {"title": "3.5 Add Code Comments & Examples", "description": f"Add inline code comments, docstrings, and code examples throughout {task_name} codebase.", "estimated_hours": max(1, h['implementation'] * 0.05)},
        {"title": "4.1 Review Documentation Completeness", "description": "Review all documentation for completeness, accuracy, and clarity. Identify gaps.", "estimated_hours": max(0.75, h['testing'] * 0.4)},
        {"title": "4.2 Test Documentation Accuracy", "description": "Test all documented procedures, commands, and examples. Verify accuracy and functionality.", "estimated_hours": max(1, h['testing'] * 0.35)},
        {"title": "4.3 Gather User Feedback on Docs", "description": "Collect feedback from users/developers on documentation usefulness and clarity.", "estimated_hours": max(0.75, h['testing'] * 0.25)},
        {"title": "5.1 Finalize & Publish Documentation", "description": f"Final review, formatting, publish documentation for {task_name} to public/internal repository.", "estimated_hours": max(0.75, h['review'])},
    ])

    return sub_tasks[:15]


def _generate_infrastructure_subtasks(task_name, hours, priority):
    """Generate infrastructure setup-specific sub_tasks"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    sub_tasks.extend([
        {"title": "1.1 Define Infrastructure Requirements", "description": f"Document infrastructure needs, hardware specs, network requirements for {task_name}.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.2 Research Technology Stack", "description": "Research and select frameworks, libraries, database, cache, and other technologies.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.3 Plan Development Environment", "description": "Plan local development setup, containerization, and development workflow.", "estimated_hours": max(0.75, h['planning'] * 0.3)},
        {"title": "2.1 Design System Architecture", "description": f"Design overall system architecture, components, data flow, and integration points for {task_name}.", "estimated_hours": max(1.5, h['design'] * 0.4)},
        {"title": "2.2 Design Infrastructure & DevOps", "description": "Design infrastructure topology, CI/CD pipeline, deployment strategy, and monitoring architecture.", "estimated_hours": max(1, h['design'] * 0.35)},
        {"title": "2.3 Plan Scalability & Performance", "description": "Plan for scalability, load balancing, caching strategy, and performance optimization.", "estimated_hours": max(1, h['design'] * 0.25)},
        {"title": "3.1 Initialize Project Structure", "description": f"Create project repository, set up folder structure, initialize version control for {task_name}.", "estimated_hours": max(1, h['implementation'] * 0.1)},
        {"title": "3.2 Set Up Development Dependencies", "description": "Install and configure all development dependencies, package managers, and build tools.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "3.3 Configure Build & Development Tools", "description": "Configure webpack/vite, Babel, linters, formatters, and other development tools.",  "estimated_hours": max(1.5, h['implementation'] * 0.2)},
        {"title": "3.4 Set Up Version Control & CI/CD", "description": "Configure Git workflow, set up GitHub Actions/GitLab CI, automated testing, and deployment pipelines.", "estimated_hours": max(1.5, h['implementation'] * 0.25)},
        {"title": "3.5 Set Up Local Development Environment", "description": "Create Docker Compose files, set up database containers, and local development stack.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "3.6 Configure Linting & Code Quality", "description": "Set up ESLint, Prettier, code quality tools, and pre-commit hooks for code standards.", "estimated_hours": max(1, h['implementation'] * 0.15)},
        {"title": "4.1 Test Development Setup", "description": f"Test development environment setup, verify all dependencies work, test build process for {task_name}.", "estimated_hours": max(1, h['testing'] * 0.4)},
        {"title": "4.2 Test CI/CD Pipeline", "description": "Test continuous integration pipeline, automated tests, and deployment automation.", "estimated_hours": max(1, h['testing'] * 0.35)},
        {"title": "4.3 Verify Tool Configurations", "description": "Verify linters, formatters, build tools work correctly and enforce code standards.", "estimated_hours": max(0.75, h['testing'] * 0.25)},
        {"title": "5.1 Create Setup Documentation", "description": f"Document setup procedures, environment configuration, troubleshooting for {task_name} development.", "estimated_hours": max(0.75, h['review'])},
    ])

    return sub_tasks[:16]


def _generate_general_subtasks(task_name, hours, priority):
    """Generate general development sub_tasks as fallback"""
    h = _divide_hours(hours, priority)
    sub_tasks = []

    sub_tasks.extend([
        {"title": "1.1 Gather Requirements", "description": f"Collect and document all requirements for {task_name}. Define scope and objectives.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.2 Research & Analysis", "description": "Research best practices, analyze existing solutions, and evaluate approaches.", "estimated_hours": max(0.75, h['planning'] * 0.35)},
        {"title": "1.3 Create Implementation Plan", "description": f"Create detailed plan, define milestones, allocate resources for {task_name}.",  "estimated_hours": max(0.75, h['planning'] * 0.3)},
        {"title": "2.1 Design Architecture", "description": f"Design architecture, define components, data flow, and integration for {task_name}.", "estimated_hours": max(1, h['design'] * 0.5)},
        {"title": "2.2 Define Technical Specs", "description": "Define technical specifications, interfaces, and implementation details.", "estimated_hours": max(1, h['design'] * 0.5)},
        {"title": "3.1 Set Up Project Environment", "description": f"Initialize project, configure tools, and set up development environment for {task_name}.", "estimated_hours": max(1, h['implementation'] * 0.12)},
        {"title": "3.2 Implement Core Functionality - Part A", "description": f"Implement core features and main logic of {task_name}.", "estimated_hours": max(2, h['implementation'] * 0.4)},
        {"title": "3.3 Implement Additional Features", "description": f"Implement secondary features, utilities, and supporting functionality for {task_name}.", "estimated_hours": max(2, h['implementation'] * 0.35)},
        {"title": "3.4 Add Error Handling & Logging", "description": "Implement error handling, logging, and monitoring capabilities.", "estimated_hours": max(1, h['implementation'] * 0.13)},
        {"title": "4.1 Write Unit Tests", "description": f"Write unit tests covering all functions, targeting 80%+ code coverage for {task_name}.", "estimated_hours": max(1, h['testing'] * 0.35)},
        {"title": "4.2 Integration Testing", "description": "Test integration between components and with external systems.", "estimated_hours": max(1, h['testing'] * 0.35)},
        {"title": "4.3 System & User Acceptance Testing", "description": "Perform end-to-end testing, system testing, and user acceptance testing.", "estimated_hours": max(1, h['testing'] * 0.2)},
        {"title": "4.4 Bug Fixes & Refinement", "description": "Fix identified bugs, optimize performance, and refine implementation.", "estimated_hours": max(0.75, h['testing'] * 0.1)},
        {"title": "5.1 Code Review & Optimization", "description": f"Submit for peer review, address feedback, optimize {task_name} implementation.", "estimated_hours": max(0.75, h['review'] * 0.7)},
        {"title": "5.2 Create Implementation Documentation", "description": f"Document implementation, create technical guides, and provide developer notes for {task_name}.", "estimated_hours": max(0.75, h['review'] * 0.3)},
    ])

    return sub_tasks[:15]


def _determine_priority(task_name: str, features_lower: List[str], task_index: int, total_tasks: int) -> str:
    """Determine task priority based on name, features, and position"""
    task_lower = task_name.lower()

    # High priority indicators
    high_priority_keywords = ["api", "auth", "database", "core", "critical", "main", "primary", "setup", "foundation"]
    if any(keyword in task_lower for keyword in high_priority_keywords):
        return "high"

    # Check if task is mentioned in key features
    if any(task_lower in feature for feature in features_lower):
        return "high"

    # First tasks tend to be foundational (higher priority)
    if task_index == 0:
        return "high"

    # Low priority keywords
    low_priority_keywords = ["documentation", "testing", "cleanup", "optimization", "polish", "refactor"]
    if any(keyword in task_lower for keyword in low_priority_keywords):
        return "low"

    return "medium"


def _generate_detailed_subtasks(task_name: str, estimated_hours: int, priority: str) -> List[Dict]:
    """Generate highly detailed sub_tasks with comprehensive breakdowns"""
    sub_tasks = []
    task_lower = task_name.lower()

    # Calculate time allocations
    if priority == "high":
        planning_hours = max(1.5, estimated_hours * 0.2)
        design_hours = max(1, estimated_hours * 0.15)
        implementation_hours = max(3, estimated_hours * 0.45)
        testing_hours = max(1.5, estimated_hours * 0.15)
        review_hours = max(0.5, estimated_hours * 0.05)
    elif priority == "low":
        planning_hours = max(0.5, estimated_hours * 0.12)
        design_hours = max(0.5, estimated_hours * 0.08)
        implementation_hours = max(2, estimated_hours * 0.65)
        testing_hours = max(0.5, estimated_hours * 0.1)
        review_hours = max(0.25, estimated_hours * 0.05)
    else:
        planning_hours = max(1, estimated_hours * 0.18)
        design_hours = max(0.75, estimated_hours * 0.12)
        implementation_hours = max(2.5, estimated_hours * 0.55)
        testing_hours = max(1, estimated_hours * 0.1)
        review_hours = max(0.25, estimated_hours * 0.05)

    # PHASE 1: PLANNING & REQUIREMENTS
    sub_tasks.append({
        "title": f"1.1 Requirements Gathering & Analysis",
        "description": f"Collect and document all requirements for {task_name}. Define scope, objectives, success criteria, dependencies, and constraints. Create requirement specification document.",
        "estimated_hours": max(0.5, planning_hours * 0.35)
    })

    sub_tasks.append({
        "title": f"1.2 Research & Feasibility Study",
        "description": f"Research existing solutions, best practices, and technology options for {task_name}. Evaluate feasibility, identify risks, and document findings.",
        "estimated_hours": max(0.5, planning_hours * 0.35)
    })

    sub_tasks.append({
        "title": f"1.3 Create Project Plan & Timeline",
        "description": f"Break down {task_name} into phases, set milestones, allocate resources, and create detailed timeline. Define success metrics and KPIs.",
        "estimated_hours": max(0.5, planning_hours * 0.3)
    })

    # PHASE 2: DESIGN & ARCHITECTURE
    sub_tasks.append({
        "title": f"2.1 System Design & Architecture",
        "description": f"Design the overall architecture for {task_name}. Create system diagrams, data flow diagrams, and architectural documentation. Define component interactions.",
        "estimated_hours": max(0.75, design_hours * 0.4)
    })

    if "api" in task_lower or "endpoint" in task_lower:
        sub_tasks.append({
            "title": f"2.2 API Specification & Contract Design",
            "description": f"Define REST/GraphQL API endpoints, HTTP methods, request/response schemas, status codes, and examples. Create OpenAPI/Swagger documentation. Define authentication and authorization patterns.",
            "estimated_hours": max(0.75, design_hours * 0.35)
        })
        sub_tasks.append({
            "title": f"2.3 Error Handling & Status Code Strategy",
            "description": f"Design comprehensive error handling strategy with appropriate HTTP status codes, error messages, retry logic, and fallback mechanisms.",
            "estimated_hours": max(0.5, design_hours * 0.25)
        })

    elif "database" in task_lower or "schema" in task_lower:
        sub_tasks.append({
            "title": f"2.2 Database Schema Design",
            "description": f"Design database schema with tables, columns, data types, constraints, relationships, and indexes. Create ER diagrams. Plan normalization strategy.",
            "estimated_hours": max(0.75, design_hours * 0.4)
        })
        sub_tasks.append({
            "title": f"2.3 Data Migration & Backup Strategy",
            "description": f"Plan data migration approach, backup strategy, recovery procedures, and rollback plans. Document data integrity checks.",
            "estimated_hours": max(0.5, design_hours * 0.25)
        })

    elif "auth" in task_lower or "security" in task_lower:
        sub_tasks.append({
            "title": f"2.2 Security Architecture & Threat Modeling",
            "description": f"Perform threat modeling, identify attack vectors, and design security architecture. Define authentication flows, token management, and session handling.",
            "estimated_hours": max(0.75, design_hours * 0.4)
        })
        sub_tasks.append({
            "title": f"2.3 Compliance & Standards Review",
            "description": f"Review applicable security standards (OWASP, NIST), compliance requirements, and best practices. Document security controls and policies.",
            "estimated_hours": max(0.5, design_hours * 0.25)
        })

    else:
        sub_tasks.append({
            "title": f"2.2 Technical Design Details",
            "description": f"Create detailed technical design including algorithms, data structures, workflows, and integration points for {task_name}.",
            "estimated_hours": max(0.75, design_hours * 0.6)
        })

    # PHASE 3: IMPLEMENTATION
    sub_tasks.append({
        "title": f"3.1 Setup Development Environment",
        "description": f"Set up project structure, dependencies, build tools, CI/CD pipelines, and development environment configurations for {task_name}.",
        "estimated_hours": max(1, implementation_hours * 0.12)
    })

    sub_tasks.append({
        "title": f"3.2 Core Implementation - Part A",
        "description": f"Implement core functionality and main logic for {task_name}. Write initial code, set up base classes/modules, and implement primary features.",
        "estimated_hours": max(1.5, implementation_hours * 0.35)
    })

    sub_tasks.append({
        "title": f"3.3 Core Implementation - Part B",
        "description": f"Continue implementation of secondary features, utility functions, helpers, and supporting code. Implement data models and persistence layer.",
        "estimated_hours": max(1.5, implementation_hours * 0.35)
    })

    sub_tasks.append({
        "title": f"3.4 Input Validation & Error Handling",
        "description": f"Implement comprehensive input validation, exception handling, logging, and error recovery mechanisms. Add defensive programming practices.",
        "estimated_hours": max(1, implementation_hours * 0.15)
    })

    sub_tasks.append({
        "title": f"3.5 Integration & Testing Setup",
        "description": f"Integrate with other components/services. Set up test frameworks, test utilities, fixtures, and mocks needed for testing {task_name}.",
        "estimated_hours": max(0.5, implementation_hours * 0.03)
    })

    # PHASE 4: TESTING & QA
    sub_tasks.append({
        "title": f"4.1 Unit Testing",
        "description": f"Write and execute unit tests for all functions/methods. Aim for 80%+ code coverage. Test edge cases, boundary conditions, and error scenarios.",
        "estimated_hours": max(0.75, testing_hours * 0.35)
    })

    sub_tasks.append({
        "title": f"4.2 Integration Testing",
        "description": f"Test integration between components/services. Verify data flow, contract compliance, and interaction patterns. Test with realistic data volumes.",
        "estimated_hours": max(0.75, testing_hours * 0.3)
    })

    sub_tasks.append({
        "title": f"4.3 End-to-End & System Testing",
        "description": f"Execute end-to-end test scenarios simulating user workflows. Test system behavior under normal and stress conditions. Verify performance requirements.",
        "estimated_hours": max(0.75, testing_hours * 0.25)
    })

    sub_tasks.append({
        "title": f"4.4 Bug Fixes & Quality Refinement",
        "description": f"Fix identified bugs, optimize performance bottlenecks, and refine code quality. Conduct code review with team and address feedback.",
        "estimated_hours": max(0.5, testing_hours * 0.1)
    })

    # PHASE 5: CODE REVIEW & QUALITY ASSURANCE
    sub_tasks.append({
        "title": f"5.1 Code Review & Peer Feedback",
        "description": f"Submit {task_name} implementation for peer review. Address code quality feedback, style issues, and best practice recommendations.",
        "estimated_hours": max(0.5, review_hours * 0.6)
    })

    sub_tasks.append({
        "title": f"5.2 Performance Optimization & Security Review",
        "description": f"Optimize code for performance, memory usage, and efficiency. Conduct security audit and vulnerability scan. Implement security hardening.",
        "estimated_hours": max(0.5, review_hours * 0.4)
    })

    # PHASE 6: DOCUMENTATION
    sub_tasks.append({
        "title": f"6.1 API/Technical Documentation",
        "description": f"Write comprehensive technical documentation including API docs (if applicable), code comments, class/function documentation, and architecture overview.",
        "estimated_hours": max(0.5, max(1, testing_hours * 0.5))
    })

    sub_tasks.append({
        "title": f"6.2 User Guide & Implementation Notes",
        "description": f"Create user guide, setup instructions, configuration documentation, and implementation notes. Document known limitations and future improvements.",
        "estimated_hours": max(0.5, max(0.75, testing_hours * 0.3))
    })

    sub_tasks.append({
        "title": f"6.3 Testing & Deployment Documentation",
        "description": f"Document testing procedures, test cases, deployment steps, rollback procedures, and operational guidelines for {task_name}.",
        "estimated_hours": max(0.5, max(0.75, testing_hours * 0.3))
    })

    # PHASE 7: DEPLOYMENT & MONITORING
    sub_tasks.append({
        "title": f"7.1 Deployment Preparation",
        "description": f"Prepare deployment artifacts, containers, configuration files, and deployment scripts. Set up staging environment and run pre-deployment tests.",
        "estimated_hours": max(0.5, review_hours * 0.5)
    })

    sub_tasks.append({
        "title": f"7.2 Monitoring & Logging Setup",
        "description": f"Configure application monitoring, logging, alerting, and metrics collection for {task_name}. Set up dashboards and health checks.",
        "estimated_hours": max(0.5, review_hours * 0.5)
    })

    return sub_tasks


async def breakdown_task_details(task: Dict, project_plan: Dict = None) -> Dict:
    """Break down a specific task into detailed sub-tasks using LLM.
    
    Takes a task and generates comprehensive sub-tasks with detailed descriptions
    without requiring the full task data - just task ID and project reference.
    """
    task_title = task.get("title", "Task")
    task_description = task.get("description", "")
    estimated_hours = int(task.get("estimated_hours") or 20)
    priority = task.get("priority", "medium")
    
    # Detect task type from title/description
    task_type = _detect_task_type(task_title, task_description)
    logger.info(
        f"Generating task breakdown with AI for '{task_title}' "
        f"(type={task_type}, estimated_hours={estimated_hours}, priority={priority})"
    )
    
    # Build context-aware prompt for breakdown
    breakdown_prompt = f"""You are PRAXIS, the official AI Support Agent, and an expert project manager breaking down a specific task into detailed, actionable sub-tasks.

TASK TO BREAK DOWN:
Title: {task_title}
Description: {task_description}
Estimated Hours: {estimated_hours}
Priority: {priority}
Task Type: {task_type}

REQUIREMENTS:
1. Generate 5-8 detailed sub-tasks that collectively complete this main task
2. Each sub-task must have:
   - Specific, actionable title (3-5 words)
   - Detailed description (50+ words) with acceptance criteria
   - Realistic estimated_hours (2-{estimated_hours // 2} hours)
3. Sub-tasks should be sequential but can have some parallelization
4. Distribute time realistically across sub-tasks
5. Include all necessary phases: Planning → Design → Implementation → Testing → Documentation
6. Consider the task type ({task_type}) when generating specific sub-tasks

TASK TYPE SPECIFIC GUIDANCE:
- API tasks: Include endpoint specification, schema validation, error handling
- Database tasks: Include schema design, migration, optimization
- Frontend tasks: Include design, implementation, testing, responsive design
- Backend tasks: Include architecture, implementation, testing, documentation
- Testing tasks: Include test planning, automation, coverage analysis
- Deployment tasks: Include preparation, execution, validation, rollback plan

CRITICAL: Task names/descriptions must be specific and actionable.

JSON OUTPUT (MUST BE VALID):
{{
    "sub_tasks": [
        {{
            "title": "Specific subtask name",
            "description": "Detailed description with acceptance criteria",
            "estimated_hours": 4
        }}
    ]
}}

Return ONLY valid JSON, no markdown, no explanations."""

    try:
        data = await client.generate_json_completion(
            messages=[
                {
                    "role": "system",
                    "content": "You are PRAXIS, the official AI Support Agent, and an expert at breaking down tasks into detailed, specific sub-tasks. Return only valid JSON."
                },
                {
                    "role": "user",
                    "content": breakdown_prompt
                }
            ],
            temperature=0.4,
            max_tokens=2000
        )
        if not isinstance(data, dict):
            data = {"sub_tasks": data if isinstance(data, list) else []}
        sub_tasks = data.get("sub_tasks", [])
        
        # Ensure sub_tasks is a valid list
        if not isinstance(sub_tasks, list):
            sub_tasks = [sub_tasks] if sub_tasks else []
        
        # Validate and normalize sub-tasks
        normalized_subtasks = []
        for st in sub_tasks:
            if isinstance(st, dict):
                normalized_subtasks.append({
                    "title": st.get("title", "Untitled"),
                    "description": st.get("description", ""),
                    "estimated_hours": int(st.get("estimated_hours", 1))
                })

        logger.info(
            f"AI task breakdown generated successfully for '{task_title}' "
            f"with {len(normalized_subtasks)} sub-tasks"
        )
        
        return {
            "task_id": task.get("_id") or task.get("id"),
            "task_title": task_title,
            "estimated_hours": estimated_hours,
            "sub_tasks": normalized_subtasks,
            "total_sub_task_hours": sum(st.get("estimated_hours", 0) for st in normalized_subtasks)
        }
        
    except Exception as e:
        logger.warning(f"Error breaking down task with LLM: {e}. Using fallback...")
        # Return fallback breakdown using pattern-based generation
        return _generate_fallback_breakdown(task)


def _detect_task_type(title: str, description: str) -> str:
    """Detect task type from title and description"""
    combined = (title + " " + description).lower()
    
    task_types = {
        'api': ['api', 'endpoint', 'rest', 'graphql', 'service'],
        'database': ['database', 'db', 'schema', 'migration', 'sql'],
        'frontend': ['frontend', 'ui', 'component', 'react', 'vue', 'angular', 'css'],
        'backend': ['backend', 'server', 'logic', 'business', 'core'],
        'authentication': ['auth', 'login', 'jwt', 'oauth', 'security'],
        'testing': ['test', 'qa', 'quality', 'coverage', 'validation'],
        'deployment': ['deploy', 'devops', 'docker', 'kubernetes', 'ci/cd'],
        'documentation': ['document', 'guide', 'readme', 'wiki', 'spec']
    }
    
    for task_type, keywords in task_types.items():
        if any(kw in combined for kw in keywords):
            return task_type
    
    return 'general'


def _generate_fallback_breakdown(task: Dict) -> Dict:
    """Generate fallback breakdown when LLM fails"""
    task_title = task.get("title", "Task")
    estimated_hours = int(task.get("estimated_hours") or 20)
    task_type = _detect_task_type(task_title, task.get("description", ""))
    logger.info(
        f"Generating fallback task breakdown for '{task_title}' "
        f"(type={task_type}, estimated_hours={estimated_hours})"
    )
    
    # Generate standard breakdown based on task type
    breakdown_map = {
        'api': [
            {"title": "Basic Requirements Review", "description": "Start by reading the feature request and identifying the simplest API behavior that must exist. List the main actors, the data they send, the data they expect back, and the minimum set of endpoints needed to satisfy the request without adding extra complexity.", "estimated_hours": max(2, estimated_hours * 0.1)},
            {"title": "Basic Endpoint Planning", "description": "Define the first version of the endpoint contract with routes, HTTP methods, request bodies, response shapes, and status codes. Keep this step simple and focused on the most direct request and response flow so implementation can begin with a clear target.", "estimated_hours": max(2, estimated_hours * 0.13)},
            {"title": "Intermediate Security Design", "description": "Add authentication and authorization planning, then decide which endpoints should be public, protected, or role-restricted. Document token handling, permission checks, and the minimum security controls needed to support the feature safely.", "estimated_hours": max(2, estimated_hours * 0.17)},
            {"title": "Core API Implementation", "description": "Implement the primary routes and business logic, wire the handlers into the application, and connect the API to its data or service layer. Focus on a working end-to-end path first, then refine the structure so the core flow is stable and reusable.", "estimated_hours": max(4, estimated_hours * 0.27)},
            {"title": "Advanced Validation and Testing", "description": "Add schema validation, edge-case handling, integration tests, and failure-path checks so the API behaves predictably under realistic and unusual inputs. Verify that the implementation is resilient, consistent, and ready for broader use.", "estimated_hours": max(3, estimated_hours * 0.2)},
            {"title": "Advanced Documentation and Handoff", "description": "Finish by documenting the API contract, usage examples, limitations, and operational notes. Include enough detail for another developer or service to integrate with the API confidently and maintain it without needing additional context.", "estimated_hours": max(3, estimated_hours * 0.13)},
        ],
        'database': [
            {"title": "Basic Data Inventory", "description": "Identify the smallest set of data entities, records, and fields that the feature depends on. Capture what must be stored, what must be read back, and the minimum business rules that shape the storage design.", "estimated_hours": max(2, estimated_hours * 0.1)},
            {"title": "Basic Schema Draft", "description": "Create a first-pass schema with the core tables or collections, primary keys, and essential relationships. Keep the structure simple, but make sure it already supports the main read and write flows required by the task.", "estimated_hours": max(2, estimated_hours * 0.13)},
            {"title": "Intermediate Integrity Rules", "description": "Add constraints, validation rules, indexes, and migration planning so the schema is safe to evolve. Cover the most important data integrity concerns before implementation begins.", "estimated_hours": max(2, estimated_hours * 0.17)},
            {"title": "Core Model and Access Layer", "description": "Implement the ORM models, repositories, or access helpers that connect application logic to the database. Keep this step focused on the main path first, while making the data layer easy to extend later.", "estimated_hours": max(4, estimated_hours * 0.27)},
            {"title": "Advanced Query Optimization", "description": "Tune indexes, review query plans, and address bottlenecks that could affect performance at scale. Validate that the important read and write patterns are efficient and that the schema will hold up under heavier use.", "estimated_hours": max(3, estimated_hours * 0.2)},
            {"title": "Advanced Recovery and Validation", "description": "Verify backups, restore paths, rollback strategies, and consistency checks so the database layer is production-ready. Confirm that the design can recover from failure and still preserve data integrity.", "estimated_hours": max(3, estimated_hours * 0.13)},
        ],
        'frontend': [
            {"title": "Basic User Flow Mapping", "description": "Start with the simplest user journey for the feature and identify the screens, actions, and content needed to complete it. Capture the minimum viable flow first so the UI has a clear direction before component design begins.", "estimated_hours": max(2, estimated_hours * 0.1)},
            {"title": "Basic Layout and Components", "description": "Sketch the page structure and reusable component set needed to support the flow. Keep the first pass straightforward, with clear separation between shared UI pieces and page-specific content.", "estimated_hours": max(2, estimated_hours * 0.13)},
            {"title": "Intermediate Interaction Design", "description": "Define state changes, form behavior, loading states, error states, and user feedback. Make sure the interface handles the most important interactions cleanly before styling and polish are added.", "estimated_hours": max(2, estimated_hours * 0.17)},
            {"title": "Core UI Implementation", "description": "Build the actual screens, components, and client-side logic needed for the feature to work end to end. Focus on the main interaction path first, then connect it to data and application state.", "estimated_hours": max(4, estimated_hours * 0.27)},
            {"title": "Advanced Styling and Responsiveness", "description": "Refine spacing, typography, layout behavior, and responsive breakpoints so the UI works well across devices. Improve visual consistency and usability once the functional foundation is in place.", "estimated_hours": max(3, estimated_hours * 0.2)},
            {"title": "Advanced Accessibility and Polish", "description": "Finish by validating accessibility, keyboard support, screen reader behavior, and overall usability. Resolve remaining UX issues and ensure the UI is ready for release or handoff.", "estimated_hours": max(3, estimated_hours * 0.13)},
        ],
        'testing': [
            {"title": "Basic Test Planning", "description": "Start with the smallest useful test plan by identifying what the feature must prove and which behaviors are most important to check. Define the simplest pass criteria so the testing effort stays focused from the beginning.", "estimated_hours": max(1, estimated_hours * 0.1)},
            {"title": "Basic Unit Coverage", "description": "Write direct unit tests for the core functions, helpers, or rules that support the feature. Cover the simplest success path first, then add a few essential failure cases to make the logic reliable.", "estimated_hours": max(2, estimated_hours * 0.16)},
            {"title": "Intermediate Integration Coverage", "description": "Test how the feature behaves when it interacts with APIs, databases, services, or component boundaries. Confirm that the connected pieces work together before moving on to broader validation.", "estimated_hours": max(2, estimated_hours * 0.2)},
            {"title": "Core End-to-End Execution", "description": "Run the feature through realistic workflows from start to finish and verify that the main user or system path works as expected. This establishes that the implementation is functional beyond individual unit checks.", "estimated_hours": max(2, estimated_hours * 0.22)},
            {"title": "Advanced Regression and Edge Testing", "description": "Push the implementation through edge cases, unusual inputs, and regression scenarios to find weaknesses that the main path does not expose. This step hardens the feature before release.", "estimated_hours": max(2, estimated_hours * 0.18)},
            {"title": "Advanced Reporting and Sign-off", "description": "Summarize coverage, defects, risk areas, and final test outcomes in a way that supports release decisions. Make the results easy to review, trace, and hand off to the next person.", "estimated_hours": max(2, estimated_hours * 0.14)},
        ],
        'deployment': [
            {"title": "Basic Release Preparation", "description": "Gather the files, configuration, and environment details needed to ship the feature. Confirm the simplest release package is available and that the deployment target is known before any automation is introduced.", "estimated_hours": max(2, estimated_hours * 0.1)},
            {"title": "Basic Infrastructure Setup", "description": "Prepare the target environment with the minimum runtime, network, and storage requirements needed for a safe release. Keep this stage simple and focused on making deployment possible without introducing unnecessary complexity.", "estimated_hours": max(2, estimated_hours * 0.14)},
            {"title": "Intermediate CI/CD Automation", "description": "Set up or refine the build, test, and deployment pipeline so releases can be repeated reliably. Add the basic checks and gates needed to reduce manual effort and avoid obvious release mistakes.", "estimated_hours": max(2, estimated_hours * 0.18)},
            {"title": "Core Staging Deployment", "description": "Deploy the feature to staging or a similar pre-production environment and verify that configuration, integrations, and behavior are correct. Use this as the main dress rehearsal before production.", "estimated_hours": max(2, estimated_hours * 0.24)},
            {"title": "Advanced Production Validation", "description": "Run smoke tests, monitor logs and metrics, and confirm that the release is healthy under real conditions. Check for regressions, performance issues, and rollback readiness before signing off.", "estimated_hours": max(3, estimated_hours * 0.22)},
            {"title": "Advanced Operational Handoff", "description": "Document the deployment steps, monitoring notes, and operational follow-up so the release can be supported confidently. Include what was validated, what remains risky, and what to watch after deployment.", "estimated_hours": max(3, estimated_hours * 0.12)},
        ],
    }
    
    sub_tasks = breakdown_map.get(task_type, [
        {"title": "1. Basic Scope Review", "description": "Read the task and identify the most basic deliverable that must exist before anything else. Capture the minimum goal, the main constraint, and the first pass at what success looks like.", "estimated_hours": max(2, estimated_hours * 0.1)},
        {"title": "2. Basic Approach Design", "description": "Outline the simplest workable approach, including the components involved and the sequence in which they should be built. Keep the design practical and focused on getting a clear implementation path.", "estimated_hours": max(2, estimated_hours * 0.14)},
        {"title": "3. Intermediate Core Build", "description": "Implement the primary logic or feature behavior, making sure the task works end to end at a functional level. This should establish the foundation before deeper refinement begins.", "estimated_hours": max(4, estimated_hours * 0.28)},
        {"title": "4. Intermediate Validation", "description": "Add the basic checks, guardrails, and error handling needed to keep the implementation stable. Validate the main path and a few important edge cases so the work is dependable.", "estimated_hours": max(2, estimated_hours * 0.18)},
        {"title": "5. Advanced Refinement", "description": "Improve the implementation with stronger tests, more complete behavior coverage, and better resilience. Tighten any weak points that could cause issues under real usage or future changes.", "estimated_hours": max(2, estimated_hours * 0.18)},
        {"title": "6. Advanced Documentation and Handoff", "description": "Document the completed solution, explain how it works, and note any assumptions, limitations, or maintenance needs. Make the result easy to understand, reuse, and extend.", "estimated_hours": max(1, estimated_hours * 0.12)},
    ])
    
    return {
        "task_id": task.get("_id") or task.get("id"),
        "task_title": task.get("title", "Task"),
        "estimated_hours": estimated_hours,
        "sub_tasks": sub_tasks,
        "total_sub_task_hours": sum(st.get("estimated_hours", 0) for st in sub_tasks)
    }


async def generate_related_tasks_with_llm(reference_task: Dict, count: int = 4) -> List[Dict]:
    """Generate multiple related tasks based on a reference task using the local Ollama model
    
    Args:
        reference_task: The reference task containing title and description
        count: Number of related tasks to generate (default: 4, max: 8)
    
    Returns:
        List of generated related tasks with same format as reference task
    """
    
    # Limit count to prevent excessive generation
    count = min(max(1, count), 8)
    
    task_title = reference_task.get("title", "Task")
    task_description = reference_task.get("description", "")
    task_priority = reference_task.get("priority", "medium")
    task_estimated_hours = reference_task.get("estimated_hours", 12)
    
    system_prompt = f"""You are PRAXIS, the official AI Support Agent, and an expert project manager specializing in breaking down tasks and generating related subtasks.

Your task is to generate {count} related and complementary tasks based on a reference task.

CRITICAL GENERATION RULES:
1. Each task should be COMPLEMENTARY to the reference task (not duplicates)
2. Tasks should cover different aspects, dependencies, or related features
3. Each task must have a SHORT TITLE (4-8 words, <=60 characters) that is DIFFERENT from other tasks
4. Each task must have a LONG DESCRIPTION (100-160 words) with specific details
5. Related tasks should have SIMILAR or DEPENDENT priority levels
6. Estimated hours should vary but be realistic for complexity
7. Tasks can be prerequisites, follow-ups, or sidebars to the reference task
8. All tasks should contribute to the overall project goal

TASK STRUCTURE:
- "title": Short, specific, unique task name (4-8 words)
- "description": Detailed description with scope and deliverables (100-160 words, DO NOT repeat the title)
- "priority": high/medium/low
- "estimated_hours": Realistic effort estimate (4-120)
- "dependencies": List of tasks this depends on (initially empty list is fine)

JSON OUTPUT FORMAT (MUST BE VALID):
[
    {{
        "title": "Unique Task Title Here",
        "description": "Comprehensive description with specific details, scope, acceptance criteria, and deliverables...",
        "priority": "high|medium|low",
        "estimated_hours": 12,
        "dependencies": []
    }}
]

⚠️ CRITICAL REQUIREMENTS:
- Generate EXACTLY {count} tasks
- Each task title MUST be unique and different from others
- Task descriptions MUST be 100-160 words and NOT repeat the title
- All JSON keys and string values must use double quotes
- No markdown code blocks - pure JSON only
- Return ONLY the JSON array, no other text"""

    user_prompt = f"""Generate {count} related and complementary tasks based on this reference task:

REFERENCE TASK:
Title: {task_title}
Description: {task_description}
Priority: {task_priority}
Estimated Hours: {task_estimated_hours}

The new tasks should be:
1. Related to the reference task's domain and objectives
2. Complementary (covering different aspects, dependencies, or prerequisites)
3. Following similar quality and formatting standards
4. Each with unique, specific titles (4-8 words each)
5. Each with detailed descriptions (100-160 words), not repeating titles

Generate exactly {count} diverse, actionable tasks that would work well together with the reference task in a project plan."""

    logger.info(f"Generating {count} related tasks for reference task: {task_title}")
    
    try:
        tasks_data = await client.generate_json_completion(
            messages=[
                {
                    "role": "system", 
                    "content": system_prompt
                },
                {
                    "role": "user", 
                    "content": user_prompt
                }
            ],
            temperature=0.5,  # Slightly higher than base generation for variety
            max_tokens=2500
        )
        if isinstance(tasks_data, dict):
            tasks_data = tasks_data.get("tasks") or tasks_data.get("related_tasks") or [tasks_data]
        result = tasks_data if isinstance(tasks_data, list) else [tasks_data]
        result = [task for task in result if isinstance(task, dict)]
        
        # Ensure we return exactly the requested count
        return result[:count]
        
    except Exception as e:
        logger.warning(f"Error generating related tasks with LLM: {e}")
        # Fallback: Generate simple related tasks
        return _generate_fallback_related_tasks(reference_task, count)


def _generate_fallback_related_tasks(reference_task: Dict, count: int) -> List[Dict]:
    """Generate fallback related tasks when LLM is unavailable"""
    
    title = reference_task.get("title", "Task")
    hours = reference_task.get("estimated_hours", 12)
    priority = reference_task.get("priority", "medium")
    
    # Define task templates for different types of related tasks
    task_templates = [
        {
            "type": "testing",
            "title_template": "Test and Validate {area}",
            "description_template": "Create comprehensive test suite for {area}. Define test cases covering happy path, edge cases, and error scenarios. Write unit tests, integration tests, and manual testing procedures. Document test results, coverage metrics, and any identified issues. Ensure {area} meets quality standards and is production-ready. Include regression testing to verify no existing functionality is broken. Create test documentation for future maintenance and CI/CD pipeline integration."
        },
        {
            "type": "documentation",
            "title_template": "Document {area} Implementation",
            "description_template": "Create comprehensive documentation for {area}. Write technical documentation explaining architecture, design decisions, and implementation details. Create user guides and API documentation if applicable. Document configuration options, setup procedures, and deployment instructions. Create troubleshooting guides and FAQ sections. Include code examples and usage scenarios. Ensure documentation is clear, complete, and maintainable for future team members."
        },
        {
            "type": "optimization",
            "title_template": "Optimize and Refine {area}",
            "description_template": "Performance optimization and refinement of {area}. Analyze current implementation for bottlenecks and inefficiencies. Optimize database queries, caching strategies, and API response times. Refactor code for maintainability and clarity. Reduce technical debt and improve code quality. Conduct code reviews and implement best practices. Profile application performance under various load conditions. Generate performance reports and optimization recommendations."
        },
        {
            "type": "security",
            "title_template": "Security Hardening for {area}",
            "description_template": "Implement security measures and hardening for {area}. Conduct security audit and threat modeling. Identify and fix security vulnerabilities. Implement authentication and authorization controls if needed. Add input validation and sanitization. Configure security headers and protect against common attacks. Implement rate limiting and DDoS protection if applicable. Create security audit trail and logging. Document security assumptions and constraints."
        },
        {
            "type": "integration",
            "title_template": "Integrate {area} with Other Systems",
            "description_template": "Integrate {area} with dependent systems and services. Define integration points and APIs required. Implement data synchronization mechanisms if needed. Handle error cases and timeouts in integrations. Implement retry logic and fallback mechanisms. Test integration under various network conditions. Monitor integration health and performance. Document integration specifications and deployment dependencies. Create integration tests covering all integration points."
        },
        {
            "type": "deployment",
            "title_template": "Deployment and Release of {area}",
            "description_template": "Prepare {area} for production deployment. Create deployment scripts and automation. Set up staging environment for pre-release testing. Plan rollout strategy including rollback procedures. Document deployment steps and configuration requirements. Prepare operations runbook for production support. Set up monitoring and alerting for production. Create go-live checklist and post-deployment validation steps. Plan for scaling and future maintenance."
        },
        {
            "type": "enhancement",
            "title_template": "Enhance {area} with Advanced Features",
            "description_template": "Add advanced features and enhancements to {area}. Identify high-value feature requests and improvements. Design new functionality aligned with existing architecture. Implement additional capabilities that users have requested. Add configuration options for customization. Improve user experience based on feedback. Ensure new features integrate seamlessly with existing code. Create feature documentation and release notes. Gather metrics on feature adoption."
        },
        {
            "type": "monitoring",
            "title_template": "Setup Monitoring and Logging for {area}",
            "description_template": "Implement comprehensive monitoring and logging for {area}. Set up application metrics and KPI tracking. Configure log aggregation and analysis. Create dashboards for real-time monitoring. Set up alerts for critical errors and performance degradation. Implement distributed tracing for debugging. Create runbooks for common issues and incidents. Monitor resource utilization and cost optimization. Document monitoring strategy and alerting thresholds."
        }
    ]
    
    # Generate tasks based on templates
    related_tasks = []
    templates_to_use = task_templates[:count] if count <= len(task_templates) else task_templates * ((count // len(task_templates)) + 1)
    
    for i, template in enumerate(templates_to_use[:count]):
        # Customize based on reference task
        area = title.lower()
        
        # Adjust priority based on task type
        task_priority = priority
        if template["type"] in ["security", "testing"]:
            # Security and testing usually have high importance
            task_priority = "high" if priority != "low" else "medium"
        elif template["type"] in ["documentation", "monitoring"]:
            task_priority = priority
        
        # Estimate hours based on reference task and type
        if template["type"] == "testing":
            est_hours = int(hours * 0.8)
        elif template["type"] == "documentation":
            est_hours = int(hours * 0.5)
        elif template["type"] == "security":
            est_hours = int(hours * 0.6)
        elif template["type"] == "optimization":
            est_hours = int(hours * 0.4)
        elif template["type"] == "integration":
            est_hours = int(hours * 1.0)
        elif template["type"] == "deployment":
            est_hours = int(hours * 0.5)
        elif template["type"] == "enhancement":
            est_hours = int(hours * 0.9)
        else:  # monitoring
            est_hours = int(hours * 0.4)
        
        est_hours = max(4, est_hours)  # Minimum 4 hours
        
        task_title = template["title_template"].format(area=title)
        task_description = template["description_template"].format(area=title)
        
        related_tasks.append({
            "title": task_title,
            "description": task_description,
            "priority": task_priority,
            "estimated_hours": est_hours,
            "dependencies": [title],  # Depends on reference task
        })
    
    return related_tasks[:count]
