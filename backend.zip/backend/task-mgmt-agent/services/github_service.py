# github_service.py
import httpx
from datetime import datetime, timezone
from typing import List, Dict, Optional, Any
from config.settings import GITHUB_TOKEN

class GitHubService:
    def __init__(self):
        self.token = GITHUB_TOKEN
        self.headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github.v3+json"
        }
    
    async def fetch_commits(self, username: str, repo: str, since: Optional[datetime] = None) -> List[Dict]:
        """Fetch GitHub commits for a repository"""
        url = f"https://api.github.com/repos/{username}/{repo}/commits"
        
        params = {}
        if since:
            params["since"] = since.isoformat()
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers, params=params)
                response.raise_for_status()
                commits_data = response.json()
                
                commits = []
                for commit_data in commits_data[:20]:  # Limit to 20 recent commits
                    commit = await self._process_commit(client, username, repo, commit_data)
                    commits.append(commit)
                
                return commits
                
            except Exception as e:
                print(f"Error fetching GitHub commits: {e}")
                return []

    async def fetch_commit_by_sha(self, username: str, repo: str, sha: str) -> Optional[Dict[str, Any]]:
        """Fetch a single GitHub commit by SHA and normalize to our commit schema."""
        sha = (sha or "").strip()
        if not sha:
            return None

        url = f"https://api.github.com/repos/{username}/{repo}/commits/{sha}"
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers)
                if response.status_code == 404:
                    return None
                response.raise_for_status()
                detail_data = response.json() or {}

                commit_obj = detail_data.get("commit") or {}
                author_obj = commit_obj.get("author") or {}
                committer_obj = commit_obj.get("committer") or {}
                date_str = author_obj.get("date") or committer_obj.get("date")

                timestamp: datetime
                if isinstance(date_str, str) and date_str:
                    try:
                        timestamp = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                    except Exception:
                        timestamp = datetime.now(timezone.utc)
                else:
                    timestamp = datetime.now(timezone.utc)

                files = detail_data.get("files")
                files_changed: List[str] = []
                if isinstance(files, list):
                    for f in files:
                        if isinstance(f, dict) and isinstance(f.get("filename"), str):
                            files_changed.append(f["filename"])

                stats = detail_data.get("stats")
                additions = 0
                deletions = 0
                if isinstance(stats, dict):
                    additions = int(stats.get("additions") or 0)
                    deletions = int(stats.get("deletions") or 0)

                author_name = None
                if isinstance(author_obj, dict):
                    author_name = author_obj.get("name")
                if not author_name and isinstance(detail_data.get("author"), dict):
                    author_name = detail_data.get("author", {}).get("login")

                return {
                    "commit_sha": detail_data.get("sha") or sha,
                    "message": (commit_obj.get("message") if isinstance(commit_obj, dict) else None) or "",
                    "author": author_name or "unknown",
                    "timestamp": timestamp,
                    "files_changed": files_changed,
                    "additions": additions,
                    "deletions": deletions,
                    # Helpful for UIs that want to deep-link to GitHub
                    "url": detail_data.get("html_url") or None,
                }
            except Exception as e:
                print(f"Error fetching GitHub commit {sha}: {e}")
                return None
    
    async def _process_commit(self, client: httpx.AsyncClient, username: str, repo: str, commit_data: Dict) -> Dict:
        """Process individual commit data"""
        commit = {
            "commit_sha": commit_data["sha"],
            "message": commit_data["commit"]["message"],
            "author": commit_data["commit"]["author"]["name"],
            "timestamp": datetime.fromisoformat(
                commit_data["commit"]["author"]["date"].replace("Z", "+00:00")
            ),
            "files_changed": [],
            "additions": 0,
            "deletions": 0
        }
        
        # Get detailed commit info for file changes
        try:
            detail_response = await client.get(
                f"https://api.github.com/repos/{username}/{repo}/commits/{commit_data['sha']}",
                headers=self.headers
            )
            if detail_response.status_code == 200:
                detail_data = detail_response.json()
                commit["files_changed"] = [f["filename"] for f in detail_data.get("files", [])]
                commit["additions"] = detail_data.get("stats", {}).get("additions", 0)
                commit["deletions"] = detail_data.get("stats", {}).get("deletions", 0)
        except:
            pass  # If detailed info fails, just use basic commit info
        
        return commit
    
    async def validate_repo(self, username: str, repo: str) -> bool:
        """Check if repository exists and is accessible"""
        url = f"https://api.github.com/repos/{username}/{repo}"
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers)
                return response.status_code == 200
            except:
                return False

# Create service instance
github_service = GitHubService()