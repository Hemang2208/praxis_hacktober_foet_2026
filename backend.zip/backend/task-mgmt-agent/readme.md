# Task Management Agent

Handles all task and project CRUD operations, GitHub integration, and dashboard stats.

**Port:** 8003

## What it does

- Full task lifecycle — create, update, assign, track status
- Project management with milestone tracking
- GitHub PR linking and sync
- Dashboard stats and analytics
- Related task generation via AI

## Key files

| File | Purpose |
|---|---|
| `main.py` | FastAPI app setup |
| `routes.py` | All route handlers |
| `models.py` | Pydantic models |
| `database.py` | MongoDB connection |
| `dashboard_service.py` | Stats and analytics aggregation |
| `github_controller.py` | GitHub API integration |
| `utils.py` | Shared helpers |
| `config/` | Settings and configuration |

## Main endpoints

```
GET/POST   /api/v1/tasks/              — list / create tasks
GET/PUT    /api/v1/tasks/{id}          — get / update task
DELETE     /api/v1/tasks/{id}          — delete task
GET        /api/v1/projects/           — list projects
POST       /api/v1/tasks/generate-related  — AI-generated related tasks
GET        /api/v1/dashboard/stats     — dashboard metrics
```

## Env vars

```
MONGODB_URI=
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5-coder:latest
GITHUB_TOKEN=
JWT_SECRET_KEY=
```

## Running locally

```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8003
```

## Tests

```bash
cd tests
pytest test_related_tasks.py -v
```

## Docs

- `MODELS_README.md` — full model reference with field descriptions
- `readme.md` — quick start and usage guide
