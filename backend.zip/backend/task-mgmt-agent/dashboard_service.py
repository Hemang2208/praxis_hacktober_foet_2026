# dashboard_service.py
from typing import Dict, List, Any
from motor.motor_asyncio import AsyncIOMotorDatabase

from database import get_database
from services.task_service import task_service
from github_controller import github_controller
from utils import convert_objectid

class DashboardService:
    def __init__(self):
        self.db = None
    
    def get_db(self) -> AsyncIOMotorDatabase:
        """
        Get the database connection.
        Raises an exception if the connection is unavailable to satisfy type checkers.
        """
        if self.db is None:
            self.db = get_database()
        
        # Strict Pylance check: Raise exception if still None
        if self.db is None:
            raise Exception("Database connection is not initialized")
            
        return self.db
    
    async def get_project_dashboard(self, project_id: str) -> Dict[str, Any]:
        """Get comprehensive dashboard data for a project"""
        
        db = self.get_db()
        
        # Get project statistics
        statistics = await task_service.get_project_statistics(db, project_id)
        
        # Get all tasks
        tasks = await task_service.get_project_tasks(db, project_id)
        
        # Get recent commits
        recent_commits = await github_controller.get_recent_commits(project_id)
        
        # Get recent progress updates
        recent_progress = await self._get_recent_progress(project_id)
        
        # Get commit statistics
        commit_stats = await github_controller.get_commit_stats(project_id)
        
        # Calculate distribution
        task_distribution = self._get_task_distribution(tasks)
        
        # Get timeline
        progress_timeline = await self._get_progress_timeline(project_id)
        
        dashboard_data = {
            "project_id": project_id,
            "statistics": statistics,
            "commit_stats": commit_stats,
            "tasks": tasks,
            "recent_commits": recent_commits,
            "recent_progress": recent_progress,
            "task_distribution": task_distribution,
            "progress_timeline": progress_timeline
        }
        
        return dashboard_data
    
    async def _get_recent_progress(self, project_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent progress updates for the project"""
        db = self.get_db()
        
        # Get task IDs for this project
        tasks = await task_service.get_project_tasks(db, project_id)
        task_ids = [task["id"] for task in tasks if task.get("id")]
        
        if not task_ids:
            return []
        
        # Get recent progress updates
        cursor = db.progress_tracking.find(
            {"task_id": {"$in": task_ids}}
        ).sort("timestamp", -1).limit(limit)
        
        progress_updates = await cursor.to_list(length=limit)
        
        # Add task titles to progress updates
        task_dict = {task["id"]: task["title"] for task in tasks}
        for update in progress_updates:
            task_id = update.get("task_id")
            update["task_title"] = task_dict.get(task_id, "Unknown Task")
        
        return convert_objectid(progress_updates)
    
    def _get_task_distribution(self, tasks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate task distribution by status and priority"""
        status_distribution = {}
        priority_distribution = {}
        
        for task in tasks:
            status = task.get("status", "unknown")
            priority = task.get("priority", "medium")
            
            status_distribution[status] = status_distribution.get(status, 0) + 1
            priority_distribution[priority] = priority_distribution.get(priority, 0) + 1
        
        # CRITICAL: This return must be OUTSIDE the 'for' loop.
        # If it is inside, empty 'tasks' lists will cause the function to return None.
        return {
            "by_status": status_distribution,
            "by_priority": priority_distribution
        }
    
    async def _get_progress_timeline(self, project_id: str, limit: int = 30) -> List[Dict[str, Any]]:
        """Get progress timeline for the project"""
        db = self.get_db()
        
        # Get task IDs for this project
        tasks = await task_service.get_project_tasks(db, project_id)
        task_ids = [task["id"] for task in tasks if task.get("id")]
        
        if not task_ids:
            return []
        
        # Get progress timeline
        cursor = db.progress_tracking.find(
            {"task_id": {"$in": task_ids}}
        ).sort("timestamp", 1).limit(limit)
        
        timeline = await cursor.to_list(length=limit)
        
        # Add task information
        task_dict = {task["id"]: task for task in tasks}
        for item in timeline:
            task_id = item.get("task_id")
            task = task_dict.get(task_id, {})
            item["task_title"] = task.get("title", "Unknown Task")
            item["task_priority"] = task.get("priority", "medium")
        
        return convert_objectid(timeline)
    
    async def get_summary(self, project_id: str) -> Dict[str, Any]:
        """Get a quick project summary"""
        # FIX: Ensure we get the DB here to pass to services if needed
        db = self.get_db()
        
        # Get statistics passing the required DB argument
        statistics = await task_service.get_project_statistics(db, project_id)
        
        # Get commit stats
        commit_stats = await github_controller.get_commit_stats(project_id)
        
        # Use .get() for safety to avoid KeyErrors
        return {
            "project_id": project_id,
            "completion_percentage": statistics.get("completion_percentage", 0),
            "total_tasks": statistics.get("total_tasks", 0),
            "total_commits": commit_stats.get("total_commits", 0),
            "hours_spent": statistics.get("total_actual_hours", 0),
            "estimated_hours": statistics.get("total_estimated_hours", 0)
        }

# Create service instance
dashboard_service = DashboardService()