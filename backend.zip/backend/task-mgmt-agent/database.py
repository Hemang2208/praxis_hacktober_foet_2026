# database.py
import motor.motor_asyncio
from config.settings import MONGODB_URI, DATABASE_NAME
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

class Database:
    client: Optional[AsyncIOMotorClient] = None
    database: Optional[AsyncIOMotorDatabase] = None

# Initialize database connection
async def connect_db():
    try:
        Database.client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_URI)
        # The line below correctly assigns the database object
        Database.database = Database.client[DATABASE_NAME]
        
        # Create indexes for performance
        await create_indexes()
        print("Connected to MongoDB")
    except Exception as e:
        print(f"Failed to connect to MongoDB: {e}")
        # Ensure client and database are explicitly set to None on failure
        Database.client = None
        Database.database = None

async def disconnect_db():
    if Database.client:
        await Database.client.close()
        print("Disconnected from MongoDB")

async def create_indexes():
    """Create database indexes for better performance"""
    # This check prevents the 'None' error
    if Database.database is not None:
        db = Database.database
        
        # Tasks collection indexes
        await db.tasks.create_index("project_id")
        await db.tasks.create_index("status")
        await db.tasks.create_index("assigned_to")
        
        # Progress tracking indexes
        await db.progress_tracking.create_index("task_id")
        await db.progress_tracking.create_index("timestamp")
        
        # Task assignments indexes
        await db.task_assignments.create_index("task_id")
        await db.task_assignments.create_index("user_id")
        await db.task_assignments.create_index("assignedAt")
        
        # GitHub commits indexes
        await db.github_commits.create_index([("project_id", 1), ("timestamp", -1)])
        await db.github_commits.create_index("commitSha")
        
        # Projects collection indexes
        await db.projects.create_index("user")
        await db.projects.create_index("team_members.user")
        await db.projects.create_index("resources.user")
    else:
        print("Database connection not available. Skipping index creation.")

def get_database():
    return Database.database

async def get_database_validated():
    """Get database with validation - raises HTTPException if unavailable"""
    from fastapi import HTTPException
    
    db = Database.database
    if db is None:
        raise HTTPException(
            status_code=503,
            detail="Database connection unavailable. Please try again later."
        )
    return db