# config.py
import os
from dotenv import load_dotenv

load_dotenv()

# MongoDB Configuration
MONGODB_URI = os.getenv("MONGODB_URI")
if not MONGODB_URI:
    raise ValueError("MONGODB_URI is not set in environment variables. Please configure it in .env file.")
DATABASE_NAME = os.getenv("DATABASE_NAME", "praxis-aipm")

# GitHub Configuration
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

# App Configuration
API_VERSION = "1.0.0"
DEBUG = os.getenv("DEBUG", "False").lower() == "true"