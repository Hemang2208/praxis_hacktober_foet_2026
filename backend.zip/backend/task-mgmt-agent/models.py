# models.py
from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import List, Optional, Dict, Any
from bson import ObjectId


class SubTask(BaseModel):
    """Sub-task model.

    Notes:
    - We allow extra fields so the frontend can persist stable IDs and timestamps.
    - Stored Mongo documents may already contain additional keys (e.g. `completed`).
    """

    model_config = ConfigDict(extra="allow")

    id: Optional[str] = None
    _id: Optional[str] = None  # MongoDB ObjectId as string
    title: str
    description: str
    estimated_hours: int = 1
    status: str = "pending"
    completed: Optional[bool] = None
    created_at: Optional[datetime] = None


class Comment(BaseModel):
    _id: Optional[str] = None
    user_id: str
    message: str
    created_at: Optional[datetime] = None


class Author(BaseModel):
    id: str
    name: str
    avatar: str = ""


class Note(BaseModel):
    _id: Optional[str] = None
    content: str
    created_at: Optional[datetime] = None
    parent_id: Optional[str] = None
    is_deleted: bool = False
    author: Author


class Attachment(BaseModel):
    _id: Optional[str] = None
    name: str
    url: str
    type: str
    size: int

class TimeTracking(BaseModel):
    estimated: int = 0  # in hours
    logged: int = 0  # in hours
    remaining: int = 0  # in hours


class Task(BaseModel):
    id: Optional[str] = None
    project_id: Optional[str] = None
    project: Optional[str] = None  # Backward compatibility - ObjectId as string
    title: str
    description: str
    status: str = "todo"  # todo, in-progress, completed, blocked
    priority: str = "medium"  # low, medium, high
    due_date: Optional[datetime] = None
    assigned_to: Optional[str] = None
    tags: List[str] = []
    sub_tasks: List[SubTask] = []
    comments: List[Comment] = []
    notes: List[Note] = []
    attachments: List[Attachment] = []
    time_tracking: Optional[TimeTracking] = None
    dependencies: List[str] = []
    completed_at: Optional[datetime] = None
    linked_pr_id: Optional[str] = None
    linked_pull_request: Optional[str] = None  # ObjectId as string
    ai_feedback: Optional[str] = None
    has_feedback: bool = False
    feedback_status: Optional[str] = "pending"  # pending, ready, reviewed
    feedback_notification_sent: bool = False
    is_deleted: bool = False
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    # Legacy fields for backward compatibility
    estimated_hours: Optional[int] = None
    actual_hours: Optional[int] = None


class TaskCreate(BaseModel):
    project_id: Optional[str] = None
    title: str
    description: str
    status: str = "todo"
    priority: str = "medium"
    due_date: Optional[datetime] = None
    assigned_to: Optional[str] = None
    tags: List[str] = []
    dependencies: List[str] = []
    sub_tasks: List[SubTask] = []
    comments: List[Comment] = []
    notes: List[Note] = []
    attachments: List[Attachment] = []
    time_tracking: Optional[TimeTracking] = None
    linked_pr_id: Optional[str] = None
    linked_pull_request: Optional[str] = None
    ai_feedback: Optional[str] = None
    has_feedback: bool = False
    feedback_status: Optional[str] = "pending"
    is_deleted: bool = False
    # Legacy fields for backward compatibility
    estimated_hours: Optional[int] = None

class ProgressUpdate(BaseModel):
    task_id: str
    status: str
    hours_worked: int = 0
    notes: Optional[str] = None

class GitHubCommit(BaseModel):
    commit_sha: str
    message: str
    author: str
    timestamp: datetime
    files_changed: List[str] = []
    additions: int = 0
    deletions: int = 0

class TaskAssignment(BaseModel):
    task_id: str
    user_id: str  # Single user for backward compatibility
    user_ids: Optional[List[str]] = None  # Multiple users for new functionality
    notes: Optional[str] = None

class ProjectDashboard(BaseModel):
    project_id: str
    statistics: Dict
    tasks: List[Task]
    recent_commits: List[Dict]
    recent_progress: List[Dict]


class AssignedUserResponse(BaseModel):
    user: Optional[Dict[str, Any]] = None
    message: Optional[str] = None