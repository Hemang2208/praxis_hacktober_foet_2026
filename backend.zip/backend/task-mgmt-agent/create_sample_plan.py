#!/usr/bin/env python3
"""
Script to create a sample project plan for testing
"""
import asyncio
import sys
import os
from datetime import datetime, timezone

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database import connect_db, disconnect_db, get_database
from utils import get_current_time

async def create_sample_project_plan():
    """Create a sample project plan"""
    
    # Connect to database
    await connect_db()
    db = get_database()
    
    if  db is not None:
        print("Failed to connect to database")
        return
    
    project_id = "68babc78331da3bf1513dd52"  # Your project ID
    
    # Sample project plan data
    plan_data = {
        "project_id": project_id,
        "title": "Task Manager Application",
        "description": "A comprehensive task planning and tracking system with LLM integration",
        "objectives": [
            "Create a user-friendly task management interface",
            "Implement AI-powered task generation",
            "Integrate with GitHub for commit tracking",
            "Provide real-time progress monitoring",
            "Enable team collaboration features"
        ],
        "requirements": [
            "FastAPI backend with async support",
            "MongoDB for data persistence",
            "Ollama integration for LLM features",
            "GitHub API integration",
            "RESTful API design",
            "Docker containerization"
        ],
        "technologies": [
            "Python 3.11",
            "FastAPI",
            "MongoDB",
            "Motor (async MongoDB driver)",
            "Ollama API",
            "GitHub API",
            "Docker",
            "Uvicorn"
        ],
        "timeline": {
            "start_date": "2025-09-16",
            "estimated_duration": "4 weeks",
            "milestones": [
                "Week 1: Core API development",
                "Week 2: Database integration",
                "Week 3: LLM and GitHub integration",
                "Week 4: Testing and deployment"
            ]
        },
        "created_at": get_current_time(),
        "updated_at": get_current_time()
    }
    
    try:
        # Check if plan already exists
        existing_plan = await db.project_plans.find_one({"project_id": project_id})
        if existing_plan:
            print(f"Project plan for {project_id} already exists")
            print("Existing plan:", existing_plan)
            return
        
        # Insert the project plan
        result = await db.project_plans.insert_one(plan_data)
        print(f"✅ Created project plan for project {project_id}")
        print(f"Plan ID: {result.inserted_id}")
        print("Plan data:", plan_data)
        
    except Exception as e:
        print(f"❌ Error creating project plan: {e}")
    
    finally:
        await disconnect_db()

if __name__ == "__main__":
    asyncio.run(create_sample_project_plan())
