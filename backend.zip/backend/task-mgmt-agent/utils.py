# utils.py
from bson import ObjectId
from datetime import datetime, timezone
from typing import Any

def convert_objectid(obj: Any) -> Any:
    """Convert ObjectId to string for JSON serialization"""
    if isinstance(obj, ObjectId):
        return str(obj)
    elif isinstance(obj, dict):
        return {k: convert_objectid(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_objectid(item) for item in obj]
    elif isinstance(obj, datetime):
        return obj.isoformat()
    return obj

def is_valid_object_id(obj_id: str) -> bool:
    """Check if string is a valid ObjectId"""
    return ObjectId.is_valid(obj_id)

def get_current_time():
    """Get current UTC datetime"""
    return datetime.now(timezone.utc)

def calculate_completion_percentage(completed_tasks: int, total_tasks: int) -> float:
    """Calculate completion percentage"""
    if total_tasks == 0:
        return 0.0
    return round((completed_tasks / total_tasks) * 100, 2)