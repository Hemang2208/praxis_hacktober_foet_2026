# routes.py
from fastapi import APIRouter, HTTPException, Query, Depends, Body
from typing import Optional, Dict, Any, List
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from pydantic import BaseModel

from models import TaskCreate, ProgressUpdate, TaskAssignment, AssignedUserResponse
from services.task_service import task_service
from github_controller import github_controller
from dashboard_service import dashboard_service
from database import get_database
from utils import convert_objectid, get_current_time

# Create API router
router = APIRouter()


class SyncSelectedCommitsRequest(BaseModel):
    shas: List[str]

# Project Routes
@router.post("/projects/{project_id}/plan")
async def create_project_plan(
    project_id: str,
    plan_data: Dict,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Create a project plan"""
    try:
        # Check if plan already exists
        existing_plan = await task_service.get_project_plan(db, project_id)
        if existing_plan:
            raise HTTPException(status_code=400, detail="Project plan already exists")
        
        # Create new project plan using the service to preserve AI schema
        saved_plan = await task_service.create_project_plan(db, project_id, plan_data)
        
        return {
            "message": "Project plan created successfully",
            "plan": saved_plan
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating project plan: {str(e)}")

@router.get("/projects/{project_id}/plan")
async def get_project_plan(
    project_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
) -> Optional[Dict]:
    """Get project plan from database"""
    try:
        project_plan = await task_service.get_project_plan(db, project_id)
        if not project_plan:
            raise HTTPException(status_code=404, detail="Project plan not found")
        return project_plan
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching project plan: {str(e)}")

@router.post("/projects/{project_id}/generate-tasks")
async def generate_tasks(
    project_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Generate tasks for a project using LLM"""
    try:
        created_tasks = await task_service.generate_tasks(db, project_id)
        return {
            "message": f"Generated {len(created_tasks)} tasks",
            "tasks": created_tasks
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating tasks: {str(e)}")

@router.post("/projects/{project_id}/tasks/{task_id}/generate-related-tasks")
async def generate_related_tasks(
    project_id: str,
    task_id: str,
    count: int = 4,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Generate multiple related tasks based on a reference task.
    
    Takes a previously created task and generates complementary tasks that work well with it.
    Each generated task will have:
    - Short title (4-8 words)
    - Long description (100-160 words)
    - Priority, estimated hours, and dependencies
    
    Args:
        project_id: The project ID
        task_id: The reference task ID to base generation on
        count: Number of related tasks to generate (1-8, default: 4)
    
    Returns:
        List of generated related tasks in preview format (not yet persisted)
    """
    try:
        # Validate count parameter
        try:
            count = int(count)
        except (ValueError, TypeError):
            count = 4
        
        related_tasks = await task_service.generate_related_tasks(db, project_id, task_id, count)
        return {
            "message": f"Generated {len(related_tasks)} related tasks based on task {task_id}",
            "reference_task_id": task_id,
            "tasks": related_tasks
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating related tasks: {str(e)}")

# Task Routes
@router.get("/projects/{project_id}/tasks")
async def get_project_tasks(
    project_id: str,
    include_deleted: bool = False,
    include_notes: bool = True,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all tasks for a project"""
    try:
        tasks = await task_service.get_project_tasks(
            db,
            project_id,
            include_deleted=include_deleted,
            include_notes=include_notes,
        )
        return tasks
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching tasks: {str(e)}")

@router.post("/projects/{project_id}/tasks")
async def create_task(
    project_id: str,
    task: TaskCreate,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Create a new task for a project (overwrites any existing assignment if provided)"""
    try:
        created_task = await task_service.create_task(db, project_id, task)
        return {
            "message": "Task created successfully",
            "task": created_task
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating task: {str(e)}")

@router.get("/tasks")
async def get_tasks(
    include_deleted: bool = False,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all tasks"""
    try:
        tasks = await task_service.get_all_tasks(db, include_deleted)
        return {"tasks": tasks}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching tasks: {str(e)}")

@router.get("/tasks/{task_id}")
async def get_task(
    task_id: str,
    include_deleted: bool = False,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get single task by ID"""
    try:
        task = await task_service.get_task_by_id(db, task_id, include_deleted)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        return task
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching task: {str(e)}")

@router.patch("/tasks/{task_id}")
async def update_task(
    task_id: str,
    update_data: Dict,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Update task details"""
    try:
        # Validate database connection
        if db is None:
            raise HTTPException(status_code=503, detail="Database connection unavailable")
        
        updated_task = await task_service.update_task(db, task_id, update_data)
        if not updated_task:
            raise HTTPException(status_code=404, detail="Task not found or no changes made")
        return {
            "message": "Task updated successfully",
            "task": updated_task
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating task: {str(e)}")


@router.post("/tasks/{task_id}/breakdown")
async def breakdown_task(
    task_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Generate detailed breakdown/sub-tasks for a specific task.
    
    User only needs to provide task_id - the endpoint fetches the task
    and generates comprehensive sub-tasks using AI.
    This complements manual sub-task creation with intelligent suggestions.
    """
    try:
        result = await task_service.breakdown_task(db, task_id)
        return {
            "message": "Task breakdown generated successfully",
            "breakdown": result.get("breakdown"),
            "task": result.get("task"),
            "added_count": result.get("added_count", 0),
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating task breakdown: {str(e)}")


@router.post("/tasks/{task_id}/sub_tasks")
async def create_subtask(
    task_id: str,
    subtask_data: Dict[str, Any],
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    """Create (append) a subtask for a task.

    This avoids clients needing to PATCH the full `sub_tasks` array.
    """
    try:
        updated_task = await task_service.add_subtask(db, task_id, subtask_data)
        if not updated_task:
            raise HTTPException(status_code=404, detail="Task not found")
        return {
            "message": "Subtask created successfully",
            "task": updated_task,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating subtask: {str(e)}")


@router.get("/tasks/{task_id}/notes")
async def get_task_notes(
    task_id: str,
    include_deleted: bool = False,
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    """Get notes for a task (thread-capable: supports parent_id)."""
    try:
        result = await task_service.list_task_notes(db, task_id, include_deleted=include_deleted)
        if not result:
            raise HTTPException(status_code=404, detail="Task not found")
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching notes: {str(e)}")


@router.post("/tasks/{task_id}/notes")
async def add_task_note(
    task_id: str,
    note_data: Dict[str, Any],
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    """Add a note to a task."""
    try:
        content = note_data.get("content")
        parent_id = note_data.get("parent_id") or note_data.get("parent_id")
        author = note_data.get("author")

        note = await task_service.add_task_note(
            db,
            task_id,
            content=str(content) if content is not None else "",
            parent_id=str(parent_id) if parent_id else None,
            author=author if isinstance(author, dict) else None,
        )
        if not note:
            raise HTTPException(status_code=404, detail="Task not found")
        return {"success": True, "note": note}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error adding note: {str(e)}")


@router.patch("/tasks/{task_id}/notes")
async def update_task_note(
    task_id: str,
    note_data: Dict[str, Any],
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    """Update a note's content."""
    try:
        note_id = note_data.get("noteId") or note_data.get("note_id") or note_data.get("id")
        content = note_data.get("content")
        updated_note = await task_service.update_task_note(
            db,
            task_id,
            note_id=str(note_id) if note_id is not None else "",
            content=str(content) if content is not None else "",
        )
        if not updated_note:
            raise HTTPException(status_code=404, detail="Note not found")
        return {"success": True, "note": updated_note}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating note: {str(e)}")


@router.delete("/tasks/{task_id}/notes")
async def delete_task_note(
    task_id: str,
    noteId: str = Query(..., description="Note ID"),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    """Soft delete a note."""
    try:
        ok = await task_service.delete_task_note(db, task_id, noteId)
        if not ok:
            raise HTTPException(status_code=404, detail="Note not found")
        return {"success": True, "noteId": noteId}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting note: {str(e)}")

@router.delete("/tasks/{task_id}")
async def delete_task(
    task_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Soft delete a task"""
    try:
        success = await task_service.soft_delete_task(db, task_id)
        if not success:
            raise HTTPException(status_code=404, detail="Task not found")
        return {"message": "Task soft-deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting task: {str(e)}")

@router.put("/tasks/{task_id}/progress")
async def update_task_progress(
    task_id: str, 
    progress: ProgressUpdate,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Update task progress"""
    try:
        result = await task_service.update_task_progress(db, task_id, progress)
        if not result:
            raise HTTPException(status_code=404, detail="Task not found")
        # Keep backward compatibility: always include the original message.
        # Also include computed project progress/status when available.
        return {
            "message": "Task progress updated successfully",
            **result,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating task progress: {str(e)}")

@router.post("/tasks/{task_id}/assign/{user_id}")
async def assign_user_to_task(
    task_id: str,
    user_id: str,
    assignment_data: Dict = {},
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Assign a user to a task"""
    try:
        assignment = TaskAssignment(
            task_id=task_id,
            user_id=user_id,
            notes=assignment_data.get("notes", None)
        )
        
        success = await task_service.assign_user_to_task(db, task_id, assignment)
        if not success:
            raise HTTPException(status_code=404, detail="Task assignment failed")
        
        return {
            "message": "User assigned to task successfully",
            "task_id": task_id,
            "assigned_to": user_id
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error assigning user to task: {str(e)}")

# GitHub Routes
@router.post("/projects/{project_id}/sync-commits")
async def sync_github_commits(
    project_id: str, 
    username: str = Query(..., description="GitHub username"),
    repo: str = Query(..., description="Repository name")
):
    """Sync GitHub commits for a project"""
    try:
        result = await github_controller.sync_commits(project_id, username, repo)
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error syncing commits: {str(e)}")


@router.post("/projects/{project_id}/sync-selected-commits")
async def sync_selected_github_commits(
    project_id: str,
    payload: SyncSelectedCommitsRequest = Body(...),
    username: str = Query(..., description="GitHub username"),
    repo: str = Query(..., description="Repository name"),
):
    """Sync only selected GitHub commits (by SHA) for a project."""
    try:
        result = await github_controller.sync_selected_commits(
            project_id,
            username,
            repo,
            payload.shas,
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error syncing selected commits: {str(e)}",
        )

@router.get("/projects/{project_id}/commits")
async def get_project_commits(
    project_id: str, 
    limit: int = Query(50, ge=1, le=100, description="Number of commits to fetch")
):
    """Get GitHub commits for a project"""
    try:
        commits = await github_controller.get_project_commits(project_id, limit)
        return commits
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching commits: {str(e)}")

# Dashboard Routes
@router.get("/projects/{project_id}/dashboard")
async def get_project_dashboard(
    project_id: str
):
    """Get comprehensive dashboard data for a project"""
    try:
        dashboard_data = await dashboard_service.get_project_dashboard(project_id)
        return dashboard_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching dashboard data: {str(e)}")

@router.get("/projects/{project_id}/summary")
async def get_summary(
    project_id: str
):
    """Get project summary"""
    try:
        summary = await dashboard_service.get_summary(project_id)
        return summary
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching project summary: {str(e)}")

@router.get("/projects/{project_id}/statistics")
async def get_project_statistics(
    project_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get project statistics"""
    try:
        statistics = await task_service.get_project_statistics(db, project_id)
        return statistics
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching statistics: {str(e)}")

@router.get("/projects/{project_id}/members")
async def get_project_members(
    project_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get project members (team members and resources)"""
    try:
        members = await task_service.get_project_members(db, project_id)
        return {"members": members}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching project members: {str(e)}")

@router.get("/projects/{project_id}/assignable-members")
async def get_assignable_members(
    project_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get assignable project members with detailed validation info"""
    try:
        members = await task_service.get_project_members(db, project_id)
        
        # Provide detailed information about member validation
        assignable_members = []
        non_assignable_members = []
        
        for member in members:
            user_id = member.get("user", "").strip()
            name = member.get("name", "").strip()
            
            if user_id and len(user_id) >= 12 and name and len(name) > 1:
                assignable_members.append(member)
            else:
                non_assignable_members.append({
                    **member,
                    "validation_issues": {
                        "user_id_length": len(user_id) if user_id else 0,
                        "has_user_id": bool(user_id),
                        "name_length": len(name) if name else 0,
                        "has_name": bool(name)
                    }
                })
        
        return {
            "assignable_members": assignable_members,
            "non_assignable_members": non_assignable_members,
            "total_members": len(members),
            "assignable_count": len(assignable_members),
            "project_id": project_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching assignable members: {str(e)}")

@router.post("/projects/{project_id}/fix-members")
async def fix_project_members(
    project_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Fix project members by ensuring they have proper user IDs"""
    try:
        result = await task_service.fix_project_members(db, project_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fixing project members: {str(e)}")

@router.get("/tasks/assigned/{user_id}")
async def get_assigned_tasks(
    user_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get all tasks assigned to a specific user"""
    try:
        tasks = await task_service.get_assigned_tasks(db, user_id)
        return {"tasks": tasks}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching assigned tasks: {str(e)}")


@router.get("/tasks/{task_id}/assigned-user", response_model=AssignedUserResponse)
async def get_task_assigned_user_info(
    task_id: str,
    db: AsyncIOMotorDatabase = Depends(get_database)
):
    """Get full user info for the user assigned to a task (by `assigned_to` user id).

    Strategy:
    - Fetch the task, read `assigned_to` (or similar) field.
    - Try to fetch full user doc from `users` collection using ObjectId(_id).
    - Fallback to searching the parent project (`team_members` / `resources`) for a matching `user` field.
    - If nothing found, return the user_id with a not-found message.
    """
    try:
        task = await task_service.get_task_by_id(db, task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")

        # Look for common assignment fields
        user_id = task.get("assigned_to") or task.get("assigned")
        if not user_id:
            return {
                "user": None,
                "message": "Task has no assigned user"
            }

        # Try users, students, colleges, companies collections (covers all user models)
        user_doc = None
        try:
            user_id_str = str(user_id)
            if ObjectId.is_valid(user_id_str):
                user_oid = ObjectId(user_id_str)
                for coll_name in ("students", "colleges", "companies", "users"):
                    user_doc = await db[coll_name].find_one({"_id": user_oid})
                    if user_doc:
                        break
            else:
                for coll_name in ("students", "colleges", "companies", "users"):
                    user_doc = await db[coll_name].find_one({"user_id": user_id_str})
                    if user_doc:
                        break

            if user_doc:
                return {"user": convert_objectid(user_doc)}
        except Exception as e:
            # ignore and try project members fallback
            print(f"Error looking up user by ID {user_id}: {e}")
            user_doc = None

        # Fallback: try to find the user in the parent project's members
        project_id = task.get("project_id") or task.get("project_id") or task.get("project")
        if project_id:
            try:
                project = await db.projects.find_one({"_id": ObjectId(project_id)})
            except Exception:
                project = None

            if project:
                # search in team_members and resources
                for coll in ("team_members", "resources"):
                    for member in project.get(coll, []):
                        if str(member.get("user", "")) == str(user_id):
                            return {"user": convert_objectid(member)}

                # check project owner
                if str(project.get("user", "")) == str(user_id):
                    # try to return owner details from users collection if available
                    try:
                        owner = await db.users.find_one({"_id": ObjectId(user_id)})
                        if owner:
                            return {"user": convert_objectid(owner)}
                    except Exception:
                        pass

        # Nothing found
        return {
            "user": {"user_id": user_id},
            "message": "User details not found in `users` collection or project members"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching assigned user info: {str(e)}")