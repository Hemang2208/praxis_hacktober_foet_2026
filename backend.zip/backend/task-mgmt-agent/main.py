# main.py
import sys
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

# Add parent directory to sys.path to import shared
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from shared.cache_utils import cache_manager

from database import connect_db, disconnect_db
from routes import router
from config.settings import API_VERSION

# Lifespan manager for startup/shutdown events
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    await connect_db()
    await cache_manager.connect()
    yield
    # Shutdown
    await cache_manager.disconnect()
    await disconnect_db()

# Create FastAPI app
app = FastAPI(
    title="Task Planner Agent API",
    description="A comprehensive task planning and tracking system with LLM integration",
    version=API_VERSION,
    lifespan=lifespan
)

# Add CORS middleware
def _get_allowed_origins():
    """Read CORS origins from the environment and always allow local development."""
    configured = os.getenv("ALLOWED_ORIGINS", "")
    origins = [origin.strip() for origin in configured.split(",") if origin.strip()]
    for local in ("http://localhost:3000", "http://localhost:8000", "http://localhost"):
        if local not in origins:
            origins.append(local)
    return origins


app.add_middleware(
    CORSMiddleware,
    allow_origins=_get_allowed_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routes
app.include_router(router, prefix="/api/v1")

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Task Planner Agent API",
        "version": API_VERSION,
        "status": "running"
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    import os
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8003)), reload=True)